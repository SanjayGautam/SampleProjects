MDS Market Definition Systems 
========================================
1. As you have already checked out the project you need to do following.  
2. If project is not compiling with the latest maven , please check the settings.xml in your home folder. 
3. compare it with the settings.xml which is can be found in the folder path /src/mavens-settings/ 
4. compile the project in the command prompt it should compile. 
   Note: If it fails make sure that you take note of the error and if errors are related with Access Denied on certain repo URLS please run it again and again. 
         You should not get same error on the second run. you might still get AccessDenied but it would be on different dependency if that is the case please run it again. 
         this is happening because of the fact that CAISO internet breaks the connection after few minutes of download. it might take 10 of 15 trials before you can build this project.
5. If Project Compiles. You can import this project as the Maven Project. 
6. You need to define and map in project facets in properties/preferences two things. 
	a) JBoss-BPM-Server mostly control it externally.
	b) JBPM Runtime which is actually a place where you installed JBPM  <JBPM_INSTALL_HOME>\jbpm-6.2.0.Final-installer-full\runtime
		 i. Error Message  "Targeted Runtime Jboss-BPM-Server is not defined"
		    Fix : Add The Runtime and Select it in Project Facets in Properties of this project.  
	c) JPA  : Please configure the JPA Connections they were used for entity generations and other JPA help with comes out of the box.
	    i. Error Message "Currently Selected Library Provider is invalid" 
	      

package com.caiso.mds.dao.mds;

import java.util.Date;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktEvntDef;
import com.caiso.mds.entity.mds.MrktEvntHistory;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktPlanPK;
import com.caiso.mds.util.MdsBpmNexusConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MarketEventHistoryDaoTest {

    @Autowired
    private MdsMarketEventHistoryDao mdsMarketEventHistoryDao;

    @Autowired
    MdsBpmNexusConfig                mdsBpmNexusConfig;

    @Test
    public void testCreateMarketEventHistory() {
        MrktEvntHistory mrktEvntHistory = new MrktEvntHistory();

        mrktEvntHistory.setCreatedBy("Test");
        mrktEvntHistory.setCreatedDt(new Date());
        mrktEvntHistory.setMrktDate(new DateTime());

        MrktEvntDef mrktEvntDef = new MrktEvntDef();
        mrktEvntDef.setMrktEvntDefId(37);
        mrktEvntHistory.setMrktEvntDef(mrktEvntDef);

        MrktPlan mrktPlan = new MrktPlan();
        MrktPlanPK markPlanPK = new MrktPlanPK();
        markPlanPK.setMrktPlanId("0122");
        markPlanPK.setMrktRunId("098887");
        mrktPlan.setId(markPlanPK);
        mrktEvntHistory.setMrktPlan(mrktPlan);

        mrktEvntHistory.setMrktStatusHistoryId(3);
        mrktEvntHistory.setUpdatedBy("Tests");
        mrktEvntHistory.setUpdatedDt(new Date());

        mrktEvntHistory = mdsMarketEventHistoryDao.createMrktEvntHistory(mrktEvntHistory);

        Assert.assertEquals(1l, mrktEvntHistory.getMrktEvntHistoryId());

        /*
         * Assert.assertEquals("John Smith", member.getName());
         * Assert.assertEquals("john.smith@mailinator.com", member.getEmail());
         * Assert.assertEquals("2125551212", member.getPhoneNumber());
         */

    }

}

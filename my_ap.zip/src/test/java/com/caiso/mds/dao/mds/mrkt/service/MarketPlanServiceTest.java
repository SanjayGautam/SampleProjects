package com.caiso.mds.dao.mds.mrkt.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.dao.mds.MdsMarketDefinitionDao;
import com.caiso.mds.dao.mds.MdsMarketPlanDao;
import com.caiso.mds.dto.MarketDefintionDto;
import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.entity.mds.MrktDefinition;
import com.caiso.mds.exception.MdsBpmException;
import com.caiso.mds.mrkt.run.service.MarketPlanService;
import com.caiso.mds.mrkt.run.service.MarketPlanServiceHelper;
import com.caiso.mds.types.MarketType;
import com.caiso.mds.util.MarketPlanGenerator;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MarketPlanServiceTest {

    @InjectMocks
    @Autowired
    private MarketPlanService      marketPlanService;

    @Mock
    private MdsMarketDefinitionDao mdsMarketDefinitionDao;

    @Mock
    private MdsMarketPlanDao       mdsMarketPlanDao;

    @Mock
    List<MrktDefinition>           mrktDefinitions  = new ArrayList<MrktDefinition>();

    @Mock
    List<MarketDefintionDto>       mrkDefintionDtos = new ArrayList<MarketDefintionDto>();

    @Mock
    MarketPlanServiceHelper        marketPlanServiceHelper;

    @Mock
    MarketPlanGenerator            marketPlanGenerator;

    @Mock
    List<MarketPlanDto>            marketPlanDtos;

    @Before
    public void init() {

        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGenerateMarketPlansFromDamMarketType() {

        DateTime lastMarketDate = new DateTime();
        MarketDefintionDto md = new MarketDefintionDto();
        md.setMarketClass("");
        md.setMarketDesc("sdf");
        md.setMarketType("");
        md.setMarketDefinitionId("1");
        mrkDefintionDtos.add(md);

        when(mdsMarketPlanDao.getLastMarketPlanDateByMarketType(MarketType.DAM)).thenReturn(lastMarketDate);
        when(mdsMarketDefinitionDao.getMarketDefintionByMarketType(MarketType.DAM)).thenReturn(mrktDefinitions);
        when(marketPlanServiceHelper.populateMarketDefObject(mrktDefinitions)).thenReturn(mrkDefintionDtos);
        when(marketPlanGenerator.getMarketPlans(lastMarketDate.toDate(), MarketType.DAM, mrkDefintionDtos)).thenReturn(marketPlanDtos);

        marketPlanService.setNumberOfDaysToGenerateMarketPlans(30);
        try {
            marketPlanService.generateMarketPlanByMarketType(MarketType.DAM);
        } catch (MdsBpmException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void testGenerateMarketPlansFromDamMarketTypeWhenLastDateIsMoreThanEightDaysInFuture() {

        DateTime lastMarketDate = new DateTime();
        lastMarketDate = lastMarketDate.minusDays(9);

        MarketDefintionDto md = new MarketDefintionDto();
        md.setMarketClass("");
        md.setMarketDesc("sdf");
        md.setMarketType("");
        md.setMarketDefinitionId("1");
        mrkDefintionDtos.add(md);

        when(mdsMarketPlanDao.getLastMarketPlanDateByMarketType(MarketType.DAM)).thenReturn(lastMarketDate);
        when(mdsMarketDefinitionDao.getMarketDefintionByMarketType(MarketType.DAM)).thenReturn(mrktDefinitions);
        when(marketPlanServiceHelper.populateMarketDefObject(mrktDefinitions)).thenReturn(mrkDefintionDtos);
        when(marketPlanGenerator.getMarketPlans(lastMarketDate.toDate(), MarketType.DAM, mrkDefintionDtos)).thenReturn(marketPlanDtos);

        marketPlanService.setNumberOfDaysToGenerateMarketPlans(30);
        try {
            marketPlanService.generateMarketPlanByMarketType(MarketType.DAM);
        } catch (MdsBpmException e) {
            e.printStackTrace();
        }

    }

}

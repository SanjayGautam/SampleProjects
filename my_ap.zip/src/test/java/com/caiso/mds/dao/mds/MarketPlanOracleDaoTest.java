package com.caiso.mds.dao.mds;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.util.DateUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MarketPlanOracleDaoTest {

    @Autowired
    private MdsMarketPlanDao mdsMarketPlanDao;

    @Autowired
    private DateUtil         dateUtil;

    @Test
    public void testGetLastMarketDateGenerated() {

        DateTime actualDate = mdsMarketPlanDao.getLastMarketPlanDate();

        /*
         * Assert.assertEquals( "02072015",
         * dateUtil.convertDateToStringFormat(actualDate.toDate(),
         * DateUtil.PATTERN_MMddyyyy, TimeZone.getTimeZone("US\\Americas")));
         */

    }

    @Test
    public void testSavingMarketPlanObject() {

        // given
        List<MrktPlan> list = new ArrayList<MrktPlan>();

        // mdsMarketPlanDao.saveOrUpdateMrktPlans(mrktPlans);

    }

}

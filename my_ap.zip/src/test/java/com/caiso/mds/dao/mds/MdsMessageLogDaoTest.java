package com.caiso.mds.dao.mds;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MdsLog;
import com.caiso.mds.util.MdsBpmNexusConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MdsMessageLogDaoTest {

    @Autowired
    private MdsMessageLogDao mdsMessageLogDao;

    @Autowired
    MdsBpmNexusConfig        mdsBpmNexusConfig;

    @Test
    public void testCreateMdsLog() {
        MdsLog mdsLog = new MdsLog();

        mdsMessageLogDao.createMessageLogRecord(mdsLog);

        Assert.assertEquals(1l, mdsLog.getMdsLogId());

        /*
         * Assert.assertEquals("John Smith", member.getName());
         * Assert.assertEquals("john.smith@mailinator.com", member.getEmail());
         * Assert.assertEquals("2125551212", member.getPhoneNumber());
         */

    }

    @Test
    public void testGetNumberOfDaysFromPropertiesFile() {

        Integer days = mdsBpmNexusConfig.getNumberOfDaysToGenerateMarketPlans();

        Assert.assertEquals(100, days.intValue());

    }

}

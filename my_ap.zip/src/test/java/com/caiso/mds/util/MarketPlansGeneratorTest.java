/**
 * During the PDT period it will be 7:00 and PST period it will be 8:00 am
 * 
 * PLAN ID => YYYYMMDD + MarketPeriod
 * 
 * If MarketPeriod RUN ID ALSO CALLED AS ACTIVITY ID => ActivityID + YYYYMMDD + MarketPeriod
 * 
 * 00 = DAM Market Type 01 = RTM Market Type
 * 
 * Activity ID = 1 = B = MARKET <== Market Class
 * 
 * Activity ID = 2 = T = TRADES <== Market Class
 * 
 * Activity ID = 3 = C = CB <== Market Class
 * 
 * Activity ID = 4 = S = BASE <== Market Class
 * 
 * 
 * @throws Exception
 */

package com.caiso.mds.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.dto.MarketDefintionDto;
import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.types.MarketType;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MarketPlansGeneratorTest {

    @Autowired
    private MarketPlanGenerator marketPlanGenerator;

    private final static Logger logger = LoggerFactory.getLogger(MarketPlansGeneratorTest.class);

    @Autowired
    private DateUtil            dateUtil;

    @Test
    public void testGenerateMarketPlanForDamMarketForPDTPeriod() throws Exception {

        // Given
        String marketDateInString = "20150618";

        Date marketDate = dateUtil.createDateFromString(marketDateInString, DateUtil.PATTERN_yyyyMMdd, TimeZone.getTimeZone("US/Pacific"));
        String expectedMarketDateString = "20150618 07:00:00";
        String expectedPlanId = "15061800";

        MarketType marketType = MarketType.DAM;
        List<MarketDefintionDto> marketDefinitions = new ArrayList<MarketDefintionDto>();
        marketDefinitions = getMarketDAMMarketDefintions();

        // when
        List<MarketPlanDto> marketPlanDtos = marketPlanGenerator.getMarketPlans(marketDate, marketType, marketDefinitions);

        Assert.assertEquals(true, marketPlanDtos.size() == 1);
        Iterator<MarketDefintionDto> marketDefItr = marketDefinitions.iterator();

        // then check plan ids are generated for complete set of definition id
        for (MarketPlanDto actualMarketPlanDto : marketPlanDtos) {

            MarketDefintionDto marketDef = marketDefItr.next();

            String expectedRunId = marketDef.getMarketActivityId() + "150618" + "00";

            Assert.assertEquals(expectedPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());

            Assert.assertEquals(expectedMarketDateString,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), DateUtil.PATTERN_yyyyMMdd_HH_mm_ss, TimeZone.getTimeZone("GMT")));
            Assert.assertEquals("00", actualMarketPlanDto.getMarketHour());

        }

    }

    @Test
    public void testGenerateMarketPlanForDamMarketForPSTPeriod() throws Exception {

        String expectedMarketDateString_20141219 = "20141219 08:00:00";

        // Given
        Date marketDate = dateUtil.createDateFromString("20141219", DateUtil.PATTERN_yyyyMMdd, TimeZone.getTimeZone("US/Pacific"));

        MarketType marketType = MarketType.DAM;
        List<MarketDefintionDto> marketDefinitions = getMarketDAMMarketDefintions();

        // when
        List<MarketPlanDto> marketPlanDtos = marketPlanGenerator.getMarketPlans(marketDate, marketType, marketDefinitions);

        Assert.assertEquals(true, marketPlanDtos.size() == 1);
        Iterator<MarketDefintionDto> marketDefItr = marketDefinitions.iterator();
        MarketDefintionDto marketDef = marketDefItr.next();

        // then
        String expectedPlanId = "14121900";
        String expectedRunId = marketDef.getMarketActivityId() + "141219" + "00";

        // then check plan ids are generated for complete set of definition id
        for (MarketPlanDto actualMarketPlanDto : marketPlanDtos) {

            String marketDefId = marketDef.getMarketDefinitionId();

            Assert.assertEquals(expectedPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5l, actualMarketPlanDto.getMarketStatusTypeId());

            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            Assert.assertEquals(expectedMarketDateString_20141219,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), DateUtil.PATTERN_yyyyMMdd_HH_mm_ss, TimeZone.getTimeZone("GMT")));
            Assert.assertEquals("00", actualMarketPlanDto.getMarketHour());

        }

    }

    /**
     * 
     * @throws Exception
     */
    @Test
    public void testGenerateMarketPlanForRTMMarketForNormalDayBetweenShortDayStartAndLongDayPDT() throws Exception {

        // Given

        String dateString_20140619 = "20140619";
        String expectedDateString_140619 = "140619";
        Date marketDate = dateUtil.createDateFromString(dateString_20140619, DateUtil.PATTERN_yyyyMMdd, TimeZone.getTimeZone("US/Pacific"));

        MarketType marketType = MarketType.RTM;
        List<MarketDefintionDto> marketDefinitions = getMarketRTM_MarketDefintions();

        // when
        List<MarketPlanDto> marketPlanDtos = marketPlanGenerator.getMarketPlans(marketDate, marketType, marketDefinitions);

        Assert.assertEquals(true, marketPlanDtos.size() == 48);

        Iterator<MarketDefintionDto> marketDefinitionsItr = marketDefinitions.iterator();

        MarketDefintionDto marketDefintionDto = marketDefinitionsItr.next();

        for (int i = 0; i < 24; ++i) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedDateString_140619 + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedDateString_140619
                    + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());

            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;
            logger.debug(i + "");

            if (i < 17) {
                expectedMarketDateStr = dateString_20140619 + NumberUtil.convertNumberToFormatedString(i + 7, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20140620" + NumberUtil.convertNumberToFormatedString(i - 17, NumberUtil.marketHourPattern_00) + ":00:00";
            }
            logger.info(dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());

        }

        marketDefintionDto = marketDefinitionsItr.next();
        int hours = 0;

        for (int i = 24; i < 48; i++) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedDateString_140619 + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedDateString_140619
                    + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());
            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;
            if (i < 41) {
                expectedMarketDateStr = dateString_20140619 + NumberUtil.convertNumberToFormatedString(hours + 7, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20140620" + NumberUtil.convertNumberToFormatedString(hours - 17, NumberUtil.marketHourPattern_00) + ":00:00";
            }

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());
            hours++;

        }

    }

    @Test
    public void testGenerateMarketPlanForRTMMarketForNormalDayBetweenBeforeShortDayAndAfterLongDay() throws Exception {

        // Given

        String dateString_20141219 = "20141219";
        String expectedDateString_141219 = "141219";
        Date marketDate = dateUtil.createDateFromString(dateString_20141219, DateUtil.PATTERN_yyyyMMdd, TimeZone.getTimeZone("US/Pacific"));

        MarketType marketType = MarketType.RTM;
        List<MarketDefintionDto> marketDefinitions = getMarketRTM_MarketDefintions();

        // when
        List<MarketPlanDto> marketPlanDtos = marketPlanGenerator.getMarketPlans(marketDate, marketType, marketDefinitions);

        Assert.assertEquals(true, marketPlanDtos.size() == 48);

        Iterator<MarketDefintionDto> marketDefinitionsItr = marketDefinitions.iterator();

        MarketDefintionDto marketDefintionDto = marketDefinitionsItr.next();

        for (int i = 0; i < 24; i++) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedDateString_141219 + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedDateString_141219
                    + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());

            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;
            logger.debug(i + "");

            if (i < 16) {
                expectedMarketDateStr = dateString_20141219 + NumberUtil.convertNumberToFormatedString(i + 8, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20141220" + NumberUtil.convertNumberToFormatedString(i - 16, NumberUtil.marketHourPattern_00) + ":00:00";
            }
            logger.info(dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());

        }

        marketDefintionDto = marketDefinitionsItr.next();
        int hours = 0;

        for (int i = 24; i < 48; i++) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedDateString_141219 + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedDateString_141219
                    + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());
            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;
            if (i < 40) {
                expectedMarketDateStr = dateString_20141219 + NumberUtil.convertNumberToFormatedString(hours + 8, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20141220" + NumberUtil.convertNumberToFormatedString(hours - 16, NumberUtil.marketHourPattern_00) + ":00:00";
            }

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());
            hours++;

        }

    }

    @Test
    public void testGenerateMarketPlanForRTMMarketForLongDay() throws Exception {

        // Given Nov 02 2014 Long Day

        String dateString_20141102 = "20141102";
        String expectedDateString_141102 = "141102";
        Date marketDate = dateUtil.createDateFromString(dateString_20141102, "yyyyMMdd", TimeZone.getTimeZone("US/Pacific"));

        MarketType marketType = MarketType.RTM;
        List<MarketDefintionDto> marketDefinitions = getMarketRTM_MarketDefintions();

        // when
        List<MarketPlanDto> marketPlanDtos = marketPlanGenerator.getMarketPlans(marketDate, marketType, marketDefinitions);

        Assert.assertEquals(50, marketPlanDtos.size());

        Iterator<MarketDefintionDto> marketDefinitionsItr = marketDefinitions.iterator();

        MarketDefintionDto marketDefintionDto = marketDefinitionsItr.next();

        for (int i = 0; i < 25; i++) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedDateString_141102 + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedDateString_141102
                    + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());

            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;

            if (i < 17) {
                expectedMarketDateStr = dateString_20141102 + NumberUtil.convertNumberToFormatedString(i + 7, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20141103" + NumberUtil.convertNumberToFormatedString(i - 17, NumberUtil.marketHourPattern_00) + ":00:00";
            }
            logger.info(dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());

        }

        marketDefintionDto = marketDefinitionsItr.next();
        int hours = 0;

        for (int i = 25; i < 48; i++) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedDateString_141102 + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedDateString_141102
                    + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());
            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;
            if (i < 42) {
                expectedMarketDateStr = dateString_20141102 + NumberUtil.convertNumberToFormatedString(hours + 7, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20141103" + NumberUtil.convertNumberToFormatedString(hours - 17, NumberUtil.marketHourPattern_00) + ":00:00";
            }

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());
            hours++;

        }

    }

    @Test
    public void testGenerateMarketPlanForRTMMarketForShortDay() throws Exception {

        String dateString_20150308 = "20150308";
        String expectedString_150308 = "150308";
        Date marketDate = dateUtil.createDateFromString(dateString_20150308, "yyyyMMdd", TimeZone.getTimeZone("US/Pacific"));

        MarketType marketType = MarketType.RTM;
        List<MarketDefintionDto> marketDefinitions = getMarketRTM_MarketDefintions();

        // when
        List<MarketPlanDto> marketPlanDtos = marketPlanGenerator.getMarketPlans(marketDate, marketType, marketDefinitions);

        Assert.assertEquals(46, marketPlanDtos.size());

        Iterator<MarketDefintionDto> marketDefinitionsItr = marketDefinitions.iterator();

        MarketDefintionDto marketDefintionDto = marketDefinitionsItr.next();

        for (int i = 0; i < 23; i++) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedString_150308 + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedString_150308
                    + NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());

            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;

            if (i < 16) {
                expectedMarketDateStr = dateString_20150308 + NumberUtil.convertNumberToFormatedString(i + 8, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20150309" + NumberUtil.convertNumberToFormatedString(i - 16, NumberUtil.marketHourPattern_00) + ":00:00";
            }
            logger.info(dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(i + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());

        }

        marketDefintionDto = marketDefinitionsItr.next();
        int hours = 0;

        for (int i = 23; i < 46; i++) {

            String marketDefId = marketDefintionDto.getMarketDefinitionId();
            MarketPlanDto actualMarketPlanDto = marketPlanDtos.get(i);

            String expectedMarketPlanId = expectedString_150308 + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            String expectedMarketRunId = marketDefintionDto.getMarketActivityId() + expectedString_150308
                    + NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00);

            Assert.assertEquals(expectedMarketPlanId, actualMarketPlanDto.getMarketPlanId());
            Assert.assertEquals(expectedMarketRunId, actualMarketPlanDto.getMarketRunId());
            Assert.assertEquals(5, actualMarketPlanDto.getMarketStatusTypeId());
            Assert.assertEquals(marketDefId, actualMarketPlanDto.getMarketDefinitionId());

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;
            if (i < 39) {
                expectedMarketDateStr = dateString_20150308 + NumberUtil.convertNumberToFormatedString(hours + 8, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "20150309" + NumberUtil.convertNumberToFormatedString(hours - 16, NumberUtil.marketHourPattern_00) + ":00:00";
            }

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(actualMarketPlanDto.getMarketDate(), "yyyyMMddHH:mm:ss", TimeZone.getTimeZone("GMT")));
            Assert.assertEquals(NumberUtil.convertNumberToFormatedString(hours + 1, NumberUtil.marketHourPattern_00), actualMarketPlanDto.getMarketHour());
            hours++;

        }

    }

    /**
     * 
     * @return
     */
    private List<MarketDefintionDto> getMarketDAMMarketDefintions() {

        List<MarketDefintionDto> marketDefintions = new ArrayList<MarketDefintionDto>();
        MarketDefintionDto marketDefintionDto = new MarketDefintionDto();
        marketDefintionDto.setMarketDefinitionId("01");
        marketDefintionDto.setMarketType("DAM");
        marketDefintionDto.setMarketActivityId(1);
        marketDefintionDto.setMarketClass("MARKET");
        marketDefintions.add(marketDefintionDto);

        return marketDefintions;
    }

    private List<MarketDefintionDto> getMarketRTM_MarketDefintions() {

        List<MarketDefintionDto> marketDefintions = new ArrayList<MarketDefintionDto>();
        MarketDefintionDto marketDefintionDto = new MarketDefintionDto();
        marketDefintionDto = new MarketDefintionDto();
        marketDefintionDto.setMarketDefinitionId("03");
        marketDefintionDto.setMarketType("RTM");
        marketDefintionDto.setMarketActivityId(1);
        marketDefintionDto.setMarketClass("MARKET");

        marketDefintions.add(marketDefintionDto);

        marketDefintionDto = new MarketDefintionDto();
        marketDefintionDto = new MarketDefintionDto();
        marketDefintionDto.setMarketDefinitionId("04");
        marketDefintionDto.setMarketType("RTM");
        marketDefintionDto.setMarketActivityId(2);
        marketDefintionDto.setMarketClass("TRADES");
        marketDefintions.add(marketDefintionDto);

        return marketDefintions;
    }

}

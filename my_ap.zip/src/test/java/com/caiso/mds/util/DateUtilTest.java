package com.caiso.mds.util;

import java.util.Calendar;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class DateUtilTest {

    @Autowired
    private DateUtil dateUtil;

    @Test
    public void testIsLongDayMethodReturnsFalseForNonLongDay() {
        // given
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2013);
        cal.set(Calendar.DATE, 12);
        cal.set(Calendar.MONTH, Calendar.MARCH);

        boolean expected = false;
        // when
        boolean actual = dateUtil.isDateIsLongDay(cal.getTime());
        // then
        Assert.assertEquals("The test for date verified is not a Long Day , Looks like date is Long Day Instead  ", expected, actual);

    }

    /**
	 * 
	 */
    @Test
    public void testIsLongDayMethodReturnsTrueForLongDay() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill
        // given November 1 2015 , November 2 2014 ,
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 1);
        cal.set(Calendar.MONTH, Calendar.NOVEMBER);

        boolean expected = true;
        // when
        boolean actual = dateUtil.isDateIsLongDay(cal.getTime());
        // then
        Assert.assertEquals("The Test is to return TRUE for LONG DAY Failed  ", expected, actual);

    }

    @Test
    public void testIsShortDayMethodReturnsTrueForShortDay() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2016);
        cal.set(Calendar.DATE, 13);
        cal.set(Calendar.MONTH, Calendar.MARCH);

        boolean expected = true;
        // when
        boolean actual = dateUtil.isDateIsShortDay(cal.getTime());
        // then
        Assert.assertEquals("The Test is to return TRUE for LONG DAY Failed  ", expected, actual);

    }

    @Test
    public void testIsShortDayMethodReturnsFalseForDayWhichIsNotAShortDay() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);

        boolean expected = false;
        // when
        boolean actual = dateUtil.isDateIsShortDay(cal.getTime());
        // then
        Assert.assertEquals("The Test is to return TRUE for LONG DAY Failed  ", expected, actual);

    }

    @Test
    public void testStartOfDayForNormalDay() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);

        String expectedStartOfDayInUTC = "2015-03-10T07:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getStartOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedStartOfDayInUTC, dateTime.toString());
        // then

    }

    @Test
    public void testEndOFDayForNormalDay() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill

        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);

        String expectedEndOfDayInUTC = "2015-03-11T07:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getEndOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedEndOfDayInUTC, dateTime.toString());
        // then

    }

    @Test
    public void testStartOfDayForLongDay() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill
        // given November 1 2015 , November 2 2014 ,
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 1);
        cal.set(Calendar.MONTH, Calendar.NOVEMBER);

        String expectedStartOfDayInUTC = "2015-11-01T07:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getStartOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedStartOfDayInUTC, dateTime.toString());
        // then

    }

    @Test
    public void testEndOFDayForLongDay() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill
        // given November 1 2015 , November 2 2014 ,
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 1);
        cal.set(Calendar.MONTH, Calendar.NOVEMBER);

        String expectedEndOfDayInUTC = "2015-11-02T07:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getEndOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedEndOfDayInUTC, dateTime.toString());
        // then

    }

    // 12192014

    @Test
    public void testStartOfDayAfterLongDayAndBeforeShortDay_PST() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill
        // given November 1 2015 , November 2 2014 ,
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.NOVEMBER);

        String expectedStartOfDayInUTC = "2015-11-10T08:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getStartOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedStartOfDayInUTC, dateTime.toString());
        // then

    }

    @Test
    public void testEndOfDayAfterLongDayAndBeforeShortDay_PST() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill
        // given November 1 2015 , November 2 2014 ,
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.NOVEMBER);

        String expectedStartOfDayInUTC = "2015-11-11T08:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getEndOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedStartOfDayInUTC, dateTime.toString());
        // then

    }

    @Test
    public void testStartOfDayAfterShortDayAndBeforeLongDay_PDT() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill
        // given November 1 2015 , November 2 2014 ,
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);

        String expectedStartOfDayInUTC = "2015-03-10T07:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getStartOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedStartOfDayInUTC, dateTime.toString());
        // then

    }

    @Test
    public void testEndOfDayAfterShortDayAndBeforeLongDay_PDT() {
        // given 2016 March 13 , 2015 March 08 are long DAYS as per nist law and
        // bill
        // given November 1 2015 , November 2 2014 ,
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);

        String expectedStartOfDayInUTC = "2015-03-11T07:00:00.000Z";
        // when
        DateTime dateTime = dateUtil.getEndOfDayDateTimeInUTC1ForPSTDateTime(cal.getTime());

        Assert.assertEquals(expectedStartOfDayInUTC, dateTime.toString());
        // then

    }

    @Test
    public void testFormatYYYYMMDDforDateConversion() {

        // given
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);
        System.err.println(cal.getTime());

        String actualDateString = dateUtil.convertDateToStringFormat(cal.getTime(), DateUtil.PATTERN_yyyyMMdd, TimeZone.getTimeZone("US/Pacific"));

        Assert.assertEquals("20150310", actualDateString);

    }

    @Test
    public void testFormatYYYY_MM_DDforDateConversion() {

        // given
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);
        System.err.println(cal.getTime());

        String actualDateString = dateUtil.convertDateToStringFormat(cal.getTime(), DateUtil.PATTERN_MM_dd_yyyy, TimeZone.getTimeZone("US/Pacific"));

        Assert.assertEquals("03/10/2015", actualDateString);

    }

    @Test
    public void testFormatYYMMDDforDateConversion() {

        // given
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.YEAR, 2015);
        cal.set(Calendar.DATE, 10);
        cal.set(Calendar.MONTH, Calendar.MARCH);
        System.err.println(cal.getTime());

        String actualDateString = dateUtil.convertDateToStringFormat(cal.getTime(), DateUtil.PATTERN_yyMMdd, TimeZone.getTimeZone("America/Los_Angeles"));

        Assert.assertEquals("150310", actualDateString);

    }

}

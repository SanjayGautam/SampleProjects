package com.caiso.mds.util;

import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MarketHoursGeneratorTest {

    private final static Logger  logger = LoggerFactory.getLogger(MarketHoursGeneratorTest.class);

    @Autowired
    private MarketHoursGenerator marketHoursGenerator;

    @Autowired
    private DateUtil             dateUtil;

    @Test
    public void testMarketDateAndHoursForLongDay() throws Exception {

        String dateString_11022014 = "11022014";
        Date date = dateUtil.createDateFromString(dateString_11022014, "MMddyyyy", TimeZone.getTimeZone("US/Pacific"));
        DateTime marketDate = new DateTime(date);

        // when
        List<DateTime> marketDateAndHours = marketHoursGenerator.generateMarketHours(marketDate);

        Assert.assertEquals(25, marketDateAndHours.size());

        for (int i = 0; i < 25; i++) {

            DateTime marketDateHour = marketDateAndHours.get(i);

            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;

            if (i < 17) {
                expectedMarketDateStr = dateString_11022014 + NumberUtil.convertNumberToFormatedString(i + 7, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "11032014" + NumberUtil.convertNumberToFormatedString(i - 17, NumberUtil.marketHourPattern_00) + ":00:00";
            }

            logger.info(dateUtil.convertDateToStringFormat(marketDateHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(marketDateHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

        }

    }

    @Test
    public void testMarketDateAndHoursForShortDay() throws Exception {

        String dateString_11022014 = "03082015";
        Date date = dateUtil.createDateFromString(dateString_11022014, "MMddyyyy", TimeZone.getTimeZone("US/Pacific"));
        DateTime marketDate = new DateTime(date);

        // when
        List<DateTime> marketDateAndHours = marketHoursGenerator.generateMarketHours(marketDate);

        Assert.assertEquals(23, marketDateAndHours.size());

        for (int i = 0; i < 23; i++) {

            DateTime marketDateHour = marketDateAndHours.get(i);
            logger.info(" Hours of the Day :" + i);
            /*
             * Calendar c = Calendar.getInstance();
             * c.setTime(actualMarketPlanDto.getMarketDate());
             * c.setTimeZone(TimeZone.getTimeZone("GMT"));
             */
            String expectedMarketDateStr = null;

            if (i < 16) {
                expectedMarketDateStr = dateString_11022014 + NumberUtil.convertNumberToFormatedString(i + 8, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "03092015" + NumberUtil.convertNumberToFormatedString(i - 16, NumberUtil.marketHourPattern_00) + ":00:00";
            }

            logger.info(dateUtil.convertDateToStringFormat(marketDateHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(marketDateHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

        }

    }

    @Test
    public void testGenerateMarketDateAndHoursForNormalDayAfterShortDayAndBeforeLongDay() throws Exception {

        // Given
        String dateString_06192014 = "06192014";
        Date marketDate = dateUtil.createDateFromString(dateString_06192014, "MMddyyyy", TimeZone.getTimeZone("US/Pacific"));

        // when
        List<DateTime> marketDateAndHours = marketHoursGenerator.generateMarketHours(new DateTime(marketDate));

        Assert.assertEquals(true, marketDateAndHours.size() == 24);

        for (int i = 0; i < 24; i++) {

            DateTime marketDateAndHour = marketDateAndHours.get(i);

            String expectedMarketDateStr = null;

            if (i < 17) {
                expectedMarketDateStr = dateString_06192014 + NumberUtil.convertNumberToFormatedString(i + 7, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "06202014" + NumberUtil.convertNumberToFormatedString(i - 17, NumberUtil.marketHourPattern_00) + ":00:00";
            }
            logger.info(dateUtil.convertDateToStringFormat(marketDateAndHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(marketDateAndHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

        }
    }

    @Test
    public void testGenerateMarketDateAndHoursForNormalDayBeforeShortDayOrAfterLongDay() throws Exception {

        // Given
        String dateString_12192014 = "12192014";
        Date marketDate = dateUtil.createDateFromString(dateString_12192014, "MMddyyyy", TimeZone.getTimeZone("US/Pacific"));

        // when
        List<DateTime> marketDateAndHours = marketHoursGenerator.generateMarketHours(new DateTime(marketDate));

        Assert.assertEquals(true, marketDateAndHours.size() == 24);

        for (int i = 0; i < 24; i++) {

            DateTime marketDateAndHour = marketDateAndHours.get(i);

            String expectedMarketDateStr = null;

            if (i < 16) {
                expectedMarketDateStr = dateString_12192014 + NumberUtil.convertNumberToFormatedString(i + 8, NumberUtil.marketHourPattern_00) + ":00:00";
            } else {
                expectedMarketDateStr = "12202014" + NumberUtil.convertNumberToFormatedString(i - 16, NumberUtil.marketHourPattern_00) + ":00:00";
            }
            logger.info(dateUtil.convertDateToStringFormat(marketDateAndHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

            Assert.assertEquals(expectedMarketDateStr,
                    dateUtil.convertDateToStringFormat(marketDateAndHour.toDate(), "MMddyyyyHH:mm:ss", TimeZone.getTimeZone("GMT")));

        }

    }

}

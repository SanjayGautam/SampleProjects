package com.caiso.mds.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktEvntDef;
import com.caiso.mds.entity.mds.MrktEvntSchd;
import com.caiso.mds.types.EventTimeOffsetStartTimeEntityType;
import com.caiso.mds.types.EventTimeOffsetUnitType;
import com.caiso.mds.types.MarketEventActivationStatus;
import com.caiso.mds.types.MarketPublishStateType;
import com.caiso.mds.types.RepeatIntervalUnit;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:test-context.xml", "classpath:/META-INF/spring/applicationContext.xml" })
@Transactional
@TransactionConfiguration(defaultRollback = true)
public class MarketEventScheduleGeneratorTest {

    private final static Logger          logger = LoggerFactory.getLogger(MarketEventScheduleGeneratorTest.class);

    @Autowired
    private MarketEventScheduleGenerator marketEventScheduleGenerator;

    @Autowired
    private DateUtil                     dateUtil;

    @Test
    public void testGenerateMarketEventScheduleFor_Dam_Market() {

        // given
        MrktEvntDef mrktEvntDef = getMarketEventDefObject(21, "DA Market Deadline Approaching Notification",
                "DA Market Deadline Approaching for this Trade Date", "MarketEventNotification", "DAMD", 1, false, "09:45", "09:45", -1,
                EventTimeOffsetUnitType.DAYS.getName(), EventTimeOffsetStartTimeEntityType.MARKET_DATE.getName(), 0);

        // Expected
        Date marketDate = dateUtil.createDateFromString("06182015", "MMddyyyy", TimeZone.getTimeZone("US/Pacific"));
        DateTime expectedMarketEventPubDateTime = new DateTime(marketDate);
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.plusDays(-1);

        String[] hhMM = "09:45".split(":");
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withTimeAtStartOfDay();
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withHourOfDay(Integer.parseInt(hhMM[0]));
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withMinuteOfHour(Integer.parseInt(hhMM[1]));
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withZone(DateTimeZone.UTC);

        // When
        List<MrktEvntSchd> list = marketEventScheduleGenerator.processGeneric(mrktEvntDef, new DateTime(marketDate));
        // There should be only On record for this. s
        // then
        Assert.assertEquals("There should be only one Market Event Generated for This Market Event Def Id :" + mrktEvntDef.getMrktEvntDefId(), 1, list.size());
        for (Iterator<MrktEvntSchd> iterator = list.iterator(); iterator.hasNext();) {
            MrktEvntSchd mrktEvntSchd = iterator.next();
            Assert.assertEquals(expectedMarketEventPubDateTime, mrktEvntSchd.getMrktEvntFireDate());
            Assert.assertEquals(marketDate, mrktEvntSchd.getMrktDate().toDate());
            Assert.assertEquals(MarketEventActivationStatus.ENABLED.getName(), mrktEvntSchd.getMrktEvntActivationStatus());
            Assert.assertEquals(MarketPublishStateType.SCHEDULED.getName(), mrktEvntSchd.getMrktEvntPubState());
            Assert.assertEquals(1, mrktEvntSchd.getMrktDefinition().getMrktDefinitionId());
            Assert.assertEquals(new Long(1), mrktEvntSchd.getMrktEvntDef().getAssocMrktDefinitionId());
            Assert.assertEquals(21, mrktEvntSchd.getMrktEvntDef().getMrktEvntDefId());
        }

    }

    @Test
    public void testGenerateMarketEventsSchedulesFor_RTM_BASE_OPEN() {

        // given
        String startTime0030 = "00:30";
        String endTime0030 = "00:30";
        int offsetDays = -7;
        int associateMarketDef = 7;
        int marketEventDef = 55;
        String marketDateStr_06182015 = "06182015";
        String dateFormat_MMddyyyy = "MMddyyyy";

        MrktEvntDef mrktEvntDef = getMarketEventDefObject(marketEventDef, "RT BASE Market Open Notification",
                "Real-Time Base Markets for this Trade Date are open", "MarketEventNotification", "RBOP", associateMarketDef, false, startTime0030,
                endTime0030, offsetDays, EventTimeOffsetUnitType.DAYS.getName(), EventTimeOffsetStartTimeEntityType.MARKET_HOUR.getName(), 0);

        // Expected
        Date marketDate = dateUtil.createDateFromString(marketDateStr_06182015, dateFormat_MMddyyyy, TimeZone.getTimeZone("US/Pacific"));
        DateTime expectedMarketEventPubDateTime = new DateTime(marketDate);
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.plusDays(offsetDays);

        String[] hhMM = startTime0030.split(":");
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withTimeAtStartOfDay();
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withHourOfDay(Integer.parseInt(hhMM[0]));
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withMinuteOfHour(Integer.parseInt(hhMM[1]));
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withZone(DateTimeZone.UTC);

        DateTime marketDateAndTime = new DateTime(marketDate);

        // When
        List<MrktEvntSchd> list = marketEventScheduleGenerator.processGeneric(mrktEvntDef, new DateTime(marketDateAndTime));
        // There should be only On record for this. s
        // then
        Assert.assertEquals("There should be only 24 Market Event Generated for This Market Event Def Id :" + mrktEvntDef.getMrktEvntDefId(), 24, list.size());
        int i = 0;
        for (Iterator<MrktEvntSchd> iterator = list.iterator(); iterator.hasNext();) {
            MrktEvntSchd mrktEvntSchd = iterator.next();

            Assert.assertEquals(expectedMarketEventPubDateTime, mrktEvntSchd.getMrktEvntFireDate());
            Assert.assertEquals(marketDateAndTime.plusHours(i).toDate(), mrktEvntSchd.getMrktDate().toDate());
            Assert.assertEquals(MarketEventActivationStatus.ENABLED.getName(), mrktEvntSchd.getMrktEvntActivationStatus());
            Assert.assertEquals(MarketPublishStateType.SCHEDULED.getName(), mrktEvntSchd.getMrktEvntPubState());
            Assert.assertEquals(associateMarketDef, mrktEvntSchd.getMrktDefinition().getMrktDefinitionId());
            Assert.assertEquals(associateMarketDef, mrktEvntSchd.getMrktEvntDef().getAssocMrktDefinitionId().longValue());
            Assert.assertEquals(marketEventDef, mrktEvntSchd.getMrktEvntDef().getMrktEvntDefId());
            i++;
        }

    }

    @Test
    public void testGenerateMarketEventsSchedulesFor_RTM_TRADE_OPEN() {

        // given
        String startTime0002 = "00:02";
        String endTime0002 = "00:02";
        int offsetDays = -1;
        int associateMarketDef = 4;
        int marketEventDef = 39;
        String eventCode_RTOP = "RTOP";
        String marketDateStr = "06182015";
        String dateFormat_MMddyyyy = "MMddyyyy";

        MrktEvntDef mrktEvntDef = getMarketEventDefObject(marketEventDef, "RT Market Open Notification", "Real-Time Markets for this Trade Date are open",
                "MarketEventNotification", eventCode_RTOP, associateMarketDef, false, startTime0002, endTime0002, offsetDays,
                EventTimeOffsetUnitType.DAYS.getName(), EventTimeOffsetStartTimeEntityType.MARKET_HOUR.getName(), 0);

        // Expected
        Date marketDate = dateUtil.createDateFromString(marketDateStr, dateFormat_MMddyyyy, TimeZone.getTimeZone("US/Pacific"));
        DateTime expectedMarketEventPubDateTime = new DateTime(marketDate);
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.plusDays(offsetDays);

        String[] hhMM = startTime0002.split(":");
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withTimeAtStartOfDay();
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withHourOfDay(Integer.parseInt(hhMM[0]));
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withMinuteOfHour(Integer.parseInt(hhMM[1]));

        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withZone(DateTimeZone.UTC);

        DateTime marketDateAndTime = new DateTime(marketDate);

        // When
        List<MrktEvntSchd> list = marketEventScheduleGenerator.processGeneric(mrktEvntDef, new DateTime(marketDate));
        // There should be only On record for this. s
        // then
        Assert.assertEquals("There should be only one Market Event Generated for This Market Event Def Id :" + mrktEvntDef.getMrktEvntDefId(), 24, list.size());
        int i = 0;
        for (Iterator<MrktEvntSchd> iterator = list.iterator(); iterator.hasNext();) {
            logger.info(" index =>" + i);
            MrktEvntSchd mrktEvntSchd = iterator.next();
            Assert.assertEquals(expectedMarketEventPubDateTime, mrktEvntSchd.getMrktEvntFireDate());
            Assert.assertEquals(marketDateAndTime.plusHours(i).toDate(), mrktEvntSchd.getMrktDate().toDate());
            Assert.assertEquals(MarketEventActivationStatus.ENABLED.getName(), mrktEvntSchd.getMrktEvntActivationStatus());
            Assert.assertEquals(MarketPublishStateType.SCHEDULED.getName(), mrktEvntSchd.getMrktEvntPubState());
            Assert.assertEquals(associateMarketDef, mrktEvntSchd.getMrktDefinition().getMrktDefinitionId());
            Assert.assertEquals(associateMarketDef, mrktEvntSchd.getMrktEvntDef().getAssocMrktDefinitionId().longValue());
            Assert.assertEquals(marketEventDef, mrktEvntSchd.getMrktEvntDef().getMrktEvntDefId());
            i++;
        }

    }

    @Test
    public void testGenerateMarketEventsSchedulesFor_DAM_TRADES_MarketValidations() {

        // given
        String startTime1630 = "06:00";
        String endTime1630 = "06:00";
        int offsetDays = -1;
        int associateMarketDef = 2;
        int marketEventDef = 35;
        int repeatInterval = 20;
        String repeatIntervalUnit = RepeatIntervalUnit.EVERY_MINUTE.getName();
        int repeatOccurance = 19;
        MrktEvntDef mrktEvntDef = getMarketEventDefObject(marketEventDef, "RT Market Open Notification", "Real-Time Markets for this Trade Date are open",
                "MarketEventNotification", "RTOP", associateMarketDef, false, startTime1630, endTime1630, offsetDays, EventTimeOffsetUnitType.DAYS.getName(),
                EventTimeOffsetStartTimeEntityType.MARKET_DATE.getName(), 0);
        mrktEvntDef.setEvntRptIntrvl(repeatInterval);
        mrktEvntDef.setEvntRptIntrvlUnit(repeatIntervalUnit);
        mrktEvntDef.setEvntRptIntrvlOccurance(repeatOccurance);
        // Expected
        Date marketDate = dateUtil.createDateFromString("06182015", "MMddyyyy", TimeZone.getTimeZone("US/Pacific"));
        DateTime expectedMarketEventPubDateTime = new DateTime(marketDate);
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.plusDays(offsetDays);

        String[] hhMM = startTime1630.split(":");
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withTimeAtStartOfDay();
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withHourOfDay(Integer.parseInt(hhMM[0]));
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withMinuteOfHour(Integer.parseInt(hhMM[1]));
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.withZone(DateTimeZone.UTC);

        // When
        List<MrktEvntSchd> list = marketEventScheduleGenerator.processGeneric(mrktEvntDef, new DateTime(marketDate));
        // There should be only On record for this. s
        // then
        Assert.assertEquals("There should be only one Market Event Generated for This Market Event Def Id :" + mrktEvntDef.getMrktEvntDefId(), 19, list.size());

        for (MrktEvntSchd mrktEvntSchd : list) {

            Assert.assertEquals(expectedMarketEventPubDateTime, mrktEvntSchd.getMrktEvntFireDate());
            expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.plusMinutes(repeatInterval);
            Assert.assertEquals(marketDate, mrktEvntSchd.getMrktDate().toDate());
            Assert.assertEquals(MarketEventActivationStatus.ENABLED.getName(), mrktEvntSchd.getMrktEvntActivationStatus());
            Assert.assertEquals(MarketPublishStateType.SCHEDULED.getName(), mrktEvntSchd.getMrktEvntPubState());
            Assert.assertEquals(associateMarketDef, mrktEvntSchd.getMrktDefinition().getMrktDefinitionId());
            Assert.assertEquals(associateMarketDef, mrktEvntSchd.getMrktEvntDef().getAssocMrktDefinitionId().longValue());
            Assert.assertEquals(marketEventDef, mrktEvntSchd.getMrktEvntDef().getMrktEvntDefId());
        }

    }

    @Test
    public void testGenerateMarketEventsSchedulesFor_RTM_TRADES_PreCloseNotifications() {

        // given
        String startTime1630 = null;
        String endTime1630 = null;
        int offsetDays = -180;
        int associateMarketDef = 4;
        int marketEventDef = 41;
        int repeatInterval = 20;
        String repeatIntervalUnit = RepeatIntervalUnit.EVERY_MINUTE.getName();
        int repeatOccurance = 7;

        MrktEvntDef mrktEvntDef = getMarketEventDefObject(marketEventDef, "RT ISC Trade PreClose Notification",
                "Real-Time Inter-SC 20 Minute Validations Started", "MarketEventNotification", "RDPC", associateMarketDef, false, startTime1630, endTime1630,
                offsetDays, EventTimeOffsetUnitType.MINS.getName(), EventTimeOffsetStartTimeEntityType.MARKET_HOUR.getName(), 0);

        mrktEvntDef.setEvntRptIntrvl(repeatInterval);
        mrktEvntDef.setEvntRptIntrvlUnit(repeatIntervalUnit);
        mrktEvntDef.setEvntRptIntrvlOccurance(repeatOccurance);
        // Expected
        Date marketDate = dateUtil.createDateFromString("07102015", "MMddyyyy", TimeZone.getTimeZone("US/Pacific"));
        DateTime expectedMarketEventPubDateTime = new DateTime(marketDate);
        expectedMarketEventPubDateTime = expectedMarketEventPubDateTime.plusDays(offsetDays);

        // When
        List<MrktEvntSchd> list = marketEventScheduleGenerator.processGeneric(mrktEvntDef, new DateTime(marketDate));
        for (MrktEvntSchd mrktEvntSchd : list) {
            DateFormat df = new SimpleDateFormat();
            df.setTimeZone(TimeZone.getTimeZone("GMT"));
            logger.debug("Fire Event " + df.format(mrktEvntSchd.getMrktEvntFireDate().toDate()) + " Makret Date "
                    + df.format(mrktEvntSchd.getMrktDate().toDate()));
        }
        // There should be only On record for this. s
        // then
        Assert.assertEquals("There should be only one Market Event Generated for This Market Event Def Id :" + mrktEvntDef.getMrktEvntDefId(), 168, list.size());

        /*
         * for (MrktEvntSchd mrktEvntSchd : list) {
         * 
         * Assert.assertEquals(expectedMarketEventPubDateTime,
         * mrktEvntSchd.getMrktEvntFireDate());
         * expectedMarketEventPubDateTime=expectedMarketEventPubDateTime
         * .plusMinutes(repeatInterval); Assert.assertEquals(marketDate,
         * mrktEvntSchd.getMrktDate().toDate());
         * Assert.assertEquals(MarketEventActivationStatus.ENABLED.getName(),
         * mrktEvntSchd.getMrktEvntActivationStatus()); Assert.assertEquals(
         * MarketPublishStateType.SCHEDULED.getName() ,
         * mrktEvntSchd.getMrktEvntPubState());
         * Assert.assertEquals(associateMarketDef,
         * mrktEvntSchd.getMrktDefinitionId().getMrktDefinitionId());
         * Assert.assertEquals(associateMarketDef,
         * mrktEvntSchd.getMrktEvntDef().getAssocMrktDefinitionId());
         * Assert.assertEquals(marketEventDef,
         * mrktEvntSchd.getMrktEvntDef().getMrktEvntDefId()); }
         */

    }

    /**
     * 
     * @param marketEventDefId
     * @param eventDesc
     * @param eventNotificationMsg
     * @param eventNotificationName
     * @param assocMrktDef
     * @param isExternalEvent
     * @param startTime
     * @param endTime
     * @param eventTimeOffset
     * @param eventTimeOffsetUnit
     * @param timeOffsetStrtEntity
     * @param repeatInterval
     * @return
     */

    private MrktEvntDef getMarketEventDefObject(int marketEventDefId, String eventDesc, String eventNotificationMsg, String eventNotificationName,
            String eventCode, int assocMrktDef, boolean isExternalEvent, String startTime, String endTime, int eventTimeOffset, String eventTimeOffsetUnit,
            String timeOffsetStrtEntity, int repeatInterval) {

        MrktEvntDef mrktEvntDef = new MrktEvntDef();
        // DA Market Deadline Approaching Notification

        mrktEvntDef.setMrktEvntDefId(marketEventDefId);
        mrktEvntDef.setMrktEvntCd(eventCode);
        mrktEvntDef.setMrktEvntDesc(eventDesc);
        mrktEvntDef.setMrktEvntNotificationMsg(eventNotificationMsg);
        mrktEvntDef.setMrktEvntNotificationName(eventNotificationName);
        // 1/DAM/MARKET
        mrktEvntDef.setAssocMrktDefinitionId(new Long(assocMrktDef));
        mrktEvntDef.setExternalEvnt(isExternalEvent);
        mrktEvntDef.setEvntStartTime(startTime);
        mrktEvntDef.setEvntEndTime(endTime);
        mrktEvntDef.setEvntTimeOffset(eventTimeOffset);
        mrktEvntDef.setEvntTimeOffsetUnit(eventTimeOffsetUnit);
        mrktEvntDef.setEvntTimeOffsetStrtEntity(timeOffsetStrtEntity);
        mrktEvntDef.setEvntRptIntrvl(repeatInterval);
        mrktEvntDef.setHasFixedEventTriggerTime(true);
        mrktEvntDef.setIsEnabled(true);
        return mrktEvntDef;
    }

}

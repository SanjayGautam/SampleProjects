A) Instruction for standalone File 

1. The standalone file which was used was from JBPM Installation standalone-full for jbossAS7.1.1 installer.
2. the standalone-full.xml was renamed to standalone.xml becuase to make it in consistent with puppet process. 
3. The standalone has below information which will need to be modified if there is any changes in the en. 
4. tt needs the path to the quartz.properties file. that is provide as a sample below. 
5. there has to be a linux path if you are deploying it in linux system 
6. database drivers have to be declared with the right drivers which is configured as the module
7. all the ports have to be modified if the linux env forces you to do that best will be take the first three numbers and replace them all. 



   <system-properties>
        <property name="org.quartz.properties" value="E:/Dev-Home/jbpm-6.2.0.Final-installer-full/jboss-as-7.1.1.Final/standalone/configuration/org.quartz.properties"/>
    </system-properties>

On Linux Machine 
	
	<system-properties>
        <property name="org.quartz.properties" value="/app/mds/standalone/configuration/org.quartz.properties"/>
    </system-properties>



	<driver name="oracle" module="com.oracle"/>
	

    <socket-binding-group name="standard-sockets" default-interface="public" port-offset="${jboss.socket.binding.port-offset:0}">
        <socket-binding name="management-native" interface="management" port="${jboss.management.native.port:25499}"/>
        <socket-binding name="management-http" interface="management" port="${jboss.management.http.port:25490}"/>
        <socket-binding name="management-https" interface="management" port="${jboss.management.https.port:25443}"/>
        <socket-binding name="ajp" port="25409"/>
        <socket-binding name="http" port="25480"/>
        <socket-binding name="https" port="25443"/>
        <socket-binding name="jacorb" interface="unsecure" port="25428"/>
        <socket-binding name="jacorb-ssl" interface="unsecure" port="25429"/>
        <socket-binding name="messaging" port="25445"/>
        <socket-binding name="messaging-throughput" port="25455"/>
        <socket-binding name="osgi-http" interface="management" port="25490"/>
        <socket-binding name="remoting" port="25447"/>
        <socket-binding name="txn-recovery-environment" port="25412"/>
        <socket-binding name="txn-status-manager" port="25413"/>
        <outbound-socket-binding name="mail-smtp">
            <remote-destination host="localhost" port="25"/>
        </outbound-socket-binding>
    </socket-binding-group>


B) mds-map-test-ds.xml <-  maptest -file.
   
   This is the database jndi configuration for the JBOSS As7.1.1 version and they are put into the separate file and not included in the standalone.xml 
   because to make sure that CSS doesnt not touch the main configuration file. which can bring down the server. 
   SO they can update the database details here in a more focused way rather then the standalone.xml where more things can go wrong. 
   
 C) users and roles properties file. 


SET DEFINE OFF;
Insert into EXTRNL_ENDPOINT
   (EXTRNL_ENDPOINT_ID, EXTRNL_APP_NAME, EXTRNL_SRVC_SEQ_NUM, EXTRNL_INT_ENDPOINT, IS_HTTP_ENDPOINT, 
    EXTRNL_REAL_ENDPOINT, EXTRNL_SRVC_ENABLED, SIGN_MSG, UPDT_LOG, EXTRNL_APP_DESC, 
    CREATED_BY, CREATED_DT, UPDATED_BY, UPDATED_DT)
 Values
   (4, 'MNS', 3, 'http://fqapjbos189.ete.wepex.net:5400/sst/runtime.asvc/ReceiveExternalNotification_MDS_SampleNonSigned_AP', 'Y', 
    'http://xxxx', 'Y', 'N', NULL, 'this is dummy ', 
    'jhuetter', TO_DATE('06/04/2016 18:33:22', 'MM/DD/YYYY HH24:MI:SS'), NULL, TO_DATE('06/04/2016 18:33:22', 'MM/DD/YYYY HH24:MI:SS'));
Insert into EXTRNL_ENDPOINT
   (EXTRNL_ENDPOINT_ID, EXTRNL_APP_NAME, EXTRNL_SRVC_SEQ_NUM, EXTRNL_INT_ENDPOINT, IS_HTTP_ENDPOINT, 
    EXTRNL_REAL_ENDPOINT, EXTRNL_SRVC_ENABLED, SIGN_MSG, UPDT_LOG, EXTRNL_APP_DESC, 
    CREATED_BY, CREATED_DT, UPDATED_BY, UPDATED_DT)
 Values
   (1, 'MNS', 1, 'http://fqapjbos189.ete.wepex.net:5400/sst/runtime.asvc/ReceiveExternalNotification_MDS_SampleNonSigned_AP', 'Y', 
    'http://fdapint475.ete.wepex.net:22480', 'Y', 'N', NULL, 'This is dummy ', 
    'user', TO_DATE('02/07/2016 22:44:21', 'MM/DD/YYYY HH24:MI:SS'), 'user', TO_DATE('02/07/2016 22:44:21', 'MM/DD/YYYY HH24:MI:SS'));
Insert into EXTRNL_ENDPOINT
   (EXTRNL_ENDPOINT_ID, EXTRNL_APP_NAME, EXTRNL_SRVC_SEQ_NUM, EXTRNL_INT_ENDPOINT, IS_HTTP_ENDPOINT, 
    EXTRNL_REAL_ENDPOINT, EXTRNL_SRVC_ENABLED, SIGN_MSG, UPDT_LOG, EXTRNL_APP_DESC, 
    CREATED_BY, CREATED_DT, UPDATED_BY, UPDATED_DT)
 Values
   (2, 'SIBR', 1, 'http://localhost:4400/sst/runtime.asvc/BroadcastMarketStatus_MDSv1_AP?wsdl
', 'N', 
    'http://localhost:4400/sst/runtime.asvc/BroadcastMarketStatus_MDSv1_AP?wsdl
', 'Y', 'N', NULL, 'This is real one AI Endpoint', 
    'user', TO_DATE('02/07/2016 22:46:25', 'MM/DD/YYYY HH24:MI:SS'), 'user', TO_DATE('02/07/2016 22:46:25', 'MM/DD/YYYY HH24:MI:SS'));
Insert into EXTRNL_ENDPOINT
   (EXTRNL_ENDPOINT_ID, EXTRNL_APP_NAME, EXTRNL_SRVC_SEQ_NUM, EXTRNL_INT_ENDPOINT, IS_HTTP_ENDPOINT, 
    EXTRNL_REAL_ENDPOINT, EXTRNL_SRVC_ENABLED, SIGN_MSG, UPDT_LOG, EXTRNL_APP_DESC, 
    CREATED_BY, CREATED_DT, UPDATED_BY, UPDATED_DT)
 Values
   (3, 'MNS', 2, 'http://localhost:25480/mds/soap/mdsMnsSimulatedMpWS_First', 'Y', 
    'http://xxxx', 'Y', 'N', NULL, 'this is dummy ', 
    'user', TO_DATE('02/07/2016 22:47:44', 'MM/DD/YYYY HH24:MI:SS'), 'user', TO_DATE('02/07/2016 22:47:44', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;

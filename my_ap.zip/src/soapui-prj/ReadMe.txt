This is a soapui which users can use to quickly test the mds project. 

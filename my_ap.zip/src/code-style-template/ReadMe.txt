These are the coding style which will be followed for this project. 
Import the styles as individual nodes while going to 
Preferences > Java > Code Style 
You will find 
1. Clean up					eclipse_cleanup.xml
2. Code Templates 			eclipse_codetemplates.xml 
3. Formatter 				eclipse_formatter.xml
4. Organise Imports  		No Import just order them manually by moving up and down.
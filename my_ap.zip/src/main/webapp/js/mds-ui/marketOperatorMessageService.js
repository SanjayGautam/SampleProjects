app.service('marketOperatorMessageService', ['$http' , function ($http ) {
    
	
	this.getMarketOperatorMessagesForLast24Hours = function(){
		
		console.log("Inside the function ");
		console.log($http);
		return $http.get('/mds/soap/moms/last24HourOperatorMessages') ;
	};
	
	this.getMdsSeverities = function(){
		
		console.log("Inside the function get severities ");
		console.log($http);
		return $http.get('/mds/soap/moms/messageSeverities') ;
	};
	
	
	this.addMarketOperatorMessage = function(bodyData){
		
		console.log(bodyData);
		
					
		/*return $http.post('http://fdapjbos357:55080/mds/rest/moms/operatorMessages' , bodyData ,   );*/
		
		return $http({
		    url: '/mds/soap/moms/operatorMessages',
		    dataType: 'json',
		    method: 'POST',
		    data: bodyData ,
		    headers: {
		        "Content-Type": "application/json"
		    }}
		);
		
		
		
	};
	

}]);
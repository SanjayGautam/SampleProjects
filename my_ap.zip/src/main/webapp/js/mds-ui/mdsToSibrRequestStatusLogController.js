app.controller('MdsToSibrRequestStatusLogController',
				function($scope, $filter, $uibModal , mdsToSibrRequestStatusLogService) {

					
					$scope.status ='' ;
					
					$scope.mdsToSibrRequestLogs = '';
					
					  
					$scope.setPage = function (pageNo) {
					    $scope.currentPage = pageNo;
					  };

					  $scope.pageChanged = function() {
					    console.log('Page changed to: ' + $scope.currentPage);
					    console.log( ' page chganegd to ' +  $scope.bigCurrentPage);
					    getMdsToSibrRequestStatusHistoryLogs( $scope.bigCurrentPage);
					  };

					  // this is max tabs visible 
					  $scope.maxSize = 5;
					  $scope.itemsPerPage =30;
					  // total page Count 
					  $scope.bigTotalItems = 676;
					  $scope.bigCurrentPage = 1;
					  $scope.totalItems = 64;
					  $scope.currentPage = 1;
						  
					
					getMdsToSibrRequestStatusHistoryLogs($scope.currentPage);
					
					
					function getMdsToSibrRequestStatusHistoryLogs(pageNumber) {

						console.log('Inside the Market Notification Logs  ');
					/*	openProgress();*/
						
						mdsToSibrRequestStatusLogService
								.getMdsToSibrRequestLogs(pageNumber).success(
										function(data) {

											console.log(data);
											
											$scope.mdsToSibrRequestLogs = data.mdsToSibrRequestLogsResult;
											$scope.bigTotalItems =data.mdsToSibrRequestLogsResult.totalRowsCount;
											$scope.totalItems =data.mdsToSibrRequestLogsResult.totalRowsCount;
											$scope.itemsPerPage =data.mdsToSibrRequestLogsResult.currentPageSize;
											console.log($scope.mdsToSibrRequestLogs);
											console.log(' big item' + $scope.bigTotalItems);
											console.log(' $scope.itemsPerPage'  + $scope.itemsPerPage);
											console.log(' $scope.numPages' +  $scope.numPages) ;
										})
								.error(
										function(error) {
											$scope.showStatus = 'true' ;	
											$scope.status = ' Unable to Load the Data  : '
													+ error.message;

										});

					}
					
				/*	var modalInstance ='' ;
					
					function openProgress(){
						
						  modalInstance= 	$modal.open({
						      animation: true,
						      templateUrl: 'myModalContent.html',
						      controller: 'ModalInstanceCtrl',
						      size: 'lg',
						      resolve: {
						          items: function () {
						            return 0;
						          }},
						          backdrop:false
						 
						      
						    });
						
					}
					
					$scope.animationsEnabled = true;

					  $scope.open = function (size) {

					    var modalInstance = $modal.open({
					      animation: true,
					      templateUrl: 'myModalContent.html',
					      controller: 'ModalInstanceCtrl',
					      size: size
					      
					    });

					    modalInstance.result.then(function (selectedItem) {
					      $scope.selected = selectedItem;
					    }, function () {
					      $log.info('Modal dismissed at: ' + new Date());
					    });
					  };

					  $scope.toggleAnimation = function () {
					    $scope.animationsEnabled = !$scope.animationsEnabled;
					  };
					  
					  
					  */
					  
					
										
});



app.controller('ModalInstanceCtrl', function ($scope, $modalInstance, items) {

  $scope.items = items;
  $scope.selected = {
    item: $scope.items[0]
  };

  $scope.ok = function () {
    $modalInstance.close($scope.selected.item);
  };

  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});


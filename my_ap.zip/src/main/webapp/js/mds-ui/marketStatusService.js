app.service('marketStatusService', ['$http' , function ($http ) {
    
	
	this.getMarketStatuses = function(marketType , dateVar){
		
		console.log("Inside Function getMarketStatuses");
		console.log($http);
		return $http.get('/mds/soap/mss/marketStatusHistory?marketType='+ marketType + '&marketDate=' + dateVar) ;
	};
	
	this.viewCurrentHour =function(marketType){
		
		console.log("Inside Funtion Current Hour ");
		console.log($http);
		return $http.get('/mds/soap/mss/marketStatusCurrentHour?marketType=' +marketType) ;
	};
	
	

}]);
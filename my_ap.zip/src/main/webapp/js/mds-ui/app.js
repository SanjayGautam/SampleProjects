var app = angular.module('mdsApp', [ 'ngAnimate', 'ngRoute', 'ui.bootstrap' ]);


    
console.log(' Module created ');

// Interceptor Service
app.factory('authSecurityService',function ($rootScope,$location) {
	return {
		getAuthorization: function() {
			var isUserHasAccess = false;
			console.log("************inside the interceptor *****************");
			console.log("inside the $rootScope.userAccess: "+$rootScope.userAccess);
			console.log("$rootScope.mdsOperatorAccess:"+ $rootScope.mdsOperatorAccess);
			if(!angular.isUndefined($rootScope.userAccess)){
				if ($rootScope.userAccess == "N"){
					$location.path("/mds-user-access-denied");
				}else{
					console.log("User has access."+$location.path().indexOf("mds-operator-add-msg"));
					if (($location.path().indexOf("mds-operator-add-msg")> -1) && ($rootScope.mdsOperatorAccess=="N")){
						console.log("Limited access.");
						$location.path("/mds-user-access-denied");
					}
				}
			}
			console.log("************Exiting the interceptor *****************");
		return isUserHasAccess;
    }
  };
});

app.config(['$routeProvider', '$locationProvider','$httpProvider' , function ($routeProvider ,$locationProvider,$httpProvider) {
	//Interceptor config
	/*$httpProvider.interceptors.push(function(authSecurityService) {
		return {
			request: function(req) {
				console.log("************ push start  *****************");
				console.log(" request "  + req);
				req.headers.Authorization = authSecurityService.getAuthorization();
				console.log("************ push end *****************");
				return req;
			}
	    };
	});*/
	
	
	  
	
			
	console.log("inside E config before route provider  ");
    $routeProvider
        .when('/mds-status',
            {
        	    controller: 'MarketStatusController',
                templateUrl: 'partials/mds-status.html'
            })
        .when('/mds-market-events-log',
            {
                controller: 'MarketEventNotificationHistoryController',
                templateUrl: 'partials/mds-market-events-log.html'
            })
        .when( '/mds-to-sibr-request-status-log' , { 
            		controller: 'MdsToSibrRequestStatusLogController',
                    templateUrl: 'partials/mds-to-sibr-request-status-log.html'
            })
        .when( '/mds-operator-msgs' , { 
        		controller: 'MarketOperatorMessagesController',
                templateUrl: 'partials/mds-operator-msgs.html'
        })
        .when( '/mds-operator-add-msg' , { 
            		controller: 'AddMarketOperatorMessagesController',
                    templateUrl: 'partials/mds-operator-add-msg.html'
            })
         .when( '/mds-user-access-denied' , { 
        	 	 controller: 'AccessDeniedController',
        	 	 templateUrl: 'mds-access-denied.html'
            })
            .otherwise( { redirectTo: '/mds-status'} );
 		}]);

		
		console.log("exiting config after route provider  ");
// Call to security service to verify the user authentication
/*app.run(function($http,$location,$rootScope) {
	console.log("Inside run method......");
	console.log("XXX Going to call via RUN Auth Services ");
	$http.get('/mds/soap/sas/mdsAuthService').success(
	function(data) {
		console.log(data);
		if (data.securityStatusDetails.userAccess == "Y"){
			console.log("User has Access ::::::::::::"+ data.securityStatusDetails.userAccess);
			console.log("mdsOperator Access ::::::::::::"+ data.securityStatusDetails.MDSOperator);
			$rootScope.userAccess = data.securityStatusDetails.userAccess;
			$rootScope.mdsOperatorAccess = data.securityStatusDetails.MDSOperator;
			$rootScope.mdsUserName = data.securityStatusDetails.mdsUserName;
		}else{
			console.log("Access Restricted");
			$location.path("/mds-user-access-denied");
			$rootScope.userAccess = data.securityStatusDetails.userAccess;
		}
	}).error(function(data,status) {
				console.log("access Error...."+status);
			});
});*/

app.controller('NavbarController', function ($scope, $location) {
    $scope.getClass = function (path) {
        if ($location.path().substr(0, path.length) == path) {
            return true;
        } else {
            return false;
        }
    };
});

app.controller('MainCtrl', ['$route', '$routeParams', '$location',
                         function($route, $routeParams, $location) {
							console.log('inside Main Controller  ');
                           this.$route = $route;
                           this.$location = $location;
                           this.$routeParams = $routeParams;
}]);
                       
                       


/*<script type="text/javascript">
  angular.element(document.getElementsByTagName('head')).append(angular.element('<base href="' + window.location.pathname + '" />'));
</script>
*/

app.filter('dateFormat_MMddyyyy', function($filter) {
	return function(input) {
		if (input == null) {
			return "";
		}

		var _date = $filter('date')(new Date(input), 'MMddyyyy');

		return _date.toUpperCase();

	};
});

app.controller(	'MarketStatusController',  function( $scope,$rootScope,$location, $filter, marketStatusService , mdsAuthService) {

					$scope.damMarketStatuses = '';
					$scope.rtmMarketStatuses = '';
					
					$scope.damDatePickerStatus = '';
					$scope.rtmDatePickerStatus = '';
					$scope.status='';
					$scope.rtmDatePicker = new Date();
					var tempDamDate = new Date();
					tempDamDate.setDate(tempDamDate.getDate()+1);
					$scope.damDatePicker = tempDamDate;
					
				  

					/*
					 * init();
					 * 
					 * function init() {
					 * 
					 * console.log("inside init");
					 * console.log(marketStatusService.getMarketStatuses()); var
					 * temp = marketStatusService.getMarketStatuses();
					 * $scope.marketStatuses = temp[0].marketStatuses;
					 * console.log($scope.marketStatuses);
					 *  }
					 */
					
					console.log("*******XXXXX Inside the B Mds Status Controller XXXX*********** ");
				
					getAuthentication();
				    
					
					
					
					$scope.hoursToShow='showCurrentHour';
					$scope.submitBtnText='View Current Hour';
					
					function getAuthentication() {
					
						console.log("****** inside the auth *******");
						
						mdsAuthService
						.getAuthInfo()
						.success(
								function(data) {
									console.log("****** Entering response from Auth Service ********");
									console.log(data);
									if (data.securityStatusDetails.userAccess == "Y"){
										console.log("User has Access ::::::::::::"+ data.securityStatusDetails.userAccess);
										console.log("mdsOperator Access ::::::::::::"+ data.securityStatusDetails.MDSOperator);
										$rootScope.userAccess = data.securityStatusDetails.userAccess;
										$rootScope.mdsOperatorAccess = data.securityStatusDetails.MDSOperator;
										$rootScope.mdsUserName = data.securityStatusDetails.mdsUserName;
										getDefaultMarketStatus();
									  
										
									}else{
										console.log("Access Restricted");
										$location.path("/mds-user-access-denied");
										$rootScope.userAccess = data.securityStatusDetails.userAccess;
									}
									console.log("****** Exiting reponse from Auth Service ********");

								})
						.error(
								function(error) {

									$scope.status = ' Error to load user data : '
											+ error.message;

								});
						
						console.log("****** exiting the auth *******");
						
						
					
					};

					function getDefaultMarketStatus() {
						
						console.log("****** inside Default Market Status  *******");
						
						var temp = $scope.rtmDatePicker;
						console.log('RTM Date picked ' + temp);
						var rtmMarketDate = $filter('dateFormat_MMddyyyy')(temp);
						console.log(' RTM Market Date ' + rtmMarketDate);
						
						
						marketStatusService
								.getMarketStatuses('RTM' , rtmMarketDate )
								.success(
										function(data) {

											console.log(data);

											$scope.rtmMarketStatuses = data.marketStatuses;

										})
								.error(
										function(error) {

											$scope.status = ' Upable to load customer data : '
													+ error.message;

										});
						
						var temp = $scope.damDatePicker;
						console.log('DAM Date picked ' + temp);
						var damMarketDate = $filter('dateFormat_MMddyyyy')(temp);
						console.log(' DAM Market Date ' + damMarketDate);
						
						marketStatusService
						.getMarketStatuses('DAM' , damMarketDate )
						.success(
								function(data) {

									console.log(data);

									$scope.damMarketStatuses = data.marketStatuses;

								})
						.error(
								function(error) {

									$scope.status = ' unable to load market status data : '
											+ error.message;

								});
						
						
						

					}

					$scope.getRtmMarketStatus = function() {

						var temp = $scope.rtmDatePicker;
						console.log(' Date picked ' + temp);
						var rtmMarketDate = $filter('dateFormat_MMddyyyy')(temp);
						console.log(' RTM Market Date  ' + rtmMarketDate);
						
						marketStatusService
								.getMarketStatuses('RTM' , rtmMarketDate )
								.success(
										function(data) {
											console.log(data);
											$scope.rtmMarketStatuses = data.marketStatuses;

										});

					};
					
					
					

					$scope.getDamMarketStatus = function() {
						
						var temp = $scope.damDatePicker;
						console.log('Dam Date picked ' + temp);
						var damMarketDate = $filter('dateFormat_MMddyyyy')(temp);
						console.log(' RTM Market Date  ' + damMarketDate);
						
						
						marketStatusService
								.getMarketStatuses('DAM' , damMarketDate )
								.success(
										function(data) {
											console.log(data);
											$scope.damMarketStatuses = data.marketStatuses;

										});

					};

					$scope.viewRtmMarketStatusForCurrentHour = function() {
						
						console.log("Inside Controller View Current Hour ");
						// setting it to current date to avoid confusion 
						$scope.rtmDatePicker = new Date();
						
						console.log($scope.hoursToShow);
						
						if($scope.hoursToShow=='showCurrentHour') {
						
							$scope.hoursToShow = 'showAllHours';
							$scope.submitBtnText='Show All Hours';
							marketStatusService
									.viewCurrentHour('RTM')
									.success(
											function(data) {
												console.log(data);
												$scope.rtmMarketStatuses = data.marketStatuses;

											});
							
						} else {
							
							$scope.hoursToShow = 'showCurrentHour';
							$scope.submitBtnText='Show Current Hour';
							$scope.getRtmMarketStatus();
							
						}
						
						

					};

					$scope.today = function() {
						$scope.rtmDatePicker = new Date();
						var tempDamDate = new Date();
						$scope.damDatePicker =tempDamDate.setDate(tempDamDate.getDate()+1);
					};

					$scope.today();

					$scope.clear = function() {
						$scope.rtmDatePicker = null;
					};

					// Disable weekend selection
					$scope.disabled = function(date, mode) {
						return (mode === 'day' && (date.getDay() === 0 || date
								.getDay() === 6));
					};

					$scope.toggleMin = function() {
						$scope.minDate = $scope.minDate ? null : new Date();
					};
					$scope.toggleMin();
					$scope.maxDate = new Date(2020, 5, 22);

					$scope.open = function($event) {
						$scope.status.opened = true;
					};
					
					$scope.status = {
							opened : false
					};
					
					$scope.openDamDatePicker = function($event) {
						$scope.damDatePickerStatus.opened = true;
					};
					
					$scope.damDatePickerStatus = {
							opened : false
					};
					
					$scope.openRtmDatePicker = function($event) {
						console.log("ope RTM Date Picker ");
						$scope.rtmDatePickerStatus.opened = true;
					};
					
					$scope.rtmDatePickerStatus = {
							opened : false
					};
					

					$scope.dateOptions = {
						formatYear : 'yy',
						startingDay : 1
					};

					$scope.formats = [ 'dd-MMMM-yyyy', 'yyyy/MM/dd',
							'dd.MM.yyyy', 'shortDate' ];
					$scope.format = $scope.formats[1];

					

					var tomorrow = new Date();
					tomorrow.setDate(tomorrow.getDate() + 1);
					var afterTomorrow = new Date();
					afterTomorrow.setDate(tomorrow.getDate() + 2);
					$scope.events = [ {
						date : tomorrow,
						status : 'full'
					}, {
						date : afterTomorrow,
						status : 'partially'
					} ];

					$scope.getDayClass = function(date, mode) {
						if (mode === 'day') {
							var dayToCheck = new Date(date)
									.setHours(0, 0, 0, 0);

							for (var i = 0; i < $scope.events.length; i++) {
								var currentDay = new Date($scope.events[i].date)
										.setHours(0, 0, 0, 0);

								if (dayToCheck === currentDay) {
									return $scope.events[i].status;
								}
							}
						}

						return '';
					};

				});

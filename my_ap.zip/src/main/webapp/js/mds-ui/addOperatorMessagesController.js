app.controller('AddMarketOperatorMessagesController',
				function($routeParams, $scope, $rootScope, $location, $filter, marketOperatorMessageService , mdsAuthService) {

					$scope.systemOperatorMessageSeverities = '';
					$scope.status ='' ;
					$scope.showStatus = 'false' ;
					$scope.operatorMessage = '' ;
					$scope.masterOperatorMessage = { "mdsSeverityName": "Select Message Severity"};
					
					this.name = "AddMarketOperatorMessagesController";
				    this.params = $routeParams;
				    
				    getAuthentication();
					
					
					
					function getAuthentication() {
						
						mdsAuthService
						.getAuthInfo()
						.success(
								function(data) {
									console.log("****** Entering response from Auth Service ********");
									console.log(data);
									if (data.securityStatusDetails.userAccess == "Y"){
										console.log("User has Access ::::::::::::"+ data.securityStatusDetails.userAccess);
										console.log("User  ::::::::::::"+ data.securityStatusDetails.MDSOperator);
										$rootScope.userAccess = data.securityStatusDetails.userAccess;
										$rootScope.mdsOperatorAccess = data.securityStatusDetails.MDSOperator;
										$rootScope.mdsUserName = data.securityStatusDetails.mdsUserName;
										getMdsSeverities();
										reset();
									}else{
										console.log("Access Restricted");
										$location.path("/mds-user-access-denied");
										$rootScope.userAccess = data.securityStatusDetails.userAccess;
									}
									console.log("****** Exiting reponse from Auth Service ********");

								})
						.error(
								function(error) {

									$scope.status = ' Error to load user data : '
											+ error.message;

								});
						
						
					
					};
					
					
					
					function getMdsSeverities() {

						console.log('inside the get operator messages ');

						marketOperatorMessageService
								.getMdsSeverities().success(
										function(data) {

											console.log(data);

											$scope.systemOperatorMessageSeverities = data.systemOperatorMessageSeverities;

										})
								.error(
										function(error) {
											$scope.showStatus = 'true' ;	
											$scope.status = ' Unable to Load the Message Severity Drop Down: '
													+ error.message;

										});

					}
					
					function reset(){
						
						console.log(' Reset  ');
						$scope.operatorMessage = angular.copy($scope.masterOperatorMessage);
						$scope.showStatus = 'false' ;
						$scope.status='';
					}
					
					$(document).on('click', '.dropdown-menu li a', function () {
						
						
					    var selText = $(this).text();
					    $scope.operatorMessage.mdsSeverityName= selText.trim();
					    console.log('inside list  =>' +    $scope.operatorMessage.mdsSeverityName.trim());
					    					    
					    $('#split-button').html(selText);
					    $scope.showStatus = 'false' ;
						$scope.status='';
					    
					    
					});
					
					
					$scope.resetForm = function(addOperatorMsgForm) {

						if (addOperatorMsgForm) {
							addOperatorMsgForm.$setPristine();
							addOperatorMsgForm.$setUntouched();
					      }
						
						console.log(' Reset  ');		
						$scope.operatorMessage = angular.copy($scope.masterOperatorMessage);
						$scope.showStatus = 'false' ;
						$scope.status='';

					};
					
					
					$scope.addOperatorMessage = function() {

						$scope.operatorMessage.messageSubmittedBy = $rootScope.mdsUserName;
						console.log(" user name add = "  +  $scope.operatorMessage.messageSubmittedBy );
						
						if($scope.operatorMessage.mdsSeverityName == "Select Message Severity"){
							
							$scope.status ='Please select Message Severity.' ;
							$scope.showStatus = 'true' ;
							return;
							
						}
						
						if($scope.operatorMessage.severityMessage == undefined ){
							return;
						}
						var messageLength = $scope.operatorMessage.severityMessage.length ;
						console.log(messageLength);
						
						if(messageLength > 3000 ){
							
							$scope.status ='Message Length cannot be greater than 3000 characters.' ;
							$scope.showStatus = 'true' ;
							return;
						}
						
						if($scope.operatorMessage.severityMessage.trim() == ""){
							
							$scope.status ='Please enter valid payload message.' ;
							$scope.showStatus = 'true' ;
							return;
						}
						
						
						var jsonString = angular.toJson($scope.operatorMessage ,2);
						console.log(jsonString);
						
						var tempJsonBody = '{ "operatorMessage":' + jsonString + '}' ;
						
						console.log(tempJsonBody) ;
						/*
								{
								  "operatorMessage": {
								    "mdsSeverityName": "EMERGENCY",
								    "severityMessage": " Testing JSONS  ",
								  }
								}
						 */
						var jsonData = angular.fromJson(tempJsonBody);
						
						console.log('inside the get Add System Operating Messages  ');
						marketOperatorMessageService.addMarketOperatorMessage(jsonData ).success(
								
								function(data) {

									console.log(data);
									$scope.showStatus = true;
									$scope.status ="System Operating Message was Successfully Created with Id [" + data.operatorMessage.systemOperatorMessageId +"]" ;
									$scope.operatorMessage = angular.copy($scope.masterOperatorMessage);
									$scope.addOperatorMsgForm.$setPristine();
								})
						.error(
								function(error) {

									$scope.status = ' Unable to create System Operating Message : '	+ error.message ;
									$scope.showStatus = true ;
									console.log($scope.status);
									$scope.addOperatorMsgForm.$setPristine();

								});
						
					};
					
					
					/*function addOperatorMessage(){
						
						console.log('inside the get Add System Operating Messages  ');
						marketOperatorMessageService.addMarketOperatorMessage().success(
								
								function(data) {

									console.log(data);

									$scope.systemOperatorMessageSeverities = data.systemOperatorMessageSeverities;

								})
						.error(
								function(error) {

									$scope.status = ' Unable to Load the Data  : '
											+ error.message;

								});
						
					};*/
					
					
					
					
				});

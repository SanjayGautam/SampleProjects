app.controller('AccessDeniedController',
function($scope, $location,$window) {
	console.log('inside the AccessDeniedController ');
	$window.location.href = 'mds-access-denied.html';
});

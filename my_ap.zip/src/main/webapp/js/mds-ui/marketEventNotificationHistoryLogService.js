app.service('marketEventNotificationHistoryLogService', ['$http' , function ($http ) {
    
	
	this.getMarketEventNotificationLogHistory = function(pageNumber){
		
		console.log(" Inside the function Event Log History ");
		console.log($http);
		return $http.get('/mds/soap/mens/marketEventNotificationLogs?pageNumber=' + pageNumber ) ;
		
	};
		

}]);
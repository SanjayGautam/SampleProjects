app.controller('MarketEventNotificationHistoryController',
				function($scope, $rootScope, $filter,$location, $uibModal , marketEventNotificationHistoryLogService , mdsAuthService) {

					
					getAuthentication();
	
	
					$scope.status ='' ;
					
					$scope.marketEventNotificationLogs = '';
					  
					$scope.setPage = function (pageNo) {
					    $scope.currentPage = pageNo;
					  };

					  $scope.pageChanged = function() {
					    console.log('Page changed to: ' + $scope.currentPage);
					    console.log( ' page chganegd to ' +  $scope.bigCurrentPage);
					    getMarketNotificationLogs( $scope.bigCurrentPage);
					  };

					  // this is max tabs visible 
					  $scope.maxSize = 5;
					  $scope.itemsPerPage =30;
					  // total page Count 
					  $scope.bigTotalItems = 676;
					  $scope.bigCurrentPage = 1;
					  $scope.totalItems = 64;
					  $scope.currentPage = 1;
						  
					
					getMarketNotificationLogs($scope.currentPage);
					
					
					function getAuthentication() {
						
						mdsAuthService
						.getAuthInfo()
						.success(
								function(data) {
									console.log("****** Entering response from Auth Service ********");
									console.log(data);
									if (data.securityStatusDetails.userAccess == "Y"){
										console.log("User has Access ::::::::::::"+ data.securityStatusDetails.userAccess);
										console.log("mdsOperator Access ::::::::::::"+ data.securityStatusDetails.MDSOperator);
										$rootScope.userAccess = data.securityStatusDetails.userAccess;
										$rootScope.mdsOperatorAccess = data.securityStatusDetails.MDSOperator;
										$rootScope.mdsUserName = data.securityStatusDetails.mdsUserName;
									}else{
										console.log("Access Restricted");
										$location.path("/mds-user-access-denied");
										$rootScope.userAccess = data.securityStatusDetails.userAccess;
									}
									console.log("****** Exiting reponse from Auth Service ********");

								})
						.error(
								function(error) {

									$scope.status = ' Error to load user data : '
											+ error.message;

								});
						
						
					
					};
					
					function getMarketNotificationLogs(pageNumber) {

						console.log('Inside the Market Notification Logs  ');
					/*	openProgress();*/
						
						marketEventNotificationHistoryLogService
								.getMarketEventNotificationLogHistory(pageNumber).success(
										function(data) {

											console.log(data);
											
											$scope.marketEventNotificationLogs = data.marketEventNotificationLogsResult;
											$scope.bigTotalItems =data.marketEventNotificationLogsResult.totalRowsCount;
											$scope.totalItems =data.marketEventNotificationLogsResult.totalRowsCount;
											$scope.itemsPerPage =data.marketEventNotificationLogsResult.currentPageSize;
											console.log($scope.marketEventNotificationLogs);
											console.log(' big item' + $scope.bigTotalItems);
											console.log(' $scope.itemsPerPage'  + $scope.itemsPerPage);
											console.log(' $scope.numPages' +  $scope.numPages) ;
										})
								.error(
										function(error) {
											$scope.showStatus = 'true' ;	
											$scope.status = ' Unable to Load the Data  : '
													+ error.message;

										});

					}
					
				/*	var modalInstance ='' ;
					
					function openProgress(){
						
						  modalInstance= 	$modal.open({
						      animation: true,
						      templateUrl: 'myModalContent.html',
						      controller: 'ModalInstanceCtrl',
						      size: 'lg',
						      resolve: {
						          items: function () {
						            return 0;
						          }},
						          backdrop:false
						 
						      
						    });
						
					}
					
					$scope.animationsEnabled = true;

					  $scope.open = function (size) {

					    var modalInstance = $modal.open({
					      animation: true,
					      templateUrl: 'myModalContent.html',
					      controller: 'ModalInstanceCtrl',
					      size: size
					      
					    });

					    modalInstance.result.then(function (selectedItem) {
					      $scope.selected = selectedItem;
					    }, function () {
					      $log.info('Modal dismissed at: ' + new Date());
					    });
					  };

					  $scope.toggleAnimation = function () {
					    $scope.animationsEnabled = !$scope.animationsEnabled;
					  };
					  
					  
					  */
					  
					
										
});



app.controller('ModalInstanceCtrl', function ($scope, $modalInstance, items) {

  $scope.items = items;
  $scope.selected = {
    item: $scope.items[0]
  };

  $scope.ok = function () {
    $modalInstance.close($scope.selected.item);
  };

  $scope.cancel = function () {
    $modalInstance.dismiss('cancel');
  };
});


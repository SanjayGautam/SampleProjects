app.service('mdsToSibrRequestStatusLogService', ['$http' , function ($http ) {
    
	
	this.getMdsToSibrRequestLogs = function(pageNumber){
		
		console.log(" Inside the Mds to Sibr Request History  log get Method ");
		console.log($http);
		return $http.get('/mds/soap/mrls/mdsToSibrRequestStatusHistoryLogs?pageNumber=' + pageNumber ) ;
		
	};
		

}]);
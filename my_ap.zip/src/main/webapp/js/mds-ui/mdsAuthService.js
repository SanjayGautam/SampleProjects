app.service('mdsAuthService', ['$http' , function ($http ) {
    
	
	
	this.getAuthInfo = function(){
			return $http.get('/mds/soap/sas/mdsAuthService');	
	};
	

}]);
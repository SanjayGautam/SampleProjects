app.controller('MarketOperatorMessagesController', function($scope, $rootScope, $location, $filter,
		$uibModal, marketOperatorMessageService , mdsAuthService) {

	$scope.operatorMessages = '';
	$scope.status = '';

	getAuthentication();
	getOperatorMessages();
	
	
	function getAuthentication() {
		
		mdsAuthService
		.getAuthInfo()
		.success(
				function(data) {
					console.log("****** Entering response from Auth Service ********");
					console.log(data);
					if (data.securityStatusDetails.userAccess == "Y"){
						console.log("User has Access ::::::::::::"+ data.securityStatusDetails.userAccess);
						console.log("mdsOperator Access ::::::::::::"+ data.securityStatusDetails.MDSOperator);
						$rootScope.userAccess = data.securityStatusDetails.userAccess;
						$rootScope.mdsOperatorAccess = data.securityStatusDetails.MDSOperator;
						$rootScope.mdsUserName = data.securityStatusDetails.mdsUserName;
					}else{
						console.log("Access Restricted");
						$location.path("/mds-user-access-denied");
						$rootScope.userAccess = data.securityStatusDetails.userAccess;
					}
					console.log("****** Exiting reponse from Auth Service ********");

				})
		.error(
				function(error) {

					$scope.status = ' Error to load user data : '
							+ error.message;

				});
		
		
	
	};
	

	function getOperatorMessages() {

		console.log('inside the get operator messages ');

		marketOperatorMessageService.getMarketOperatorMessagesForLast24Hours()
				.success(function(data) {

					console.log(data);
					$scope.operatorMessages = data.operatorMessages;

				}).error(
						function(error) {

							$scope.status = ' Unable to Load the Data  : '
									+ error.message;

						});

	}

	$scope.testClick = function(data) {

		console.log(data);

	};

	$scope.open = function(operatorMessage) {

		console.log("new popu  ");
		var modalInstance = $uibModal.open({
			templateUrl : 'partials/popup.html',
			controller : 'PopupCont',
			resolve : {
				operatorMessage2 : function() {
					return operatorMessage;
				}				
			}
		});
	};

});

app.controller('PopupCont', function($scope, $modalInstance, operatorMessage2) {
	$scope.operatorMessage = operatorMessage2;
	
	$scope.close = function() {
		$modalInstance.dismiss('cancel');
	};
});

package com.caiso.mdsoasis.dto;

import java.io.Serializable;
import java.util.Date;

public class OasisNotificationCtlDto implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer           notificationCtlId;
    private String            marketId;
    private String            marketRunId;

    private String            notificationName;
    private String            notificationComments;
    private String            status;
    private String            mdsFlowState;
    private Date              createdDts;
    private Date              updatedDts;
    private String            updateUser;
    private Integer           mdsRetryCount;
    private Date              mdsProcessAfter;
    private Date              mdsFlowStartDts;
    private Date              mdsFlowEndDts;
    private Date              tradeDt;

    public Integer getNotificationCtlId() {
        return notificationCtlId;
    }

    public void setNotificationCtlId(Integer notificationCtlId) {
        this.notificationCtlId = notificationCtlId;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public String getNotificationName() {
        return notificationName;
    }

    public void setNotificationName(String notificationName) {
        this.notificationName = notificationName;
    }

    public String getNotificationComments() {
        return notificationComments;
    }

    public void setNotificationComments(String notificationComments) {
        this.notificationComments = notificationComments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMdsFlowState() {
        return mdsFlowState;
    }

    public void setMdsFlowState(String mdsFlowState) {
        this.mdsFlowState = mdsFlowState;
    }

    public Date getCreatedDts() {
        return createdDts;
    }

    public void setCreatedDts(Date createdDts) {
        this.createdDts = createdDts;
    }

    public Date getUpdatedDts() {
        return updatedDts;
    }

    public void setUpdatedDts(Date updatedDts) {
        this.updatedDts = updatedDts;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Integer getMdsRetryCount() {
        return mdsRetryCount;
    }

    public void setMdsRetryCount(Integer mdsRetryCount) {
        this.mdsRetryCount = mdsRetryCount;
    }

    public Date getMdsProcessAfter() {
        return mdsProcessAfter;
    }

    public void setMdsProcessAfter(Date mdsProcessAfter) {
        this.mdsProcessAfter = mdsProcessAfter;
    }

    public Date getMdsFlowStartDts() {
        return mdsFlowStartDts;
    }

    public void setMdsFlowStartDts(Date mdsFlowStartDts) {
        this.mdsFlowStartDts = mdsFlowStartDts;
    }

    public Date getMdsFlowEndDts() {
        return mdsFlowEndDts;
    }

    public void setMdsFlowEndDts(Date mdsFlowEndDts) {
        this.mdsFlowEndDts = mdsFlowEndDts;
    }

    public Date getTradeDt() {
        return tradeDt;
    }

    public void setTradeDt(Date tradeDt) {
        this.tradeDt = tradeDt;
    }

    @Override
    public String toString() {

        return " notificationCtlId :" + notificationCtlId + "\n" + "marketId :" + marketId + "\n" + "marketRunId :" + marketRunId + "\n"
                + " notificationName :" + notificationName + "\n" + " notificationComments :" + notificationComments + "\n" + " status :" + status + "\n"
                + " mdsFlowState :" + mdsFlowState + "\n" + " mdsFlowStartDts :" + mdsFlowStartDts + "\n" + " mdsFlowEndDts :" + mdsFlowEndDts;

    }

}

package com.caiso.mdsoasis.dto;

import java.io.Serializable;

public class OasisMarketToPublishRequest implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -5034830504717194793L;

    private String            mdsFlowState;
    private String            status;
    private String            notificationName;

    public String getMdsFlowState() {
        return mdsFlowState;
    }

    public void setMdsFlowState(String mdsFlowState) {
        this.mdsFlowState = mdsFlowState;
    }

    public String getNotificationName() {
        return notificationName;
    }

    public void setNotificationName(String notificationName) {
        this.notificationName = notificationName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {

        return "mdsFlowState :" + mdsFlowState + "\n" + " status :" + status + "\n" + " notificationName :" + notificationName;

    }

}

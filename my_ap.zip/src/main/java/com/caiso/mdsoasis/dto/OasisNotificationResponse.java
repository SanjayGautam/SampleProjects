package com.caiso.mdsoasis.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OasisNotificationResponse implements Serializable {

    /**
	 * 
	 */
    private static final long             serialVersionUID = 3650483129767540965L;

    private List<OasisNotificationCtlDto> oasisNotificationCtlDtos;
    private String                        responseResult   = "NotFound";

    public List<OasisNotificationCtlDto> getOasisNotificationCtlDtos() {

        if (oasisNotificationCtlDtos == null) {
            oasisNotificationCtlDtos = new ArrayList<OasisNotificationCtlDto>();
        }
        return oasisNotificationCtlDtos;
    }

    public void setOasisNotificationCtlDtos(List<OasisNotificationCtlDto> oasisNotificationCtlDtos) {
        this.oasisNotificationCtlDtos = oasisNotificationCtlDtos;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("OasisNotificationResponse responseResult :" + responseResult);
        List<OasisNotificationCtlDto> list = getOasisNotificationCtlDtos();

        for (OasisNotificationCtlDto oasisNotificationCtlDto : list) {
            sb.append("[");
            sb.append(oasisNotificationCtlDto.toString());
            sb.append("]\n");
        }

        return sb.toString();
    }

}

package com.caiso.mdsoasis.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OasisNotificationRequest implements Serializable {

    /**
	 * 
	 */
    private static final long             serialVersionUID = -3323031555478342830L;

    private String                        status;
    private String                        mdsFlowState;
    private List<String>                  notificationNames;

    private List<OasisNotificationCtlDto> oasisNotificationCtlDtos;

    public String getMdsFlowState() {
        return mdsFlowState;
    }

    public void setMdsFlowState(String mdsFlowState) {
        this.mdsFlowState = mdsFlowState;
    }

    public List<String> getNotificationNames() {
        if (notificationNames == null) {
            notificationNames = new ArrayList<String>();
        }
        return notificationNames;
    }

    public void setNotificationNames(List<String> notificationNames) {
        this.notificationNames = notificationNames;
    }

    public List<OasisNotificationCtlDto> getOasisNotificationCtlDtos() {
        if (oasisNotificationCtlDtos == null) {
            oasisNotificationCtlDtos = new ArrayList<OasisNotificationCtlDto>();
        }
        return oasisNotificationCtlDtos;
    }

    public void setOasisNotificationCtlDtos(List<OasisNotificationCtlDto> oasisNotificationCtlDtos) {
        this.oasisNotificationCtlDtos = oasisNotificationCtlDtos;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        sb.append("mdsFlowState :s" + mdsFlowState);

        List<String> notifcationNameList = getNotificationNames();
        sb.append("[");
        for (String notificatioName : notifcationNameList) {

            sb.append("notificatioName :");
            sb.append(notificatioName);
        }
        sb.append("]/n");

        List<OasisNotificationCtlDto> list = getOasisNotificationCtlDtos();

        for (OasisNotificationCtlDto oasisNotificationCtlDto : list) {
            sb.append("Oasis Notification Ctl [");
            sb.append(oasisNotificationCtlDto.toString());
        }
        sb.append("]/n");

        return sb.toString();
    }
}

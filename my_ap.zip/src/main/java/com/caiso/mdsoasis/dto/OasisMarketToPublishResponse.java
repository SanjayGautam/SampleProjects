package com.caiso.mdsoasis.dto;

import java.io.Serializable;

public class OasisMarketToPublishResponse implements Serializable {

    /**
	 * 
	 */
    private static final long       serialVersionUID = 3144979031146470938L;

    private OasisNotificationCtlDto oasisNotificationCtlDto;

    private String                  responseResult   = "NotFound";

    public OasisNotificationCtlDto getOasisNotificationCtlDto() {
        return oasisNotificationCtlDto;
    }

    public void setOasisNotificationCtlDto(OasisNotificationCtlDto oasisNotificationCtlDto) {
        this.oasisNotificationCtlDto = oasisNotificationCtlDto;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("OasisMarketToPublishResponse Response Result :" + responseResult);

        if (oasisNotificationCtlDto != null) {
            sb.append("[");
            sb.append(oasisNotificationCtlDto.toString());
            sb.append("]\n");
        }

        return sb.toString();
    }

}

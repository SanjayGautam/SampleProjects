package com.caiso.mdscmri.dto;

import java.io.Serializable;
import java.util.Date;

public class CmriOasisStatusCtlDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    private int               oasisStatusId;
    private String            marketId;
    private String            marketRunId;
    private String            notificationName;
    private String            notificationComments;
    private String            status;
    private Date              createdDts;

    public int getOasisStatusId() {
        return oasisStatusId;
    }

    public void setOasisStatusId(int oasisStatusId) {
        this.oasisStatusId = oasisStatusId;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public String getNotificationName() {
        return notificationName;
    }

    public void setNotificationName(String notificationName) {
        this.notificationName = notificationName;
    }

    public String getNotificationComments() {
        return notificationComments;
    }

    public void setNotificationComments(String notificationComments) {
        this.notificationComments = notificationComments;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedDts() {
        return createdDts;
    }

    public void setCreatedDts(Date createdDts) {
        this.createdDts = createdDts;
    }

    @Override
    public String toString() {

        return "oasisStatusId :" + oasisStatusId + "\n" + "marketId :" + marketId + "\n" + "marketRunId :" + marketRunId + "\n" + "notificationName :"
                + notificationName + "\n" + "notificationComments :" + notificationComments + "\n" + "status :" + status;

    }
}

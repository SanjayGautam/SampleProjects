package com.caiso.mdscmri.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CmriNotificationRequest implements Serializable {

    /**
	 * 
	 */
    private static final long            serialVersionUID = 6631208183508089554L;

    private List<CmriNotificationCtlDto> cmriNotificationCtlDtos;

    private List<CmriOasisStatusCtlDto>  cmriOasisStatusCtlDtos;

    public List<CmriOasisStatusCtlDto> getCmriOasisStatusCtlDtos() {
        if (cmriOasisStatusCtlDtos == null) {
            cmriOasisStatusCtlDtos = new ArrayList<CmriOasisStatusCtlDto>();
        }
        return cmriOasisStatusCtlDtos;
    }

    public void setCmriOasisStatusCtlDtos(List<CmriOasisStatusCtlDto> cmriOasisStatusCtlDtos) {
        this.cmriOasisStatusCtlDtos = cmriOasisStatusCtlDtos;

    }

    public List<CmriNotificationCtlDto> getCmriNotificationCtlDtos() {
        if (cmriNotificationCtlDtos == null) {
            cmriNotificationCtlDtos = new ArrayList<CmriNotificationCtlDto>();
        }
        return cmriNotificationCtlDtos;
    }

    public void setCmriNotificationCtlDtos(List<CmriNotificationCtlDto> cmriNotificationCtlDtos) {
        this.cmriNotificationCtlDtos = cmriNotificationCtlDtos;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        List<CmriNotificationCtlDto> list = getCmriNotificationCtlDtos();
        sb.append("CmriNotificationRequest ");
        for (CmriNotificationCtlDto cmriNotificationCtlDto : list) {
            sb.append("[");
            sb.append(cmriNotificationCtlDto.toString());
            sb.append("]\n");
        }

        return sb.toString();
    }
}

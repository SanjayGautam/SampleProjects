package com.caiso.mdscmri.dto;

import java.io.Serializable;

public class CmriMarketToPublishRequest implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -6225476587921971083L;
    private String            mdsFlowState;
    private String            cmriStatus;
    private String            notificationName;

    public String getMdsFlowState() {
        return mdsFlowState;
    }

    public void setMdsFlowState(String mdsFlowState) {
        this.mdsFlowState = mdsFlowState;
    }

    public String getCmriStatus() {
        return cmriStatus;
    }

    public void setCmriStatus(String cmriStatus) {
        this.cmriStatus = cmriStatus;
    }

    public String getNotificationName() {
        return notificationName;
    }

    public void setNotificationName(String notificationName) {
        this.notificationName = notificationName;
    }

    @Override
    public String toString() {

        return "CmriMarketToPublishRequest : mdsFlowState :" + mdsFlowState + "\n" + "cmriStatus :" + cmriStatus + "\n" + "notificationName :"
                + notificationName;

    }
}

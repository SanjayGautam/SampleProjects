package com.caiso.mdscmri.dto;

import java.io.Serializable;

public class CmriMarketToPublishResponse implements Serializable {

    /**
	 * 
	 */
    private static final long      serialVersionUID = -5637204274830807966L;

    private String                 responseResult   = "NotFound";
    private CmriNotificationCtlDto cmriNotificationCtlDto;

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

    public CmriNotificationCtlDto getCmriNotificationCtlDto() {
        return cmriNotificationCtlDto;
    }

    public void setCmriNotificationCtlDto(CmriNotificationCtlDto cmriNotificationCtlDto) {
        this.cmriNotificationCtlDto = cmriNotificationCtlDto;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        sb.append("CmriMarketToPublishResponse responseResult :" + responseResult);

        if (cmriNotificationCtlDto != null) {
            sb.append("[");
            sb.append(cmriNotificationCtlDto.toString());
            sb.append("]/n");
        }

        return sb.toString();
    }
}

package com.caiso.mds.soa.connector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.soa.parser.sax.ReceiveCleanBidCaisoDASaxAdaptorV4;
import com.caiso.mds.soa.parser.sax.ReceiveCleanBidCaisoRTSaxAdaptorV4;
import com.caiso.mds.soa.parser.sax.ReceiveFinalTradeSetSaxAdaptorV1;
import com.caiso.mds.types.ServiceName;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@Component
public class MdsReceiverEsbAdaptor {

    private final Logger                       logger = LoggerFactory.getLogger(MdsReceiverEsbAdaptor.class);

    @Autowired
    private ReceiveCleanBidCaisoRTSaxAdaptorV4 receiveCleanBidCaisoRTSaxAdaptorV4;

    @Autowired
    private ReceiveCleanBidCaisoDASaxAdaptorV4 receiveCleanBidCaisoDASaxAdaptorV4;

    @Autowired
    private ReceiveFinalTradeSetSaxAdaptorV1   receiveFinalTradeSetSaxAdaptorV1;

    public OutputDataType onMessage(String soapAction, String xmlPayload) throws Exception {

        logger.debug(" ******* Entering method onMessage(String soapAction, String xmlPayload)  ****** ");

        logger.info("Received payload of size :" + xmlPayload.length() + " for serviceUrl :" + soapAction);
        OutputDataType outputDataType = null;
        String serviceName = getServiceName(soapAction);
        logger.info("Service Name :" + serviceName);
        ServiceName service = ServiceName.valueOf(serviceName);

        switch (service) {
        case receiveDACleanBidCaiso_v4:
            outputDataType = processDaCleanBidCaiso_v4(serviceName, xmlPayload);
            break;
        case receiveRTCleanBidCaiso_v4:
            outputDataType = receiveRTCleanBidCaiso_v4(serviceName, xmlPayload);
            break;
        case receiveFinalTradeSet:
            outputDataType = receiveFinalTradeSet(serviceName, xmlPayload);
            break;
        default:
            throw new Exception("Invalid receive service " + serviceName);
        }

        logger.info("Processing of payload for service " + serviceName + " complete, returning SCSS0001 to SOA.");
        logger.debug(" ******* Exiting method onMessage(String soapAction, String xmlPayload)  ****** ");
        return outputDataType;
    }

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @throws Exception
     */
    private OutputDataType receiveFinalTradeSet(String serviceName, String xmlPayload) throws Exception {

        return receiveFinalTradeSetSaxAdaptorV1.process(serviceName, xmlPayload);

    }

    /**
     * 
     * @param soapActionValue
     * @return
     */
    private String getServiceName(String soapActionValue) {

        // http://www.caiso.com/soa/receiveRTCleanBidCaiso_v4.wsdl
        String serviceName = null;

        if (soapActionValue != null) {
            String[] actionParts = soapActionValue.split("/");
            logger.debug("SoapAction " + actionParts[actionParts.length - 1]);
            serviceName = actionParts[actionParts.length - 1];

        }

        return serviceName;
    }

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @throws Exception
     */
    private OutputDataType receiveRTCleanBidCaiso_v4(String serviceName, String xmlPayload) throws Exception {
        return receiveCleanBidCaisoRTSaxAdaptorV4.process(serviceName, xmlPayload);
    }

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @throws Exception
     */
    private OutputDataType processDaCleanBidCaiso_v4(String serviceName, String xmlPayload) throws Exception {
        return receiveCleanBidCaisoDASaxAdaptorV4.process(serviceName, xmlPayload);
    }

}

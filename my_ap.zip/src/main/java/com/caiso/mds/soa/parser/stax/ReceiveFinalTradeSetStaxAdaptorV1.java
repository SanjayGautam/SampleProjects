package com.caiso.mds.soa.parser.stax;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.external.ws.service.MdsToMnsService;
import com.caiso.mds.external.ws.service.MdsToSibrService;
import com.caiso.mds.mrkt.run.service.MarketPlanServiceHelper;
import com.caiso.mds.mrkt.run.service.MarketStatusService;
import com.caiso.mds.types.MarketStatusType;
import com.caiso.mds.util.OutputTypeResponseHelper;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;
import com.caiso.soa.proxies.trade.set.v1.MarketRunMsg;

@Component()
public class ReceiveFinalTradeSetStaxAdaptorV1 {

    private final Logger                      logger = LoggerFactory.getLogger(ReceiveFinalTradeSetStaxAdaptorV1.class);

    @Autowired
    private MdsToMnsService                   mdsToMnsService;

    @Autowired
    private MarketStatusService               marketStatusService;

    @Autowired
    private MdsToSibrService                  mdsToSibrService;

    @Autowired
    private OutputTypeResponseHelper          outputTypeResponseHelper;

    // receive
    @Autowired
    @Qualifier("receiveFinalTradeSetV1StaxBindingUtil")
    private StaxJaxbBindingUtil<MarketRunMsg> receiveFinalTradeSetV1StaxBindingUtil;

    @Autowired
    private MarketPlanServiceHelper           marketPlanServiceHelper;

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @return
     * @throws Exception
     */

    public OutputDataType process(String serviceName, String xmlPayload) throws Exception {

        logger.info("************ Processing FinalTradeDT payload ***************");
        MarketEventDefinitionDto marketEventDefinitionDto = new MarketEventDefinitionDto();

        JAXBElement<MarketRunMsg> finalTradeSetJaxbElement = receiveFinalTradeSetV1StaxBindingUtil.unmarshal(xmlPayload, MarketRunMsg.class, "MarketRun");

        MarketRunMsg marketRunMsg = finalTradeSetJaxbElement.getValue();
        logger.info("Market Plan Id	    	 :{} ", marketRunMsg.getMarketID());
        logger.info("Market Run Id	         :{} ", marketRunMsg.getMarketRunID());
        logger.info("Market End Time         :{} ", marketRunMsg.getMarketEndTime());

        MrktPlan mrktPlan = marketPlanServiceHelper.getMarketPlan(marketRunMsg.getMarketID(), marketRunMsg.getMarketRunID());

        if (mrktPlan != null) {

            List<MarketPlanDto> marketPlanDtos = prepareMarketPlanDto(mrktPlan);
            marketStatusService.changeMarketStatusesInMds(marketPlanDtos, "status changed due to final trade payload process");
            marketPlanServiceHelper.setEventNotificationCodeForPublishBasedOnMarketType(marketEventDefinitionDto, mrktPlan);
            mdsToMnsService.marketNotificationBpmFlowWrapper(marketRunMsg.getMarketID(), marketRunMsg.getMarketRunID(), marketRunMsg.getMarketEndTime(),
                    marketEventDefinitionDto);

        } else {

            logger.info("Since Market Id :{} and Market Plan Id :{}  Does not exist in the MDS System we are ignoring publish to MNS or Market Participants",
                    marketRunMsg.getMarketID(), marketRunMsg.getMarketRunID());

        }

        OutputDataType outputDataType = outputTypeResponseHelper.prepareResponse("SCSS0001", UUID.randomUUID().toString(), serviceName, serviceName
                + ": Received Data From AI", "INFO", "SVC", serviceName + ": Received Data From AI", serviceName + ": Received Data From AI");

        logger.info("************ End of FinalTradeDT payload ***************");
        return outputDataType;

    }

    /**
     * 
     * if (MarketType.RTM.toString().equals(mrktPlan.getMrktDefinition().
     * getMrktType())) { // set event for realtime trades
     * marketEventDefinitionDto.setMarketEventDefCode("RDFP");
     * logger.info("Market Event Set         :{}", "RDFP"); } else { // it is
     * assumed that other will be day ahead trade.
     * marketEventDefinitionDto.setMarketEventDefCode("DTFP");
     * logger.info("Market Event Set         :{}", "DTFP"); }
     * 
     * @param mrktPlan
     * @return
     */
    private List<MarketPlanDto> prepareMarketPlanDto(MrktPlan mrktPlan) {

        List<MarketPlanDto> marketPlanDtos = new ArrayList<MarketPlanDto>();

        MarketPlanDto marketPlanDto = new MarketPlanDto();
        marketPlanDto = new MarketPlanDto();
        marketPlanDto.setCreatedBy("sibr");
        marketPlanDto.setCreatedDate(new Date());
        marketPlanDto.setUpdatedBy("sibr");
        marketPlanDto.setUpdatedDate(new Date());
        marketPlanDto.setMarketClass(mrktPlan.getMrktDefinition().getMrktClass());
        marketPlanDto.setMarketDate(mrktPlan.getMrktDate().toDate());
        marketPlanDto.setMarketPlanId(mrktPlan.getId().getMrktPlanId());
        marketPlanDto.setMarketRunId(mrktPlan.getId().getMrktRunId());
        marketPlanDto.setMarketStatusTypeId(MarketStatusType.PUBLISH.getMarketStatusTypeId());
        marketPlanDto.setMarketType(mrktPlan.getMrktDefinition().getMrktType());
        marketPlanDto.setMarketDefinitionId(mrktPlan.getMrktDefinition().getMrktDefinitionId() + "");
        marketPlanDtos.add(marketPlanDto);
        return marketPlanDtos;
    }
}

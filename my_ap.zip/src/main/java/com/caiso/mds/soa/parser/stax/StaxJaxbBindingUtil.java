package com.caiso.mds.soa.parser.stax;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartElement;

import org.codehaus.stax2.XMLEventReader2;
import org.codehaus.stax2.XMLInputFactory2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ctc.wstx.stax.WstxInputFactory;

public class StaxJaxbBindingUtil<T> {

    private Unmarshaller unmarshaller = null;

    private JAXBContext  jc           = null;
    private final Logger logger       = LoggerFactory.getLogger(StaxJaxbBindingUtil.class);

    public StaxJaxbBindingUtil(String serviceJaxbContext) throws Exception {
        // create a JAXBContext capable of handling classes generated into
        // the ...data.dto package
        try {
            jc = JAXBContext.newInstance(serviceJaxbContext, Thread.currentThread().getContextClassLoader());

        } catch (Exception e) {
            logger.error("Error in XML Binding for jaxbContext :" + serviceJaxbContext, e);
            throw new Exception("[XMLBindUtility] Context: \'" + serviceJaxbContext + "\' is not a valid JAXB package", e);
        }
    }

    /**
     * 
     * @param xmlPayload
     * @param expectedType
     * @return
     * @throws Exception
     */
    public JAXBElement<T> unmarshal(String xmlPayload, Class<T> expectedType, String elementName) throws Exception {
        JAXBElement<T> jaxbElementObj = null;

        XMLEventReader2 xmlEventReader = null;

        try {

            if (unmarshaller == null) {
                unmarshaller = jc.createUnmarshaller();
            }

            xmlEventReader = getXmlEventReader(xmlPayload);

            while (xmlEventReader.hasNext()) {
                if (xmlEventReader.peek().isStartElement()) {
                    StartElement startelement = xmlEventReader.peek().asStartElement();
                    if (startelement.getName().getLocalPart().equals(elementName)) {
                        jaxbElementObj = unmarshaller.unmarshal(xmlEventReader, expectedType);
                    } else
                        xmlEventReader.next();
                } else
                    xmlEventReader.next();
            }

            return jaxbElementObj;

        } catch (JAXBException e) {
            logger.error("Errroor ", e);
            throw new Exception(e);
        }
    }

    /**
     * 
     * @param xmlPayload
     * @return
     * @throws UnsupportedEncodingException
     * @throws XMLStreamException
     */

    private XMLEventReader2 getXmlEventReader(String xmlPayload) throws UnsupportedEncodingException, XMLStreamException {
        XMLInputFactory2 xmlif2;
        XMLEventReader2 xer;
        xmlif2 = new WstxInputFactory();
        // xmlif2 = (XMLInputFactory2) XMLInputFactory.newInstance();
        xmlif2.setProperty(XMLInputFactory.IS_REPLACING_ENTITY_REFERENCES, Boolean.FALSE);
        xmlif2.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
        xmlif2.setProperty(XMLInputFactory.IS_COALESCING, Boolean.FALSE);
        xmlif2.setProperty(XMLInputFactory.IS_NAMESPACE_AWARE, Boolean.TRUE);

        byte[] byteArray = xmlPayload.getBytes("UTF-8");
        ByteArrayInputStream inputStream = new ByteArrayInputStream(byteArray);
        xer = (XMLEventReader2) xmlif2.createXMLEventReader(inputStream);
        return xer;
    }

}

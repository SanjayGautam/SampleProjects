package com.caiso.mds.soa.connector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.soa.parser.stax.ReceiveCleanBidCaisoDAStaxAdaptorV4;
import com.caiso.mds.soa.parser.stax.ReceiveCleanBidCaisoRTStaxAdaptorV4;
import com.caiso.mds.soa.parser.stax.ReceiveFinalTradeSetStaxAdaptorV1;
import com.caiso.mds.types.ServiceName;
import com.caiso.mds.util.SoapHelper;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@Component
public class MdsReceiverEsbStaxAdaptor {

    private final Logger                        logger = LoggerFactory.getLogger(MdsReceiverEsbStaxAdaptor.class);

    @Autowired
    private ReceiveCleanBidCaisoRTStaxAdaptorV4 receiveCleanBidCaisoRTStaxAdaptorV4;

    @Autowired
    private ReceiveCleanBidCaisoDAStaxAdaptorV4 receiveCleanBidCaisoDAStaxAdaptorV4;

    @Autowired
    private ReceiveFinalTradeSetStaxAdaptorV1   receiveFinalTradeSetStaxAdaptorV1;

    @Autowired
    private SoapHelper                          soapHelper;

    /**
     * 
     * @param soapAction
     * @param xmlPayload
     * @return
     * @throws Exception
     */
    public OutputDataType onMessage(String soapAction, String xmlPayload) throws Exception {

        logger.debug("********* Entering Method onMessage(String soapAction, String xmlPayload) ********** ");
        logger.info("Received payload of size :" + xmlPayload.length() + " for serviceUrl :" + soapAction);
        OutputDataType outputDataType = null;
        String serviceName = soapHelper.getServiceName(soapAction);
        logger.info("Service Name :" + serviceName);
        ServiceName service = ServiceName.valueOf(serviceName);

        switch (service) {
        case receiveDACleanBidCaiso_v4:
            outputDataType = processDaCleanBidCaiso_v4(serviceName, xmlPayload);
            break;
        case receiveRTCleanBidCaiso_v4:
            outputDataType = receiveRTCleanBidCaiso_v4(serviceName, xmlPayload);
            break;
        case receiveFinalTradeSet:
            outputDataType = receiveFinalTradeSet(serviceName, xmlPayload);
            break;
        default:
            throw new Exception("Invalid receive service " + serviceName);
        }

        logger.info("Processing of payload for service " + serviceName + " complete, returning SCSS0001 to SOA.");
        logger.debug("********* Exiting Method onMessage(String soapAction, String xmlPayload) ********** ");
        return outputDataType;
    }

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @throws Exception
     */
    private OutputDataType receiveFinalTradeSet(String serviceName, String xmlPayload) throws Exception {
        return receiveFinalTradeSetStaxAdaptorV1.process(serviceName, xmlPayload);
    }

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @throws Exception
     */
    private OutputDataType receiveRTCleanBidCaiso_v4(String serviceName, String xmlPayload) throws Exception {
        return receiveCleanBidCaisoRTStaxAdaptorV4.process(serviceName, xmlPayload);
    }

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @throws Exception
     */
    private OutputDataType processDaCleanBidCaiso_v4(String serviceName, String xmlPayload) throws Exception {
        return receiveCleanBidCaisoDAStaxAdaptorV4.process(serviceName, xmlPayload);
    }

}

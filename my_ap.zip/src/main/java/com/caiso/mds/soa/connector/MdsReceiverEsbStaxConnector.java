package com.caiso.mds.soa.connector;

import java.util.UUID;

import javax.xml.bind.JAXBException;
import javax.xml.soap.SOAPMessage;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.util.OutputTypeResponseHelper;
import com.caiso.mds.util.SoapHelper;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@Component
public class MdsReceiverEsbStaxConnector implements Processor {

    private static final Logger       logger = Logger.getLogger(MdsReceiverEsbStaxConnector.class);

    @Autowired
    private MdsReceiverEsbStaxAdaptor mdsReceiverEsbStaxAdaptor;

    @Autowired
    private SoapHelper                soapHelper;

    @Autowired
    private OutputTypeResponseHelper  outputTypeResponseHelper;

    @Override
    public void process(Exchange exchange) throws Exception {

        logger.debug("********* Entering Method process(Exchange exchange) ********** ");

        String soapAction = null;
        String xmlPayload = null;
        SOAPMessage soapMessage = null;
        StringBuilder soapResponse = null;
        OutputDataType outputDataType = null;

        try {

            soapMessage = soapHelper.getSoapMessage(exchange);
            xmlPayload = soapHelper.getContentFromAttachment(soapMessage);
            soapAction = soapHelper.validateSoapAction(exchange);

            if (xmlPayload != null) {
                outputDataType = mdsReceiverEsbStaxAdaptor.onMessage(soapAction, xmlPayload);
                soapResponse = soapHelper.getOutputDataType(outputDataType);
                exchange.getOut().setBody(soapResponse.toString());
            } else {
                logger.warn("No Attachment Found in the in coming messages");
                processError(exchange);
            }

            logger.debug("********* Exiting Method process(Exchange exchange) ********** ");

        } catch (Exception e) {

            logger.error("Error in Processing the MDS Request inside MdsReceiverEsbStaxConnector ", e);
            processError(exchange);
        }

    }

    /**
     * 
     * @param exchange
     * @throws JAXBException
     */

    private void processError(Exchange exchange) throws JAXBException {
        StringBuilder soapResponse;
        OutputDataType outputDataType;
        outputDataType = outputTypeResponseHelper.prepareResponse("SVC0001", UUID.randomUUID().toString(), "System Error",
                "An unexpected error occured while processing your request. Please check the logs for more details.", "ERROR", "GNRL0001",
                "Failed to update the Market Status in MDS", " Failed to update MarketStatus in MDS");

        soapResponse = soapHelper.getOutputDataType(outputDataType);
        exchange.getOut().setBody(soapResponse.toString());
    }

}

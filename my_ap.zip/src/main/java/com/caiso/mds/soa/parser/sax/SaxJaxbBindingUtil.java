package com.caiso.mds.soa.parser.sax;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SaxJaxbBindingUtil<T> {

    private final Logger logger       = LoggerFactory.getLogger(SaxJaxbBindingUtil.class);

    private Unmarshaller unmarshaller = null;

    private Marshaller   marshaller   = null;

    private JAXBContext  jc           = null;

    public SaxJaxbBindingUtil(String serviceJaxbContext) throws Exception {
        // create a JAXBContext capable of handling classes generated into
        // the ...data.dto package
        try {
            jc = JAXBContext.newInstance(serviceJaxbContext, Thread.currentThread().getContextClassLoader());

        } catch (Exception e) {
            logger.error("Error in XML Binding for jaxbContext :" + serviceJaxbContext, e);
            throw new Exception("[XMLBindUtility] Context: \'" + serviceJaxbContext + "\' is not a valid JAXB package", e);
        }
    }

    /**
     * 
     * @param xmlPayload
     * @param expectedType
     * @return
     * @throws Exception
     */
    public JAXBElement<T> unmarshal(String xmlPayload, Class<T> expectedType) throws Exception {
        JAXBElement<T> jaxbElementObj = null;

        try {

            if (unmarshaller == null) {
                unmarshaller = jc.createUnmarshaller();

            }
            StreamSource streamSource = new StreamSource(new StringReader(xmlPayload));
            jaxbElementObj = unmarshaller.unmarshal(streamSource, expectedType);

            return jaxbElementObj;
        } catch (JAXBException e) {
            logger.error("Error while UNMARSHALL the xmlPayload :" + xmlPayload, e);
            throw new Exception(e);
        }
    }

    /**
     * 
     * @param xmlPayload
     * @param expectedType
     * @return
     * @throws Exception
     */
    public String marshal(String nameSpaceUri, String namePart, Class<T> expectedType, T source) throws Exception {

        StringWriter stringWriter = new StringWriter();
        String result = null;
        try {

            if (marshaller == null) {
                marshaller = jc.createMarshaller();
            }

            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            // QName qName = new
            // QName("http://www.caiso.com/soa/2006-06-13/StandardOutput.xsd",
            // "OutputDataType");
            // "OutputDataType"
            QName qName = new QName(nameSpaceUri, namePart);
            JAXBElement<T> root = new JAXBElement<T>(qName, expectedType, source);
            marshaller.marshal(root, stringWriter);
            result = stringWriter.toString();
            if (result != null && result.length() > 0) {
                result = result.substring(result.indexOf("?>") + 2);
            }

        } catch (JAXBException e) {
            logger.error("Error while marshalling the nameSpaceUri :" + nameSpaceUri + " namePart :" + namePart, e);
            throw new Exception(e);
        }

        return result;
    }
}

package com.caiso.mds.soa.parser.sax;

import java.util.UUID;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.external.ws.service.MdsToMnsService;
import com.caiso.mds.mrkt.run.service.MarketPlanServiceHelper;
import com.caiso.mds.util.OutputTypeResponseHelper;
import com.caiso.soa.proxies.clean.bid.v4.CleanBidCaiso;
import com.caiso.soa.proxies.clean.bid.v4.MarketRun;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@Component
public class ReceiveCleanBidCaisoRTSaxAdaptorV4 {

    private final Logger                      logger = LoggerFactory.getLogger(ReceiveCleanBidCaisoRTSaxAdaptorV4.class);
    @Autowired
    @Qualifier("receiveCleanBidCaisoRTV4JaxbBindingUtil")
    private SaxJaxbBindingUtil<CleanBidCaiso> receiveCleanBidCaisoRTV4JaxbBindingUtil;

    @Autowired
    private OutputTypeResponseHelper          outputTypeResponseHelper;

    @Autowired
    private MarketPlanServiceHelper           marketPlanServiceHelper;

    @Autowired
    private MdsToMnsService                   mdsToMnsService;

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @return
     * @throws Exception
     */
    public OutputDataType process(String serviceName, String xmlPayload) throws Exception {

        logger.info("***************** Processing CleanBidRT Payload  ******");
        MarketEventDefinitionDto marketEventDefinitionDto = new MarketEventDefinitionDto();
        marketEventDefinitionDto.setMarketEventDefCode("RTCB");

        JAXBElement<CleanBidCaiso> cleanBidJaxbElement = receiveCleanBidCaisoRTV4JaxbBindingUtil.unmarshal(xmlPayload, CleanBidCaiso.class);

        logger.debug(" cleanBidJaxbELement " + cleanBidJaxbElement);
        CleanBidCaiso cleanBidCaiso = cleanBidJaxbElement.getValue();
        MarketRun marketRun = cleanBidCaiso.getMessagePayload().getMarketRun();
        logger.info("Market Plan Id	for  RTCB :{} ", marketRun.getMarketID());
        logger.info("Market Run Id for   RTCB :{} ", marketRun.getMarketRunID());
        logger.info("Market End Time for RTCB :{}", marketRun.getMarketEndTime());

        if (marketPlanServiceHelper.isMarketRunInMDS(marketRun.getMarketID(), marketRun.getMarketRunID())) {
            mdsToMnsService.marketNotificationBpmFlowWrapper(marketRun.getMarketID(), marketRun.getMarketRunID(), marketRun.getMarketEndTime(),
                    marketEventDefinitionDto);
        } else {
            logger.warn("Since Market Id :{} and Market Plan Id :{}  Does not exist in the MDS System we are ignoring publish to MNS or Market Participants",
                    marketRun.getMarketID(), marketRun.getMarketRunID());
        }

        OutputDataType outputDataType = outputTypeResponseHelper.prepareResponse("SCSS0001", UUID.randomUUID().toString(), serviceName, serviceName
                + ": Received Data From MDS", "INFO", "SVC", serviceName + ": Received Data From AI", serviceName + ": Received Data From MDS");

        logger.info("***************** Exit the Process Method ******");
        return outputDataType;

    }
}

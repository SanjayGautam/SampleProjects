package com.caiso.mds.soa.parser.stax;

import java.util.UUID;

import javax.xml.bind.JAXBElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.external.ws.service.MdsToMnsService;
import com.caiso.mds.mrkt.run.service.MarketPlanServiceHelper;
import com.caiso.mds.util.OutputTypeResponseHelper;
import com.caiso.soa.proxies.clean.bid.v4.MarketRun;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@Component
public class ReceiveCleanBidCaisoDAStaxAdaptorV4 {

    private final Logger                   logger = LoggerFactory.getLogger(ReceiveCleanBidCaisoDAStaxAdaptorV4.class);
    @Autowired
    @Qualifier("receiveCleanBidCaisoDAV4StaxBindingUtil")
    private StaxJaxbBindingUtil<MarketRun> receiveCleanBidCaisoDAV4StaxBindingUtil;

    @Autowired
    private OutputTypeResponseHelper       outputTypeResponseHelper;

    @Autowired
    private MdsToMnsService                mdsToMnsService;

    @Autowired
    private MarketPlanServiceHelper        marketPlanServiceHelper;

    /**
     * 
     * @param serviceName
     * @param xmlPayload
     * @return
     * @throws Exception
     */
    public OutputDataType process(String serviceName, String xmlPayload) throws Exception {

        logger.info("************* Processing Payload for the CleanBidDA ******");
        MarketRun marketRun = null;

        JAXBElement<MarketRun> jaxbElementMarketRun = receiveCleanBidCaisoDAV4StaxBindingUtil.unmarshal(xmlPayload, MarketRun.class, "MarketRun");
        marketRun = jaxbElementMarketRun.getValue();
        logger.info("Market Plan ID for DACB 			:{} ", marketRun.getMarketID());
        logger.info("Market Run ID for  DACB			:{}", marketRun.getMarketRunID());
        logger.info("Market End Time in Payload for DACB:{}", marketRun.getMarketEndTime());

        MarketEventDefinitionDto marketEventDefinitionDto = new MarketEventDefinitionDto();
        marketEventDefinitionDto.setMarketEventDefCode("DACB");

        if (marketPlanServiceHelper.isMarketRunInMDS(marketRun.getMarketID(), marketRun.getMarketRunID())) {

            mdsToMnsService.marketNotificationBpmFlowWrapper(marketRun.getMarketID(), marketRun.getMarketRunID(), marketRun.getMarketEndTime(),
                    marketEventDefinitionDto);

        } else {

            logger.warn("Since Market Id :{} and Market Plan Id :{}  Does not exist in the MDS System we are ignoring publish to MNS or Market Participants",
                    marketRun.getMarketID(), marketRun.getMarketRunID());

        }

        OutputDataType outputDataType = outputTypeResponseHelper.prepareResponse("SCSS0001", UUID.randomUUID().toString(), serviceName, serviceName
                + ": Received Data From AI", "INFO", "SVC", serviceName + ": Received Data From AI", serviceName + ": Received Data From AI");

        logger.info("***************** Exit the Process Method CleanBidDA ******");
        return outputDataType;

    }

}

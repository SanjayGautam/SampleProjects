package com.caiso.mds.soa.connector;

import java.util.UUID;

import javax.xml.soap.SOAPMessage;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.util.OutputTypeResponseHelper;
import com.caiso.mds.util.SoapHelper;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

public class MdsReceiverEsbConnector implements Processor {

    private final Logger             logger = LoggerFactory.getLogger(MdsReceiverEsbConnector.class);

    @Autowired
    private MdsReceiverEsbAdaptor    receiverAdaptor;

    @Autowired
    private OutputTypeResponseHelper outputTypeResponseHelper;

    @Autowired
    private SoapHelper               soapHelper;

    /**
     * Handles all incoming receive requests. Maps the payload using the
     * appropriate adaptor based on pService name.
     */

    @Override
    public void process(Exchange exchange) throws Exception {

        OutputDataType outputDataType = null;
        StringBuilder soapResponse = null;
        String xmlPayload = null;
        String soapAction = null;

        try {
            logger.debug(" ******* Entering method process(Exchange exchange) ****** ");

            SOAPMessage soapMessage = soapHelper.getSoapMessage(exchange);
            soapAction = soapHelper.validateSoapAction(exchange);
            xmlPayload = soapHelper.getContentFromAttachment(soapMessage);
            outputDataType = receiverAdaptor.onMessage(soapAction, xmlPayload);
            soapResponse = soapHelper.getOutputDataType(outputDataType);
            exchange.getOut().setBody(soapResponse.toString());

            logger.debug(" ******* Exiting method process(Exchange exchange) ****** ");

        } catch (Exception e) {

            logger.error("Error in processing the request inside MdsReceiverEsbConnector ", e);
            outputDataType = outputTypeResponseHelper.prepareResponse("SVC0001", UUID.randomUUID().toString(), "System Error",
                    "An unexpected error occured while processing your request. Please check the logs for more details.", "ERROR", "GNRL0001",
                    "Failed to update the Market Status in MDS", " Failed to update MarketStatus in MDS");

            soapResponse = soapHelper.getOutputDataType(outputDataType);
            exchange.getOut().setBody(soapResponse.toString());

        }

    }

}

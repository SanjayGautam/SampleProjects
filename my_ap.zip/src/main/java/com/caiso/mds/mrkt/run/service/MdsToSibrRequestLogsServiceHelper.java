package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.caiso.mds.entity.mds.MdsToSibrMsgLog;
import com.caiso.mds.entity.mds.MdsToSibrRequestLogResults;
import com.caiso.mds.ui.vo.MdsToSibrRequestLogVO;
import com.caiso.mds.ui.vo.MdsToSibrRequestLogsResultVO;

@Component
public class MdsToSibrRequestLogsServiceHelper {

    private final Logger logger = LoggerFactory.getLogger(MdsToSibrRequestLogsServiceHelper.class);

    /**
     * 
     * @param mdsToSibrRequestLogResults
     * @return
     */
    public MdsToSibrRequestLogsResultVO populateMarketEventNotificationLogObject(MdsToSibrRequestLogResults mdsToSibrRequestLogResults) {

        logger.debug("******** Entered method populateMarketEventNotificationLogObject ***************");

        MdsToSibrRequestLogsResultVO mdsToSibrRequestLogsResultVO = null;

        if (mdsToSibrRequestLogResults != null) {
            mdsToSibrRequestLogsResultVO = new MdsToSibrRequestLogsResultVO();
            mdsToSibrRequestLogsResultVO.setCurrentPageNumber(mdsToSibrRequestLogResults.getCurrentPageNumber());
            mdsToSibrRequestLogsResultVO.setCurrentPageSize(mdsToSibrRequestLogResults.getCurrentPageSize());
            mdsToSibrRequestLogsResultVO.setTotalPagesCount(mdsToSibrRequestLogResults.getTotalPagesCount());
            mdsToSibrRequestLogsResultVO.setTotalRowsCount(mdsToSibrRequestLogResults.getTotalRowsCount());

            List<MdsToSibrMsgLog> mdsToSibrMsgLogs = mdsToSibrRequestLogResults.getMdsToSibrMsgLogs();
            List<MdsToSibrRequestLogVO> mdsToSibrRequestLogVOs = new ArrayList<MdsToSibrRequestLogVO>();
            MdsToSibrRequestLogVO mdsToSibrRequestLogVO = null;

            for (MdsToSibrMsgLog mdsToSibrMsgLog : mdsToSibrMsgLogs) {
                mdsToSibrRequestLogVO = populateMdsToSibrRequestLogVO(mdsToSibrMsgLog);
                mdsToSibrRequestLogVOs.add(mdsToSibrRequestLogVO);
            }

            mdsToSibrRequestLogsResultVO.setMdsToSibrRequestLogs(mdsToSibrRequestLogVOs);
            logger.info("Notification Event History logs were found and fetching it ..");
        } else {

            mdsToSibrRequestLogsResultVO = new MdsToSibrRequestLogsResultVO();
            mdsToSibrRequestLogsResultVO.setCurrentPageNumber(1);
            mdsToSibrRequestLogsResultVO.setCurrentPageSize(1);
            mdsToSibrRequestLogsResultVO.setTotalPagesCount(1);
            mdsToSibrRequestLogsResultVO.setTotalRowsCount(0);
            List<MdsToSibrRequestLogVO> mdsToSibrRequestLogVOs = new ArrayList<MdsToSibrRequestLogVO>();
            mdsToSibrRequestLogsResultVO.setMdsToSibrRequestLogs(mdsToSibrRequestLogVOs);
            logger.info("Notification Event History logs not found..");

        }

        logger.debug("******** Exiting method populateMarketEventNotificationLogObject ***************");

        return mdsToSibrRequestLogsResultVO;
    }

    /**
     * 
     * @param mdsToSibrMsgLog
     * @return
     */

    private MdsToSibrRequestLogVO populateMdsToSibrRequestLogVO(MdsToSibrMsgLog mdsToSibrMsgLog) {
        MdsToSibrRequestLogVO mdsToSibrRequestLogVO = new MdsToSibrRequestLogVO();
        mdsToSibrRequestLogVO.setMarketClass(mdsToSibrMsgLog.getMrktClass());
        mdsToSibrRequestLogVO.setMarketDate(mdsToSibrMsgLog.getMrktDate().toDate());
        mdsToSibrRequestLogVO.setMarketPlanId(mdsToSibrMsgLog.getMrktPlanId());
        mdsToSibrRequestLogVO.setMarketRunId(mdsToSibrMsgLog.getMrktRunId());
        mdsToSibrRequestLogVO.setMarketType(mdsToSibrMsgLog.getMrktType());
        mdsToSibrRequestLogVO.setServiceRequest(mdsToSibrMsgLog.getServiceRequest());
        mdsToSibrRequestLogVO.setServiceResponse(mdsToSibrMsgLog.getServiceResponse());
        mdsToSibrRequestLogVO.setServiceShortRequest("View");
        mdsToSibrRequestLogVO.setServiceShortResponse("View");
        mdsToSibrRequestLogVO.setRequestedTime(mdsToSibrMsgLog.getCreatedDt());

        return mdsToSibrRequestLogVO;
    }
}

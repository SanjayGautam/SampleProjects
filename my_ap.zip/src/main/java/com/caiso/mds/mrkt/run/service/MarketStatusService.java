package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketPlanDao;
import com.caiso.mds.dao.mds.MdsMarketStatusHistoryDao;
import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktStatusHistory;
import com.caiso.mds.types.MarketDefintionType;
import com.caiso.mds.types.MarketStatusType;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mds.marketstatus.MarketRunMktStatusMsg;
import com.caiso.soa.proxies.mds.marketstatus.MarketStatus;

@Component
public class MarketStatusService {

    private final static Logger       logger = LoggerFactory.getLogger(MarketStatusService.class);

    @Autowired
    private MdsMarketPlanDao          mdsMarketPlanDao;

    @Autowired
    private MdsMarketStatusHistoryDao mdsMarketStatusHistoryDao;

    @Autowired
    private MarketPlanServiceHelper   marketPlanServiceHelper;

    @Autowired
    private DateUtil                  dateUtil;

    public void changeMarketStatus(MarketPlanDto marketPlanDto, String statusChangeComments) {

        // TODO get the previous and current status for market
        MrktPlan mrktPlan = marketPlanServiceHelper.populateMrkPlanObject(marketPlanDto);
        // Add new status in the market status history table SO now e.g. if OPEN
        // was there it will be CLOSE just incase new status
        // is CLOSE

        MrktStatusHistory mrktStatusHistory = marketPlanServiceHelper.populateMrktStatusHistory(marketPlanDto, statusChangeComments);

        // Change the status in the Market Plan Table

        mdsMarketPlanDao.updateMrktPlan(mrktPlan);
        mdsMarketStatusHistoryDao.createMarketStatusHistory(mrktStatusHistory);

    }

    /**
     * 
     * @param marketStatus
     * @param statusChangeComments
     */

    public void changeMarketStatusesInMds(MarketStatus marketStatus, String statusChangeComments) {

        List<MarketPlanDto> marketPlanDtos = populateMarketPlanDto(marketStatus);
        for (MarketPlanDto marketPlanDto : marketPlanDtos) {
            if (marketPlanServiceHelper.isMarketRunInMDS(marketPlanDto)) {
                changeMarketStatus(marketPlanDto, statusChangeComments);
            } else {
                logger.info("Market Plan id :{} Market Run Id :{} Does not exists and hence Ignoreing the Market status Update ",
                        marketPlanDto.getMarketPlanId(), marketPlanDto.getMarketRunId());
            }
        }

    }

    /**
     * 
     * @param marketStatus
     * @param statusChangeComments
     */
    public void changeMarketStatusesInMds(List<MarketPlanDto> marketPlanDtos, String statusChangeComments) {

        for (MarketPlanDto marketPlanDto : marketPlanDtos) {
            if (marketPlanServiceHelper.isMarketRunInMDS(marketPlanDto)) {
                changeMarketStatus(marketPlanDto, statusChangeComments);
            } else {
                logger.info("Market Plan id :{} Market Run Id :{} Does not exists and hence Ignoreing the Market status Update ",
                        marketPlanDto.getMarketPlanId(), marketPlanDto.getMarketRunId());
            }
        }

    }

    /**
     * 
     * @param marketPlanId
     * @return
     */
    public Long getLastMarketStatusForMarketRunId(String marketRunId) {

        Long marketStatusHistoryId = mdsMarketStatusHistoryDao.getLastMarketStatusForMarketRunId(marketRunId);

        if (marketStatusHistoryId == null) {
            logger.warn("Market status history was found to be null for Market Run Id, process will fail. marketRunId:[" + marketRunId + "]");
        }

        return marketStatusHistoryId;

    }

    /**
     * 
     * @param marketStatus
     * @return
     */
    private List<MarketPlanDto> populateMarketPlanDto(MarketStatus marketStatus) {

        List<MarketPlanDto> marketPlanDtos = new ArrayList<MarketPlanDto>();
        MarketPlanDto marketPlanDto = null;

        List<MarketRunMktStatusMsg> list = marketStatus.getMarketRun();
        for (MarketRunMktStatusMsg marketRunMktStatusMsg : list) {
            logger.info("********* Market(s) Received From the SIBR ********************* ");

            marketPlanDto = new MarketPlanDto();
            marketPlanDto.setCreatedBy("sibr");
            marketPlanDto.setCreatedDate(new Date());
            marketPlanDto.setUpdatedBy("sibr");
            marketPlanDto.setUpdatedDate(new Date());
            marketPlanDto.setMarketClass(marketRunMktStatusMsg.getMarketClass().name());
            marketPlanDto.setMarketDate(dateUtil.getUtilDateFromXmlGeorgianDate(marketRunMktStatusMsg.getMarketStartTime()));
            marketPlanDto.setMarketPlanId(marketRunMktStatusMsg.getMarketID());
            marketPlanDto.setMarketRunId(marketRunMktStatusMsg.getMarketRunID());
            marketPlanDto.setMarketStatusTypeId(MarketStatusType.valueOf(marketRunMktStatusMsg.getRequestedStatus().value()).getMarketStatusTypeId());
            marketPlanDto.setMarketType(marketRunMktStatusMsg.getMarketType().name());

            marketPlanDto.setMarketDefinitionId(MarketDefintionType.valueOf(
                    marketRunMktStatusMsg.getMarketType().name() + "_" + marketRunMktStatusMsg.getMarketClass().name()).getId()
                    + "");

            logger.info("	Market Plan Id 			:{}", marketRunMktStatusMsg.getMarketID());
            logger.info("	Market Run  Id 			:{}", marketRunMktStatusMsg.getMarketRunID());
            logger.info("	Market Type 			:{}", marketRunMktStatusMsg.getMarketType().name());
            logger.info("	Market Class 			:{}", marketRunMktStatusMsg.getMarketClass().name());
            logger.info("	Market Requested Status	:{}", marketRunMktStatusMsg.getRequestedStatus().value());

            logger.info("******************************************************************");
            marketPlanDtos.add(marketPlanDto);
        }

        logger.info("**************** End of Markets Received from SIBR ********************");
        return marketPlanDtos;
    }

    /**
     * 
     * @return
     */
    public Long getMaxMarketStatusHistoryId() {
        Long maxStatusHistoryId = mdsMarketStatusHistoryDao.getMaxMarketStatusHistoryId();
        return maxStatusHistoryId;
    }

}

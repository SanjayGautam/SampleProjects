package com.caiso.mds.mrkt.run.service;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketEventHistoryDao;
import com.caiso.mds.dto.MarketEventHistoryDto;
import com.caiso.mds.entity.mds.MrktEventLogResults;
import com.caiso.mds.entity.mds.MrktEvntHistory;
import com.caiso.mds.ui.vo.MarketEventNotificationLogsResultVO;

@Component
public class MarketEventHistoryService {

    private final Logger                    logger                          = LoggerFactory.getLogger(MarketEventHistoryService.class);

    @Autowired
    private MdsMarketEventHistoryDao        mdsMarketEventHistoryDao;

    @Autowired
    private MarketEventHistoryServiceHelper marketEventHistoryServiceHelper;

    @Autowired
    private Integer                         mdsMonitorWebPaginationPageSize = 25;

    public void createMarketEventHistory(MarketEventHistoryDto marketEventHistoryDto) {

        logger.debug("******** Entered method createMarketEventHistory  ********* ");
        MrktEvntHistory mrktEvntHistory = marketEventHistoryServiceHelper.populateMarketEventHistory(marketEventHistoryDto);
        mdsMarketEventHistoryDao.createMrktEvntHistory(mrktEvntHistory);
        logger.debug("******** Exiting method createMarketEventHistory  ********* ");
    }

    /**
     * 
     * @param pageNumber
     * @return
     */
    public MarketEventNotificationLogsResultVO getMarketEventNotificationLog(int pageNumber) {

        logger.debug("******** Entered method getMarketEventNotificationLog  ********* ");

        DateTime marketDateInPST = new DateTime();
        marketDateInPST = marketDateInPST.minusHours(24);
        MrktEventLogResults marketEventLogResults = mdsMarketEventHistoryDao.getMrtEventHistoryLog(pageNumber, mdsMonitorWebPaginationPageSize,
                marketDateInPST.toDate());
        MarketEventNotificationLogsResultVO marketEventNotificationLogsResultVO = marketEventHistoryServiceHelper
                .populateMarketEventNotificationLogObject(marketEventLogResults);

        logger.debug("******** Exiting method getMarketEventNotificationLog  ********* ");
        return marketEventNotificationLogsResultVO;
    }
}

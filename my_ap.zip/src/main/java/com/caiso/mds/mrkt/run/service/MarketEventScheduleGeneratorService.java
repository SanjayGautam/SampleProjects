package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketEventDefinitionDao;
import com.caiso.mds.dao.mds.MdsMarketEventScheduleDao;
import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.entity.mds.MrktEvntDef;
import com.caiso.mds.entity.mds.MrktEvntSchd;
import com.caiso.mds.exception.MdsBpmException;
import com.caiso.mds.util.MarketEventScheduleGenerator;

@Component
public class MarketEventScheduleGeneratorService {

    private static final int             DAYS_30 = 30;

    private final Logger                 logger  = LoggerFactory.getLogger(MarketEventScheduleGeneratorService.class);

    @Autowired
    private MdsMarketEventScheduleDao    mdsMarketEventScheduleDao;

    @Autowired
    private MdsMarketEventDefinitionDao  mdsMarketEventDefinitionDao;

    @Autowired
    private MarketEventScheduleGenerator marketEventScheduleGenerator;

    @Autowired
    private Integer                      numberOfDaysMarketEventScheduleToBeCreated;

    public void generateEventSchedules() throws MdsBpmException {

        logger.debug("******** Entered method generateEventSchedules ***************");

        List<MrktEvntSchd> mrktEvntSchds = null;
        int diffDays = -1;
        DateTime todayDate = new DateTime();

        DateTime marketDateInMarketEventSchedule = deriveMarketDateForMarketEventSchedule();

        if (marketDateInMarketEventSchedule != null) {
            diffDays = Days.daysBetween(todayDate, marketDateInMarketEventSchedule).getDays();
            logger.info(" Days In Between " + diffDays);
        }

        try {
            if (diffDays >= DAYS_30) {
                logger.info("The Market Event Schedules are already there for the days :{} in future no need to generate more data right now. ***** ",
                        diffDays);
            } else {
                logger.info("Going to Generate the Market Event Schedules as data available is not more than " + DAYS_30 + " days  ***** ");
                mrktEvntSchds = generate(marketDateInMarketEventSchedule);
                Date dateStart = new Date();
                logger.info(" @XXX Start Time : " + dateStart.getTime());
                mdsMarketEventScheduleDao.createMarketEventSchedules(mrktEvntSchds);
                Date dateEnd = new Date();
                logger.info(" @XXX End Time : " + dateEnd);

            }
        } catch (Exception e) {
            logger.error("Error while Generating Market Event Schedules.", e);
            throw new MdsBpmException(e);
        }

        logger.debug("******** Exited method generateEventSchedules ***************");

    }

    /**
     * 
     * @param marketDateInMarketEventSchedule
     */
    private List<MrktEvntSchd> generate(DateTime marketDateInMarketEventSchedule) {

        logger.debug("******** Entered method generate ***************");

        List<MrktEvntSchd> allMarketEventSchedules = new ArrayList<MrktEvntSchd>();
        // we get all the events which are internal , has fixed time to trigger
        // and enabled
        List<MrktEvntDef> marketEventsDefs = mdsMarketEventDefinitionDao.getMarketEventDef(false, true, true);
        DateTime tempDate = null;
        marketDateInMarketEventSchedule = marketDateInMarketEventSchedule.withTimeAtStartOfDay();
        tempDate = marketDateInMarketEventSchedule.toDateTime();

        for (int i = 0; i < numberOfDaysMarketEventScheduleToBeCreated; i++) {

            for (MrktEvntDef mrktEvntDef : marketEventsDefs) {
                List<MrktEvntSchd> marketEvntScheduleForMarketDef = marketEventScheduleGenerator.processGeneric(mrktEvntDef, tempDate);
                allMarketEventSchedules.addAll(marketEvntScheduleForMarketDef);
            }

            tempDate = marketDateInMarketEventSchedule.plusDays(i + 1);
        }

        logger.debug("******** Exited method generate ***************");

        return allMarketEventSchedules;
    }

    /**
     * 
     * @return
     */
    private DateTime deriveMarketDateForMarketEventSchedule() {

        DateTime marketDateInMarketEventSchedule = mdsMarketEventScheduleDao.getLastMarketDateSchedule();
        if (marketDateInMarketEventSchedule != null) {
            marketDateInMarketEventSchedule.plusDays(1);
        } else {
            marketDateInMarketEventSchedule = new DateTime();
        }
        return marketDateInMarketEventSchedule;
    }

    /**
     * 
     * @param marketEventNotificationDto
     */
    public void updateMarketEventSchedule(MarketEventNotificationDto marketEventNotificationDto) {

        logger.info("Updating  the Market Event Schedule Id {} record to {}", marketEventNotificationDto.getMarketEventScheduleId(),
                marketEventNotificationDto.getMarketEventPubState());
        if (marketEventNotificationDto.getMarketEventScheduleId() != 0) {
            MrktEvntSchd mrktEvntSchd = prepareMarketEventSchedule(marketEventNotificationDto);
            mdsMarketEventScheduleDao.updateMrktEvntSchd(mrktEvntSchd);
        } else {
            logger.info(
                    "Market Event Schedule Id was 0 and Market Run Id {} Market Plan Id {} Market Event Schedule Table was Not Updated as the record does not exists",
                    marketEventNotificationDto.getMarketRunId(), marketEventNotificationDto.getMarketPlanId());
        }
        logger.info("Updateing the Market Event Schedule record to PUBLISHED ");

    }

    /**
     * 
     * @param marketEventNotificationDto
     * @return
     */
    private MrktEvntSchd prepareMarketEventSchedule(MarketEventNotificationDto marketEventNotificationDto) {

        MrktEvntSchd mrktEvntSchd = new MrktEvntSchd();
        mrktEvntSchd.setCreatedBy("mds_bpm");
        mrktEvntSchd.setUpdatedBy("mds_bpm");
        mrktEvntSchd.setUpdatedDt(new Date());
        mrktEvntSchd.setMrktDate(new DateTime(marketEventNotificationDto.getMarketDate()));
        mrktEvntSchd.setMrktEvntFireDate(new DateTime(marketEventNotificationDto.getMarketEventFireDateTime()));
        mrktEvntSchd.setMrktEvntPubState(marketEventNotificationDto.getMarketEventPubState());
        mrktEvntSchd.setMrktEvntSchdId(marketEventNotificationDto.getMarketEventScheduleId());

        return mrktEvntSchd;
    }

}

package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketPlanDao;
import com.caiso.mds.dto.MarketDefintionDto;
import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.entity.mds.MrktDefinition;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktPlanAndStatusDetails;
import com.caiso.mds.entity.mds.MrktPlanPK;
import com.caiso.mds.entity.mds.MrktStatusHistory;
import com.caiso.mds.entity.mds.MrktStatusType;
import com.caiso.mds.types.MarketDefintionType;
import com.caiso.mds.types.MarketType;
import com.caiso.mds.ui.vo.BidAndSchedulesStatusVO;
import com.caiso.mds.ui.vo.InterScTradesStatusVO;
import com.caiso.mds.ui.vo.MarketStatusVO;
import com.caiso.mds.ui.vo.MarketStatuses;

@Component
public class MarketPlanServiceHelper {

    private final Logger     logger = LoggerFactory.getLogger(MarketPlanServiceHelper.class);

    @Autowired
    private MdsMarketPlanDao mdsMarketPlanDao;

    /**
     * 
     * @param marketPlanDto
     * @return
     */
    public boolean isMarketRunInMDS(MarketPlanDto marketPlanDto) {

        MrktPlan mrktPlan = mdsMarketPlanDao.getMarketPlan(marketPlanDto.getMarketPlanId(), marketPlanDto.getMarketRunId());
        if (mrktPlan != null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 
     * @param marketPlanDto
     * @return
     */
    public boolean isMarketRunInMDS(String marketPlanId, String marketRunId) {

        MrktPlan mrktPlan = mdsMarketPlanDao.getMarketPlan(marketPlanId, marketRunId);
        if (mrktPlan != null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 
     * @param marketPlanId
     * @param marketRunId
     * @return
     */
    public MrktPlan getMarketPlan(String marketPlanId, String marketRunId) {

        return mdsMarketPlanDao.getMarketPlan(marketPlanId, marketRunId);

    }

    /**
     * 
     * @param mrkplanDtos
     * @return
     */
    public List<MrktPlan> populateMrktPlanObjects(List<MarketPlanDto> mrkplanDtos) {

        List<MrktPlan> list = new ArrayList<MrktPlan>();

        for (MarketPlanDto marketPlanDto : mrkplanDtos) {
            MrktPlan p = populateMrkPlanObject(marketPlanDto);
            list.add(p);
        }
        return list;
    }

    public MrktPlan setMrktPlanPkToMrktPlanObj(String mrktPlanId, String mrktRunId) {
        MrktPlan mrktPlan = new MrktPlan();
        MrktPlanPK markPlanPK = new MrktPlanPK();
        markPlanPK.setMrktPlanId(mrktPlanId);
        markPlanPK.setMrktRunId(mrktRunId);
        mrktPlan.setId(markPlanPK);
        return mrktPlan;
    }

    /**
     * 
     * @param marketPlanDto
     * @return
     */
    public MrktPlan populateMrkPlanObject(MarketPlanDto marketPlanDto) {
        MrktPlan mrktPlan = new MrktPlan();
        MrktPlanPK id = new MrktPlanPK();
        id.setMrktPlanId(marketPlanDto.getMarketPlanId());
        id.setMrktRunId(marketPlanDto.getMarketRunId());
        mrktPlan.setId(id);
        // p.setMrktDate(marketPlanDto.getMarketDate());

        DateTime marketDate = new DateTime(marketPlanDto.getMarketDate(), DateTimeZone.UTC);
        mrktPlan.setMrktDate(marketDate);
        mrktPlan.setMrktHour(marketPlanDto.getMarketHour());

        MrktDefinition md = new MrktDefinition();
        md.setMrktDefinitionId(Long.parseLong(marketPlanDto.getMarketDefinitionId()));
        mrktPlan.setMrktDefinition(md);

        MrktStatusType mst = new MrktStatusType();
        mst.setMrktStatusTypeId(marketPlanDto.getMarketStatusTypeId());

        mrktPlan.setMrktStatusType(mst);

        mrktPlan.setCreatedDt(new Date());
        mrktPlan.setCreatedBy(marketPlanDto.getCreatedBy());

        mrktPlan.setUpdatedDt(new Date());
        mrktPlan.setUpdatedBy(marketPlanDto.getUpdatedBy());
        mrktPlan.setRecStatus(marketPlanDto.getRecordStatus());

        // TODO to see whether really need this other wise here as we are
        // manually taking care of the relationship
        MrktStatusHistory mrktStatusHistory = populateMrktStatusHistory(mrktPlan, mst);
        mrktPlan.setMrktStatusHistories(new ArrayList<MrktStatusHistory>());
        mrktPlan.addMrktStatusHistory(mrktStatusHistory);

        return mrktPlan;
    }

    /**
     * 
     * @param p
     * @param mst
     * @return
     */

    public MrktStatusHistory populateMrktStatusHistory(MrktPlan p, MrktStatusType mst) {

        MrktStatusHistory mrktStatusHistory = new MrktStatusHistory();
        mrktStatusHistory.setComments("New Market Created ");

        mrktStatusHistory.setMrktPlan(p);
        /*
         * mrktStatusHistory.setMrktPlanId(p.getId().getMrktPlanId());
         * mrktStatusHistory.setMrktRunId(p.getId().getMrktRunId());
         */

        mrktStatusHistory.setMrktStatusType(mst);

        mrktStatusHistory.setCreatedBy("mds_bpm");
        mrktStatusHistory.setUpdatedBy("mds_bpm");
        mrktStatusHistory.setUpdatedDt(new Date());
        mrktStatusHistory.setCreatedDt(new Date());
        return mrktStatusHistory;
    }

    /**
     * 
     * @param marketPlanDto
     * @param changeComments
     * @return
     */
    public MrktStatusHistory populateMrktStatusHistory(MarketPlanDto marketPlanDto, String changeComments) {

        // Market Plan Details
        MrktPlan mrktPlan = new MrktPlan();
        MrktPlanPK id = new MrktPlanPK();
        id.setMrktPlanId(marketPlanDto.getMarketPlanId());
        id.setMrktRunId(marketPlanDto.getMarketRunId());
        mrktPlan.setId(id);

        // Market status type
        MrktStatusType mst = new MrktStatusType();
        mst.setMrktStatusTypeId(marketPlanDto.getMarketStatusTypeId());

        // Market History
        MrktStatusHistory mrktStatusHistory = new MrktStatusHistory();
        mrktStatusHistory.setComments(changeComments);
        mrktStatusHistory.setMrktPlan(mrktPlan);
        mrktStatusHistory.setMrktStatusType(mst);
        mrktStatusHistory.setCreatedBy("mds_bpm");
        mrktStatusHistory.setUpdatedBy("mds_bpm");
        mrktStatusHistory.setUpdatedDt(new Date());
        mrktStatusHistory.setCreatedDt(new Date());
        return mrktStatusHistory;

    }

    /**
     * 
     * @param marketDefinitionsForMarketTypeList
     * @return
     */
    public List<MarketDefintionDto> populateMarketDefObject(List<MrktDefinition> marketDefinitionsForMarketTypeList) {

        List<MarketDefintionDto> list = new ArrayList<MarketDefintionDto>();

        for (MrktDefinition mrktDefinition : marketDefinitionsForMarketTypeList) {

            MarketDefintionDto dto = new MarketDefintionDto();
            dto.setMarketClass(mrktDefinition.getMrktClass());
            dto.setMarketType(mrktDefinition.getMrktType());
            dto.setMarketDefinitionId(mrktDefinition.getMrktDefinitionId() + "");
            dto.setMarketActivityId((int) mrktDefinition.getMrktActivity().getMrktActivityId());
            list.add(dto);

        }

        return list;
    }

    public MarketPlanDto createMarketPlanDto(MrktPlan mrktPlan) {

        MarketPlanDto marketPlanDto = null;
        if (mrktPlan != null) {
            marketPlanDto = new MarketPlanDto();
            marketPlanDto.setCreatedBy(mrktPlan.getCreatedBy());
            marketPlanDto.setCreatedDate(mrktPlan.getUpdatedDt());
            marketPlanDto.setMarketDate(mrktPlan.getMrktDate().toDate());
            marketPlanDto.setMarketHour(mrktPlan.getMrktHour());
            marketPlanDto.setMarketPlanId(mrktPlan.getId().getMrktPlanId());
            marketPlanDto.setMarketRunId(mrktPlan.getId().getMrktRunId());
            marketPlanDto.setUpdatedBy(mrktPlan.getUpdatedBy());
            marketPlanDto.setUpdatedDate(mrktPlan.getUpdatedDt());
            marketPlanDto.setMarketDefinitionId(Long.toString(mrktPlan.getMrktDefinition().getMrktDefinitionId()));
            marketPlanDto.setMarketStatusTypeId(mrktPlan.getMrktStatusType().getMrktStatusTypeId());
        }

        return marketPlanDto;
    }

    /**
     * 
     * @param mrktPlans
     * @return
     */
    public List<MarketPlanDto> populateMarketPlansDto(List<MrktPlan> mrktPlans) {

        List<MarketPlanDto> marketPlanDtos = new ArrayList<MarketPlanDto>();

        if (mrktPlans.size() > 0) {

            for (MrktPlan mrktPlan : mrktPlans) {

                MarketPlanDto marketPlanDto = populateMarketPlanDto(mrktPlan);
                marketPlanDtos.add(marketPlanDto);
            }

        }
        return marketPlanDtos;
    }

    /**
     * 
     * @param mrktPlan
     * @return
     */

    public MarketPlanDto populateMarketPlanDto(MrktPlan mrktPlan) {

        MarketPlanDto marketPlanDto = new MarketPlanDto();
        marketPlanDto.setCreatedBy(mrktPlan.getCreatedBy());
        marketPlanDto.setCreatedDate(mrktPlan.getCreatedDt());
        marketPlanDto.setMarketDate(mrktPlan.getMrktDate().toDate());
        marketPlanDto.setMarketDefinitionId(mrktPlan.getMrktDefinition().getMrktDefinitionId() + "");
        marketPlanDto.setMarketHour(mrktPlan.getMrktHour());
        marketPlanDto.setMarketPlanId(mrktPlan.getId().getMrktPlanId());
        marketPlanDto.setMarketRunId(mrktPlan.getId().getMrktRunId());
        marketPlanDto.setMarketStatusTypeId(mrktPlan.getMrktStatusType().getMrktStatusTypeId());
        marketPlanDto.setRecordStatus(mrktPlan.getRecStatus());
        marketPlanDto.setUpdatedBy(mrktPlan.getUpdatedBy());
        marketPlanDto.setUpdatedDate(mrktPlan.getUpdatedDt());
        marketPlanDto.setMarketClass(mrktPlan.getMrktDefinition().getMrktClass());
        marketPlanDto.setMarketType(mrktPlan.getMrktDefinition().getMrktType());

        return marketPlanDto;
    }

    /**
     * 
     * @param markAndStatusDetails
     * @return
     */
    public MarketStatuses createMarketStatuses(List<MrktPlanAndStatusDetails> markAndStatusDetails) {

        MarketStatuses marketStatuses = new MarketStatuses();
        List<MarketStatusVO> marketStatusForDamMarkets = populateForDamMarketDetails(markAndStatusDetails);
        List<MarketStatusVO> marketStatusForRtmMarkets = populateForRtmMarketDetails(markAndStatusDetails);
        marketStatuses.setMarketStatusForDamMarkets(marketStatusForDamMarkets);
        marketStatuses.setMarketStatusForRtmMarkets(marketStatusForRtmMarkets);

        return marketStatuses;
    }

    /**
     * 
     * @param markAndStatusDetails
     * @return
     */

    private List<MarketStatusVO> populateForRtmMarketDetails(List<MrktPlanAndStatusDetails> markAndStatusDetails) {

        List<MarketStatusVO> marketStatusForRtmMarket = new ArrayList<MarketStatusVO>();
        MarketStatusVO marketStatusVO = new MarketStatusVO();

        for (MrktPlanAndStatusDetails mrktPlanAndStatusDetails : markAndStatusDetails) {

            if (mrktPlanAndStatusDetails.getMrktDefinition().getMrktDefinitionId() == MarketDefintionType.RTM_MARKET.getId()) {

                marketStatusVO = new MarketStatusVO();
                marketStatusVO.setHourEnding(mrktPlanAndStatusDetails.getMarketHour());

                BidAndSchedulesStatusVO bidAndSchedulesStatusVO = populateBidAndSchedulesStatusVO(mrktPlanAndStatusDetails);

                marketStatusVO.setBidAndSchedulesStatus(bidAndSchedulesStatusVO);

                marketStatusForRtmMarket.add(marketStatusVO);

            }
        }

        int index = 0;
        for (MrktPlanAndStatusDetails mrktPlanAndStatusDetails : markAndStatusDetails) {

            if (mrktPlanAndStatusDetails.getMrktDefinition().getMrktDefinitionId() == MarketDefintionType.RTM_TRADES.getId()) {

                marketStatusVO = marketStatusForRtmMarket.get(index);

                InterScTradesStatusVO interScTradesStatusVO = populateInterScTradesStatusVO(mrktPlanAndStatusDetails);

                marketStatusVO.setInterScTradesStatus(interScTradesStatusVO);
                index++;
            }

        }

        logger.debug(" Market RTM ### Status count now  " + marketStatusForRtmMarket.size());
        return marketStatusForRtmMarket;
    }

    /**
     * 
     * @param mrktPlanAndStatusDetails
     * @return
     */

    private InterScTradesStatusVO populateInterScTradesStatusVO(MrktPlanAndStatusDetails mrktPlanAndStatusDetails) {
        InterScTradesStatusVO interScTradesStatusVO = new InterScTradesStatusVO();
        interScTradesStatusVO.setMarketPlanId(mrktPlanAndStatusDetails.getMarketPlanId());
        interScTradesStatusVO.setMarketRunId(mrktPlanAndStatusDetails.getMarketRunId());
        interScTradesStatusVO.setMarketDate(mrktPlanAndStatusDetails.getMarketDate().toDate());
        interScTradesStatusVO.setMarketType(mrktPlanAndStatusDetails.getMrktDefinition().getMrktType());
        interScTradesStatusVO.setMarketClass(mrktPlanAndStatusDetails.getMrktDefinition().getMrktClass());
        interScTradesStatusVO.setMarketCurrentStatus(mrktPlanAndStatusDetails.getMarketStatus());
        return interScTradesStatusVO;
    }

    /**
     * 
     * @param mrktPlanAndStatusDetails
     * @return
     */
    private BidAndSchedulesStatusVO populateBidAndSchedulesStatusVO(MrktPlanAndStatusDetails mrktPlanAndStatusDetails) {
        BidAndSchedulesStatusVO bidAndSchedulesStatusVO = new BidAndSchedulesStatusVO();
        bidAndSchedulesStatusVO.setMarketPlanId(mrktPlanAndStatusDetails.getMarketPlanId());
        bidAndSchedulesStatusVO.setMarketRunId(mrktPlanAndStatusDetails.getMarketRunId());
        bidAndSchedulesStatusVO.setMarketDate(mrktPlanAndStatusDetails.getMarketDate().toDate());
        bidAndSchedulesStatusVO.setMarketDefId(mrktPlanAndStatusDetails.getMrktDefinition().getMrktDefinitionId());
        bidAndSchedulesStatusVO.setMarketType(mrktPlanAndStatusDetails.getMrktDefinition().getMrktType());
        bidAndSchedulesStatusVO.setMarketClass(mrktPlanAndStatusDetails.getMrktDefinition().getMrktClass());
        bidAndSchedulesStatusVO.setMarketCurrentStatus(mrktPlanAndStatusDetails.getMarketStatus());
        return bidAndSchedulesStatusVO;
    }

    /**
     * 
     * @param markAndStatusDetails
     * @return
     */
    private List<MarketStatusVO> populateForDamMarketDetails(List<MrktPlanAndStatusDetails> markAndStatusDetails) {

        List<MarketStatusVO> marketStatusForDamMarket = new ArrayList<MarketStatusVO>();
        MarketStatusVO marketStatusVO = new MarketStatusVO();

        for (MrktPlanAndStatusDetails mrktPlanAndStatusDetails : markAndStatusDetails) {

            if (mrktPlanAndStatusDetails.getMrktDefinition().getMrktDefinitionId() == MarketDefintionType.DAM_MARKET.getId()) {

                marketStatusVO = new MarketStatusVO();
                marketStatusVO.setHourEnding(mrktPlanAndStatusDetails.getMarketHour());

                BidAndSchedulesStatusVO bidAndSchedulesStatusVO = populateBidAndSchedulesStatusVO(mrktPlanAndStatusDetails);

                marketStatusVO.setBidAndSchedulesStatus(bidAndSchedulesStatusVO);

                marketStatusForDamMarket.add(marketStatusVO);

            }
        }

        int index = 0;
        for (MrktPlanAndStatusDetails mrktPlanAndStatusDetails : markAndStatusDetails) {

            if (mrktPlanAndStatusDetails.getMrktDefinition().getMrktDefinitionId() == MarketDefintionType.DAM_TRADES.getId()) {

                marketStatusVO = marketStatusForDamMarket.get(index);

                InterScTradesStatusVO interScTradesStatusVO = populateInterScTradesStatusVO(mrktPlanAndStatusDetails);

                marketStatusVO.setInterScTradesStatus(interScTradesStatusVO);
                index++;
            }

        }

        logger.debug(" Market DAM ### Status count now  " + marketStatusForDamMarket.size());
        return marketStatusForDamMarket;

    }

    /**
     * 
     * @param marketEventDefinitionDto
     * @param mrktPlan
     */
    public void setEventNotificationCodeForPublishBasedOnMarketType(MarketEventDefinitionDto marketEventDefinitionDto, MrktPlan mrktPlan) {

        if (MarketType.RTM.toString().equals(mrktPlan.getMrktDefinition().getMrktType())) {
            // set event for realtime trades
            marketEventDefinitionDto.setMarketEventDefCode("RDFP");
            logger.info("Market Event Set         :{}", "RDFP");
        } else {
            // it is assumed that other will be day ahead trade.
            marketEventDefinitionDto.setMarketEventDefCode("DTFP");
            logger.info("Market Event Set         :{}", "DTFP");
        }
    }

}

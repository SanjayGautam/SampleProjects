package com.caiso.mds.mrkt.run.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsLogDao;
import com.caiso.mds.dao.mds.MdsMarketEventHistoryDao;
import com.caiso.mds.dao.mds.MdsMarketStatusHistoryDao;
import com.caiso.mds.dao.mds.MdsToSibrMsgLogDao;

@Component
public class DatabaseCleanUpService {

    private final Logger              logger = LoggerFactory.getLogger(DatabaseCleanUpService.class);

    @Autowired
    private MdsLogDao                 mdsLogDao;

    @Autowired
    private MdsToSibrMsgLogDao        mdsToSibrMsgLogDao;

    @Autowired
    private MdsMarketEventHistoryDao  mdsMarketEventHistoryDao;

    @Autowired
    private MdsMarketStatusHistoryDao mdsMarketStatusHistoryDao;

    @Autowired
    private Integer                   mdsPurgingNumberOfDaysInPast;

    public int cleanupDatabase() {

        int recordsDeleted = 0;
        logger.info("****  Entered the MDSCleanUpTask ***** ");
        recordsDeleted = mdsLogDao.deleteMdsLogRecordsBasedOnDaysInPast(mdsPurgingNumberOfDaysInPast);
        logger.info("****  MDSCleanUpTask deleted records in MDS_LOG Table [" + recordsDeleted + "]");
        recordsDeleted = mdsToSibrMsgLogDao.deleteMdsToSibrLogRecordsBasedOnDaysInPast(mdsPurgingNumberOfDaysInPast);
        logger.info("****  MDSCleanUpTask deleted records in MDS_TO_SIBR_LOG Table [" + recordsDeleted + "]");
        recordsDeleted = mdsMarketEventHistoryDao.deleteMarketEventHistoryBasedOnDaysInPast(mdsPurgingNumberOfDaysInPast);
        logger.info("****  MDSCleanUpTask deleted records in MRKT_EVNT_HISTORY Table [" + recordsDeleted + "]");
        recordsDeleted = mdsMarketStatusHistoryDao.deleteMarketStatusHistoryBasedOnDaysInPast(mdsPurgingNumberOfDaysInPast);
        logger.info("****  MDSCleanUpTask deleted records in MRKT_STATUS_HISTORY Table [" + recordsDeleted + "]");
        logger.info("****  Exited the MDSCleanUpTask ***** ");

        return recordsDeleted;
    }

}

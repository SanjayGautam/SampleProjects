package com.caiso.mds.mrkt.run.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MdsLogDto;
import com.caiso.mds.entity.mds.MdsLog;
import com.caiso.mds.entity.mds.MdsLogMsgType;

@Component
public class MdsLogServiceHelper {

    @Autowired
    MarketPlanServiceHelper marketPlanServiceHelper;

    public MdsLog populateMdsLogObj(MdsLogDto mdsLogDto) {

        MdsLog mdsLog = new MdsLog();
        mdsLog.setMdsLogInsertDts(new Date());

        // MDS Log Type Id
        MdsLogMsgType mdsLogMsgType = new MdsLogMsgType();
        mdsLogMsgType.setMdsLogMsgTypeId(mdsLogDto.getLogMessageTypeId());
        mdsLog.setMdsLogMsgType(mdsLogMsgType);

        mdsLog.setMessageDetail(mdsLogDto.getMessageDetail());
        mdsLog.setMessageSummary(mdsLogDto.getMessageSummary());
        // mrkt plan
        // MrktPlan mrktPlan
        // =marketPlanServiceHelper.setMrktPlanPkToMrktPlanObj(mdsLogDto.getMarketPlanId(),
        // mdsLogDto.getMarketRunId());
        mdsLog.setMrktPlanId(mdsLogDto.getMarketPlanId());
        mdsLog.setMrktRunId(mdsLogDto.getMarketRunId());

        // status history Id
        /*
         * MrktStatusHistory mrktStatusHistory = new MrktStatusHistory();
         * mrktStatusHistory
         * .setMrktStatusHistoryId(mdsLogDto.getMarketStatusHistoryId());
         */
        mdsLog.setMrktStatusHistoryId(mdsLogDto.getMarketStatusHistoryId());
        ;
        // event history id
        /*
         * MrktEvntHistory mrktEvntHistory = new MrktEvntHistory();
         * mrktEvntHistory.setMrktEvntHistoryId();
         */
        mdsLog.setMrktEvntHistoryId(mdsLogDto.getMarketEventHistoryId());

        return mdsLog;
    }

}

package com.caiso.mds.mrkt.run.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsLogDao;
import com.caiso.mds.dto.MdsLogDto;
import com.caiso.mds.entity.mds.MdsLog;

@Component
public class MdsLogService {

    @Autowired
    private MdsLogDao           mdsLogDao;

    @Autowired
    private MdsLogServiceHelper mdsLogServiceHelper;

    public void log(MdsLogDto mdsLogDto) {
        MdsLog mdsLog = mdsLogServiceHelper.populateMdsLogObj(mdsLogDto);
        mdsLogDao.createMdsLogRecord(mdsLog);
    }

}

package com.caiso.mds.mrkt.run.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketEventDefinitionDao;
import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.entity.mds.MrktEvntDef;

@Component
public class MarketEventDefinitionService {

    private final Logger                logger = LoggerFactory.getLogger(MarketEventDefinitionService.class);

    @Autowired
    private MdsMarketEventDefinitionDao mdsMarketEventDefinitionDao;

    /**
     * MarketEventNotification is a Domain Object which actually is or will be
     * published, but it is made from the Information related with
     * MarketEventDefinition and hence I intentionally used the two object to
     * keep the Domain and Entity Class decoupled.
     * 
     * @param marketEventDefinitionDto
     * @return
     */
    public MarketEventDefinitionDto getMarketEventDefinitionByEventDefCode(MarketEventDefinitionDto marketEventDefinitionDto) {
        logger.debug("******** Entered method getMarketEventDefinitionByEventDefCode  ********* ");
        MrktEvntDef mrktEvntDef = mdsMarketEventDefinitionDao.getMarketDefinitionByEventCode(marketEventDefinitionDto);
        marketEventDefinitionDto = populateMarketEventNotificationDetails(mrktEvntDef);
        logger.debug("******** Exiting method getMarketEventDefinitionByEventDefCode  ********* ");
        return marketEventDefinitionDto;
    }

    /**
     * 
     * @param marketEventDefinitionDto
     * @return
     */
    private MarketEventDefinitionDto populateMarketEventNotificationDetails(MrktEvntDef mrktEvntDef) {

        logger.debug("******** Entered method  populateMarketEventNotificationDetails********* ");
        MarketEventDefinitionDto marketEventDefintionDto = null;

        if (mrktEvntDef != null) {
            marketEventDefintionDto = new MarketEventDefinitionDto();
            marketEventDefintionDto.setMarketEventDefId(mrktEvntDef.getMrktEvntDefId());
            marketEventDefintionDto.setMarketEventDefNotificationMsg(mrktEvntDef.getMrktEvntNotificationMsg());
            marketEventDefintionDto.setMarketEventDefNotificationName(mrktEvntDef.getMrktEvntNotificationName());
            marketEventDefintionDto.setMarketEventDefCode(mrktEvntDef.getMrktEvntCd());
            marketEventDefintionDto.setMarketEventDefDesc(mrktEvntDef.getMrktEvntDesc());
            marketEventDefintionDto.setMarketEventType(mrktEvntDef.getMrktEvntType());
            if (mrktEvntDef.getAssocMrktDefinitionId() != null) {
                marketEventDefintionDto.setAssociatedMarketDefId(mrktEvntDef.getAssocMrktDefinitionId().longValue());
            }

        } else {

            logger.warn("Market event Def not found {}", mrktEvntDef);

        }

        logger.debug("******** Exiting method  populateMarketEventNotificationDetails********* ");
        return marketEventDefintionDto;
    }

    /**
     * 
     * @param associatedMarketDefId
     * @param marketEventType
     * @return
     */
    public MarketEventDefinitionDto getMarketEventDefinitionForMarketEventTypeAndMarketDefId(long associatedMarketDefId, String marketEventType) {

        logger.debug("******** Entered method  getMarketEventDefinitionForMarketEventTypeAndMarketDefId ********* ");
        MrktEvntDef mrktEvntDef = mdsMarketEventDefinitionDao.getMarketDefinitionByMarketDefIdAndMarketEventType(associatedMarketDefId, marketEventType);
        MarketEventDefinitionDto marketEventDefinitionDto = populateMarketEventNotificationDetails(mrktEvntDef);
        logger.debug("******** Exiting method  getMarketEventDefinitionForMarketEventTypeAndMarketDefId ********* ");

        return marketEventDefinitionDto;
    }

}

package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketDefinitionDao;
import com.caiso.mds.dao.mds.MdsMarketPlanDao;
import com.caiso.mds.dao.mds.MdsMarketStatusHistoryDao;
import com.caiso.mds.dto.MarketDefintionDto;
import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.dto.MarketPlanServiceResponse;
import com.caiso.mds.entity.mds.MrktDefinition;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktPlanAndStatusDetails;
import com.caiso.mds.entity.mds.MrktStatusHistory;
import com.caiso.mds.exception.MdsBpmException;
import com.caiso.mds.types.MarketDefintionType;
import com.caiso.mds.types.MarketType;
import com.caiso.mds.ui.vo.MarketStatuses;
import com.caiso.mds.util.DateUtil;
import com.caiso.mds.util.MarketPlanGenerator;

@Component
public class MarketPlanService {

    private static final int _30_DAYS = 30;

    @Autowired
    private MdsMarketPlanDao          mdsMarketPlanDao;

    @Autowired
    private MdsMarketStatusHistoryDao mdsMarketStatusHistoryDao;

    @Autowired
    private MdsMarketDefinitionDao    mdsMarketDefinitionDao;

    @Autowired
    private Integer                   numberOfDaysToGenerateMarketPlans;

    @Autowired
    private MarketPlanServiceHelper   marketPlanServiceHelper;

    @Autowired
    private MarketPlanGenerator       marketPlanGenerator;

    @Autowired
    private DateUtil                  dateUtil;

    private final Logger              logger = LoggerFactory.getLogger(MarketPlanService.class);

    /**
     * 
     * @param marketType
     * @throws MdsBpmException
     */
    public void generateMarketPlanByMarketType(MarketType marketType) throws MdsBpmException {

        DateTime lastMarketDate = null;
        DateTime todayDate = new DateTime();
        int diffDays = -1;
        lastMarketDate = mdsMarketPlanDao.getLastMarketPlanDateByMarketType(marketType);
        logger.info("lastMarketDate " + lastMarketDate + " marketType " + marketType);
        if (lastMarketDate != null) {
            diffDays = Days.daysBetween(todayDate, lastMarketDate).getDays();
            logger.info(" Days In Between " + diffDays);
        }

        try {
            if (lastMarketDate == null) {
                Calendar marketDateCal = dateUtil.resetMarketDateToStartOf24HourCycle();
                generate(marketType, marketDateCal);
            } else if (diffDays >= _30_DAYS) {
                logger.info(" Last Date For MarketType  " + marketType.getName() + " Last Date  " + lastMarketDate + " Is After Days No Need to Generate Today"
                        + diffDays);

            } else {
                logger.info(" Going to Generate because Date Found in Database is Not After Now . " + lastMarketDate.toString() + " marketType " + marketType);
                Calendar marketDateCal = dateUtil.resetMarketDateToStartOf24CycleForThatDay(lastMarketDate);
                marketDateCal.add(Calendar.DAY_OF_YEAR, 1);
                generate(marketType, marketDateCal);
            }
        } catch (Exception e) {

            logger.error("Error in Generating Market Plan By Market Type", e);
            throw new MdsBpmException("Error in Generating Market Plan By Market Type ", e);

        }
    }

    /**
     * 
     * @param marketType
     * @param startMarketDate
     */

    private void generate(MarketType marketType, Calendar startMarketDate) {
        List<MrktDefinition> marketDefinitionsForMarketType = mdsMarketDefinitionDao.getMarketDefintionByMarketType(marketType);
        List<MarketDefintionDto> mrktDefList = marketPlanServiceHelper.populateMarketDefObject(marketDefinitionsForMarketType);
        logger.info("Going to Generate Market Plans for :{}", numberOfDaysToGenerateMarketPlans.intValue());

        for (int i = 0; i < numberOfDaysToGenerateMarketPlans.intValue(); i++) {

            List<MarketPlanDto> mrkplanDtos = marketPlanGenerator.getMarketPlans(startMarketDate.getTime(), marketType, mrktDefList);
            List<MrktPlan> mrktplans = marketPlanServiceHelper.populateMrktPlanObjects(mrkplanDtos);
            mdsMarketPlanDao.createMrktPlans(mrktplans);
            List<MrktStatusHistory> mrktStatusHistories = createMarketStatusHistoryFromMarketPlans(mrktplans);
            mdsMarketStatusHistoryDao.createMarketStatusHistories(mrktStatusHistories);
            startMarketDate.add(Calendar.DAY_OF_YEAR, 1);

        }
    }

    /**
     * 
     * @param mrktplans
     * @return
     */

    private List<MrktStatusHistory> createMarketStatusHistoryFromMarketPlans(List<MrktPlan> mrktplans) {

        List<MrktStatusHistory> mrktStatusHistories = new ArrayList<MrktStatusHistory>();
        MrktStatusHistory mrktStatusHistory = null;

        for (MrktPlan mrktPlan : mrktplans) {
            mrktStatusHistory = new MrktStatusHistory();

            mrktStatusHistory.setMrktPlan(mrktPlan);
            mrktStatusHistory.setCreatedBy("mds_bpm");
            mrktStatusHistory.setCreatedDt(new Date());
            mrktStatusHistory.setUpdatedBy("mds_bpm");
            mrktStatusHistory.setUpdatedDt(new Date());
            mrktStatusHistory.setMrktStatusType(mrktPlan.getMrktStatusType());

            mrktStatusHistories.add(mrktStatusHistory);
        }
        return mrktStatusHistories;
    }

    public Integer getNumberOfDaysToGenerateMarketPlans() {
        return numberOfDaysToGenerateMarketPlans;
    }

    public void setNumberOfDaysToGenerateMarketPlans(Integer numberOfDaysToGenerateMarketPlans) {
        this.numberOfDaysToGenerateMarketPlans = numberOfDaysToGenerateMarketPlans;
    }

    /**
     * 
     * @param marketPlanId
     * @param marketRunId
     * @return
     */
    public MarketPlanServiceResponse getMarketDetails(String marketPlanId, String marketRunId) {
        logger.info(" Market Plan ID " + marketPlanId);
        logger.info(" Market Run ID  " + marketRunId);

        MrktPlan mrktPlan = mdsMarketPlanDao.getMarketPlan(marketPlanId, marketRunId);
        MarketPlanDto marketPlanDto = marketPlanServiceHelper.createMarketPlanDto(mrktPlan);
        MarketPlanServiceResponse marketPlanServiceResponse = null;
        if (marketPlanDto != null) {
            marketPlanServiceResponse = new MarketPlanServiceResponse();
            marketPlanServiceResponse.setMarketPlanDto(marketPlanDto);
            marketPlanServiceResponse.setResponseResult("Found");
        } else {
            marketPlanServiceResponse = new MarketPlanServiceResponse();
            marketPlanServiceResponse.setResponseResult("NotFound");
        }

        return marketPlanServiceResponse;

    }

    /**
     * 
     * @param marketDateInPST
     * @return
     */
    public MarketStatuses getMarketStatusForMainMarkets(MarketType marketType, Date marketDateInPST) {

        Long[] marketDefIdsArr;

        if (marketType.equals(MarketType.DAM)) {
            marketDefIdsArr = new Long[] { MarketDefintionType.DAM_MARKET.getId(), MarketDefintionType.DAM_TRADES.getId(), };
        } else {
            marketDefIdsArr = new Long[] { MarketDefintionType.RTM_TRADES.getId(), MarketDefintionType.RTM_MARKET.getId() };
        }

        List<Long> marketDefIds = Arrays.asList(marketDefIdsArr);

        List<MrktPlanAndStatusDetails> markAndStatusDetails = mdsMarketPlanDao.getMarketStatusForMainMarketDate(marketDateInPST, marketDefIds);
        MarketStatuses marketStatuses = marketPlanServiceHelper.createMarketStatuses(markAndStatusDetails);
        return marketStatuses;
    }

    /**
     * 
     * @param marketType
     * @param marketDateInPST
     * @param currentMarketHour
     * @return
     */
    public MarketStatuses getMarketStatusForMainMarketsForCurrentHour(MarketType marketType) {

        Long[] marketDefIdsArr;

        if (marketType.equals(MarketType.DAM)) {
            marketDefIdsArr = new Long[] { MarketDefintionType.DAM_MARKET.getId(), MarketDefintionType.DAM_TRADES.getId(), };
        } else {
            marketDefIdsArr = new Long[] { MarketDefintionType.RTM_TRADES.getId(), MarketDefintionType.RTM_MARKET.getId() };
        }

        List<Long> marketDefIds = Arrays.asList(marketDefIdsArr);
        Date marketCurrentDateAndHourInPST = new Date();

        List<MrktPlanAndStatusDetails> markAndStatusDetails = mdsMarketPlanDao.getMarketStatusForMainMarketsForCurrentHour(marketCurrentDateAndHourInPST,
                marketDefIds);
        MarketStatuses marketStatuses = marketPlanServiceHelper.createMarketStatuses(markAndStatusDetails);
        return marketStatuses;
    }

    /**
     * 
     * @param marketDateInPST
     * @return
     */

    public MarketStatuses getMarketStatusForMainMarkets(Date marketDateInPST) {

        Long[] marketDefIdsArr = { MarketDefintionType.DAM_MARKET.getId(), MarketDefintionType.DAM_TRADES.getId(), MarketDefintionType.RTM_TRADES.getId(),
                MarketDefintionType.RTM_MARKET.getId() };

        List<Long> marketDefIds = Arrays.asList(marketDefIdsArr);

        List<MrktPlanAndStatusDetails> markAndStatusDetails = mdsMarketPlanDao.getMarketStatusForMainMarketDate(marketDateInPST, marketDefIds);
        MarketStatuses marketStatuses = marketPlanServiceHelper.createMarketStatuses(markAndStatusDetails);
        return marketStatuses;
    }

    /**
     * 
     * @param marketDate
     * @param marketDefId
     * @return
     */
    public List<MarketPlanDto> getMarketPlanDtos(Date marketDate, Long marketDefId) {

        List<MrktPlan> mrktPlans = mdsMarketPlanDao.getMarketPlans(marketDate, marketDefId);
        List<MarketPlanDto> marketPlanDtos = marketPlanServiceHelper.populateMarketPlansDto(mrktPlans);

        return marketPlanDtos;
    }

    public List<MarketPlanDto> getMarketPlansForMarketPlanIdAndMarketDefId(String marketPlanId, Long marketDefId) {

        List<MrktPlan> mrktPlans = mdsMarketPlanDao.getMarketPlansForMarketPlanIdAndMarketDefId(marketPlanId, marketDefId);
        List<MarketPlanDto> marketPlanDtos = marketPlanServiceHelper.populateMarketPlansDto(mrktPlans);

        return marketPlanDtos;
    }

    public String getMarketStatus(String marketPlanId, Long marketDefId) {

        String marketStatus = mdsMarketPlanDao.getMarketStatusForMarketPlanIdAndDefId(marketPlanId, marketDefId);

        return marketStatus;
    }

    /**
     * 
     * @param marketEventNotifications
     * @return
     */

    public List<MarketEventNotificationDto> updateMarketDatesForMarketEventNotifications(List<MarketEventNotificationDto> marketEventNotifications) {

        for (MarketEventNotificationDto marketEventNotificationDto : marketEventNotifications) {
            MrktPlan mrktPlan = mdsMarketPlanDao.getMarketPlan(marketEventNotificationDto.getMarketPlanId(), marketEventNotificationDto.getMarketRunId());
            if (mrktPlan != null) {
                marketEventNotificationDto.setMarketDate(mrktPlan.getMrktDate().toDate());
            } else {
                logger.warn("while updating market event notification dto we were not able to find market run id {}",
                        marketEventNotificationDto.getMarketRunId());
            }
        }

        return marketEventNotifications;
    }
}

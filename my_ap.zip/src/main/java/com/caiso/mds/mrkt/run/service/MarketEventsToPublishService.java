package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketEventDefinitionDao;
import com.caiso.mds.dao.mds.MdsMarketEventScheduleDao;
import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.entity.mds.MrktEvntDef;
import com.caiso.mds.entity.mds.MrktEvntNotification;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.external.ws.service.MdsToMnsService;
import com.caiso.mds.types.MarketDefintionType;
import com.caiso.mds.types.MarketEventType;
import com.caiso.soa.proxies.mds.marketstatus.MarketRunMktStatusMsg;
import com.caiso.soa.proxies.mds.marketstatus.MarketStatus;

@Component
public class MarketEventsToPublishService {

    private final Logger                    logger = LoggerFactory.getLogger(MarketEventsToPublishService.class);

    @Autowired
    private MdsToMnsService                 mdsToMnsService;

    @Autowired
    private MdsMarketEventScheduleDao       mdsMarketEventScheduleDao;

    @Autowired
    private MarketEventHistoryServiceHelper marketEventHistoryServiceHelper;

    @Autowired
    private MarketPlanServiceHelper         marketPlanServiceHelper;

    @Autowired
    private MdsMarketEventDefinitionDao     mdsMarketEventDefinitionDao;

    public List<MarketEventNotificationDto> getMarketEventsNotificationForMarketDef(MarketDefintionType marketDefintionType) {

        List<MrktEvntNotification> list = mdsMarketEventScheduleDao.getMarketEventNotifications(marketDefintionType.getId());
        List<MarketEventNotificationDto> eventNotificationDtos = prepareNotificationDTO(list);
        return eventNotificationDtos;
    }

    /**
     * 
     * @param marketEventPubState
     * @return
     */
    public List<MarketEventNotificationDto> getAllMarketEventsToPublishNow(String marketEventPubState) {

        List<MrktEvntNotification> list = mdsMarketEventScheduleDao.getAllMarketEventsToPublishNow(marketEventPubState);
        List<MarketEventNotificationDto> eventNotificationDtos = prepareNotificationDTO(list);

        return eventNotificationDtos;
    }

    /**
     * 
     * @param list
     * @return
     */
    private List<MarketEventNotificationDto> prepareNotificationDTO(List<MrktEvntNotification> list) {

        List<MarketEventNotificationDto> eventNotificationDtos = new ArrayList<MarketEventNotificationDto>();

        for (MrktEvntNotification mrktEvntNotification : list) {
            MarketEventNotificationDto marketEventNotificationDto = new MarketEventNotificationDto();

            marketEventNotificationDto.setMarketDefintionId(mrktEvntNotification.getMarketDefintionId());
            marketEventNotificationDto.setMarketEventDefId(mrktEvntNotification.getMarketEventDefId());
            marketEventNotificationDto.setMarketEventDefCode(mrktEvntNotification.getMarketEventDefCode());
            marketEventNotificationDto.setMarketEventDefDesc(mrktEvntNotification.getMarketEventDefDesc());
            marketEventNotificationDto.setMarketEventDefNotificationMessage(mrktEvntNotification.getMarketEventDefNotificationMsg());
            marketEventNotificationDto.setMarketEventDefNotificationName(mrktEvntNotification.getMarketEventDefNotificationName());

            marketEventNotificationDto.setMarketDefClass(mrktEvntNotification.getMarketDefClass());
            marketEventNotificationDto.setMarketDefDesc(mrktEvntNotification.getMarketDefDesc());
            marketEventNotificationDto.setMarketDefType(mrktEvntNotification.getMarketDefType());

            marketEventNotificationDto.setMarketDate(mrktEvntNotification.getMarketDate().toDate());
            marketEventNotificationDto.setMarketEventFireDateTime(mrktEvntNotification.getMarketEventFireDateTime().toDate());
            marketEventNotificationDto.setMarketEventType(mrktEvntNotification.getMarketEventType());

            marketEventNotificationDto.setMarketEventScheduleId(mrktEvntNotification.getMarketEventScheduleId());
            marketEventNotificationDto.setMarketPlanId(mrktEvntNotification.getMarketPlanId());
            marketEventNotificationDto.setMarketRunId(mrktEvntNotification.getMarketRunId());
            marketEventNotificationDto.setMarketHour(mrktEvntNotification.getMarketHour());

            eventNotificationDtos.add(marketEventNotificationDto);

        }
        return eventNotificationDtos;
    }

    /**
     * 
     * @param marketEventNotifications
     * @return
     */
    public List<MarketEventNotificationDto> publishMarketEventNotificationsToMarket(List<MarketEventNotificationDto> marketEventNotifications) {

        for (MarketEventNotificationDto marketEventNotificationDto : marketEventNotifications) {

            logger.info(" Marekt Run ID         :" + marketEventNotificationDto.getMarketRunId());
            logger.info(" Market Def Id         :" + marketEventNotificationDto.getMarketDefintionId());
            logger.info(" marketDate            :" + marketEventNotificationDto.getMarketDate());
            logger.info(" eventFireDateTime     :" + marketEventNotificationDto.getMarketEventFireDateTime());
            logger.info(" eventDefCode          :" + marketEventNotificationDto.getMarketEventDefCode());

            mdsToMnsService.sendMarketEventNotificationToMnsByHttpClient(marketEventNotificationDto);

        }
        return marketEventNotifications;
    }

    /**
     * 
     * @param marketStatus
     */
    public void updateEventHistoryAndSendMnsMessages(MarketStatus marketStatus) {

        List<MarketRunMktStatusMsg> list = marketStatus.getMarketRun();
        for (MarketRunMktStatusMsg marketRunMktStatusMsg : list) {
            logger.info("********* Market(s) Received From the SIBR ********************* ");
            String planId = marketRunMktStatusMsg.getMarketID();
            String runId = marketRunMktStatusMsg.getMarketRunID();

            if (marketPlanServiceHelper.isMarketRunInMDS(planId, runId)) {

                MarketEventDefinitionDto marketEventDefinitionDto = setMarketEventDefintionDto(marketRunMktStatusMsg);
                mdsToMnsService.marketNotificationBpmFlowWrapper(planId, runId, marketRunMktStatusMsg.getMarketStartTime(), marketEventDefinitionDto);

            } else {

                logger.warn("Market Plan id :{} Market Run Id :{} Does not exists and hence Ignoring the Market Event History Update",
                        marketRunMktStatusMsg.getMarketID(), marketRunMktStatusMsg.getMarketRunID());
            }

        }

    }

    /**
     * 
     * @param marketRunMktStatusMsg
     * @return
     */

    private MarketEventDefinitionDto setMarketEventDefintionDto(MarketRunMktStatusMsg marketRunMktStatusMsg) {

        MarketEventDefinitionDto marketEventDefinitionDto = new MarketEventDefinitionDto();
        MrktPlan mrktPlan = marketPlanServiceHelper.getMarketPlan(marketRunMktStatusMsg.getMarketID(), marketRunMktStatusMsg.getMarketRunID());

        if (mrktPlan != null) {
            MrktEvntDef mrktEvntDef = mdsMarketEventDefinitionDao.getMarketDefinitionByMarketDefIdAndMarketEventType(mrktPlan.getMrktDefinition()
                    .getMrktDefinitionId(), MarketEventType.CLOSE.toString());
            marketEventDefinitionDto.setMarketEventDefCode(mrktEvntDef.getMrktEvntCd());
            mdsToMnsService.marketNotificationBpmFlowWrapper(marketRunMktStatusMsg.getMarketID(), marketRunMktStatusMsg.getMarketRunID(),
                    marketRunMktStatusMsg.getMarketStartTime(), marketEventDefinitionDto);

        } else {
            logger.warn("Market Plan id :{} Market Run Id :{} Does not exists and hence Ignoring the Market Event History Update",
                    marketRunMktStatusMsg.getMarketID(), marketRunMktStatusMsg.getMarketRunID());
        }

        return marketEventDefinitionDto;
    }

    /**
     * 
     * @param marketEventPubState
     * @return
     */

    public List<MarketEventNotificationDto> getAllOpenMarketEventsNotPublishedYet(String marketEventPubState, String mrktEvntType, int lastHours) {

        List<MrktEvntNotification> list = mdsMarketEventScheduleDao.getAllOpenMarketEventsNotPublishedYet(marketEventPubState, mrktEvntType, lastHours);
        List<MarketEventNotificationDto> eventNotificationDtos = prepareNotificationDTO(list);

        return eventNotificationDtos;
    }
}

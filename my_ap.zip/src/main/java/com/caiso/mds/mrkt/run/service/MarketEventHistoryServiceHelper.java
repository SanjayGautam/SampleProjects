package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketEventHistoryDto;
import com.caiso.mds.entity.mds.MrktEventLogResults;
import com.caiso.mds.entity.mds.MrktEvntDef;
import com.caiso.mds.entity.mds.MrktEvntHistory;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktPlanPK;
import com.caiso.mds.ui.vo.MarketEventNotificationLogsResultVO;
import com.caiso.mds.ui.vo.MarketEventNotificationVO;

@Component
public class MarketEventHistoryServiceHelper {

    private final Logger logger = LoggerFactory.getLogger(MarketEventHistoryServiceHelper.class);

    /**
     * 
     * @param marketEventHistoryDto
     * @return
     */
    public MrktEvntHistory populateMarketEventHistory(MarketEventHistoryDto marketEventHistoryDto) {

        logger.debug("******** Entered method populateMarketEventHistory ***************");

        MrktEvntHistory mrktEvntHistory = new MrktEvntHistory();
        mrktEvntHistory.setCreatedBy("mds_bpm");
        mrktEvntHistory.setCreatedDt(new Date());
        mrktEvntHistory.setMrktDate(new DateTime(marketEventHistoryDto.getMarketDate(), DateTimeZone.UTC));
        // Market Event Def
        MrktEvntDef mrktEvntDef = new MrktEvntDef();
        mrktEvntDef.setMrktEvntDefId(marketEventHistoryDto.getMarketEventDefinitionId());

        mrktEvntHistory.setMrktEvntDef(mrktEvntDef);
        // Market Status Type ID
        mrktEvntHistory.setMrktStatusHistoryId(marketEventHistoryDto.getMarketStatusHistoryId());

        // Market Plan and Market Run id
        MrktPlan mrktPlan = new MrktPlan();
        MrktPlanPK mrktPlanPK = new MrktPlanPK();
        mrktPlanPK.setMrktPlanId(marketEventHistoryDto.getMarketPlanId());
        mrktPlanPK.setMrktRunId(marketEventHistoryDto.getMarketRunId());
        mrktPlan.setId(mrktPlanPK);
        mrktEvntHistory.setMrktPlan(mrktPlan);

        if (marketEventHistoryDto.getUpdateDate() != null) {
            mrktEvntHistory.setUpdatedDt(marketEventHistoryDto.getUpdateDate());
        } else {
            mrktEvntHistory.setUpdatedDt(new Date());
        }

        mrktEvntHistory.setUpdatedBy("mds_bpmn");
        mrktEvntHistory.setCreatedBy("mds_bpm");
        mrktEvntHistory.setMrktEvntPubState("PUBLISHED");

        logger.debug("******** Entered method populateMarketEventHistory ***************");

        return mrktEvntHistory;
    }

    /**
     * 
     * @param marketEventLogResults
     * @return
     */
    public MarketEventNotificationLogsResultVO populateMarketEventNotificationLogObject(MrktEventLogResults marketEventLogResults) {

        logger.debug("******** Entered method populateMarketEventNotificationLogObject ***************");

        MarketEventNotificationLogsResultVO marketEventNotLogsResultsVO = null;

        if (marketEventLogResults != null) {
            marketEventNotLogsResultsVO = new MarketEventNotificationLogsResultVO();
            marketEventNotLogsResultsVO.setCurrentPageNumber(marketEventLogResults.getCurrentPageNumber());
            marketEventNotLogsResultsVO.setCurrentPageSize(marketEventLogResults.getCurrentPageSize());
            marketEventNotLogsResultsVO.setTotalPagesCount(marketEventLogResults.getTotalPagesCount());
            marketEventNotLogsResultsVO.setTotalRowsCount(marketEventLogResults.getTotalRowsCount());

            List<MrktEvntHistory> marketEventHistories = marketEventLogResults.getMarketEventHistories();
            List<MarketEventNotificationVO> marketEventNotificationVOs = new ArrayList<MarketEventNotificationVO>();
            MarketEventNotificationVO marketEventNotificationVO = null;

            for (MrktEvntHistory mrktEvntHistory : marketEventHistories) {
                marketEventNotificationVO = populateMarketEventNotification(mrktEvntHistory);
                marketEventNotificationVOs.add(marketEventNotificationVO);
            }

            marketEventNotLogsResultsVO.setMarketEventNotificationLogs(marketEventNotificationVOs);
            logger.info("Notification Event History logs were found and fetching it ..");
        } else {

            marketEventNotLogsResultsVO = new MarketEventNotificationLogsResultVO();
            marketEventNotLogsResultsVO.setCurrentPageNumber(1);
            marketEventNotLogsResultsVO.setCurrentPageSize(1);
            marketEventNotLogsResultsVO.setTotalPagesCount(1);
            marketEventNotLogsResultsVO.setTotalRowsCount(0);
            List<MarketEventNotificationVO> marketEventNotificationVOs = new ArrayList<MarketEventNotificationVO>();
            marketEventNotLogsResultsVO.setMarketEventNotificationLogs(marketEventNotificationVOs);
            logger.info("Notification Event History logs not found..");

        }

        logger.debug("******** Exiting method populateMarketEventNotificationLogObject ***************");

        return marketEventNotLogsResultsVO;
    }

    /**
     * 
     * @param mrktEvntHistory
     * @return
     */
    private MarketEventNotificationVO populateMarketEventNotification(MrktEvntHistory mrktEvntHistory) {

        logger.debug("******** Entered  method populateMarketEventNotification ***************");
        MarketEventNotificationVO marketEventNotificationVO = new MarketEventNotificationVO();
        marketEventNotificationVO.setMarketDate(mrktEvntHistory.getMrktDate().toDate());
        marketEventNotificationVO.setMarketEventDefCode(mrktEvntHistory.getMrktEvntDef().getMrktEvntCd());
        marketEventNotificationVO.setMarketEventNotificationMsg(mrktEvntHistory.getMrktEvntDef().getMrktEvntNotificationMsg());
        marketEventNotificationVO.setMarketHour(mrktEvntHistory.getMrktPlan().getMrktHour());
        marketEventNotificationVO.setMarketEventTime(mrktEvntHistory.getCreatedDt());
        if (mrktEvntHistory.getMrktPlan() != null) {
            marketEventNotificationVO.setMarketRunId(mrktEvntHistory.getMrktPlan().getId().getMrktRunId());
        }
        logger.debug("******** Exited method populateMarketEventNotification ***************");
        return marketEventNotificationVO;
    }
}

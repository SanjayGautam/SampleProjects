package com.caiso.mds.mrkt.run.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsMarketSysOperatorMsgDao;
import com.caiso.mds.dao.mds.MdsOperatorMsgSeverityDao;
import com.caiso.mds.dao.oasis.MdsOasisNotificationCtlDao;
import com.caiso.mds.dto.MarketSystemOperatorMessageDto;
import com.caiso.mds.entity.mds.MrktMdsSeverity;
import com.caiso.mds.entity.mds.MrktSysOperatorMsg;
import com.caiso.mds.entity.oasis.MdsAweNotification;
import com.caiso.mds.ui.vo.MarketSystemOperatorMessageSeverityVO;
import com.caiso.mds.ui.vo.MarketSystemOperatorMessageVO;

@Component
public class MarketSysOperatorMsgService {

    @Autowired
    private MdsMarketSysOperatorMsgDao mdsMarketSysOperatorMsgDao;

    @Autowired
    private MdsOperatorMsgSeverityDao  mdsOperatorMsgSeverityDao;

    @Autowired
    private MdsOasisNotificationCtlDao mdsOasisNotificationCtlDao;

    private final Logger               logger = LoggerFactory.getLogger(MarketSysOperatorMsgService.class);

    /**
     * 
     * @param marketSystemOperatorMessageDto
     * @return
     */
    public MarketSystemOperatorMessageDto createMarketSysOperatorMessage(MarketSystemOperatorMessageDto marketSystemOperatorMessageDto) {

        MrktSysOperatorMsg mrktSysOperatorMsg = populateSystemOperatorMessageEntity(marketSystemOperatorMessageDto);
        mdsMarketSysOperatorMsgDao.createMrktSysOperatorMsg(mrktSysOperatorMsg);
        marketSystemOperatorMessageDto.setMdsSeverityId(mrktSysOperatorMsg.getMrkSysOperatorMsgId());
        return marketSystemOperatorMessageDto;
    }

    /**
     * 
     * @return
     */
    public List<MarketSystemOperatorMessageSeverityVO> getAllMdsSeverities() {

        List<MrktMdsSeverity> list = mdsOperatorMsgSeverityDao.getAllMdsSeverities();
        List<MarketSystemOperatorMessageSeverityVO> vos = new ArrayList<MarketSystemOperatorMessageSeverityVO>();
        MarketSystemOperatorMessageSeverityVO marketSystemOperatorMessageSeverityVO = null;

        for (MrktMdsSeverity mrktMdsSeverity : list) {
            marketSystemOperatorMessageSeverityVO = new MarketSystemOperatorMessageSeverityVO();
            marketSystemOperatorMessageSeverityVO.setMessageSeverityDesc(mrktMdsSeverity.getMdsSeverityDesc());
            marketSystemOperatorMessageSeverityVO.setMessageSeverityId(mrktMdsSeverity.getMdsSeverityId());
            marketSystemOperatorMessageSeverityVO.setMessageSeverityName(mrktMdsSeverity.getMdsSeverityName());
            vos.add(marketSystemOperatorMessageSeverityVO);
        }

        return vos;
    }

    /**
     * 
     * @param marketSystemOperatorMessageVO
     * @return
     */
    public MarketSystemOperatorMessageVO createMarketSysOperatorMessage(MarketSystemOperatorMessageVO marketSystemOperatorMessageVO) {

        boolean oasisPublishedFlag = true;

        MrktSysOperatorMsg mrktSysOperatorMsg = populateSystemOperatorMessageEntity(marketSystemOperatorMessageVO);

        try {
            MdsAweNotification mdsAweNotification = createAndPopulateMdsAweNotifications(mrktSysOperatorMsg);
            mdsOasisNotificationCtlDao.createMdsAweNotifications(mdsAweNotification);
        } catch (Exception e) {
            // issue in oasis , make sure in mds mark unpublished for the job to
            // publish it later on.

            logger.warn("message was not posted to the oasis_int awe notification due to some reason will be tried by job later on.", e);
            mrktSysOperatorMsg.setOasisPublishedStatus("NOT_PUBLISHED");
            mdsMarketSysOperatorMsgDao.createMrktSysOperatorMsg(mrktSysOperatorMsg);
            oasisPublishedFlag = false;
        }

        if (oasisPublishedFlag) {
            mrktSysOperatorMsg.setOasisPublishedStatus("PUBLISHED");
            mdsMarketSysOperatorMsgDao.createMrktSysOperatorMsg(mrktSysOperatorMsg);
        }

        marketSystemOperatorMessageVO.setSystemOperatorMessageId(mrktSysOperatorMsg.getMrkSysOperatorMsgId());
        marketSystemOperatorMessageVO.setRequestResult("Created");
        return marketSystemOperatorMessageVO;
    }

    /**
     * 
     * @param mrktSysOperatorMsg
     * @return
     */

    private MdsAweNotification createAndPopulateMdsAweNotifications(MrktSysOperatorMsg mrktSysOperatorMsg) {

        MdsAweNotification mdsAweNotification = new MdsAweNotification();
        mdsAweNotification.setCreatedDts(new Date());
        mdsAweNotification.setMessagesCreatedDts(mrktSysOperatorMsg.getSeverityInsertDts());
        mdsAweNotification.setNotificationText(mrktSysOperatorMsg.getSeverityMessage());
        mdsAweNotification.setSeverityRating(mrktSysOperatorMsg.getMrktMdsSeverity().getMdsSeverityId() + "");

        return mdsAweNotification;
    }

    /**
     * 
     * @param marketSystemOperatorMessageVO
     * @return
     */

    private MrktSysOperatorMsg populateSystemOperatorMessageEntity(MarketSystemOperatorMessageVO marketSystemOperatorMessageVO) {
        MrktSysOperatorMsg mrktSysOperatorMsg = null;
        MrktMdsSeverity mrktMdsSeverity = null;

        if (marketSystemOperatorMessageVO == null) {
            throw new IllegalArgumentException("Market System Operating Message Object cannot be null ");
        } else {

            mrktSysOperatorMsg = new MrktSysOperatorMsg();
            mrktMdsSeverity = new MrktMdsSeverity();

            mrktMdsSeverity.setMdsSeverityId(marketSystemOperatorMessageVO.getMdsSeverityId());
            mrktMdsSeverity.setMdsSeverityName(marketSystemOperatorMessageVO.getMdsSeverityName());
            mrktSysOperatorMsg.setMrktMdsSeverity(mrktMdsSeverity);

            mrktSysOperatorMsg.setPollStatus(marketSystemOperatorMessageVO.getPollStatus());
            mrktSysOperatorMsg.setSeverityInsertDts(new Date());
            mrktSysOperatorMsg.setSeverityMessage(marketSystemOperatorMessageVO.getSeverityMessage());
            mrktSysOperatorMsg.setMrkSysOperatorMsgId(marketSystemOperatorMessageVO.getSystemOperatorMessageId());
            mrktSysOperatorMsg.setMessageSubmittedBy(marketSystemOperatorMessageVO.getMessageSubmittedBy());

        }

        return mrktSysOperatorMsg;
    }

    /**
     * 
     * @param marketSystemOperatorMessageDto
     * @return
     */
    private MrktSysOperatorMsg populateSystemOperatorMessageEntity(MarketSystemOperatorMessageDto marketSystemOperatorMessageDto) {

        MrktSysOperatorMsg mrktSysOperatorMsg = null;
        MrktMdsSeverity mrktMdsSeverity = null;

        if (marketSystemOperatorMessageDto == null) {
            throw new IllegalArgumentException("Market System Operating Message Object cannot be null ");
        } else {

            mrktSysOperatorMsg = new MrktSysOperatorMsg();
            mrktMdsSeverity = new MrktMdsSeverity();

            mrktMdsSeverity.setMdsSeverityId(marketSystemOperatorMessageDto.getMdsSeverityId());
            mrktMdsSeverity.setMdsSeverityName(marketSystemOperatorMessageDto.getMdsSeverityName());
            mrktSysOperatorMsg.setMrktMdsSeverity(mrktMdsSeverity);

            mrktSysOperatorMsg.setPollStatus(marketSystemOperatorMessageDto.getPollStatus());
            mrktSysOperatorMsg.setSeverityInsertDts(new Date());
            mrktSysOperatorMsg.setSeverityMessage(marketSystemOperatorMessageDto.getSeverityMessage());

        }

        return mrktSysOperatorMsg;
    }

    public void updateMarketSysOperatorMessage(MarketSystemOperatorMessageVO marketSystemOperatorMessageVO) {

        MrktSysOperatorMsg mrktSysOperatorMsg = populateSystemOperatorMessageEntity(marketSystemOperatorMessageVO);
        mdsMarketSysOperatorMsgDao.updateMrktSysOperatorMsg(mrktSysOperatorMsg);

    }

    /**
     * 
     * @return
     */

    public List<MarketSystemOperatorMessageVO> getLast24HourOperatorMessages() {

        List<MarketSystemOperatorMessageVO> operatorMessageList = new ArrayList<MarketSystemOperatorMessageVO>();

        List<MrktSysOperatorMsg> operatorMessages = mdsMarketSysOperatorMsgDao.getMrktSysOperatorMsgsForLastHours(24);
        for (MrktSysOperatorMsg mrktSysOperatorMsg : operatorMessages) {
            MarketSystemOperatorMessageVO marketSystemOperatorMessageVO = populateOperatorMessageValueObject(mrktSysOperatorMsg);

            operatorMessageList.add(marketSystemOperatorMessageVO);
        }

        return operatorMessageList;
    }

    /**
     * 
     * @param mrktSysOperatorMsg
     * @return
     */

    private MarketSystemOperatorMessageVO populateOperatorMessageValueObject(MrktSysOperatorMsg mrktSysOperatorMsg) {

        MarketSystemOperatorMessageVO marketSystemOperatorMessageVO = null;

        if (mrktSysOperatorMsg != null) {
            marketSystemOperatorMessageVO = new MarketSystemOperatorMessageVO();
            marketSystemOperatorMessageVO.setMdsSeverityId(mrktSysOperatorMsg.getMrktMdsSeverity().getMdsSeverityId());
            marketSystemOperatorMessageVO.setMdsSeverityName(mrktSysOperatorMsg.getMrktMdsSeverity().getMdsSeverityName());
            marketSystemOperatorMessageVO.setPollStatus(mrktSysOperatorMsg.getPollStatus());
            marketSystemOperatorMessageVO.setRequestResult("Found");
            marketSystemOperatorMessageVO.setSeverityInsertDate(mrktSysOperatorMsg.getSeverityInsertDts());
            marketSystemOperatorMessageVO.setSeverityMessage(mrktSysOperatorMsg.getSeverityMessage());
            marketSystemOperatorMessageVO.setSystemOperatorMessageId(mrktSysOperatorMsg.getMrkSysOperatorMsgId());
            marketSystemOperatorMessageVO.setMessageSubmittedBy(mrktSysOperatorMsg.getMessageSubmittedBy());

        }

        return marketSystemOperatorMessageVO;
    }

    /**
     * 
     */
    public void syncMdsOperatingMessageToOasis() {

        List<MrktSysOperatorMsg> operatorMessages = mdsMarketSysOperatorMsgDao.getOperatingMessagesNotPublishedToOasis("NOT_PUBLISHED");
        for (MrktSysOperatorMsg mrktSysOperatorMsg : operatorMessages) {
            MdsAweNotification mdsAweNotification = createAndPopulateMdsAweNotifications(mrktSysOperatorMsg);
            try {
                mdsOasisNotificationCtlDao.createMdsAweNotifications(mdsAweNotification);
                mrktSysOperatorMsg.setOasisPublishedStatus("PUBLISHED");
                mdsMarketSysOperatorMsgDao.updateMrktSysOperatorMsg(mrktSysOperatorMsg);
            } catch (Exception e) {
                logger.warn("Some issue with OASIS cannot sync the Operating Messages Id:" + mrktSysOperatorMsg.getMrkSysOperatorMsgId(), e);
            }
        }
    }
}

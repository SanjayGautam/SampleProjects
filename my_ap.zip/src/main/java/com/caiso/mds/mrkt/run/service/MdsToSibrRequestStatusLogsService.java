package com.caiso.mds.mrkt.run.service;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.MdsToSibrMsgLogDao;
import com.caiso.mds.entity.mds.MdsToSibrRequestLogResults;
import com.caiso.mds.ui.vo.MdsToSibrRequestLogsResultVO;

@Component
public class MdsToSibrRequestStatusLogsService {

    private final Logger                      logger                          = LoggerFactory.getLogger(MdsToSibrRequestStatusLogsService.class);

    @Autowired
    private MdsToSibrMsgLogDao                mdsToSibrMsgLogDao;

    @Autowired
    private MdsToSibrRequestLogsServiceHelper mdsToSibrRequestLogsServiceHelper;

    @Autowired
    private Integer                           mdsMonitorWebPaginationPageSize = 25;

    /**
     * 
     * @param pageNumber
     * @return
     */
    public MdsToSibrRequestLogsResultVO getMdsToSibrRequestLogs(int pageNumber) {

        logger.debug("******** Entered method getMarketEventNotificationLog  ********* ");

        DateTime marketDateInPST = new DateTime();
        marketDateInPST = marketDateInPST.minusHours(24);
        MdsToSibrRequestLogResults mdsToSibrRequestLogResults = mdsToSibrMsgLogDao.getMdsToSibrRequestLogs(pageNumber, mdsMonitorWebPaginationPageSize,
                marketDateInPST.toDate());
        MdsToSibrRequestLogsResultVO mdsToSibrRequestLogsResultVO = mdsToSibrRequestLogsServiceHelper
                .populateMarketEventNotificationLogObject(mdsToSibrRequestLogResults);

        logger.debug("******** Exiting method getMarketEventNotificationLog  ********* ");
        return mdsToSibrRequestLogsResultVO;
    }
}

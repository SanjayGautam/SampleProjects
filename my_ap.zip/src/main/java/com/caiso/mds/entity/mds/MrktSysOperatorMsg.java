package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "SYS_OPER_MESSAGE", catalog = "MDS_APP")
public class MrktSysOperatorMsg implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -7356689469850593378L;

    @Id
    @SequenceGenerator(name = "SEQ_OPER_MSG_ID_SEQ", sequenceName = "SEQ_OPER_MSG_ID_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_OPER_MSG_ID_SEQ")
    @Column(name = "SYS_OPER_MESSAGE_ID")
    private long              mrkSysOperatorMsgId;

    @ManyToOne
    @JoinColumn(name = "MDS_SEVERITY_ID", updatable = false)
    private MrktMdsSeverity   mrktMdsSeverity;

    @Column(name = "SEVERITY_PAYLOAD")
    private String            severityMessage;

    @Column(name = "POLL_STATUS")
    private String            pollStatus;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "SEVERITY_INSERT_DTS")
    private Date              severityInsertDts;

    @Column(name = "OASIS_PUBLISHED_STATUS")
    private String            oasisPublishedStatus;

    @Column(name = "MSG_SUBMITTED_BY")
    private String            messageSubmittedBy;

    public String getMessageSubmittedBy() {
        return messageSubmittedBy;
    }

    public void setMessageSubmittedBy(String messageSubmittedBy) {
        this.messageSubmittedBy = messageSubmittedBy;
    }

    public String getOasisPublishedStatus() {
        return oasisPublishedStatus;
    }

    public void setOasisPublishedStatus(String oasisPublishedStatus) {
        this.oasisPublishedStatus = oasisPublishedStatus;
    }

    public long getMrkSysOperatorMsgId() {
        return mrkSysOperatorMsgId;
    }

    public void setMrkSysOperatorMsgId(long mrkSysOperatorMsgId) {
        this.mrkSysOperatorMsgId = mrkSysOperatorMsgId;
    }

    public MrktMdsSeverity getMrktMdsSeverity() {
        return mrktMdsSeverity;
    }

    public void setMrktMdsSeverity(MrktMdsSeverity mrktMdsSeverity) {
        this.mrktMdsSeverity = mrktMdsSeverity;
    }

    public String getSeverityMessage() {
        return severityMessage;
    }

    public void setSeverityMessage(String severityMessage) {
        this.severityMessage = severityMessage;
    }

    public String getPollStatus() {
        return pollStatus;
    }

    public void setPollStatus(String pollStatus) {
        this.pollStatus = pollStatus;
    }

    public Date getSeverityInsertDts() {
        return severityInsertDts;
    }

    public void setSeverityInsertDts(Date severityInsertDts) {
        this.severityInsertDts = severityInsertDts;
    }

}

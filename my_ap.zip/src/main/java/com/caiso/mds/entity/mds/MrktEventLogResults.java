package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.List;

public class MrktEventLogResults implements Serializable {

    /**
	 * 
	 */
    private static final long     serialVersionUID = -6035920381300942339L;

    private List<MrktEvntHistory> marketEventHistories;

    private long                  totalRowsCount;
    private int                   totalPagesCount;
    private int                   currentPageNumber;
    private int                   currentPageSize;

    public List<MrktEvntHistory> getMarketEventHistories() {
        return marketEventHistories;
    }

    public void setMarketEventHistories(List<MrktEvntHistory> marketEventHistories) {
        this.marketEventHistories = marketEventHistories;
    }

    public long getTotalRowsCount() {
        return totalRowsCount;
    }

    public void setTotalRowsCount(long totalRowsCount) {
        this.totalRowsCount = totalRowsCount;
    }

    public int getTotalPagesCount() {
        return totalPagesCount;
    }

    public void setTotalPagesCount(int totalPagesCount) {
        this.totalPagesCount = totalPagesCount;
    }

    public int getCurrentPageNumber() {
        return currentPageNumber;
    }

    public void setCurrentPageNumber(int currentPageNumber) {
        this.currentPageNumber = currentPageNumber;
    }

    public int getCurrentPageSize() {
        return currentPageSize;
    }

    public void setCurrentPageSize(int currentPageSize) {
        this.currentPageSize = currentPageSize;
    }

}

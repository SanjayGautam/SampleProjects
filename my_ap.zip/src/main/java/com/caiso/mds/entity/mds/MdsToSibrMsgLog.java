package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

/**
 * The persistent class for the MDS_LOG database table.
 * 
 */
@Entity
@Table(name = "MDS_TO_SIBR_MSG_LOG", catalog = "MDS_APP")
@NamedQuery(name = "MdsToSibrMsgLog.findAll", query = "SELECT m FROM MdsToSibrMsgLog m")
public class MdsToSibrMsgLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "MDS_TO_SIBR_MSG_LOG_ID_SEQ", sequenceName = "MDS_TO_SIBR_MSG_LOG_ID_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MDS_TO_SIBR_MSG_LOG_ID_SEQ")
    @Column(name = "MDS_TO_SIBR_MSG_LOG_ID")
    private long              mdsToSibrMsgLogId;

    @Column(name = "MRKT_PLAN_ID")
    private String            mrktPlanId;

    @Column(name = "MRKT_RUN_ID")
    private String            mrktRunId;

    @Column(name = "MRKT_TYPE")
    private String            mrktType;

    @Column(name = "MRKT_CLASS")
    private String            mrktClass;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "MRKT_DT")
    private DateTime          mrktDate;

    @Column(name = "REQUESTED_STATUS")
    private String            requestedStatus;

    @Column(name = "CURRENT_STATUS")
    private String            currentStatus;

    @Column(name = "PREVIOUS_STATUS")
    private String            previousStatus;

    @Column(name = "REQUEST_RESULT")
    private String            requestResult;

    @Lob
    @Column(name = "SERVICE_RESPONSE", columnDefinition = "CLOB NOT NULL")
    private String            serviceResponse;

    @Lob
    @Column(name = "SERVICE_REQUEST", columnDefinition = "CLOB NOT NULL")
    private String            serviceRequest;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED_DT")
    private Date              updatedDt;

    @Column(name = "UPDATED_BY")
    private String            updatedBy;

    @Column(name = "CREATED_BY", updatable = false)
    private String            createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DT", updatable = false)
    private Date              createdDt;

    public MdsToSibrMsgLog() {
    }

    public long getMdsToSibrMsgLogId() {
        return mdsToSibrMsgLogId;
    }

    public void setMdsToSibrMsgLogId(long mdsToSibrMsgLogId) {
        this.mdsToSibrMsgLogId = mdsToSibrMsgLogId;
    }

    public String getMrktPlanId() {
        return mrktPlanId;
    }

    public void setMrktPlanId(String mrktPlanId) {
        this.mrktPlanId = mrktPlanId;
    }

    public String getMrktRunId() {
        return mrktRunId;
    }

    public void setMrktRunId(String mrktRunId) {
        this.mrktRunId = mrktRunId;
    }

    public DateTime getMrktDate() {
        return mrktDate;
    }

    public void setMrktDate(DateTime mrktDate) {
        this.mrktDate = mrktDate;
    }

    public String getRequestedStatus() {
        return requestedStatus;
    }

    public void setRequestedStatus(String requestedStatus) {
        this.requestedStatus = requestedStatus;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getPreviousStatus() {
        return previousStatus;
    }

    public void setPreviousStatus(String previousStatus) {
        this.previousStatus = previousStatus;
    }

    public String getRequestResult() {
        return requestResult;
    }

    public void setRequestResult(String responseStatus) {
        this.requestResult = responseStatus;
    }

    public String getServiceResponse() {
        return serviceResponse;
    }

    public void setServiceResponse(String serviceResponse) {
        this.serviceResponse = serviceResponse;
    }

    public String getServiceRequest() {
        return serviceRequest;
    }

    public void setServiceRequest(String serviceRequest) {
        this.serviceRequest = serviceRequest;
    }

    public Date getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public void setMrktType(String mrktType) {
        this.mrktType = mrktType;

    }

    public String getMrktType() {
        return mrktType;
    }

    public void setMrktClass(String mrktClass) {

        this.mrktClass = mrktClass;
    }

    public String getMrktClass() {
        return mrktClass;
    }
}
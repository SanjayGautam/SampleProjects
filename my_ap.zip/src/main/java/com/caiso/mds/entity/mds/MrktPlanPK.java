package com.caiso.mds.entity.mds;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the MRKT_PLAN database table.
 * 
 */
@Embeddable
public class MrktPlanPK implements Serializable {
    // default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name = "MRKT_PLAN_ID", updatable = false)
    private String            mrktPlanId;

    @Column(name = "MRKT_RUN_ID", updatable = false)
    private String            mrktRunId;

    public MrktPlanPK() {
    }

    public String getMrktPlanId() {
        return this.mrktPlanId;
    }

    public void setMrktPlanId(String mrktPlanId) {
        this.mrktPlanId = mrktPlanId;
    }

    public String getMrktRunId() {
        return this.mrktRunId;
    }

    public void setMrktRunId(String mrktRunId) {
        this.mrktRunId = mrktRunId;
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof MrktPlanPK)) {
            return false;
        }
        MrktPlanPK castOther = (MrktPlanPK) other;
        return this.mrktPlanId.equals(castOther.mrktPlanId) && this.mrktRunId.equals(castOther.mrktRunId);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int hash = 17;
        hash = hash * prime + this.mrktPlanId.hashCode();
        hash = hash * prime + this.mrktRunId.hashCode();

        return hash;
    }
}
package com.caiso.mds.entity.mds;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the MRKT_ACTIVITY database table.
 * 
 */
@Entity
@Table(name = "MRKT_ACTIVITY", catalog = "MDS_APP")
@NamedQuery(name = "MrktActivity.findAll", query = "SELECT m FROM MrktActivity m")
public class MrktActivity implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "MRKT_ACTIVITY_ID")
    private long              mrktActivityId;

    @Column(name = "MRKT_ACTIVITY_NAME")
    private String            mrktActivityName;

    @Column(name = "MRKT_ACTIVITY_DESC")
    private String            mrktActivityDesc;

    @Column(name = "MRKT_ACTIVITY_CD")
    private String            mrktActivityCd;

    public MrktActivity() {
    }

    public long getMrktActivityId() {
        return mrktActivityId;
    }

    public void setMrktActivityId(long mrktActivityId) {
        this.mrktActivityId = mrktActivityId;
    }

    public String getMrktActivityName() {
        return mrktActivityName;
    }

    public void setMrktActivityName(String mrktActivityName) {
        this.mrktActivityName = mrktActivityName;
    }

    public String getMrktActivityDesc() {
        return mrktActivityDesc;
    }

    public void setMrktActivityDesc(String mrktActivityDesc) {
        this.mrktActivityDesc = mrktActivityDesc;
    }

    public String getMrktActivityCd() {
        return mrktActivityCd;
    }

    public void setMrktActivityCd(String mrktActivityCd) {
        this.mrktActivityCd = mrktActivityCd;
    }

}
package com.caiso.mds.entity.mds;

import java.io.Serializable;

import org.joda.time.DateTime;

public class MrktPlanAndStatusDetails implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -8875004177044642241L;

    private String            marketPlanId;
    private String            marketRunId;
    private MrktDefinition    marketDefinition;
    private DateTime          marketDate;
    private String            marketStatus;
    private String            marketHour;

    public MrktPlanAndStatusDetails(String marketPlanId, String marketRunId, MrktDefinition marketDef, DateTime marketDate, String marketStatus,
            String marketHour) {
        super();
        this.marketPlanId = marketPlanId;
        this.marketRunId = marketRunId;
        this.marketDefinition = marketDef;
        this.marketDate = marketDate;
        this.marketStatus = marketStatus;
        this.marketHour = marketHour;
    }

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public MrktDefinition getMrktDefinition() {
        return marketDefinition;
    }

    public void setMrktDefinition(MrktDefinition marketDefinition) {
        this.marketDefinition = marketDefinition;
    }

    public DateTime getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(DateTime marketDate) {
        this.marketDate = marketDate;
    }

    public String getMarketStatus() {
        return marketStatus;
    }

    public void setMarketStatus(String marketStatus) {
        this.marketStatus = marketStatus;
    }

    public String getMarketHour() {
        return marketHour;
    }

    public void setMarketHour(String marketHour) {
        this.marketHour = marketHour;
    }

}

package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

/**
 * The persistent class for the MRKT_PLAN database table.
 * 
 */
@Entity
@Table(name = "MRKT_PLAN", catalog = "MDS_APP")
@NamedQuery(name = "MrktPlan.findAll", query = "SELECT m FROM MrktPlan m")
public class MrktPlan implements Serializable {
    private static final long       serialVersionUID = 1L;

    @EmbeddedId
    private MrktPlanPK              id;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "MRKT_DT", updatable = false)
    private DateTime                mrktDate;

    @Column(name = "MRKT_HOUR", updatable = false)
    private String                  mrktHour;

    @Column(name = "REC_STATUS")
    private String                  recStatus;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED_DT")
    private Date                    updatedDt;

    @Column(name = "UPDATED_BY")
    private String                  updatedBy;

    @Column(name = "CREATED_BY", updatable = false)
    private String                  createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DT", updatable = false)
    private Date                    createdDt;

    // bi-directional many-to-one association to MdsJob
    @OneToMany(mappedBy = "mrktPlan")
    private List<MdsJob>            mdsJobs;

    /*
     * // bi-directional many-to-one association to MdsLog
     * 
     * @OneToMany(mappedBy = "mrktPlan") private List<MdsLog> mdsLogs;
     */

    // bi-directional many-to-one association to MrktEvntHistory
    @OneToMany(mappedBy = "mrktPlan")
    private List<MrktEvntHistory>   mrktEvntHistories;

    // bi-directional many-to-one association to MrktDefinition
    @ManyToOne(optional = true)
    @JoinColumn(name = "MRKT_DEFINITION_ID", updatable = false)
    private MrktDefinition          mrktDefinition;

    // bi-directional many-to-one association to MrktStatusType
    @ManyToOne
    @JoinColumn(name = "MRKT_STATUS_TYPE_ID")
    private MrktStatusType          mrktStatusType;

    // bi-directional many-to-one association to MrktStatusHistory
    // @OneToMany(mappedBy="mrktPlan" , cascade=CascadeType.PERSIST) original
    // I dont want to maintain relationships implicitly as it is hard to
    // maintain it and hence removed the cascade all
    // @OneToMany(cascade=CascadeType.ALL, mappedBy="mrktPlan" )
    @OneToMany(mappedBy = "mrktPlan", fetch = FetchType.EAGER)
    @OrderBy("createdDt DESC")
    private List<MrktStatusHistory> mrktStatusHistories;

    public MrktPlan() {
    }

    public MrktPlanPK getId() {
        return this.id;
    }

    public void setId(MrktPlanPK id) {
        this.id = id;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return this.createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public DateTime getMrktDate() {
        return this.mrktDate;
    }

    public void setMrktDate(DateTime mrktDate) {
        this.mrktDate = mrktDate;
    }

    public String getMrktHour() {
        return this.mrktHour;
    }

    public void setMrktHour(String mrktHour) {
        this.mrktHour = mrktHour;
    }

    public String getRecStatus() {
        return this.recStatus;
    }

    public void setRecStatus(String recStatus) {
        this.recStatus = recStatus;
    }

    public Date getUpdatedDt() {
        return this.updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public List<MdsJob> getMdsJobs() {
        return this.mdsJobs;
    }

    public void setMdsJobs(List<MdsJob> mdsJobs) {
        this.mdsJobs = mdsJobs;
    }

    public MdsJob addMdsJob(MdsJob mdsJob) {
        getMdsJobs().add(mdsJob);
        mdsJob.setMrktPlan(this);

        return mdsJob;
    }

    public MdsJob removeMdsJob(MdsJob mdsJob) {
        getMdsJobs().remove(mdsJob);
        mdsJob.setMrktPlan(null);

        return mdsJob;
    }

    /*
     * public List<MdsLog> getMdsLogs() { return this.mdsLogs; }
     * 
     * public void setMdsLogs(List<MdsLog> mdsLogs) { this.mdsLogs = mdsLogs; }
     * 
     * public MdsLog addMdsLog(MdsLog mdsLog) { getMdsLogs().add(mdsLog);
     * mdsLog.setMrktPlan(this);
     * 
     * return mdsLog; }
     */

    /*
     * public MdsLog removeMdsLog(MdsLog mdsLog) { getMdsLogs().remove(mdsLog);
     * mdsLog.setMrktPlan(null);
     * 
     * return mdsLog; }
     */

    public List<MrktEvntHistory> getMrktEvntHistories() {
        return this.mrktEvntHistories;
    }

    public void setMrktEvntHistories(List<MrktEvntHistory> mrktEvntHistories) {
        this.mrktEvntHistories = mrktEvntHistories;
    }

    public MrktEvntHistory addMrktEvntHistory(MrktEvntHistory mrktEvntHistory) {
        getMrktEvntHistories().add(mrktEvntHistory);
        mrktEvntHistory.setMrktPlan(this);

        return mrktEvntHistory;
    }

    public MrktEvntHistory removeMrktEvntHistory(MrktEvntHistory mrktEvntHistory) {
        getMrktEvntHistories().remove(mrktEvntHistory);
        mrktEvntHistory.setMrktPlan(null);

        return mrktEvntHistory;
    }

    public MrktDefinition getMrktDefinition() {
        return this.mrktDefinition;
    }

    public void setMrktDefinition(MrktDefinition mrktDefinition) {
        this.mrktDefinition = mrktDefinition;
    }

    public MrktStatusType getMrktStatusType() {
        return this.mrktStatusType;
    }

    public void setMrktStatusType(MrktStatusType mrktStatusType) {
        this.mrktStatusType = mrktStatusType;
    }

    public List<MrktStatusHistory> getMrktStatusHistories() {
        return this.mrktStatusHistories;
    }

    public void setMrktStatusHistories(List<MrktStatusHistory> mrktStatusHistories) {
        this.mrktStatusHistories = mrktStatusHistories;
    }

    public MrktStatusHistory addMrktStatusHistory(MrktStatusHistory mrktStatusHistory) {
        getMrktStatusHistories().add(mrktStatusHistory);
        // mrktStatusHistory.setMrktPlan(this);

        return mrktStatusHistory;
    }

    public MrktStatusHistory removeMrktStatusHistory(MrktStatusHistory mrktStatusHistory) {
        getMrktStatusHistories().remove(mrktStatusHistory);
        // mrktStatusHistory.setMrktPlan(null);

        return mrktStatusHistory;
    }

}
package com.caiso.mds.entity.mds;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "MDS_SEVERITY", catalog = "MDS_APP")
public class MrktMdsSeverity implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 2952342460911650572L;

    @Id
    @Column(name = "MDS_SEVERITY_ID")
    private long              mdsSeverityId;

    @Column(name = "MDS_SEVERITY_NAME")
    private String            mdsSeverityName;

    @Column(name = "MDS_SEVERITY_DESC")
    private String            mdsSeverityDesc;

    public long getMdsSeverityId() {
        return mdsSeverityId;
    }

    public void setMdsSeverityId(long mdsSeverityId) {
        this.mdsSeverityId = mdsSeverityId;
    }

    public String getMdsSeverityName() {
        return mdsSeverityName;
    }

    public void setMdsSeverityName(String mdsSeverityName) {
        this.mdsSeverityName = mdsSeverityName;
    }

    public String getMdsSeverityDesc() {
        return mdsSeverityDesc;
    }

    public void setMdsSeverityDesc(String mdsSeverityDesc) {
        this.mdsSeverityDesc = mdsSeverityDesc;
    }
}

package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the MRKT_STATUS_TYPE database table.
 * 
 */
@Entity
@Table(name = "MRKT_STATUS_TYPE", catalog = "MDS_APP")
@NamedQuery(name = "MrktStatusType.findAll", query = "SELECT m FROM MrktStatusType m")
public class MrktStatusType implements Serializable {
    private static final long       serialVersionUID = 1L;

    @Id
    @Column(name = "MRKT_STATUS_TYPE_ID")
    private long                    mrktStatusTypeId;

    @Column(name = "MRKT_STATUS_TYPE_DESC")
    private String                  mrktStatusTypeDesc;

    @Column(name = "MRKT_STATUS_TYPE_NAME")
    private String                  mrktStatusTypeName;

    /*
     * //bi-directional many-to-one association to MrktEvntHistory
     * 
     * @OneToMany(mappedBy="mrktStatusType") private List<MrktEvntHistory>
     * mrktEvntHistories;
     */
    // bi-directional many-to-one association to MrktPlan
    @OneToMany(mappedBy = "mrktStatusType")
    private List<MrktPlan>          mrktPlans;

    // bi-directional many-to-one association to MrktStatusHistory
    @OneToMany(mappedBy = "mrktStatusType")
    private List<MrktStatusHistory> mrktStatusHistories;

    public MrktStatusType() {
    }

    public long getMrktStatusTypeId() {
        return this.mrktStatusTypeId;
    }

    public void setMrktStatusTypeId(long mrktStatusTypeId) {
        this.mrktStatusTypeId = mrktStatusTypeId;
    }

    public String getMrktStatusTypeDesc() {
        return this.mrktStatusTypeDesc;
    }

    public void setMrktStatusTypeDesc(String mrktStatusTypeDesc) {
        this.mrktStatusTypeDesc = mrktStatusTypeDesc;
    }

    public String getMrktStatusTypeName() {
        return this.mrktStatusTypeName;
    }

    public void setMrktStatusTypeName(String mrktStatusTypeName) {
        this.mrktStatusTypeName = mrktStatusTypeName;
    }

    /*
     * public List<MrktEvntHistory> getMrktEvntHistories() { return
     * this.mrktEvntHistories; }
     * 
     * public void setMrktEvntHistories(List<MrktEvntHistory> mrktEvntHistories)
     * { this.mrktEvntHistories = mrktEvntHistories; }
     * 
     * public MrktEvntHistory addMrktEvntHistory(MrktEvntHistory
     * mrktEvntHistory) { getMrktEvntHistories().add(mrktEvntHistory);
     * mrktEvntHistory.setMrktStatusType(this);
     * 
     * return mrktEvntHistory; }
     * 
     * public MrktEvntHistory removeMrktEvntHistory(MrktEvntHistory
     * mrktEvntHistory) { getMrktEvntHistories().remove(mrktEvntHistory);
     * mrktEvntHistory.setMrktStatusType(null);
     * 
     * return mrktEvntHistory; }
     */
    public List<MrktPlan> getMrktPlans() {
        return this.mrktPlans;
    }

    public void setMrktPlans(List<MrktPlan> mrktPlans) {
        this.mrktPlans = mrktPlans;
    }

    public MrktPlan addMrktPlan(MrktPlan mrktPlan) {
        getMrktPlans().add(mrktPlan);
        mrktPlan.setMrktStatusType(this);

        return mrktPlan;
    }

    public MrktPlan removeMrktPlan(MrktPlan mrktPlan) {
        getMrktPlans().remove(mrktPlan);
        mrktPlan.setMrktStatusType(null);

        return mrktPlan;
    }

    public List<MrktStatusHistory> getMrktStatusHistories() {
        return this.mrktStatusHistories;
    }

    public void setMrktStatusHistories(List<MrktStatusHistory> mrktStatusHistories) {
        this.mrktStatusHistories = mrktStatusHistories;
    }

    public MrktStatusHistory addMrktStatusHistory(MrktStatusHistory mrktStatusHistory) {
        getMrktStatusHistories().add(mrktStatusHistory);
        mrktStatusHistory.setMrktStatusType(this);

        return mrktStatusHistory;
    }

    public MrktStatusHistory removeMrktStatusHistory(MrktStatusHistory mrktStatusHistory) {
        getMrktStatusHistories().remove(mrktStatusHistory);
        mrktStatusHistory.setMrktStatusType(null);

        return mrktStatusHistory;
    }

}
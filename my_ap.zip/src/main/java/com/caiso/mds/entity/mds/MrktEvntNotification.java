package com.caiso.mds.entity.mds;

import java.io.Serializable;

import org.joda.time.DateTime;

public class MrktEvntNotification implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 4824760260156727392L;
    private String            marketPlanId;
    private String            marketRunId;
    private long              marketEventScheduleId;
    private DateTime          marketEventFireDateTime;
    private DateTime          marketDate;
    private long              marketDefintionId;
    private String            marketDefType;
    private String            marketDefClass;
    private String            marketDefDesc;

    private long              marketEventDefId;
    private String            marketEventDefDesc;
    private String            marketEventDefNotificationName;
    private String            marketEventDefNotificationMsg;
    private String            marketEventDefCode;

    private String            marketHour;
    private String            marketEventType;
    private String            marketEventPubState;

    public MrktEvntNotification() {

    }

    public MrktEvntNotification(String marketPlanId, String marketRunId, long marketEventScheduleId, DateTime marketEventFireDateTime, DateTime marketDate,
            long marketDefintionId, String marketDefType, String marketDefClass, String marketDefDesc, long marketEventDefId, String marketEventDefDesc,
            String marketEventType, String marketEventDefNotificationName, String marketEventDefNotificationMsg, String marketEventDefCode, String marketHour,
            String marketEventPubState) {
        this.marketPlanId = marketPlanId;
        this.marketRunId = marketRunId;
        this.marketEventScheduleId = marketEventScheduleId;
        this.marketEventFireDateTime = marketEventFireDateTime;
        this.marketDate = marketDate;
        this.marketDefintionId = marketDefintionId;
        this.marketDefType = marketDefType;
        this.marketDefClass = marketDefClass;
        this.marketDefDesc = marketDefDesc;
        this.marketEventDefId = marketEventDefId;
        this.marketEventDefDesc = marketEventDefDesc;
        this.marketEventType = marketEventType;
        this.marketEventDefNotificationName = marketEventDefNotificationName;
        this.marketEventDefNotificationMsg = marketEventDefNotificationMsg;
        this.marketEventDefCode = marketEventDefCode;
        this.marketHour = marketHour;
        this.marketEventPubState = marketEventPubState;

    }

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public long getMarketEventScheduleId() {
        return marketEventScheduleId;
    }

    public void setMarketEventScheduleId(long marketEventScheduleId) {
        this.marketEventScheduleId = marketEventScheduleId;
    }

    public DateTime getMarketEventFireDateTime() {
        return marketEventFireDateTime;
    }

    public void setMarketEventFireDateTime(DateTime marketEventFireDateTime) {
        this.marketEventFireDateTime = marketEventFireDateTime;
    }

    public DateTime getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(DateTime marketDate) {
        this.marketDate = marketDate;
    }

    public long getMarketDefintionId() {
        return marketDefintionId;
    }

    public void setMarketDefintionId(long marketDefintionId) {
        this.marketDefintionId = marketDefintionId;
    }

    public long getMarketEventDefId() {
        return marketEventDefId;
    }

    public void setMarketEventDefId(int marketEventDefId) {
        this.marketEventDefId = marketEventDefId;
    }

    public String getMarketHour() {
        return marketHour;
    }

    public void setMarketHour(String marketHour) {
        this.marketHour = marketHour;
    }

    public String getMarketDefDesc() {
        return marketDefDesc;
    }

    public void setMarketDefDesc(String marketDefDesc) {
        this.marketDefDesc = marketDefDesc;
    }

    public void setMarketEventDefId(long marketEventDefId) {
        this.marketEventDefId = marketEventDefId;
    }

    public String getMarketDefType() {
        return marketDefType;
    }

    public void setMarketDefType(String marketDefType) {
        this.marketDefType = marketDefType;
    }

    public String getMarketDefClass() {
        return marketDefClass;
    }

    public void setMarketDefClass(String marketDefClass) {
        this.marketDefClass = marketDefClass;
    }

    public String getMarketEventDefDesc() {
        return marketEventDefDesc;
    }

    public void setMarketEventDefDesc(String marketEventDefDesc) {
        this.marketEventDefDesc = marketEventDefDesc;
    }

    public String getMarketEventDefNotificationName() {
        return marketEventDefNotificationName;
    }

    public void setMarketEventDefNotificationName(String marketEventDefNotificationName) {
        this.marketEventDefNotificationName = marketEventDefNotificationName;
    }

    public String getMarketEventDefNotificationMsg() {
        return marketEventDefNotificationMsg;
    }

    public void setMarketEventDefNotificationMsg(String marketEventDefNotificationMsg) {
        this.marketEventDefNotificationMsg = marketEventDefNotificationMsg;
    }

    public String getMarketEventDefCode() {
        return marketEventDefCode;
    }

    public void setMarketEventDefCode(String marketEventDefCode) {
        this.marketEventDefCode = marketEventDefCode;
    }

    public String getMarketEventType() {
        return marketEventType;
    }

    public void setMarketEventType(String marketEventType) {
        this.marketEventType = marketEventType;
    }

    public String getMarketEventPubState() {
        return marketEventPubState;
    }

    public void setMarketEventPubState(String marketEventPubState) {
        this.marketEventPubState = marketEventPubState;
    }
}

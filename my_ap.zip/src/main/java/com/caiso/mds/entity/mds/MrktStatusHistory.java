package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MRKT_STATUS_HISTORY database table.
 * 
 */
@Entity
@Table(name = "MRKT_STATUS_HISTORY", catalog = "MDS_APP")
@NamedQuery(name = "MrktStatusHistory.findAll", query = "SELECT m FROM MrktStatusHistory m")
public class MrktStatusHistory implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "MRKT_STATUS_HISTORY_ID_SEQ", sequenceName = "MRKT_STATUS_HISTORY_ID_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MRKT_STATUS_HISTORY_ID_SEQ")
    @Column(name = "MRKT_STATUS_HISTORY_ID")
    private long              mrktStatusHistoryId;

    @Column(name = "COMMENTS")
    private String            comments;

    @Column(name = "CREATED_BY", updatable = false)
    private String            createdBy;

    @Column(name = "CREATED_DT", updatable = false)
    private Date              createdDt;

    @Column(name = "UPDATED_DT")
    private Date              updatedDt;

    @Column(name = "UPDATED_BY")
    private String            updatedBy;

    // bi-directional many-to-one association to MrktPlan
    @ManyToOne
    @JoinColumns({ @JoinColumn(name = "MRKT_PLAN_ID", referencedColumnName = "MRKT_PLAN_ID"),
            @JoinColumn(name = "MRKT_RUN_ID", referencedColumnName = "MRKT_RUN_ID") })
    private MrktPlan          mrktPlan;

    /*
     * @Column(name="MRKT_PLAN_ID") private String mrktPlanId ;
     * 
     * @Column(name="MRKT_RUN_ID") private String mrktRunId ;
     */

    // bi-directional many-to-one association to MrktStatusType
    @ManyToOne
    @JoinColumn(name = "MRKT_STATUS_TYPE_ID")
    private MrktStatusType    mrktStatusType;

    public MrktStatusHistory() {
    }

    public long getMrktStatusHistoryId() {
        return this.mrktStatusHistoryId;
    }

    public void setMrktStatusHistoryId(long mrktStatusHistoryId) {
        this.mrktStatusHistoryId = mrktStatusHistoryId;
    }

    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return this.createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public Date getUpdatedDt() {
        return this.updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public MrktPlan getMrktPlan() {
        return this.mrktPlan;
    }

    public void setMrktPlan(MrktPlan mrktPlan) {
        this.mrktPlan = mrktPlan;
    }

    public MrktStatusType getMrktStatusType() {
        return this.mrktStatusType;
    }

    public void setMrktStatusType(MrktStatusType mrktStatusType) {
        this.mrktStatusType = mrktStatusType;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

}
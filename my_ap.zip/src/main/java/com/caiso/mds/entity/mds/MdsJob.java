package com.caiso.mds.entity.mds;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MDS_JOB database table.
 * 
 */
@Entity
@Table(name = "MDS_JOB", catalog = "MDS_APP")
@NamedQuery(name = "MdsJob.findAll", query = "SELECT m FROM MdsJob m")
public class MdsJob implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "MDS_JOB_MDSJOBID_GENERATOR", sequenceName = "MDS_JOB_ID_SEQ")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MDS_JOB_MDSJOBID_GENERATOR")
    @Column(name = "MDS_JOB_ID")
    private long              mdsJobId;

    @Column(name = "MRKT_DESC")
    private String            mrktDesc;

    // bi-directional many-to-one association to MrktPlan
    @ManyToOne
    @JoinColumns({ @JoinColumn(name = "MRKT_PLAN_ID", referencedColumnName = "MRKT_PLAN_ID"),
            @JoinColumn(name = "MRKT_RUN_ID", referencedColumnName = "MRKT_RUN_ID") })
    private MrktPlan          mrktPlan;

    public MdsJob() {
    }

    public long getMdsJobId() {
        return this.mdsJobId;
    }

    public void setMdsJobId(long mdsJobId) {
        this.mdsJobId = mdsJobId;
    }

    public String getMrktDesc() {
        return this.mrktDesc;
    }

    public void setMrktDesc(String mrktDesc) {
        this.mrktDesc = mrktDesc;
    }

    public MrktPlan getMrktPlan() {
        return this.mrktPlan;
    }

    public void setMrktPlan(MrktPlan mrktPlan) {
        this.mrktPlan = mrktPlan;
    }

}
package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MDS_LOG database table.
 * 
 */
@Entity
@Table(name = "MDS_LOG", catalog = "MDS_APP")
@NamedQuery(name = "MdsLog.findAll", query = "SELECT m FROM MdsLog m")
public class MdsLog implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "MDS_LOG_ID_SEQ", sequenceName = "MDS_LOG_ID_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MDS_LOG_ID_SEQ")
    @Column(name = "MDS_LOG_ID")
    private long              mdsLogId;

    @Column(name = "MDS_LOG_INSERT_DT")
    private Date              mdsLogInsertDts;

    @Column(name = "MESSAGE_DETAIL")
    private String            messageDetail;

    @Column(name = "MESSAGE_SUMMARY")
    private String            messageSummary;

    // bi-directional many-to-one association to MdsLogMsgType
    @ManyToOne
    @JoinColumn(name = "MDS_LOG_MSG_TYPE_ID")
    private MdsLogMsgType     mdsLogMsgType;

    /*
     * // bi-directional many-to-one association to MrktEvntHistory
     * 
     * @ManyToOne
     * 
     * @JoinColumn(name = "MRKT_EVNT_HISTORY_ID") private MrktEvntHistory
     * mrktEvntHistory;
     * 
     * // bi-directional many-to-one association to MrktStatusHistory
     * 
     * @ManyToOne
     * 
     * @JoinColumn(name = "MRKT_STATUS_HISTORY_ID") private MrktStatusHistory
     * mrktStatusHistory;
     * 
     * // bi-directional many-to-one association to MrktPlan
     * 
     * @ManyToOne
     * 
     * @JoinColumns({ @JoinColumn(name = "MRKT_PLAN_ID", referencedColumnName =
     * "MRKT_PLAN_ID"),
     * 
     * @JoinColumn(name = "MRKT_RUN_ID", referencedColumnName = "MRKT_RUN_ID")
     * }) private MrktPlan mrktPlan;
     */

    @Column(name = "MRKT_PLAN_ID")
    private String            mrktPlanId;

    @Column(name = "MRKT_RUN_ID")
    private String            mrktRunId;

    @Column(name = "MRKT_EVNT_HISTORY_ID")
    private long              mrktEvntHistoryId;

    @Column(name = "MRKT_STATUS_HISTORY_ID")
    private long              mrktStatusHistoryId;

    public MdsLog() {
    }

    public long getMdsLogId() {
        return this.mdsLogId;
    }

    public void setMdsLogId(long mdsLogId) {
        this.mdsLogId = mdsLogId;
    }

    public Date getMdsLogInsertDts() {
        return this.mdsLogInsertDts;
    }

    public void setMdsLogInsertDts(Date mdsLogInsertDts) {
        this.mdsLogInsertDts = mdsLogInsertDts;
    }

    public String getMessageDetail() {
        return this.messageDetail;
    }

    public void setMessageDetail(String messageDetail) {
        this.messageDetail = messageDetail;
    }

    public String getMessageSummary() {
        return this.messageSummary;
    }

    public void setMessageSummary(String messageSummary) {
        this.messageSummary = messageSummary;
    }

    public MdsLogMsgType getMdsLogMsgType() {
        return this.mdsLogMsgType;
    }

    public void setMdsLogMsgType(MdsLogMsgType mdsLogMsgType) {
        this.mdsLogMsgType = mdsLogMsgType;
    }

    public String getMrktPlanId() {
        return mrktPlanId;
    }

    public void setMrktPlanId(String mrktPlanId) {
        this.mrktPlanId = mrktPlanId;
    }

    public String getMrktRunId() {
        return mrktRunId;
    }

    public void setMrktRunId(String mrktRunId) {
        this.mrktRunId = mrktRunId;
    }

    public long getMrktEvntHistoryId() {
        return mrktEvntHistoryId;
    }

    public void setMrktEvntHistoryId(Long mrktEvntHistoryId) {
        this.mrktEvntHistoryId = mrktEvntHistoryId;
    }

    public long getMrktStatusHistoryId() {
        return mrktStatusHistoryId;
    }

    public void setMrktStatusHistoryId(Long mrktStatusHistoryId) {
        this.mrktStatusHistoryId = mrktStatusHistoryId;
    }

    /*
     * public MrktEvntHistory getMrktEvntHistory() { return
     * this.mrktEvntHistory; }
     * 
     * public void setMrktEvntHistory(MrktEvntHistory mrktEvntHistory) {
     * this.mrktEvntHistory = mrktEvntHistory; }
     * 
     * public MrktPlan getMrktPlan() { return this.mrktPlan; }
     * 
     * public void setMrktPlan(MrktPlan mrktPlan) { this.mrktPlan = mrktPlan; }
     * 
     * public MrktStatusHistory getMrktStatusHistory() { return
     * this.mrktStatusHistory; }
     * 
     * public void setMrktStatusHistory(MrktStatusHistory mrktStatusHistory) {
     * this.mrktStatusHistory = mrktStatusHistory; }
     */

}
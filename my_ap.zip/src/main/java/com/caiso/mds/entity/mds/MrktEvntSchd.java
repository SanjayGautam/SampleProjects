package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

/**
 * The persistent class for the MRKT_EVNT_SCHD database table.
 * 
 */
@Entity
@Table(name = "MRKT_EVNT_SCHD", catalog = "MDS_APP")
@NamedQuery(name = "MrktEvntSchd.findAll", query = "SELECT m FROM MrktEvntSchd m")
public class MrktEvntSchd implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MRKT_EVNT_SCHD_ID_SEQ")
    @SequenceGenerator(name = "MRKT_EVNT_SCHD_ID_SEQ", sequenceName = "MRKT_EVNT_SCHD_ID_SEQ", allocationSize = 1)
    @Column(name = "MRKT_EVNT_SCHD_ID")
    private long              mrktEvntSchdId;

    // bi-directional many-to-one association to MrktEvntDef
    @ManyToOne
    @JoinColumn(name = "MRKT_EVNT_DEF_ID", updatable = false)
    private MrktEvntDef       mrktEvntDef;

    // bi-directional many-to-one association to MrktEvntDef
    @ManyToOne
    @JoinColumn(name = "MRKT_DEFINITION_ID", updatable = false)
    private MrktDefinition    mrktDefinition;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "MRKT_DT", updatable = false)
    private DateTime          mrktDate;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "MRKT_EVNT_FIRE_DT", updatable = false)
    private DateTime          mrktEvntFireDate;

    @Column(name = "MRKT_EVNT_PUB_STATE")
    private String            mrktEvntPubState;

    @Column(name = "MRKT_EVNT_ACT_STATUS", updatable = false)
    private String            mrktEvntActivationStatus;

    @Column(name = "CREATED_BY", updatable = false)
    private String            createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DT", updatable = false)
    private Date              createdDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED_DT")
    private Date              updatedDt;

    @Column(name = "UPDATED_BY")
    private String            updatedBy;

    public MrktEvntSchd() {
    }

    public long getMrktEvntSchdId() {
        return mrktEvntSchdId;
    }

    public void setMrktEvntSchdId(long mrktEvntSchdId) {
        this.mrktEvntSchdId = mrktEvntSchdId;
    }

    public MrktEvntDef getMrktEvntDef() {
        return mrktEvntDef;
    }

    public void setMrktEvntDef(MrktEvntDef mrktEvntDef) {
        this.mrktEvntDef = mrktEvntDef;
    }

    public MrktDefinition getMrktDefinition() {
        return mrktDefinition;
    }

    public void setMrktDefinition(MrktDefinition mrktDefinition) {
        this.mrktDefinition = mrktDefinition;
    }

    public DateTime getMrktDate() {
        return mrktDate;
    }

    public void setMrktDate(DateTime mrktDate) {
        this.mrktDate = mrktDate;
    }

    public DateTime getMrktEvntFireDate() {
        return mrktEvntFireDate;
    }

    public void setMrktEvntFireDate(DateTime mrktEvntFireDate) {
        this.mrktEvntFireDate = mrktEvntFireDate;
    }

    public String getMrktEvntPubState() {
        return mrktEvntPubState;
    }

    public void setMrktEvntPubState(String mrktEvntPubState) {
        this.mrktEvntPubState = mrktEvntPubState;
    }

    public String getMrktEvntActivationStatus() {
        return mrktEvntActivationStatus;
    }

    public void setMrktEvntActivationStatus(String mrktEvntActivationStatus) {
        this.mrktEvntActivationStatus = mrktEvntActivationStatus;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public Date getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

}
package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "EXTRNL_ENDPOINT", catalog = "MDS_APP")
public class ExternalSystemEndpoint implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 5471882354808078145L;

    @Id
    @Column(name = "EXTRNL_ENDPOINT_ID")
    private long              externalSystemEndPointId;

    @Column(name = "EXTRNL_APP_NAME")
    private String            externalSystemName;

    @Column(name = "EXTRNL_SRVC_SEQ_NUM")
    private String            externalSystemSrvcSeqNum;

    @Column(name = "EXTRNL_INT_ENDPOINT")
    private String            externalSystemIntEndpoint;

    @Column(name = "IS_HTTP_ENDPOINT")
    private String            isHttpEndPoint;

    @Column(name = "EXTRNL_REAL_ENDPOINT")
    private String            externalSystemRealEndpoint;

    @Column(name = "EXTRNL_SRVC_ENABLED")
    private String            externalSystemSrvcEnabled;

    @Column(name = "SIGN_MSG")
    private String            signMsg;

    @Column(name = "CREATED_BY", updatable = false)
    private String            createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DT", updatable = false)
    private Date              createdDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED_DT")
    private Date              updatedDt;

    @Column(name = "UPDATED_BY")
    private String            updatedBy;

    public long getexternalSystemEndPointId() {
        return externalSystemEndPointId;
    }

    public long getExternalSystemEndPointId() {
        return externalSystemEndPointId;
    }

    public void setExternalSystemEndPointId(long externalSystemEndPointId) {
        this.externalSystemEndPointId = externalSystemEndPointId;
    }

    public String getExternalSystemName() {
        return externalSystemName;
    }

    public void setExternalSystemName(String externalSystemName) {
        this.externalSystemName = externalSystemName;
    }

    public String getExternalSystemSrvcSeqNum() {
        return externalSystemSrvcSeqNum;
    }

    public void setExternalSystemSrvcSeqNum(String externalSystemSrvcSeqNum) {
        this.externalSystemSrvcSeqNum = externalSystemSrvcSeqNum;
    }

    public String getExternalSystemIntEndpoint() {
        return externalSystemIntEndpoint;
    }

    public void setExternalSystemIntEndpoint(String externalSystemIntEndpoint) {
        this.externalSystemIntEndpoint = externalSystemIntEndpoint;
    }

    public String getIsHttpEndPoint() {
        return isHttpEndPoint;
    }

    public void setIsHttpEndPoint(String isHttpEndPoint) {
        this.isHttpEndPoint = isHttpEndPoint;
    }

    public String getExternalSystemRealEndpoint() {
        return externalSystemRealEndpoint;
    }

    public void setExternalSystemRealEndpoint(String externalSystemRealEndpoint) {
        this.externalSystemRealEndpoint = externalSystemRealEndpoint;
    }

    public String getExternalSystemSrvcEnabled() {
        return externalSystemSrvcEnabled;
    }

    public void setExternalSystemSrvcEnabled(String externalSystemSrvcEnabled) {
        this.externalSystemSrvcEnabled = externalSystemSrvcEnabled;
    }

    public String getSignMsg() {
        return signMsg;
    }

    public void setSignMsg(String signMsg) {
        this.signMsg = signMsg;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public Date getUpdatedDt() {
        return updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

}

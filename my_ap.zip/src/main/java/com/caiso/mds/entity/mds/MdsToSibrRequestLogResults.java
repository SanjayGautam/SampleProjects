package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.List;

public class MdsToSibrRequestLogResults implements Serializable {

    /**
	 * 
	 */
    private static final long     serialVersionUID = -4686767708064891151L;

    private List<MdsToSibrMsgLog> mdsToSibrMsgLogs;

    private long                  totalRowsCount;
    private int                   totalPagesCount;
    private int                   currentPageNumber;
    private int                   currentPageSize;

    public long getTotalRowsCount() {
        return totalRowsCount;
    }

    public void setTotalRowsCount(long totalRowsCount) {
        this.totalRowsCount = totalRowsCount;
    }

    public int getTotalPagesCount() {
        return totalPagesCount;
    }

    public void setTotalPagesCount(int totalPagesCount) {
        this.totalPagesCount = totalPagesCount;
    }

    public int getCurrentPageNumber() {
        return currentPageNumber;
    }

    public void setCurrentPageNumber(int currentPageNumber) {
        this.currentPageNumber = currentPageNumber;
    }

    public int getCurrentPageSize() {
        return currentPageSize;
    }

    public void setCurrentPageSize(int currentPageSize) {
        this.currentPageSize = currentPageSize;
    }

    public List<MdsToSibrMsgLog> getMdsToSibrMsgLogs() {
        return mdsToSibrMsgLogs;
    }

    public void setMdsToSibrMsgLogs(List<MdsToSibrMsgLog> mdsToSibrMsgLogs) {
        this.mdsToSibrMsgLogs = mdsToSibrMsgLogs;
    }

}

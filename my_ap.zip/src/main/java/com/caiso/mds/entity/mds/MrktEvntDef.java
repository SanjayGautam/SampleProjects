package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * The persistent class for the MRKT_EVNT_DEF database table.
 * 
 */
@Entity
@Table(name = "MRKT_EVNT_DEF", catalog = "MDS_APP")
@NamedQuery(name = "MrktEvntDef.findAll", query = "SELECT m FROM MrktEvntDef m")
public class MrktEvntDef implements Serializable {
    private static final long     serialVersionUID = 1L;

    @Id
    @Column(name = "MRKT_EVNT_DEF_ID")
    private long                  mrktEvntDefId;

    @Column(name = "MRKT_EVNT_DESC")
    private String                mrktEvntDesc;

    @Column(name = "MRKT_EVNT_NOTIFICATION_MSG")
    private String                mrktEvntNotificationMsg;

    @Column(name = "MRKT_EVNT_NOTIFICATION_NAME")
    private String                mrktEvntNotificationName;

    @Column(name = "MRKT_EVNT_CD")
    private String                mrktEvntCd;

    @Column(name = "ASSOC_MRKT_DEFINITION_ID", nullable = true)
    private Long                  assocMrktDefinitionId;

    @Column(name = "MRKT_EVNT_TYPE")
    private String                mrktEvntType;

    @Column(name = "IS_EXTERNAL_EVNT")
    private Boolean               isExternalEvnt;

    @Column(name = "HAS_FIXED_EVNT_TRGR_TIME")
    private Boolean               hasFixedEventTriggerTime;

    @Column(name = "ENABLED")
    private Boolean               isEnabled;

    @Column(name = "EVNT_START_TIME")
    private String                evntStartTime;

    @Column(name = "EVNT_END_TIME")
    private String                evntEndTime;

    @Column(name = "EVNT_TIME_OFFSET")
    private Integer               evntTimeOffset;

    @Column(name = "EVNT_TIME_OFFSET_UNIT")
    private String                evntTimeOffsetUnit;

    @Column(name = "EVNT_TIME_OFFSET_STRT_ENTTY")
    private String                evntTimeOffsetStrtEntity;

    @Column(name = "EVNT_RPT_INTRVL")
    private Integer               evntRptIntrvl;

    @Column(name = "EVNT_RPT_INTRVL_UNIT")
    private String                evntRptIntrvlUnit;

    @Column(name = "EVNT_RPT_INTRVL_OCCRANCE")
    private Integer               evntRptIntrvlOccurance;

    @Column(name = "CREATED_BY", updatable = false)
    private String                createdBy;

    @Column(name = "CREATED_DT", updatable = false)
    private Date                  createdDt;

    @Column(name = "UPDATED_DT")
    private Date                  updatedDt;

    @Column(name = "UPDATED_BY")
    private String                updatedBy;

    // bi-directional many-to-one association to MrktEvntHistory
    @OneToMany(mappedBy = "mrktEvntDef")
    private List<MrktEvntHistory> mrktEvntHistories;

    public MrktEvntDef() {
    }

    public long getMrktEvntDefId() {
        return this.mrktEvntDefId;
    }

    public void setMrktEvntDefId(long mrktEvntDefId) {
        this.mrktEvntDefId = mrktEvntDefId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Object getCreatedDt() {
        return this.createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public String getMrktEvntCd() {
        return this.mrktEvntCd;
    }

    public void setMrktEvntCd(String mrktEvntCd) {
        this.mrktEvntCd = mrktEvntCd;
    }

    public String getMrktEvntDesc() {
        return this.mrktEvntDesc;
    }

    public void setMrktEvntDesc(String mrktEvntDesc) {
        this.mrktEvntDesc = mrktEvntDesc;
    }

    public String getMrktEvntNotificationMsg() {
        return this.mrktEvntNotificationMsg;
    }

    public void setMrktEvntNotificatSionMsg(String mrktEvntNotificationMsg) {
        this.mrktEvntNotificationMsg = mrktEvntNotificationMsg;
    }

    public String getMrktEvntNotificationName() {
        return this.mrktEvntNotificationName;
    }

    public void setMrktEvntNotificationName(String mrktEvntNotificationName) {
        this.mrktEvntNotificationName = mrktEvntNotificationName;
    }

    public Object getUpdatedDt() {
        return this.updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public List<MrktEvntHistory> getMrktEvntHistories() {
        return this.mrktEvntHistories;
    }

    public void setMrktEvntHistories(List<MrktEvntHistory> mrktEvntHistories) {
        this.mrktEvntHistories = mrktEvntHistories;
    }

    public MrktEvntHistory addMrktEvntHistory(MrktEvntHistory mrktEvntHistory) {
        getMrktEvntHistories().add(mrktEvntHistory);
        mrktEvntHistory.setMrktEvntDef(this);

        return mrktEvntHistory;
    }

    public MrktEvntHistory removeMrktEvntHistory(MrktEvntHistory mrktEvntHistory) {
        getMrktEvntHistories().remove(mrktEvntHistory);
        mrktEvntHistory.setMrktEvntDef(null);

        return mrktEvntHistory;
    }

    public Long getAssocMrktDefinitionId() {
        return assocMrktDefinitionId;
    }

    public void setAssocMrktDefinitionId(Long assocMrktDefinitionId) {
        this.assocMrktDefinitionId = assocMrktDefinitionId;
    }

    public boolean isExternalEvnt() {
        return isExternalEvnt;
    }

    public void setExternalEvnt(boolean isExternalEvnt) {
        this.isExternalEvnt = isExternalEvnt;
    }

    public String getEvntStartTime() {
        return evntStartTime;
    }

    public void setEvntStartTime(String evntStartTime) {
        this.evntStartTime = evntStartTime;
    }

    public String getEvntEndTime() {
        return evntEndTime;
    }

    public void setEvntEndTime(String evntEndTime) {
        this.evntEndTime = evntEndTime;
    }

    public int getEvntTimeOffset() {
        return evntTimeOffset;
    }

    public void setEvntTimeOffset(int evntTimeOffset) {
        this.evntTimeOffset = evntTimeOffset;
    }

    public String getEvntTimeOffsetUnit() {
        return evntTimeOffsetUnit;
    }

    public void setEvntTimeOffsetUnit(String evntTimeOffsetUnit) {
        this.evntTimeOffsetUnit = evntTimeOffsetUnit;
    }

    public String getEvntTimeOffsetStrtEntity() {
        return evntTimeOffsetStrtEntity;
    }

    public void setEvntTimeOffsetStrtEntity(String evntTimeOffsetStrtEntity) {
        this.evntTimeOffsetStrtEntity = evntTimeOffsetStrtEntity;
    }

    public Integer getEvntRptIntrvl() {
        return evntRptIntrvl;
    }

    public void setEvntRptIntrvl(Integer evntRptIntrvl) {
        this.evntRptIntrvl = evntRptIntrvl;
    }

    public String getEvntRptIntrvlUnit() {
        return evntRptIntrvlUnit;
    }

    public void setEvntRptIntrvlUnit(String evntRptIntrvlUnit) {
        this.evntRptIntrvlUnit = evntRptIntrvlUnit;
    }

    public void setMrktEvntNotificationMsg(String mrktEvntNotificationMsg) {
        this.mrktEvntNotificationMsg = mrktEvntNotificationMsg;
    }

    public Integer getEvntRptIntrvlOccurance() {

        return evntRptIntrvlOccurance;
    }

    public void setEvntRptIntrvlOccurance(Integer evntRptIntrvlOccurance) {
        this.evntRptIntrvlOccurance = evntRptIntrvlOccurance;
    }

    public String getMrktEvntType() {
        return mrktEvntType;
    }

    public void setMrktEvntType(String mrktEvntType) {
        this.mrktEvntType = mrktEvntType;
    }

    public boolean getHasFixedEventTriggerTime() {
        return hasFixedEventTriggerTime;
    }

    public void setHasFixedEventTriggerTime(Boolean hasFixedEventTriggerTime) {
        this.hasFixedEventTriggerTime = hasFixedEventTriggerTime;
    }

    public boolean getIsEnabled() {
        return isEnabled;
    }

    public void setIsEnabled(boolean isEnabled) {
        this.isEnabled = isEnabled;
    }

}
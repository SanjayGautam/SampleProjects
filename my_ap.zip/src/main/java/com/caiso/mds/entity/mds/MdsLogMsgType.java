package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the MDS_LOG_MSG_TYPE database table.
 * 
 */
@Entity
@Table(name = "MDS_LOG_MSG_TYPE", catalog = "MDS_APP")
@NamedQuery(name = "MdsLogMsgType.findAll", query = "SELECT m FROM MdsLogMsgType m")
public class MdsLogMsgType implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "MDS_LOG_MSG_TYPE_MDSLOGMSGTYPEID_GENERATOR")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MDS_LOG_MSG_TYPE_MDSLOGMSGTYPEID_GENERATOR")
    @Column(name = "MDS_LOG_MSG_TYPE_ID")
    private long              mdsLogMsgTypeId;

    @Column(name = "MDS_LOG_MSG_TYPE_DESC")
    private String            mdsLogMsgTypeDesc;

    @Column(name = "MDS_LOG_MSG_TYPE_NAME")
    private String            mdsLogMsgTypeName;

    // bi-directional many-to-one association to MdsLog
    @OneToMany(mappedBy = "mdsLogMsgType")
    private List<MdsLog>      mdsLogs;

    public MdsLogMsgType() {
    }

    public long getMdsLogMsgTypeId() {
        return this.mdsLogMsgTypeId;
    }

    public void setMdsLogMsgTypeId(long mdsLogMsgTypeId) {
        this.mdsLogMsgTypeId = mdsLogMsgTypeId;
    }

    public String getMdsLogMsgTypeDesc() {
        return this.mdsLogMsgTypeDesc;
    }

    public void setMdsLogMsgTypeDesc(String mdsLogMsgTypeDesc) {
        this.mdsLogMsgTypeDesc = mdsLogMsgTypeDesc;
    }

    public String getMdsLogMsgTypeName() {
        return this.mdsLogMsgTypeName;
    }

    public void setMdsLogMsgTypeName(String mdsLogMsgTypeName) {
        this.mdsLogMsgTypeName = mdsLogMsgTypeName;
    }

    public List<MdsLog> getMdsLogs() {
        return this.mdsLogs;
    }

    public void setMdsLogs(List<MdsLog> mdsLogs) {
        this.mdsLogs = mdsLogs;
    }

    public MdsLog addMdsLog(MdsLog mdsLog) {
        getMdsLogs().add(mdsLog);
        mdsLog.setMdsLogMsgType(this);

        return mdsLog;
    }

    public MdsLog removeMdsLog(MdsLog mdsLog) {
        getMdsLogs().remove(mdsLog);
        mdsLog.setMdsLogMsgType(null);

        return mdsLog;
    }

}
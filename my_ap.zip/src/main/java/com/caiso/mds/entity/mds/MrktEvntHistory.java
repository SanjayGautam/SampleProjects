package com.caiso.mds.entity.mds;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

/**
 * The persistent class for the MRKT_EVNT_HISTORY database table.
 * 
 */
@Entity
@Table(name = "MRKT_EVNT_HISTORY", catalog = "MDS_APP")
@NamedQuery(name = "MrktEvntHistory.findAll", query = "SELECT m FROM MrktEvntHistory m")
public class MrktEvntHistory implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "MRKT_EVNT_HISTORY_ID_SEQ")
    @SequenceGenerator(name = "MRKT_EVNT_HISTORY_ID_SEQ", sequenceName = "MRKT_EVNT_HISTORY_ID_SEQ", allocationSize = 1)
    @Column(name = "MRKT_EVNT_HISTORY_ID")
    private long              mrktEvntHistoryId;

    // bi-directional many-to-one association to MrktPlan
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumns({ @JoinColumn(name = "MRKT_PLAN_ID", updatable = false, referencedColumnName = "MRKT_PLAN_ID"),
            @JoinColumn(name = "MRKT_RUN_ID", updatable = false, referencedColumnName = "MRKT_RUN_ID") })
    private MrktPlan          mrktPlan;

    // bi-directional many-to-one association to MrktEvntDef
    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "MRKT_EVNT_DEF_ID", updatable = false)
    private MrktEvntDef       mrktEvntDef;

    // bi-directional many-to-one association to MrktStatusType
    /*
     * @ManyToOne
     * 
     * @JoinColumn(name = "MRKT_STATUS_HISTORY_ID") private long
     * mrktStatusHistoryId;
     */

    @Column(name = "MRKT_STATUS_HISTORY_ID")
    private long              mrktStatusHistoryId;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @Column(name = "MRKT_DT")
    private DateTime          mrktDate;

    @Column(name = "CREATED_BY")
    private String            createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DT", updatable = false)
    private Date              createdDt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED_DT")
    private Date              updatedDt;

    @Column(name = "UPDATED_BY")
    private String            updatedBy;

    @Column(name = "MRKT_EVNT_PUB_STATE")
    private String            mrktEvntPubState;

    /*
     * //bi-directional many-to-one association to MdsLog
     * 
     * @OneToMany(mappedBy="mrktEvntHistory") private List<MdsLog> mdsLogs;
     */

    public MrktEvntHistory() {
    }

    public long getMrktEvntHistoryId() {
        return this.mrktEvntHistoryId;
    }

    public void setMrktEvntHistoryId(long mrktEvntHistoryId) {
        this.mrktEvntHistoryId = mrktEvntHistoryId;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDt() {
        return this.createdDt;
    }

    public void setCreatedDt(Date createdDt) {
        this.createdDt = createdDt;
    }

    public DateTime getMrktDate() {
        return this.mrktDate;
    }

    public void setMrktDate(DateTime mrktDate) {
        this.mrktDate = mrktDate;
    }

    public Date getUpdatedDt() {
        return this.updatedDt;
    }

    public void setUpdatedDt(Date updatedDt) {
        this.updatedDt = updatedDt;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    /*
     * public List<MdsLog> getMdsLogs() { return this.mdsLogs; }
     * 
     * public void setMdsLogs(List<MdsLog> mdsLogs) { this.mdsLogs = mdsLogs; }
     */
    /*
     * public MdsLog addMdsLog(MdsLog mdsLog) { getMdsLogs().add(mdsLog);
     * mdsLog.setMrktEvntHistory(this);
     * 
     * return mdsLog; }
     * 
     * public MdsLog removeMdsLog(MdsLog mdsLog) { getMdsLogs().remove(mdsLog);
     * mdsLog.setMrktEvntHistory(null);
     * 
     * return mdsLog; }
     */

    public MrktEvntDef getMrktEvntDef() {
        return this.mrktEvntDef;
    }

    public void setMrktEvntDef(MrktEvntDef mrktEvntDef) {
        this.mrktEvntDef = mrktEvntDef;
    }

    public MrktPlan getMrktPlan() {
        return this.mrktPlan;
    }

    public void setMrktPlan(MrktPlan mrktPlan) {
        this.mrktPlan = mrktPlan;
    }

    public long getMrktStatusHistoryId() {
        return mrktStatusHistoryId;
    }

    public void setMrktStatusHistoryId(long mrktStatusHistoryId) {
        this.mrktStatusHistoryId = mrktStatusHistoryId;
    }

    public String getMrktEvntPubState() {
        return mrktEvntPubState;
    }

    public void setMrktEvntPubState(String mrktEvntPubState) {
        this.mrktEvntPubState = mrktEvntPubState;
    }

}
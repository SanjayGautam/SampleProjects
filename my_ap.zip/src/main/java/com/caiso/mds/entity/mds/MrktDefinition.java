package com.caiso.mds.entity.mds;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the MRKT_DEFINITION database table.
 * 
 */
@Entity
@Table(name = "MRKT_DEFINITION", catalog = "MDS_APP")
@NamedQuery(name = "MrktDefinition.findAll", query = "SELECT m FROM MrktDefinition m")
public class MrktDefinition implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "MRKT_DEFINITION_ID")
    private long              mrktDefinitionId;

    @Column(name = "MRKT_CLASS")
    private String            mrktClass;

    @Column(name = "MRKT_DEF_DESC")
    private String            mrktDefDesc;

    @Column(name = "MRKT_TYPE")
    private String            mrktType;

    @ManyToOne
    @JoinColumn(name = "MRKT_ACTIVITY_ID", updatable = false)
    private MrktActivity      mrktActivity;

    public MrktDefinition() {
    }

    public long getMrktDefinitionId() {
        return this.mrktDefinitionId;
    }

    public void setMrktDefinitionId(long mrktDefinitionId) {
        this.mrktDefinitionId = mrktDefinitionId;
    }

    public String getMrktClass() {
        return this.mrktClass;
    }

    public void setMrktClass(String mrktClass) {
        this.mrktClass = mrktClass;
    }

    public String getMrktDefDesc() {
        return this.mrktDefDesc;
    }

    public void setMrktDefDesc(String mrktDefDesc) {
        this.mrktDefDesc = mrktDefDesc;
    }

    public String getMrktType() {
        return this.mrktType;
    }

    public void setMrktType(String mrktType) {
        this.mrktType = mrktType;
    }

    public MrktActivity getMrktActivity() {
        return mrktActivity;
    }

    public void setMrktActivity(MrktActivity mrktActivity) {
        this.mrktActivity = mrktActivity;
    }

}
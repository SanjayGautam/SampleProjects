package com.caiso.mds.types;

public enum MarketStatusType {

    OPEN(10, "OPEN", "Opened Market"), HOLD(30, "HOLD", "Held Market"), CLOSE(60, "CLOSE", "Close Market"), POST_CLOSE(70, "POST_CLOSE", "Post-closed Market"), PUBLISH(
            80, "PUBLISH", "Published Market"), PRE_CLOSE(90, "PRE_CLOSE", "Pre Close Market"), MARKET_ALERT(100, "MARKET_ALERT", "Market Alert State"), NEW(5,
            "NEW", "Pre Open Market");

    private final long   marketStatusTypeId;
    private final String marketStatusType;
    private final String marketStatusTypeDesc;

    public long getMarketStatusTypeId() {
        return marketStatusTypeId;
    }

    public String getMarketStatusType() {
        return marketStatusType;
    }

    public String getMarketStatusTypeDesc() {
        return marketStatusTypeDesc;
    }

    private MarketStatusType(int marketStatusTypeId, String marketStatusType, String marketStatusTypeDesc) {

        this.marketStatusType = marketStatusType;
        this.marketStatusTypeId = marketStatusTypeId;
        this.marketStatusTypeDesc = marketStatusTypeDesc;

    }

}

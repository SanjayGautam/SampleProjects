package com.caiso.mds.types;

public enum MarketEventActivationStatus {

    DISABLED(1, "DISABLED"), ENABLED(2, "ENABLED");

    private final int    id;
    private final String name;

    private MarketEventActivationStatus(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}

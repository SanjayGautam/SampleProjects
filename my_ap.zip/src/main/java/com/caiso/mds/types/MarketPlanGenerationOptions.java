package com.caiso.mds.types;

public enum MarketPlanGenerationOptions {

    GENERATE_DAM(1, "GENERATE_DAM"), GENERATE_RTM(2, "GENERATE_RTM"), GENERATE_BOTH(3, "GENERATE_BOTH");

    private final int    id;
    private final String name;

    private MarketPlanGenerationOptions(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}

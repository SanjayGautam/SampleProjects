package com.caiso.mds.types;

public enum RepeatIntervalUnit {

    EVERY_MINUTE(1, "EVERY_MINUTE"), EVERY_HOUR(2, "EVERY_HOUR");

    private final int    id;
    private final String name;

    private RepeatIntervalUnit(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}

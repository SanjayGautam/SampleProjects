package com.caiso.mds.types;

public enum ServiceName {

    receiveDACleanBidCaiso_v4(1, "receiveDACleanBidCaiso_v4"), receiveRTCleanBidCaiso_v4(2, "receiveRTCleanBidCaiso_v4"), receiveFinalTradeSet(3,
            "receiveFinalTradeSet");

    private final int    id;
    private final String name;

    private ServiceName(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}

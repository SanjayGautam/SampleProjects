package com.caiso.mds.types;

public enum EventTimeOffsetStartTimeEntityType {

    MARKET_HOUR(1, "MRKT_HOUR"), MARKET_DATE(2, "MRKT_DT");

    private int    id;
    private String name;

    private EventTimeOffsetStartTimeEntityType(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {

        this.name = name;

    }

}

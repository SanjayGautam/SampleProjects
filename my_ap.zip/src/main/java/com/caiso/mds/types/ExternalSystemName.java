package com.caiso.mds.types;

public enum ExternalSystemName {

    /**
     * SIBR Details External systems are exposed via AI and hence when we tell
     * external system url we trying to map it to the AI internal URLS or End
     * Points. All the one with SIBR is broadcastSIBR AI ,
     * 
     * MNS Details MNS pertains to all the Endpoints which comes under Market
     * Participants , They can be Internal AI endpoints or they can be totally
     * External EndPoints on the extranet . These Endpoints may be totally
     * belong to different system different organisations Objective is to create
     * buckets.
     * 
     */
    SIBR(1, "SIBR"), MNS(2, "MNS");

    private final int    id;
    private final String name;

    private ExternalSystemName(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}

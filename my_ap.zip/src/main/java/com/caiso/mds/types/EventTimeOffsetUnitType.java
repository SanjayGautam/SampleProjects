package com.caiso.mds.types;

public enum EventTimeOffsetUnitType {

    MINS(1, "MINS"), DAYS(2, "DAYS");

    private final int    id;
    private final String name;

    private EventTimeOffsetUnitType(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}

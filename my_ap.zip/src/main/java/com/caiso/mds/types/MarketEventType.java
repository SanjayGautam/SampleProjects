package com.caiso.mds.types;

/**
 * This enum basically for the requirement where the market status changes and
 * as market status or state is being changed or Achieves a certain state at the
 * moment NMS need to know about this state and for that state this will be the
 * type of event which needs to be published for that market def id .
 * 
 * each market state will have market event notification to be sent to NMS but
 * it is not necessary that each Market Event will have a corresponding state in
 * the Market Status. There will be some Market Notification which will be of
 * TYPE market Alerts which just there and need to be sent to the NMS as Alerts
 * 
 * 
 * @author sgautam
 * 
 */
public enum MarketEventType {

    OPEN(10, "OPEN", "Event To be Published when Market State is Set to Open"), HOLD(30, "HOLD", "Event To Be Published When Market State is set to Hold"), CLOSE(
            60, "CLOSE", "Event To Be Published When Market State is set to CLOSE "), POST_CLOSE(70, "POST_CLOSE",
            "Event to be Published when Market State is set to POST CLOSE"), PUBLISH(80, "PUBLISH", "Event to be published when Market State is set to PUBLISH"), PRE_CLOSE(
            90, "PRE_CLOSE", "Event to be published when Prior to Market Close"), MARKET_ALERT(100, "MARKET_ALERT",
            "Event to be published when deadline or some alerts based on external or internal state is going to reach."), NEW(5, "NEW", "Market is New");

    private final int    marketEventTypeId;
    private final String marketEventType;
    private final String marketEventTypeDesc;

    public int getMarketEventTypeId() {
        return marketEventTypeId;
    }

    public String getMarketEventType() {
        return marketEventType;
    }

    public String getMarketEventTypeDesc() {
        return marketEventTypeDesc;
    }

    private MarketEventType(int marketEventTypeId, String marketEventType, String marketEventTypeDesc) {

        this.marketEventType = marketEventType;
        this.marketEventTypeId = marketEventTypeId;
        this.marketEventTypeDesc = marketEventTypeDesc;

    }

}

package com.caiso.mds.types;

public enum MarketDefintionType {

    DAM_BASE(6, "DAM_BASE", "Day Ahead Base Market", "DAM", "BASE"), DAM_CB(5, "DAM_CB", "Day Ahead Converging Bids Market", "DAM", "CB"), DAM_MARKET(1,
            "DAM_MARKET", "Day Ahead Market ", "DAM", "MARKET"), DAM_TRADES(2, "DAM_TRADES", "Day Ahead Trades Market", "DAM", "TRADES"), RTM_BASE(7,
            "RTM_BASE", "Real Time Base Market", "RTM", "BASE"), RTM_MARKET(3, "RTM_MARKET", "Real Time Market", "RTM", "MARKET"), RTM_TRADES(4, "RTM_TRADES",
            "Real Time Trade Market", "RTM", "TRADES");

    private final long   id;
    private final String name;
    private final String desc;
    private final String marketType;
    private final String marketClass;

    private MarketDefintionType(long id, String name, String desc, String marketType, String marketClass) {

        this.id = id;
        this.name = name;
        this.desc = desc;
        this.marketType = marketType;
        this.marketClass = marketClass;

    }

    public long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public String getMarketType() {
        return marketType;
    }

    public String getMarketClass() {
        return marketClass;
    }

}

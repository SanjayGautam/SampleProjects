package com.caiso.mds.types;

public enum MarketPublishStateType {

    SCHEDULED(1, "SCHEDULED"), PUBLISHED(2, "PUBLISHED"), ERROR_IN_PUBLISH(3, "ERROR_IN_PUBLISH"), PROCESSING(1, "PROCESSING");

    private final int    id;
    private final String name;

    private MarketPublishStateType(int id, String name) {

        this.id = id;
        this.name = name;

    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

}

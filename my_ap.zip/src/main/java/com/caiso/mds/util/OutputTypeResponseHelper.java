package com.caiso.mds.util;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.soa.proxies.mds.marketstatus.Event;
import com.caiso.soa.proxies.mds.marketstatus.EventLog;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;
import com.caiso.soa.proxies.mds.marketstatus.Service;

@Component
public class OutputTypeResponseHelper {

    @Autowired
    private DateUtil dateUtil;

    /**
     * 
     * @param id
     * @param eventType
     * @param severity
     * @param result
     * @return
     */

    // TODO where ever called generate the unique Ids for this messages
    public OutputDataType prepareResponse(String result, String id, String serviceName, String description, String severity, String eventType,
            String serviceDesc, String serviceComments) {

        OutputDataType outputDataType = new OutputDataType();
        EventLog eventLog = populateEventLogInfo(id, serviceName);
        populateEventInfo(eventLog, result, id, serviceName, description, severity, eventType);
        populateServiceInfo(eventLog, serviceName, serviceDesc, serviceComments);
        outputDataType.getEventLog().add(eventLog);
        return outputDataType;
    }

    /**
     * 
     * @param eventLog
     * @param eventType
     * @param severity
     * @param result
     */
    public void populateEventInfo(EventLog eventLog, String result, String id, String name, String description, String severity, String eventType) {
        Event event = new Event();
        event.setEventType(eventType);
        event.setSeverity(severity);
        event.setCreationTime(dateUtil.getGeorgianDate(new Date()));
        event.setDescription(description);
        event.setName(name);
        event.setId("1");
        event.setResult(result); // SCSS0001

        eventLog.getEvent().add(event);
    }

    /**
     * 
     * @param id
     * @return
     */
    private EventLog populateEventLogInfo(String id, String serviceName) {
        EventLog eventLog = new EventLog();
        eventLog.setId(id);
        eventLog.setName(serviceName);
        eventLog.setDescription(serviceName + "EventLog");
        eventLog.setCreationTime(dateUtil.getGeorgianDate(new Date()));
        eventLog.setCollectionType(serviceName);
        eventLog.setCollectionQuantity("1");
        return eventLog;
    }

    /**
     * 
     * @param eventLog
     */
    private void populateServiceInfo(EventLog eventLog, String serviceName, String description, String comments) {
        Service service = new Service();
        service.setComments(comments);
        service.setDescription(description);
        service.setId(serviceName);
        service.setName(serviceName);

        eventLog.getService().add(service);
    }

}

package com.caiso.mds.util;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.entity.mds.MrktDefinition;
import com.caiso.mds.entity.mds.MrktEvntDef;
import com.caiso.mds.entity.mds.MrktEvntSchd;
import com.caiso.mds.types.EventTimeOffsetStartTimeEntityType;
import com.caiso.mds.types.EventTimeOffsetUnitType;
import com.caiso.mds.types.MarketPublishStateType;
import com.caiso.mds.types.RepeatIntervalUnit;

@Component
public class MarketEventScheduleGenerator {

    private final static Logger  logger = LoggerFactory.getLogger(MarketEventScheduleGenerator.class);

    @Autowired
    private MarketHoursGenerator marketHoursGenerator;

    /**
     * 
     * @param mrktEvntDef
     * @param marketDateInMarketEventSchedule
     * @return
     */
    /*
     * public List<MrktEvntSchd> generate(MrktEvntDef mrktEvntDef, DateTime
     * marketDateInMarketEventSchedule) {
     * logger.info("*** Entered Generating Market Event Schdeules *****************"
     * ); List<MrktEvntSchd> marketEventSchedules = null; if
     * (mrktEvntDef.getEvntTimeOffsetStrtEntity
     * ().equals(EventTimeOffsetStartTimeEntityType.MARKET_HOUR)) {
     * marketEventSchedules = processMarketHours(mrktEvntDef,
     * marketDateInMarketEventSchedule); } else { marketEventSchedules =
     * processMarketDateOffsetStartType(mrktEvntDef,
     * marketDateInMarketEventSchedule); }
     * logger.info("*** Exiting Generating Market Event Schdeules *****************"
     * ); return marketEventSchedules; }
     */
    /**
     * 
     * @param mrktEvntDef
     * @param marketDateInMarketEventSchedule
     * @return
     */
    public List<MrktEvntSchd> processGeneric(MrktEvntDef mrktEvntDef, DateTime marketDateInMarketEventSchedule) {

        logger.info(" Processing the Generic Market Event Schedules ");
        List<MrktEvntSchd> marketEventSchedules = new ArrayList<MrktEvntSchd>();

        List<DateTime> marketDateOrHours = getMarketDateAndHours(mrktEvntDef, marketDateInMarketEventSchedule);

        for (DateTime marketDateOrHour : marketDateOrHours) {

            DateTime dateTimeSchedule = setMarketEventOffSetTime(mrktEvntDef, marketDateOrHour);
            DateTime dateTimeStartTime = setEventStartTime(mrktEvntDef, dateTimeSchedule);
            List<DateTime> listOfAllEventFireDateAndTime = applyRepeatInterval(mrktEvntDef, dateTimeStartTime);
            marketEventSchedules.addAll(createMarketEventSchedules(mrktEvntDef, marketDateOrHour, listOfAllEventFireDateAndTime));

        }

        logger.info(" Exiting the Generic Market Event Schedules ");
        return marketEventSchedules;
    }

    /**
     * 
     * @param mrktEvntDef
     * @param marketDate
     * @param listOfAllEventFireDateAndTime
     * @return
     */
    private List<MrktEvntSchd> createMarketEventSchedules(MrktEvntDef mrktEvntDef, DateTime marketDate, List<DateTime> listOfAllEventFireDateAndTime) {

        List<MrktEvntSchd> marketEventSchedules = new ArrayList<MrktEvntSchd>();

        for (DateTime eventFireDateAndTime : listOfAllEventFireDateAndTime) {
            MrktEvntSchd mrktEvntSchd = new MrktEvntSchd();

            DateTime marketDateTemp = new DateTime(marketDate, DateTimeZone.UTC);
            mrktEvntSchd.setMrktDate(marketDateTemp);
            mrktEvntSchd.setMrktEvntActivationStatus("ENABLED");

            MrktDefinition mrktDefinition = new MrktDefinition();
            if (mrktEvntDef.getAssocMrktDefinitionId() != null) {
                mrktDefinition.setMrktDefinitionId(mrktEvntDef.getAssocMrktDefinitionId().longValue());
            }
            mrktEvntSchd.setMrktDefinition(mrktDefinition);

            mrktEvntSchd.setMrktEvntDef(mrktEvntDef);
            mrktEvntSchd.setCreatedBy("mds_bpm");
            mrktEvntSchd.setCreatedDt(new Date());
            mrktEvntSchd.setUpdatedBy("mds_bpm");
            mrktEvntSchd.setUpdatedDt(new Date());
            /*
             * This is for events like OPEN RTM markets which OPEN based on the
             * DAM Published Results
             */

            DateTime eventFireDateTimeTemp = new DateTime(eventFireDateAndTime, DateTimeZone.UTC);
            mrktEvntSchd.setMrktEvntFireDate(eventFireDateTimeTemp);

            mrktEvntSchd.setMrktEvntPubState(MarketPublishStateType.SCHEDULED.getName());
            marketEventSchedules.add(mrktEvntSchd);
        }

        return marketEventSchedules;
    }

    /**
     * 
     * @param timeOffsetStartEntity
     * @param marketDateInMarketEventSchedule
     * @return
     */
    private List<DateTime> getMarketDateAndHours(MrktEvntDef mrktEvntDef, DateTime marketDateInMarketEventSchedule) {

        List<DateTime> marketDateAndHours = new ArrayList<DateTime>();

        if (mrktEvntDef.getEvntTimeOffsetStrtEntity().equals(EventTimeOffsetStartTimeEntityType.MARKET_HOUR.getName())) {
            DateTime marketDate = marketDateInMarketEventSchedule.toDateTime();
            marketDateAndHours = marketHoursGenerator.generateMarketHours(marketDate);
        } else {

            // marketDateInMarketEventSchedule =
            // marketDateInMarketEventSchedule.withMinuteOfHour(0);
            // marketDateInMarketEventSchedule =
            // marketDateInMarketEventSchedule.withSecondOfMinute(0);
            // DateTime tempDate =
            // marketDateInMarketEventSchedule.withZone(DateTimeZone.forTimeZone(TimeZone.getTimeZone("GMT")));
            marketDateAndHours.add(marketDateInMarketEventSchedule);
        }

        return marketDateAndHours;
    }

    /**
     * 
     * @param mrktEvntDef
     * @param marketDateInMarketEventSchedule
     * @return
     */

    /*
     * private List<MrktEvntSchd> processMarketDateOffsetStartType(MrktEvntDef
     * mrktEvntDef, DateTime marketDateInMarketEventSchedule) {
     * 
     * DateTime marketDate = marketDateInMarketEventSchedule.toDateTime();
     * 
     * DateTime fireEventTempDateTime = setMarketEventOffSetTime(mrktEvntDef,
     * marketDateInMarketEventSchedule); fireEventTempDateTime =
     * setEventStartTime(mrktEvntDef, fireEventTempDateTime); List<MrktEvntSchd>
     * list = applyRepeatInterval(mrktEvntDef, marketDate,
     * fireEventTempDateTime);
     * 
     * return list; }
     */

    /**
     * 
     * @param mrktEvntDef
     * @param fireEventTempDateTime
     * @return
     */

    private List<DateTime> applyRepeatInterval(MrktEvntDef mrktEvntDef, DateTime fireEventTempDateTime) {

        List<DateTime> eventFireDateTimes = new ArrayList<DateTime>();

        if (mrktEvntDef.getEvntRptIntrvl() != null && mrktEvntDef.getEvntRptIntrvl() > 0) {

            int repeatInterval = mrktEvntDef.getEvntRptIntrvl();
            String repeatIntervalUnit = mrktEvntDef.getEvntRptIntrvlUnit();
            int repeatOccrances = mrktEvntDef.getEvntRptIntrvlOccurance();

            if (repeatIntervalUnit.equals(RepeatIntervalUnit.EVERY_MINUTE.getName())) {

                for (int i = 0; i < repeatOccrances; i++) {
                    DateTime dateTimeAndMinutes = fireEventTempDateTime;
                    eventFireDateTimes.add(dateTimeAndMinutes);
                    fireEventTempDateTime = fireEventTempDateTime.plusMinutes(repeatInterval);
                }

            }

        } else {

            eventFireDateTimes.add(fireEventTempDateTime);

        }

        return eventFireDateTimes;
    }

    /**
     * 
     * @param mrktEvntDef
     * @param marketDate
     * @param dateTime
     * @return
     */
    /*
     * private List<MrktEvntSchd> applyRepeatInterval(MrktEvntDef mrktEvntDef,
     * DateTime marketDate, DateTime dateTime) {
     * 
     * List<MrktEvntSchd> list = new ArrayList<MrktEvntSchd>();
     * 
     * if (mrktEvntDef.getEvntRptIntrvl() != null &&
     * mrktEvntDef.getEvntRptIntrvl() > 0) {
     * 
     * int repeatInterval = mrktEvntDef.getEvntRptIntrvl(); String
     * repeatIntervalUnit = mrktEvntDef.getEvntRptIntrvlUnit(); int
     * repeatOccrances = mrktEvntDef.getEvntRptIntrvlOccurance();
     * 
     * if (repeatIntervalUnit.equals(RepeatIntervalUnit.EVERY_MINUTE.getName()))
     * {
     * 
     * for (int i = 0; i < repeatOccrances; i++) { DateTime dateTimeAndMinutes =
     * dateTime;
     * 
     * MrktEvntSchd mrktEvntSchd = new MrktEvntSchd();
     * mrktEvntSchd.setMrktDate(marketDate);
     * mrktEvntSchd.setMrktEvntActivationStatus("DISABLED");
     * 
     * MrktDefinition mrktDefinition = new MrktDefinition();
     * mrktDefinition.setMrktDefinitionId
     * (mrktEvntDef.getAssocMrktDefinitionId());
     * mrktEvntSchd.setMrktDefinitionId(mrktDefinition);
     * 
     * mrktEvntSchd.setMrktEvntDef(mrktEvntDef);
     * mrktEvntSchd.setCreatedBy("MDS"); mrktEvntSchd.setCreatedDt(new Date());
     * mrktEvntSchd.setUpdatedBy("MDS"); mrktEvntSchd.setUpdatedDt(new Date());
     * mrktEvntSchd.setMrktEvntFireDate(dateTimeAndMinutes);
     * mrktEvntSchd.setMrktEvntPubState
     * (MarketPublishStateType.SCHEDULED.getName());
     * 
     * list.add(mrktEvntSchd); dateTime = dateTime.plusMinutes(repeatInterval);
     * }
     * 
     * }
     * 
     * } else {
     * 
     * MrktEvntSchd mrktEvntSchd = new MrktEvntSchd();
     * mrktEvntSchd.setMrktDate(marketDate);
     * mrktEvntSchd.setMrktEvntActivationStatus("DISABLED");
     * 
     * MrktDefinition mrktDefinition = new MrktDefinition();
     * mrktDefinition.setMrktDefinitionId
     * (mrktEvntDef.getAssocMrktDefinitionId());
     * mrktEvntSchd.setMrktDefinitionId(mrktDefinition);
     * 
     * mrktEvntSchd.setMrktEvntDef(mrktEvntDef);
     * mrktEvntSchd.setCreatedBy("MDS"); mrktEvntSchd.setCreatedDt(new Date());
     * mrktEvntSchd.setUpdatedBy("MDS"); mrktEvntSchd.setUpdatedDt(new Date());
     * mrktEvntSchd.setMrktEvntFireDate(dateTime);
     * mrktEvntSchd.setMrktEvntPubState
     * (MarketPublishStateType.SCHEDULED.getName()); list.add(mrktEvntSchd);
     * 
     * }
     * 
     * return list; }
     */

    /**
     * 
     * @param mrktEvntDef
     * @param marketDateInMarketEventSchedule
     * @return
     */

    private DateTime setEventStartTime(MrktEvntDef mrktEvntDef, DateTime marketDateInMarketEventSchedule) {

        DateTime datetime = null;
        if (mrktEvntDef.getEvntStartTime() == null
                && EventTimeOffsetStartTimeEntityType.MARKET_DATE.getName().equals(mrktEvntDef.getEvntTimeOffsetStrtEntity())) {
            datetime = marketDateInMarketEventSchedule.withTimeAtStartOfDay();
        } else if (mrktEvntDef.getEvntStartTime() == null
                && EventTimeOffsetStartTimeEntityType.MARKET_HOUR.getName().equals(mrktEvntDef.getEvntTimeOffsetStrtEntity())) {
            datetime = marketDateInMarketEventSchedule;
        } else if (mrktEvntDef.getEvntStartTime() != null
                && (EventTimeOffsetStartTimeEntityType.MARKET_DATE.getName().equals(mrktEvntDef.getEvntTimeOffsetStrtEntity()) || EventTimeOffsetStartTimeEntityType.MARKET_HOUR
                        .getName().equals(mrktEvntDef.getEvntTimeOffsetStrtEntity()))) {

            String[] hhMM = mrktEvntDef.getEvntStartTime().split(":");
            datetime = marketDateInMarketEventSchedule.withTimeAtStartOfDay();
            datetime = datetime.withHourOfDay(Integer.parseInt(hhMM[0]));
            datetime = datetime.withMinuteOfHour(Integer.parseInt(hhMM[1]));

        }

        return datetime;
    }

    /**
     * 
     * @param mrktEvntDef
     * @param marketDateInMarketEventSchedule
     */
    private DateTime setMarketEventOffSetTime(MrktEvntDef mrktEvntDef, DateTime marketDateInMarketEventSchedule) {

        DateTime dateTime = null;

        if (EventTimeOffsetUnitType.MINS.getName().equals(mrktEvntDef.getEvntTimeOffsetUnit())) {

            dateTime = marketDateInMarketEventSchedule.plusMinutes(mrktEvntDef.getEvntTimeOffset());

        } else {

            dateTime = marketDateInMarketEventSchedule.plusDays(mrktEvntDef.getEvntTimeOffset());
        }

        return dateTime;
    }

    /**
     * 
     * @param mrktEvntDef
     * @param marketDateInMarketEventSchedule
     * @return
     */
    /*
     * private List<MrktEvntSchd> processMarketHours(MrktEvntDef mrktEvntDef,
     * DateTime marketDateInMarketEventSchedule) {
     * 
     * DateTime marketDate = marketDateInMarketEventSchedule.toDateTime();
     * List<DateTime> marketDateAndHours =
     * marketHoursGenerator.generateMarketHours(marketDate);
     * 
     * List<MrktEvntSchd> marketEventSchedules = new ArrayList<MrktEvntSchd>();
     * 
     * for (DateTime marketDateHours : marketDateAndHours) {
     * 
     * DateTime startingDateTime = setMarketEventOffSetTime(mrktEvntDef,
     * marketDateInMarketEventSchedule); startingDateTime =
     * setEventStartTime(mrktEvntDef, startingDateTime);
     * 
     * }
     * 
     * return null; }
     */

}

package com.caiso.mds.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class DateUtil {

    private final static Logger logger                      = LoggerFactory.getLogger(DateUtil.class);
    public static final String  PATTERN_MMddyyyy            = "MMddyyyy";
    public static final String  PATTERN_MM_dd_yyyy          = "MM/dd/yyyy";
    public static final String  PATTERN_yyyyMMdd            = "yyyyMMdd";
    public static final String  PATTERN_yyMMdd              = "yyMMdd";
    public static final String  PATTERN_yyyyMMdd_HH_mm_ss   = "yyyyMMdd HH:mm:ss";
    public static final String  PATTERN_yyyy_MM_dd_HH_mm_ss = "yyyy/MM/dd HH:mm:ss";

    /**
     * 
     * @param date
     * @param pattern
     * @return
     */
    public String convertDateToStringFormat(Date date, String pattern, TimeZone timeZone) {

        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        formatter.setTimeZone(timeZone);

        String dateStr = formatter.format(date);

        return dateStr;

    }

    /**
     * 
     * @param lastMarketDate
     * @return
     */
    public Calendar resetMarketDateToStartOf24CycleForThatDay(DateTime lastMarketDate) {
        Calendar marketDateCal = Calendar.getInstance();
        marketDateCal.setTimeZone(TimeZone.getTimeZone("US/Pacific"));
        marketDateCal.setTime(lastMarketDate.toDate());
        marketDateCal.set(Calendar.HOUR_OF_DAY, 0);
        marketDateCal.set(Calendar.MINUTE, 0);
        marketDateCal.set(Calendar.SECOND, 0);
        return marketDateCal;
    }

    /**
     * 
     * @return
     */
    public Calendar resetMarketDateToStartOf24HourCycle() {
        Calendar marketDateCal = Calendar.getInstance();
        marketDateCal.setTime(new Date());
        marketDateCal.setTimeZone(TimeZone.getTimeZone("US/Pacific"));
        marketDateCal.set(Calendar.HOUR_OF_DAY, 0);
        marketDateCal.set(Calendar.MINUTE, 0);
        marketDateCal.set(Calendar.SECOND, 0);
        return marketDateCal;
    }

    /**
     * 
     * @param dateString
     * @param pattern
     * @param timeZone
     * @return
     */
    public Date createDateFromString(String dateString, String pattern, TimeZone timeZone) {

        DateFormat formatter = new SimpleDateFormat(pattern);
        formatter.setTimeZone(timeZone);

        Date date = null;
        try {
            date = formatter.parse(dateString);

        } catch (ParseException e) {
            logger.error(" Error While Parsing the date provided in String :" + dateString + " Pattern Provided :" + pattern, e);
        }
        return date;

    }

    /**
     * 
     * @param localDateAndTime
     * @return
     */
    public boolean isDateIsShortDay(Date localDateAndTime) {

        boolean isShortDayFlag = false;
        Calendar cal = Calendar.getInstance();
        cal.setTime(localDateAndTime);
        int monthOfYear = cal.get(Calendar.MONTH); // 0 is Jan 2 is for march
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); // first day is 1
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (monthOfYear == 2 && dayOfWeek == Calendar.SUNDAY && dayOfMonth > 7 && dayOfMonth <= 14) {
            isShortDayFlag = true;
        }

        return isShortDayFlag;
    }

    /**
     * 
     * @param localDateAndTime
     * @return
     */
    public boolean isDateIsLongDay(Date localDateAndTime) {

        boolean isLongDayFlag = false;
        Calendar cal = Calendar.getInstance();
        cal.clear();
        cal.setTime(localDateAndTime);
        int monthOfYear = cal.get(Calendar.MONTH); // 0 is Jan 2 is for march
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH); // first day is 1
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        if (monthOfYear == 10 && dayOfWeek == Calendar.SUNDAY && dayOfMonth <= 7) {
            isLongDayFlag = true;
        }

        return isLongDayFlag;
    }

    /**
     * 
     * @param marketDate
     * @return
     */
    public DateTime getStartOfDayDateTimeInUTC1ForPSTDateTime(Date marketDate) {

        DateTime dateTime = new DateTime(marketDate);
        dateTime.withTimeAtStartOfDay(); // start of the PST
        dateTime = dateTime.withZone(DateTimeZone.UTC);

        return dateTime;

    }

    /**
     * 
     * @param marketDate
     * @return
     */

    public DateTime getEndOfDayDateTimeInUTC1ForPSTDateTime(Date marketDate) {

        DateTime dateTime = new DateTime(marketDate);
        dateTime = dateTime.plusHours(24); // start of the PST
        dateTime = dateTime.withZone(DateTimeZone.UTC);
        return dateTime;

    }

    /**
     * 
     * @param date
     * @return
     */
    public XMLGregorianCalendar getGeorgianDate(Date date) {

        if (date != null) {
            GregorianCalendar gregorianCalendar = new GregorianCalendar();
            gregorianCalendar.setTime(date);

            XMLGregorianCalendar xmlGrogerianCalendar = null;
            try {
                xmlGrogerianCalendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
                return xmlGrogerianCalendar;
            } catch (DatatypeConfigurationException e) {
                logger.error("Data Type Configuration Issue while converting Java Date to XMLGregorianCalendar", e);
            }

        } else {
            return null;
        }
        return null;

    }

    /**
     * 
     * @param xmlDate
     * @return
     */

    public Date getUtilDateFromXmlGeorgianDate(XMLGregorianCalendar xmlDate) {
        Date date = null;
        if (xmlDate != null) {

            date = xmlDate.toGregorianCalendar().getTime();
        }
        return date;

    }

    public Date addHoursToNow(int i) {

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.HOUR_OF_DAY, i);

        return cal.getTime();
    }
}

package com.caiso.mds.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.soap.AttachmentPart;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.Source;

import org.apache.camel.Exchange;
import org.apache.camel.StringSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.soa._2006_09_30.caisowsheader.CAISOMessageInfoType;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOUsernameTokenType;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOWSHeaderType;
import com.caiso.soa._2006_09_30.caisowsheader.TimestampType;
import com.caiso.soa.common.util.Base64;
import com.caiso.soa.common.util.JAVAUtil;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@Component
public class SoapHelper {

    private final Logger                              logger       = LoggerFactory.getLogger(SoapHelper.class);

    public static final String                        SOAP_FOOTER  = "</SOAP-ENV:Body> </SOAP-ENV:Envelope>";

    public static final String                        SOAP_HEADER  = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Body>";

    // jaxb context so we don't have to do lookup.
    private static ConcurrentMap<String, JAXBContext> jaxbContexts = new ConcurrentHashMap<>();

    @Autowired
    private DateUtil                                  dateUtil;

    /**
     * 
     * @param exchange
     * @return
     * @throws SOAPException
     */
    public String validateSoapAction(Exchange exchange) throws SOAPException {

        String soapAction = (String) exchange.getIn().getHeader("soapaction");

        if (soapAction == null || soapAction.length() == 0) {
            throw new SOAPException("SOAPAction not found in SOAPMessage.");
        } else {
            soapAction = soapAction.replaceAll("\"", "");
        }
        return soapAction;
    }

    /**
     * 
     * @param exchange
     * @return
     * @throws SOAPException
     * @throws IOException
     */

    public SOAPMessage getSoapMessage(Exchange exchange) throws SOAPException, IOException {
        InputStream is = exchange.getIn().getBody(InputStream.class);
        MessageFactory msgFactory = MessageFactory.newInstance();
        MimeHeaders mimeHdrs = new MimeHeaders();
        mimeHdrs = getMimeHeaders(exchange);
        SOAPMessage payload = msgFactory.createMessage(mimeHdrs, is);
        return payload;
    }

    /**
     * 
     * @param outputDataType
     * @return
     * @throws JAXBException
     */
    public StringBuilder getOutputDataType(OutputDataType outputDataType) throws JAXBException {
        StringBuilder soapResponse = new StringBuilder();
        soapResponse.append(SOAP_HEADER).append(convertOutputDataTypeToXmlString(outputDataType)).append(SOAP_FOOTER);
        logger.info("SOAP RESPONSE : " + soapResponse);
        return soapResponse;
    }

    /**
     * 
     * @param source
     * @return
     * @throws JAXBException
     */
    public String convertOutputDataTypeToXmlString(Object source) throws JAXBException {
        StringWriter stringWriter = new StringWriter();
        JAXBContext jaxbContext = JAXBContext.newInstance(OutputDataType.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        // format the XML output
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        QName qName = new QName("http://www.caiso.com/soa/2006-06-13/StandardOutput.xsd", "OutputDataType");
        JAXBElement<OutputDataType> root = new JAXBElement<OutputDataType>(qName, OutputDataType.class, (OutputDataType) source);
        jaxbMarshaller.marshal(root, stringWriter);
        String result = stringWriter.toString();
        if (result != null && result.length() > 0) {
            result = result.substring(result.indexOf("?>") + 2);
        }

        return result;
    }

    /**
     * 
     * @param message
     * @return
     * @throws SOAPException
     */

    @SuppressWarnings("unchecked")
    public String getContentFromAttachment(SOAPMessage message) throws SOAPException {
        Iterator<AttachmentPart> attachments = message.getAttachments();

        String result = null;
        try {
            /* Assume there is only one attachment */
            if (attachments.hasNext()) {
                AttachmentPart attachment = attachments.next();
                InputStream content = (InputStream) attachment.getContent();
                String compressedStream = new String(JAVAUtil.readBytes(content));
                result = JAVAUtil.decompressBase64XML(compressedStream);
            }

        } catch (IOException e) {
            logger.error("Error while reading the Attachment from the Soap Message Object", e);
            throw new SOAPException(e);
        }

        return result;
    }

    /**
     * 
     * @param exchange
     * @return
     */

    public MimeHeaders getMimeHeaders(Exchange exchange) {

        MimeHeaders mimeHdrs = new MimeHeaders();
        mimeHdrs.addHeader("Content-Type", (String) exchange.getIn().getHeader("Content-Type"));
        mimeHdrs.addHeader("content-length", (String) exchange.getIn().getHeader("content-length"));
        mimeHdrs.addHeader("accept-encoding", (String) exchange.getIn().getHeader("accept-encoding"));
        mimeHdrs.addHeader("soapaction", (String) exchange.getIn().getHeader("soapaction"));
        return mimeHdrs;

    }

    /**
     * 
     * @param uuid
     * @return
     */
    public String getNonceValue(String uuid) {

        String nonce = Base64.encodeBytes(uuid.getBytes());
        return nonce;
    }

    /**
     * 
     * @param soapActionValue
     * @return
     */
    public String getServiceName(String soapActionValue) {

        // http://www.caiso.com/soa/receiveRTCleanBidCaiso_v4.wsdl
        String serviceName = null;

        if (soapActionValue != null) {
            String[] actionParts = soapActionValue.split("/");
            logger.debug("SoapAction " + actionParts[actionParts.length - 1]);
            serviceName = actionParts[actionParts.length - 1];

        }

        return serviceName;
    }

    /**
     * Helper method that marshall data into xml stream.
     * 
     * @param data
     * @return
     * @throws JAXBException
     */
    public ByteArrayOutputStream marshal(Object data) throws JAXBException {
        return marshal(data, false);
    }

    /**
     * 
     * @param data
     * @param ignoreDeclaration
     * @return
     * @throws JAXBException
     */

    public ByteArrayOutputStream marshal(Object data, boolean ignoreDeclaration) throws JAXBException {
        // normally we don't have to replace the ".impl" with empty string but
        // we need this here to
        // handle the weird way the service jar generated the xml elements.
        if (data == null) {
            return new ByteArrayOutputStream(0);
        }
        String packageName = data.getClass().getPackage().getName().replace(".impl", "");
        // jaxb context is expensive to construct so we are caching
        // it for the duration of the application life cycle.

        JAXBContext jaxbContext = jaxbContexts.get(packageName);

        if (jaxbContext == null) {
            jaxbContext = JAXBContext.newInstance(packageName);
            jaxbContexts.put(packageName, jaxbContext);
        }
        Marshaller marshaller = jaxbContext.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        if (ignoreDeclaration) {
            if (marshaller.getClass().getCanonicalName().contains("v2")) {
                marshaller.setProperty("jaxb.fragment", Boolean.TRUE);
            } else {
                marshaller.setProperty("com.sun.xml.bind.xmlDeclaration", Boolean.FALSE);
            }

        }
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        marshaller.marshal(data, os);
        return os;
    }

    /**
     * 
     * @param data
     * @return
     * @throws JAXBException
     */

    public Marshaller getMarshaller(Object data) throws JAXBException {
        String packageName = data.getClass().getPackage().getName().replace(".impl", "");
        // jaxb context is expensive to construct so we are caching
        // it for the duration of the application life cycle.

        JAXBContext jaxbContext = jaxbContexts.get(packageName);

        if (jaxbContext == null) {
            jaxbContext = JAXBContext.newInstance(packageName);
            jaxbContexts.put(packageName, jaxbContext);
        }
        return jaxbContext.createMarshaller();

    }

    /**
     * 
     * @param packageName
     * @param source
     * @return
     * @throws JAXBException
     */

    public Object unmarshal(String packageName, Source source) throws JAXBException {
        JAXBContext jaxbContext = jaxbContexts.get(packageName);
        if (jaxbContext == null) {
            jaxbContext = JAXBContext.newInstance(packageName);
            jaxbContexts.put(packageName, jaxbContext);
        }
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        Object object = unmarshaller.unmarshal(source);
        if (object instanceof JAXBElement) {
            object = ((JAXBElement<?>) object).getValue();
        }
        return object;
    }

    /**
     * 
     * @param packageName
     * @param xml
     * @return
     * @throws JAXBException
     */
    public Object unmarshal(String packageName, String xml) throws JAXBException {
        JAXBContext jaxbContext = jaxbContexts.get(packageName);
        if (jaxbContext == null) {
            jaxbContext = JAXBContext.newInstance(packageName);
            jaxbContexts.put(packageName, jaxbContext);
        }
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        Object object = unmarshaller.unmarshal(new StringSource(xml));
        if (object instanceof JAXBElement) {
            object = ((JAXBElement<?>) object).getValue();
        }
        return object;
    }

    /**
     * 
     * @param userName
     * @param nonce
     * @param messageId
     * @return
     */

    public CAISOWSHeaderType createCaisoWsHeaderTypeObject(String userName, String nonce, String messageId) {

        com.caiso.soa._2006_09_30.caisowsheader.ObjectFactory objFactory = new com.caiso.soa._2006_09_30.caisowsheader.ObjectFactory();

        logger.info("objFactory== " + objFactory);

        CAISOWSHeaderType header = objFactory.createCAISOWSHeaderType();

        CAISOUsernameTokenType tokenType = objFactory.createCAISOUsernameTokenType();
        logger.info("fsdf  token" + tokenType);

        dateUtil = new DateUtil();
        tokenType.setCreated(dateUtil.getGeorgianDate(new Date()));
        tokenType.setNonce(getNonceValue(nonce));
        tokenType.setUsername(userName);

        CAISOMessageInfoType messageInfoType = new CAISOMessageInfoType();
        messageInfoType.setMessageID(messageId);

        TimestampType t = objFactory.createTimestampType();
        t.setCreated(dateUtil.getGeorgianDate(new Date()));
        t.setExpires(dateUtil.getGeorgianDate(dateUtil.addHoursToNow(2)));

        messageInfoType.setTimestamp(t);

        header.setCAISOUsernameToken(tokenType);
        header.setCAISOMessageInfo(messageInfoType);

        return header;
    }

    /**
     * 
     * @param soapHeader
     * @param CAISOWSHeader
     * @throws SOAPException
     */
    public void createSoapHeaderForCaisoWsHeaderType(SOAPHeader soapHeader, CAISOWSHeaderType CAISOWSHeader) throws SOAPException {
        QName qNameCaisoHeader = new QName("http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd", "CAISOWSHeader");
        SOAPHeaderElement caisoHeaderElement = soapHeader.addHeaderElement(qNameCaisoHeader);

        QName qNameCAISOUsernameToken = new QName("http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd", "CAISOUsernameToken");
        SOAPHeaderElement caisoUsernameTokenElement = soapHeader.addHeaderElement(qNameCAISOUsernameToken);
        caisoUsernameTokenElement.setAttribute("xmlns", "http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd");

        QName qNameUsername = new QName("http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd", "Username");
        SOAPHeaderElement usernameElement = soapHeader.addHeaderElement(qNameUsername);
        usernameElement.addTextNode(CAISOWSHeader.getCAISOUsernameToken().getUsername());
        usernameElement.setAttribute("xmlns", "http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd");

        QName qNameNonce = new QName("http://schemas.xmlsoap.org/ws/2002/07/secext", "Nonce");
        SOAPHeaderElement nonceElement = soapHeader.addHeaderElement(qNameNonce);
        nonceElement.addTextNode(CAISOWSHeader.getCAISOUsernameToken().getNonce());

        QName qNameCreated = new QName("http://schemas.xmlsoap.org/ws/2002/07/utility", "Created");
        SOAPHeaderElement createdElement = soapHeader.addHeaderElement(qNameCreated);
        createdElement.addTextNode(CAISOWSHeader.getCAISOUsernameToken().getCreated().toString());
        // nonceElement.setEncodingStyle("http://docs.oasisopen.org/wss/2004/01/oasis-200401wss-soap-message-security-1.0#Base64Binary");
        nonceElement.setAttribute("EncodingType", "http://docs.oasisopen.org/wss/2004/01/oasis-200401wss-soap-message-security-1.0#Base64Binary");

        caisoUsernameTokenElement.addChildElement(usernameElement);
        caisoUsernameTokenElement.addChildElement(nonceElement);
        caisoUsernameTokenElement.addChildElement(createdElement);

        QName qNameCAISOMessageInfo = new QName("http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd", "CAISOMessageInfo");
        SOAPHeaderElement caisoMessageInfoElement = soapHeader.addHeaderElement(qNameCAISOMessageInfo);
        caisoMessageInfoElement.setAttribute("xmlns", "http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd");

        QName qNameMessageID = new QName("http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd", "MessageID");
        SOAPHeaderElement messageIDElement = soapHeader.addHeaderElement(qNameMessageID);
        messageIDElement.addTextNode(CAISOWSHeader.getCAISOMessageInfo().getMessageID());
        messageIDElement.setAttribute("xmlns", "http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd");

        QName qNameTimestamp = new QName("http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd", "Timestamp");
        SOAPHeaderElement timestampElement = soapHeader.addHeaderElement(qNameTimestamp);
        timestampElement.setAttribute("xmlns", "http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd");

        QName qNameCreated2 = new QName("http://schemas.xmlsoap.org/ws/2002/07/utility", "Created");
        SOAPHeaderElement created2Element = soapHeader.addHeaderElement(qNameCreated2);
        created2Element.addTextNode(CAISOWSHeader.getCAISOMessageInfo().getTimestamp().getCreated().toString());

        QName qNameExpires = new QName("http://schemas.xmlsoap.org/ws/2002/07/utility", "Expires");
        SOAPHeaderElement expiresElement = soapHeader.addHeaderElement(qNameExpires);
        expiresElement.addTextNode(CAISOWSHeader.getCAISOMessageInfo().getTimestamp().getExpires().toString());

        timestampElement.addChildElement(created2Element);
        timestampElement.addChildElement(expiresElement);

        caisoMessageInfoElement.addChildElement(messageIDElement);
        caisoMessageInfoElement.addChildElement(timestampElement);

        caisoHeaderElement.addChildElement(caisoUsernameTokenElement);
        caisoHeaderElement.addChildElement(caisoMessageInfoElement);

        caisoHeaderElement.setActor("");
        caisoHeaderElement.setMustUnderstand(false);
    }

    /**
     * 
     * @param date
     * @return
     * @throws DatatypeConfigurationException
     */
    public XMLGregorianCalendar convert(Date date) throws DatatypeConfigurationException {
        GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.setTime(date);
        return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
    }

    /**
     * 
     * @param date
     * @return
     * @throws DatatypeConfigurationException
     */

    public XMLGregorianCalendar convert(Calendar date) throws DatatypeConfigurationException {
        GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.setTime(date.getTime());
        return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
    }

    /**
     * 
     * @return
     * @throws DatatypeConfigurationException
     */

    public XMLGregorianCalendar currentTime() throws DatatypeConfigurationException {
        GregorianCalendar cal = new GregorianCalendar(TimeZone.getTimeZone("GMT"));
        cal.setTime(new Date());
        return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
    }
}

package com.caiso.mds.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketDefintionDto;
import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.types.MarketStatusType;
import com.caiso.mds.types.MarketType;

@Component
public class MarketPlanGenerator {

    private final static Logger logger = LoggerFactory.getLogger(MarketPlanGenerator.class);

    @Autowired
    private MarketPlanIdBuilder marketPlanIdBuilder;

    @Autowired
    private MarketRunIdBuilder  marketRunIdBuilder;

    @Autowired
    private DateUtil            dateUtil;

    /**
     * 
     * @param marketDate
     * @param marketType
     * @param marketDefinitionsForMarketType
     * @return
     */

    public List<MarketPlanDto> getMarketPlans(Date marketDate, MarketType marketType, List<MarketDefintionDto> marketDefinitionsForMarketType) {

        List<MarketPlanDto> marketPlans = null;

        //

        switch (marketType) {
        case DAM:
            marketPlans = getDamMarketPlans(marketDate, marketType, marketDefinitionsForMarketType);
            break;
        case RTM:
            marketPlans = getRtmMarketPlans(marketDate, marketType, marketDefinitionsForMarketType);
            break;
        default:
            break;
        }

        return marketPlans;
    }

    /**
     * 
     * @param marketDate
     * @return
     */

    private List<MarketPlanDto> getRtmMarketPlans(Date marketDate, MarketType marketType, List<MarketDefintionDto> marketDefinitionsForMarketType) {

        List<MarketPlanDto> marketPlans = new ArrayList<MarketPlanDto>();

        if (dateUtil.isDateIsLongDay(marketDate)) {
            marketPlans = generateForLongDay(marketDate, marketType, marketDefinitionsForMarketType);
        } else if (dateUtil.isDateIsShortDay(marketDate)) {
            marketPlans = generateForShortDay(marketDate, marketType, marketDefinitionsForMarketType);
        } else {
            marketPlans = generateForNormalDay(marketDate, marketType, marketDefinitionsForMarketType);
        }

        return marketPlans;

    }

    /**
     * 
     * @param marketDate
     * @param marketType
     * @param marketDefinitionsForMarketType
     * @return
     */
    private List<MarketPlanDto> generateForNormalDay(Date marketDate, MarketType marketType, List<MarketDefintionDto> marketDefinitionsForMarketType) {

        List<MarketPlanDto> marketPlans = new ArrayList<MarketPlanDto>();

        for (MarketDefintionDto marketDefintionDto : marketDefinitionsForMarketType) {

            Calendar marketDateCalender = Calendar.getInstance();
            marketDateCalender.setTimeZone(TimeZone.getTimeZone("UTC"));
            marketDateCalender.setTime(marketDate);
            // start 8th hour as USA is 8 on normal days
            // marketDateCalender.set(Calendar.HOUR_OF_DAY, 8);
            marketDateCalender.set(Calendar.MINUTE, 0);
            marketDateCalender.set(Calendar.SECOND, 0);

            logger.debug(" ## CAL UTC " + marketDateCalender.getTime());

            SimpleDateFormat sb = new SimpleDateFormat();
            sb.setTimeZone(TimeZone.getTimeZone("UTC"));

            logger.debug("Simple Date formater =" + sb.format(marketDateCalender.getTime()));

            String marketDateString = dateUtil.convertDateToStringFormat(marketDateCalender.getTime(), DateUtil.PATTERN_yyMMdd, TimeZone.getTimeZone("UTC"));

            logger.debug(" Market Data String " + marketDateString);

            for (int i = 1; i < 25; i++) {

                String marketPlanId = marketPlanIdBuilder.setMarketDateStr(marketDateString)
                        .setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00)).setMarketTypeId(marketType.getId())
                        .buildWithoutMarketTypeId();

                /*
                 * String marketRunId =
                 * marketRunIdBuilder.setMarketDateStr(marketDateString)
                 * .setMarketDefId(marketDefintionDto.getMarketDefinitionId())
                 * .setMarketHour(NumberUtil.convertNumberToFormatedString(i,
                 * NumberUtil.marketHourPattern_00))
                 * .setMarketTypeId(marketType.getId()).buildWithActivityId();
                 */

                String marketRunId = marketRunIdBuilder.setMarketActivityId(marketDefintionDto.getMarketActivityId() + "").setMarketDateStr(marketDateString)
                        .setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00)).buildWithActivityId();

                MarketPlanDto marketPlanDto = new MarketPlanDto();
                marketPlanDto.setMarketPlanId(marketPlanId);
                marketPlanDto.setMarketRunId(marketRunId);
                marketPlanDto.setMarketDefinitionId(marketDefintionDto.getMarketDefinitionId());

                marketPlanDto.setMarketDate(marketDateCalender.getTime());

                marketPlanDto.setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00));
                marketPlanDto.setMarketStatusTypeId(MarketStatusType.NEW.getMarketStatusTypeId());
                // TODO ask Arul about it
                marketPlanDto.setRecordStatus("AUDIT");
                marketPlans.add(marketPlanDto);
                marketDateCalender.add(Calendar.HOUR_OF_DAY, 1);

            }

        }
        return marketPlans;
    }

    /**
     * 
     * @param marketDate
     * @param marketType
     * @param marketDefinitionsForMarketType
     * @return
     */

    private List<MarketPlanDto> generateForShortDay(Date marketDate, MarketType marketType, List<MarketDefintionDto> marketDefinitionsForMarketType) {
        List<MarketPlanDto> marketPlans = new ArrayList<MarketPlanDto>();

        for (MarketDefintionDto marketDefintionDto : marketDefinitionsForMarketType) {

            Calendar marketDateCalender = Calendar.getInstance();
            marketDateCalender.setTimeZone(TimeZone.getTimeZone("UTC"));
            marketDateCalender.setTime(marketDate);
            marketDateCalender.set(Calendar.HOUR_OF_DAY, 8); // start 8th hour
                                                             // as USA is 8
                                                             // on normal
                                                             // days
            marketDateCalender.set(Calendar.MINUTE, 0);
            marketDateCalender.set(Calendar.SECOND, 0);

            logger.debug(" ## CAL UTC " + marketDateCalender.getTime());

            SimpleDateFormat sb = new SimpleDateFormat();
            sb.setTimeZone(TimeZone.getTimeZone("UTC"));

            logger.debug("Simeple Date formater =" + sb.format(marketDateCalender.getTime()));

            String marketDateString = dateUtil.convertDateToStringFormat(marketDateCalender.getTime(), DateUtil.PATTERN_yyMMdd, TimeZone.getTimeZone("UTC"));

            logger.debug(" Market Data String " + marketDateString);
            // 23 hours in USA on that day
            for (int i = 1; i < 24; i++) {

                String marketPlanId = marketPlanIdBuilder.setMarketDateStr(marketDateString)
                        .setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00)).setMarketTypeId(marketType.getId())
                        .buildWithoutMarketTypeId();

                String marketRunId = marketRunIdBuilder.setMarketDateStr(marketDateString).setMarketActivityId(marketDefintionDto.getMarketActivityId() + "")
                        .setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00)).buildWithActivityId();

                MarketPlanDto marketPlanDto = new MarketPlanDto();
                marketPlanDto.setMarketPlanId(marketPlanId);
                marketPlanDto.setMarketRunId(marketRunId);
                marketPlanDto.setMarketDefinitionId(marketDefintionDto.getMarketDefinitionId());

                marketPlanDto.setMarketDate(marketDateCalender.getTime());

                marketPlanDto.setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00));
                marketPlanDto.setMarketStatusTypeId(MarketStatusType.NEW.getMarketStatusTypeId());
                // TODO ask Arul about it
                marketPlanDto.setRecordStatus("AUDIT");
                marketPlans.add(marketPlanDto);
                marketDateCalender.add(Calendar.HOUR_OF_DAY, 1);
                logger.debug(marketDateCalender.getTime().toString());

            }

        }
        return marketPlans;
    }

    /**
     * 
     * @param marketDate
     * @param marketType
     * @param marketDefinitionsForMarketType
     * @return
     */
    private List<MarketPlanDto> generateForLongDay(Date marketDate, MarketType marketType, List<MarketDefintionDto> marketDefinitionsForMarketType) {
        List<MarketPlanDto> marketPlans = new ArrayList<MarketPlanDto>();

        for (MarketDefintionDto marketDefintionDto : marketDefinitionsForMarketType) {

            Calendar marketDateCalender = Calendar.getInstance();
            marketDateCalender.clear();
            marketDateCalender.setTimeZone(TimeZone.getTimeZone("UTC"));
            marketDateCalender.setTime(marketDate);
            // start 7th hour as normal days
            marketDateCalender.set(Calendar.HOUR_OF_DAY, 7);
            marketDateCalender.set(Calendar.MINUTE, 0);
            marketDateCalender.set(Calendar.SECOND, 0);

            logger.debug(" ## CAL UTC " + marketDateCalender.getTime());

            SimpleDateFormat sb = new SimpleDateFormat();
            sb.setTimeZone(TimeZone.getTimeZone("UTC"));

            logger.debug("Simeple Date formater =" + sb.format(marketDateCalender.getTime()));

            String marketDateString = dateUtil.convertDateToStringFormat(marketDateCalender.getTime(), DateUtil.PATTERN_yyMMdd, TimeZone.getTimeZone("UTC"));

            logger.debug(" Market Data String " + marketDateString);
            // 25 hours in USA on that day
            for (int i = 1; i < 26; ++i) {

                String marketPlanId = marketPlanIdBuilder.setMarketDateStr(marketDateString)
                        .setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00)).setMarketTypeId(marketType.getId())
                        .buildWithoutMarketTypeId();

                /*
                 * String marketRunId =
                 * marketRunIdBuilder.setMarketDateStr(marketDateString)
                 * .setMarketDefId(marketDefintionDto.getMarketDefinitionId())
                 * .setMarketHour(NumberUtil.convertNumberToFormatedString(i,
                 * NumberUtil.marketHourPattern_00))
                 * .setMarketTypeId(marketType.getId()).buildWithMarketDefId();
                 */
                String marketRunId = marketRunIdBuilder.setMarketActivityId(marketDefintionDto.getMarketActivityId() + "").setMarketDateStr(marketDateString)
                        .setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00)).buildWithActivityId();

                MarketPlanDto marketPlanDto = new MarketPlanDto();
                marketPlanDto.setMarketPlanId(marketPlanId);
                marketPlanDto.setMarketRunId(marketRunId);
                marketPlanDto.setMarketDefinitionId(marketDefintionDto.getMarketDefinitionId());

                marketPlanDto.setMarketDate(marketDateCalender.getTime());

                marketPlanDto.setMarketHour(NumberUtil.convertNumberToFormatedString(i, NumberUtil.marketHourPattern_00));
                marketPlanDto.setMarketStatusTypeId(MarketStatusType.NEW.getMarketStatusTypeId());
                // TODO ask Arul about it
                marketPlanDto.setRecordStatus("AUDIT");
                marketPlans.add(marketPlanDto);
                marketDateCalender.add(Calendar.HOUR_OF_DAY, 1);

            }

        }
        return marketPlans;
    }

    /**
     * 
     * @param marketDateInUSPacificTimeZone
     * @return
     */
    private List<MarketPlanDto> getDamMarketPlans(Date marketDateInUSPacificTimeZone, MarketType marketType,
            List<MarketDefintionDto> marketDefinitionsForMarketType) {

        List<MarketPlanDto> marketPlans = new ArrayList<MarketPlanDto>();

        DateTime marketDateInUTC = new DateTime(marketDateInUSPacificTimeZone, DateTimeZone.UTC);

        logger.debug(" Dam Market Plans market Date in UTC   " + marketDateInUTC.toString());

        String marketDateString = dateUtil.convertDateToStringFormat(marketDateInUTC.toDate(), DateUtil.PATTERN_yyMMdd, TimeZone.getTimeZone("UTC"));

        String marketPlanId = marketPlanIdBuilder.setMarketDateStr(marketDateString)
                .setMarketHour(NumberUtil.convertNumberToFormatedString(0, NumberUtil.marketHourPattern_00)).setMarketTypeId(marketType.getId())
                .buildWithoutMarketTypeId();

        for (MarketDefintionDto marketDefintionDto : marketDefinitionsForMarketType) {

            /*
             * String marketRunId =
             * marketRunIdBuilder.setMarketDateStr(marketDateString)
             * .setMarketDefId(marketDefintionDto.getMarketDefinitionId())
             * .setMarketHour(NumberUtil.convertNumberToFormatedString(0,
             * NumberUtil.marketHourPattern_00))
             * .setMarketTypeId(marketType.getId()).buildWithMarketDefId();
             */

            String marketRunId = marketRunIdBuilder.setMarketActivityId(marketDefintionDto.getMarketActivityId() + "").setMarketDateStr(marketDateString)
                    .setMarketHour(NumberUtil.convertNumberToFormatedString(0, NumberUtil.marketHourPattern_00)).buildWithActivityId();

            MarketPlanDto marketPlanDto = new MarketPlanDto();
            marketPlanDto.setMarketPlanId(marketPlanId);
            marketPlanDto.setMarketRunId(marketRunId);
            marketPlanDto.setMarketDefinitionId(marketDefintionDto.getMarketDefinitionId());
            marketPlanDto.setMarketDate(marketDateInUTC.toDate());
            marketPlanDto.setMarketHour(NumberUtil.convertNumberToFormatedString(0, NumberUtil.marketHourPattern_00));
            marketPlanDto.setMarketStatusTypeId(MarketStatusType.NEW.getMarketStatusTypeId());
            // TODO ask Arul about it
            marketPlanDto.setRecordStatus("AUDIT");
            marketPlans.add(marketPlanDto);
        }

        return marketPlans;

    }
}

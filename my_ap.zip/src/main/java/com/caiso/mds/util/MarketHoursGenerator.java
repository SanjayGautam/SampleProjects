package com.caiso.mds.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MarketHoursGenerator {

    @Autowired
    private DateUtil dateUtil;

    public List<DateTime> generateMarketHours(DateTime marketDate) {

        if (marketDate == null) {
            throw new IllegalArgumentException(" Market Date cannot be null");
        }

        List<DateTime> marketDateAndTimeHours = new ArrayList<DateTime>();

        if (dateUtil.isDateIsLongDay(marketDate.toDate())) {
            marketDateAndTimeHours = generateForLongDay(marketDate);
        } else if (dateUtil.isDateIsShortDay(marketDate.toDate())) {
            marketDateAndTimeHours = generateForShortDay(marketDate);
        } else {
            marketDateAndTimeHours = generateForNormalDay(marketDate);
        }

        return marketDateAndTimeHours;

    }

    /**
     * 
     * @param marketDate
     * @return
     */

    private List<DateTime> generateForNormalDay(DateTime marketDate) {
        List<DateTime> marketDateAndHours = new ArrayList<DateTime>();

        Calendar marketDateCalender = Calendar.getInstance();
        marketDateCalender.setTimeZone(TimeZone.getTimeZone("GMT"));
        marketDateCalender.setTime(marketDate.toDate());
        // start 8th hour as USA is 8 on normal days
        // marketDateCalender.set(Calendar.HOUR_OF_DAY, 8);
        marketDateCalender.set(Calendar.MINUTE, 0);
        marketDateCalender.set(Calendar.SECOND, 0);

        for (int i = 0; i < 24; i++) {
            marketDateAndHours.add(new DateTime(marketDateCalender.getTime()));
            marketDateCalender.add(Calendar.HOUR_OF_DAY, 1);
        }

        return marketDateAndHours;
    }

    /**
     * 
     * @param marketDate
     * @return
     */
    private List<DateTime> generateForShortDay(DateTime marketDate) {
        List<DateTime> marketDateAndHours = new ArrayList<DateTime>();

        Calendar marketDateCalender = Calendar.getInstance();
        marketDateCalender.setTimeZone(TimeZone.getTimeZone("GMT"));
        marketDateCalender.setTime(marketDate.toDate());
        marketDateCalender.set(Calendar.HOUR_OF_DAY, 8);
        marketDateCalender.set(Calendar.MINUTE, 0);
        marketDateCalender.set(Calendar.SECOND, 0);

        SimpleDateFormat sb = new SimpleDateFormat();
        sb.setTimeZone(TimeZone.getTimeZone("GMT"));
        // 23 hours in USA on that day
        for (int i = 0; i < 23; i++) {
            marketDateAndHours.add(new DateTime(marketDateCalender.getTime()));
            marketDateCalender.add(Calendar.HOUR_OF_DAY, 1);
        }

        return marketDateAndHours;
    }

    /**
     * 
     * @param marketDate
     * @return
     */
    private List<DateTime> generateForLongDay(DateTime marketDate) {

        List<DateTime> marketDateAndHours = new ArrayList<DateTime>();
        Calendar marketDateCalender = Calendar.getInstance();
        // very important to do so.
        marketDateCalender.clear();
        marketDateCalender.setTimeZone(TimeZone.getTimeZone("GMT"));
        marketDateCalender.setTime(marketDate.toDate());
        // start 7th hour as normal days
        marketDateCalender.set(Calendar.HOUR_OF_DAY, 7);
        marketDateCalender.set(Calendar.MINUTE, 0);
        marketDateCalender.set(Calendar.SECOND, 0);

        SimpleDateFormat sb = new SimpleDateFormat();
        sb.setTimeZone(TimeZone.getTimeZone("GMT"));

        // 25 hours in USA on that day
        for (int i = 0; i < 25; i++) {
            marketDateAndHours.add(new DateTime(marketDateCalender.getTime()));
            marketDateCalender.add(Calendar.HOUR_OF_DAY, 1);
        }

        return marketDateAndHours;
    }

}

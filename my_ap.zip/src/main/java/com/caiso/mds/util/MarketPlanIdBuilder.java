package com.caiso.mds.util;

import org.springframework.stereotype.Component;

@Component
public class MarketPlanIdBuilder {

    private int    marketTypeId;
    private String marketDateStr;
    private String marketHour;

    public int getMarketTypeId() {
        return marketTypeId;
    }

    public MarketPlanIdBuilder setMarketTypeId(int marketTypeId) {
        this.marketTypeId = marketTypeId;
        return this;
    }

    public MarketPlanIdBuilder setMarketDateStr(String marketDateStr) {
        this.marketDateStr = marketDateStr;
        return this;

    }

    public MarketPlanIdBuilder setMarketHour(String marketHour) {
        this.marketHour = marketHour;
        return this;
    }

    public String build() {

        StringBuilder marketPlanIdBuilder = new StringBuilder();
        marketPlanIdBuilder.append(marketTypeId); // Market Type ID
        marketPlanIdBuilder.append(marketDateStr); // date
        marketPlanIdBuilder.append(marketHour); // marketHours 00 for all the
                                                // market hours for the all
                                                // market def will be same
                                                // concatenation

        String marketPlanId = marketPlanIdBuilder.toString();
        return marketPlanId;

    }

    public String buildWithoutMarketTypeId() {

        StringBuilder marketPlanIdBuilder = new StringBuilder();
        marketPlanIdBuilder.append(marketDateStr); // date
        marketPlanIdBuilder.append(marketHour); // marketHours 00 for all the
                                                // market hours for the all
                                                // market def will be same
                                                // concatenation

        String marketPlanId = marketPlanIdBuilder.toString();
        return marketPlanId;

    }

}

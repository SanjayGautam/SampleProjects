package com.caiso.mds.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.caiso.mds.soa.parser.sax.SaxJaxbBindingUtil;
import com.caiso.mds.soa.parser.stax.StaxJaxbBindingUtil;

@Configuration
@PropertySource("classpath:mds-app-config.properties")
public class MdsBpmNexusConfig {

    public String mdsToMnsMulticastRoute = "mdsToMnsMulticastRoute";

    @Autowired
    Environment   env;

    @Bean(name = "mdsToMnsMulticastRoute")
    public String getMdsToMnsMulticastRoute() {
        return mdsToMnsMulticastRoute;
    }

    @Bean(name = "numberOfDaysToGenerateMarketPlans")
    public Integer getNumberOfDaysToGenerateMarketPlans() {
        return env.getRequiredProperty("number.of.days.market.plans.to.generate", Integer.class);
    }

    @Bean(name = "numberOfDaysMarketEventScheduleToBeCreated")
    public Integer getNumberOfDaysToGenerateMarketEvents() {
        return env.getRequiredProperty("number.of.days.market.events.schedule.to.be.created", Integer.class);
    }

    @Bean(name = "mdsPurgingNumberOfDaysInPast")
    public Integer getMdsPurgingNumberOfDaysInPast() {
        return env.getRequiredProperty("mds.tables.clean.up.days.in.past", Integer.class);
    }

    @Bean(name = "mdsToSibrBroadcastMarketStatusWsdlUrl")
    public String getMdsToSibrBroadcastMarketStatusWsdlUrl() {
        return env.getRequiredProperty("mds.to.sibr.broadcast.sibrMarketStatusService.wsdl.url", String.class);
    }

    @Bean(name = "mdsToSibrBoadcastMarketStatusServiceName")
    public String getMdsToSibrBoadcastMarketStatusServiceName() {
        return env.getRequiredProperty("mds.to.sibr.broadcast.sibrMarketStatusService.name", String.class);
    }

    @Bean(name = "mdsToMnsMarketNotificationMsgWsdlUrl")
    public String getMdsToMnsMarketNotificationMsgWsdlUrl() {
        return env.getRequiredProperty("mds.to.mns.broadcast.mnsMarketEventService.wsdl.url", String.class);
    }

    @Bean(name = "mdsToMnsMarketNotificationMsgServiceName")
    public String getMdsToMnsMarketNotificationMsgServiceName() {
        return env.getRequiredProperty("mds.to.mns.broadcast.mnsMarketEventService.name", String.class);
    }

    @Bean(name = "mdsToMnsBroadcastSwitchEnabled")
    public Boolean getMdsToMnsBroadcastSwitchEnable() {
        return env.getRequiredProperty("mds.to.mns.broadcast.switch.enable", Boolean.class);
    }

    @Bean(name = "mdsToSibrBroadcastSwitchEnabled")
    public Boolean getMdsToMnsBroadcastSwitchSibrEnabled() {
        return env.getRequiredProperty("mds.to.sibr.broadcast.switch.enable", Boolean.class);
    }

    @Bean(name = "mdsMonitorWebPaginationPageSize")
    public Integer getMdsMonitorWebPaginationPageSize() {
        return env.getRequiredProperty("mds.monitor.web.pagination.pageSize", Integer.class);
    }

    @Bean(name = "receiveDACleanBidCaiso_v4_JaxbContext")
    public String getReceiveDaCleanBidCaiso_v4() {
        return env.getRequiredProperty("receiveDACleanBidCaiso_v4.JaxbContext", String.class);
    }

    @Bean(name = "receiveRTCleanBidCaiso_v4_JaxbContext")
    public String getReceiveRTCleanBidCaiso_v4() {
        return env.getRequiredProperty("receiveRTCleanBidCaiso_v4.JaxbContext", String.class);
    }

    @Bean(name = "mdsOperatorAccess")
    public String getMdsOperatorAccess() {
        return env.getRequiredProperty("mds.operator.access", String.class);
    }

    @Bean(name = "mdsUserAccess")
    public String getMdsUserAccess() {
        return env.getRequiredProperty("mds.user.access", String.class);
    }

    @Bean(name = "receiveCleanBidCaisoDAV4JaxbBindingUtil")
    @Qualifier(value = "receiveCleanBidCaisoDAV4JaxbBindingUtil")
    public SaxJaxbBindingUtil<?> getReceiveDaCleanBidCaisoV4JaxbBindingUtil() throws IllegalStateException, Exception {
        return new SaxJaxbBindingUtil<Object>(env.getRequiredProperty("receiveDACleanBidCaiso_v4.JaxbContext", String.class));
    }

    @Bean(name = "receiveCleanBidCaisoRTV4JaxbBindingUtil")
    @Qualifier(value = "receiveCleanBidCaisoRTV4JaxbBindingUtil")
    public SaxJaxbBindingUtil<?> getReceiveRTCleanBidCaisoV4JaxbBindingUtil() throws IllegalStateException, Exception {
        return new SaxJaxbBindingUtil<Object>(env.getRequiredProperty("receiveRTCleanBidCaiso_v4.JaxbContext", String.class));
    }

    @Bean(name = "receiveFinalTradeSetV1JaxbBindingUtil")
    @Qualifier(value = "receiveFinalTradeSetV1JaxbBindingUtil")
    public SaxJaxbBindingUtil<?> getReceiveDTFinalTradeSetV1JaxbBindingUtil() throws IllegalStateException, Exception {
        return new SaxJaxbBindingUtil<Object>(env.getRequiredProperty("receiveFinalTradeSet.JaxbContext", String.class));
    }

    @Bean(name = "receiveFinalTradeSetV1StaxBindingUtil")
    @Qualifier(value = "receiveFinalTradeSetV1StaxBindingUtil")
    public StaxJaxbBindingUtil<?> receiveFinalTradeSetV1StaxBindingUtil() throws IllegalStateException, Exception {
        return new StaxJaxbBindingUtil<Object>(env.getRequiredProperty("receiveFinalTradeSet.JaxbContext", String.class));
    }

    @Bean(name = "receiveCleanBidCaisoRTV4StaxBindingUtil")
    @Qualifier(value = "receiveCleanBidCaisoRTV4StaxBindingUtil")
    public StaxJaxbBindingUtil<?> getReceiveRTCleanBidCaisoV4StaxBindingUtil() throws IllegalStateException, Exception {
        return new StaxJaxbBindingUtil<Object>(env.getRequiredProperty("receiveRTCleanBidCaiso_v4.JaxbContext", String.class));
    }

    @Bean(name = "receiveCleanBidCaisoDAV4StaxBindingUtil")
    @Qualifier(value = "receiveCleanBidCaisoDAV4StaxBindingUtil")
    public StaxJaxbBindingUtil<?> getReceiveCleanBidDACaisoV4StaxbBindingUtil() throws IllegalStateException, Exception {
        return new StaxJaxbBindingUtil<Object>(env.getRequiredProperty("receiveDACleanBidCaiso_v4.JaxbContext", String.class));
    }

}

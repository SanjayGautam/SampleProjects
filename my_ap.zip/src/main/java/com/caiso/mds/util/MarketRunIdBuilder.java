package com.caiso.mds.util;

import org.springframework.stereotype.Component;

@Component
public class MarketRunIdBuilder {

    private int    marketTypeId;
    private String marketDateStr;
    private String marketDefId;
    private String marketHour;
    private String marketActivityId;

    public int getMarketTypeId() {
        return marketTypeId;
    }

    public MarketRunIdBuilder setMarketTypeId(int marketTypeId) {
        this.marketTypeId = marketTypeId;
        return this;
    }

    public MarketRunIdBuilder setMarketActivityId(String marketActivityId) {
        this.marketActivityId = marketActivityId;
        return this;
    }

    public MarketRunIdBuilder setMarketDateStr(String marketDateStr) {
        this.marketDateStr = marketDateStr;
        return this;
    }

    public MarketRunIdBuilder setMarketDefId(String marketDefId) {
        this.marketDefId = marketDefId;
        return this;
    }

    public MarketRunIdBuilder setMarketHour(String marketHour) {
        this.marketHour = marketHour;
        return this;
    }

    public String buildWithMarketDefId() {

        StringBuilder marketRunIdBuilder = new StringBuilder();
        marketRunIdBuilder.append(marketTypeId);
        marketRunIdBuilder.append(marketDateStr);
        marketRunIdBuilder.append(marketDefId);
        marketRunIdBuilder.append(marketHour);
        String marketRunId = marketRunIdBuilder.toString();
        return marketRunId;

    }

    public String buildWithActivityId() {

        StringBuilder marketRunIdBuilder = new StringBuilder();
        marketRunIdBuilder.append(marketActivityId);
        marketRunIdBuilder.append(marketDateStr);
        marketRunIdBuilder.append(marketHour);
        String marketRunId = marketRunIdBuilder.toString();
        return marketRunId;

    }
}

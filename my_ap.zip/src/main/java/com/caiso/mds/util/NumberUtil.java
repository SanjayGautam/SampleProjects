package com.caiso.mds.util;

import java.text.DecimalFormat;

public class NumberUtil {

    public static final String marketHourPattern_00 = "00";

    public static String convertNumberToFormatedString(int number, String pattern) {

        DecimalFormat myFormatter = new DecimalFormat(pattern);
        String output = myFormatter.format(number);
        return output;

    }

}

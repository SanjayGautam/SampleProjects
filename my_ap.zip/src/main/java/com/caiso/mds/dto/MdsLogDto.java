package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MdsLogDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1744274590095982715L;
    private int               mdsLogId;
    private String            marketPlanId;
    private String            marketRunId;
    private long              marketEventHistoryId;
    private long              marketStatusHistoryId;
    private long              logMessageTypeId;
    private String            messageSummary;
    private String            messageDetail;
    private Date              logInsertDateTime;

    public int getMdsLogId() {
        return mdsLogId;
    }

    public void setMdsLogId(int mdsLogId) {
        this.mdsLogId = mdsLogId;
    }

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public long getMarketEventHistoryId() {
        return marketEventHistoryId;
    }

    public void setMarketEventHistoryId(long marketEventHistoryId) {
        this.marketEventHistoryId = marketEventHistoryId;
    }

    public long getMarketStatusHistoryId() {
        return marketStatusHistoryId;
    }

    public void setMarketStatusHistoryId(long marketStatusHistoryId) {
        this.marketStatusHistoryId = marketStatusHistoryId;
    }

    public long getLogMessageTypeId() {
        return logMessageTypeId;
    }

    public void setLogMessageTypeId(long logMessageTypeId) {
        this.logMessageTypeId = logMessageTypeId;
    }

    public String getMessageSummary() {
        return messageSummary;
    }

    public void setMessageSummary(String messageSummary) {
        this.messageSummary = messageSummary;
    }

    public String getMessageDetail() {
        return messageDetail;
    }

    public void setMessageDetail(String messageDetail) {
        this.messageDetail = messageDetail;
    }

    public Date getLogInsertDateTime() {
        return logInsertDateTime;
    }

    public void setLogInsertDateTime(Date logInsertDateTime) {
        this.logInsertDateTime = logInsertDateTime;
    }

}

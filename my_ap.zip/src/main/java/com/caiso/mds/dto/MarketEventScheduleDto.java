package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

import org.joda.time.DateTime;

public class MarketEventScheduleDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -8146720337845308577L;
    private long              marketEventScheduleId;
    private long              marketEventDefId;
    private long              marketDefinitionId;
    private DateTime          marketDate;
    private DateTime          marketEventFireDateTime;
    private String            marketEventPubState;
    private String            marketEventActivationStatus;

    private Date              createdDate;
    private Date              updatedDate;
    private String            createdBy;
    private String            updatedBy;

    public long getMarketEventScheduleId() {
        return marketEventScheduleId;
    }

    public void setMarketEventScheduleId(long marketEventScheduleId) {
        this.marketEventScheduleId = marketEventScheduleId;
    }

    public long getMarketEventDefId() {
        return marketEventDefId;
    }

    public void setMarketEventDefId(long marketEventDefId) {
        this.marketEventDefId = marketEventDefId;
    }

    public long getMarketDefinitionId() {
        return marketDefinitionId;
    }

    public void setMarketDefinitionId(long marketDefinitionId) {
        this.marketDefinitionId = marketDefinitionId;
    }

    public DateTime getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(DateTime marketDate) {
        this.marketDate = marketDate;
    }

    public DateTime getMarketEventFireDateTime() {
        return marketEventFireDateTime;
    }

    public void setMarketEventFireDateTime(DateTime marketEventFireDateTime) {
        this.marketEventFireDateTime = marketEventFireDateTime;
    }

    public String getMarketEventPubState() {
        return marketEventPubState;
    }

    public void setMarketEventPubState(String marketEventPubState) {
        this.marketEventPubState = marketEventPubState;
    }

    public String getMarketEventActivationStatus() {
        return marketEventActivationStatus;
    }

    public void setMarketEventActivationStatus(String marketEventActivationStatus) {
        this.marketEventActivationStatus = marketEventActivationStatus;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

}

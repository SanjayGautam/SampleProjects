package com.caiso.mds.dto;

import java.io.Serializable;

public class MarketDefintionDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -2339937229624431479L;
    private String            marketDefinitionId;
    private String            marketType;
    private String            marketClass;
    private String            marketDesc;
    private int               marketActivityId;

    public String getMarketDefinitionId() {
        return marketDefinitionId;
    }

    public void setMarketDefinitionId(String marketDefinitionId) {
        this.marketDefinitionId = marketDefinitionId;
    }

    public String getMarketType() {
        return marketType;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType;
    }

    public String getMarketClass() {
        return marketClass;
    }

    public void setMarketClass(String marketClass) {
        this.marketClass = marketClass;
    }

    public String getMarketDesc() {
        return marketDesc;
    }

    public void setMarketDesc(String marketDesc) {
        this.marketDesc = marketDesc;
    }

    @Override
    public String toString() {
        return "Market Def Id :" + marketDefinitionId + "\n" + " Market Type :" + marketType + "\n" + " marketClass :" + marketClass + "\n" + " marketDesc :"
                + marketDesc;
    }

    public int getMarketActivityId() {

        return marketActivityId;
    }

    public void setMarketActivityId(int marketActivityId) {

        this.marketActivityId = marketActivityId;
    }

}

package com.caiso.mds.dto;

import java.util.Date;

public class MarketSystemOperatorMessageDto {

    private long   systemOperatorMessageId;
    private long   mdsSeverityId;
    private String mdsSeverityName;
    private Date   secerityInsertDate;
    private String severityMessage;
    private String pollStatus;

    public long getSystemOperatorMessageId() {
        return systemOperatorMessageId;
    }

    public void setSystemOperatorMessageId(long systemOperatorMessageId) {
        this.systemOperatorMessageId = systemOperatorMessageId;
    }

    public String getMdsSeverityName() {
        return mdsSeverityName;
    }

    public void setMdsSeverityName(String mdsSeverityName) {
        this.mdsSeverityName = mdsSeverityName;
    }

    public Date getSecerityInsertDate() {
        return secerityInsertDate;
    }

    public void setSecerityInsertDate(Date secerityInsertDate) {
        this.secerityInsertDate = secerityInsertDate;
    }

    public String getSeverityMessage() {
        return severityMessage;
    }

    public void setSeverityMessage(String severityMessage) {
        this.severityMessage = severityMessage;
    }

    public String getPollStatus() {
        return pollStatus;
    }

    public void setPollStatus(String pollStatus) {
        this.pollStatus = pollStatus;
    }

    public long getMdsSeverityId() {
        return mdsSeverityId;
    }

    public void setMdsSeverityId(long mdsSeverityId) {
        this.mdsSeverityId = mdsSeverityId;
    }

}

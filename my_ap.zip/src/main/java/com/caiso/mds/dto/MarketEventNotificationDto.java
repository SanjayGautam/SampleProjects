package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MarketEventNotificationDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 8348953984420872383L;

    private String            marketPlanId;
    private String            marketRunId;
    private long              marketEventScheduleId;
    private Date              marketEventFireDateTime;
    private Date              marketDate;
    private long              marketDefintionId;
    private String            marketDefClass;
    private String            marketDefType;
    private String            marketDefDesc;

    private long              marketEventDefId;
    private String            marketEventDefDesc;
    private String            marketEventDefNotificationName;
    private String            marketEventDefNotificationMessage;
    private String            marketNotificationAction;
    private String            marketEventDefCode;

    private String            marketHour;

    private long              marketStatusTypeId;

    private String            marketStatus;

    private String            marketEventType;

    private String            marketEventPubState;

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public long getMarketEventScheduleId() {
        return marketEventScheduleId;
    }

    public void setMarketEventScheduleId(long marketEventScheduleId) {
        this.marketEventScheduleId = marketEventScheduleId;
    }

    public Date getMarketEventFireDateTime() {
        return marketEventFireDateTime;
    }

    public void setMarketEventFireDateTime(Date marketEventFireDateTime) {
        this.marketEventFireDateTime = marketEventFireDateTime;
    }

    public Date getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(Date marketDate) {
        this.marketDate = marketDate;
    }

    public long getMarketDefintionId() {
        return marketDefintionId;
    }

    public void setMarketDefintionId(long marketDefintionId) {
        this.marketDefintionId = marketDefintionId;
    }

    public long getMarketEventDefId() {
        return marketEventDefId;
    }

    public void setMarketEventDefId(long marketEventDefId) {
        this.marketEventDefId = marketEventDefId;
    }

    public String getMarketHour() {
        return marketHour;
    }

    public void setMarketHour(String marketHour) {
        this.marketHour = marketHour;
    }

    public String getMarketDefClass() {
        return marketDefClass;
    }

    public void setMarketDefClass(String marketDefClass) {
        this.marketDefClass = marketDefClass;
    }

    public String getMarketDefType() {
        return marketDefType;
    }

    public void setMarketDefType(String marketDefType) {
        this.marketDefType = marketDefType;
    }

    public String getMarketDefDesc() {
        return marketDefDesc;
    }

    public void setMarketDefDesc(String marketDefDesc) {
        this.marketDefDesc = marketDefDesc;
    }

    public String getMarketEventDefDesc() {
        return marketEventDefDesc;
    }

    public void setMarketEventDefDesc(String marketEventDefDesc) {
        this.marketEventDefDesc = marketEventDefDesc;
    }

    public String getMarketEventDefNotificationName() {
        return marketEventDefNotificationName;
    }

    public void setMarketEventDefNotificationName(String marketEventDefNotificationName) {
        this.marketEventDefNotificationName = marketEventDefNotificationName;
    }

    public String getMarketEventDefNotificationMessage() {
        return marketEventDefNotificationMessage;
    }

    public void setMarketEventDefNotificationMessage(String marketEventDefNotificationMessage) {
        this.marketEventDefNotificationMessage = marketEventDefNotificationMessage;
    }

    public String getMarketEventDefCode() {
        return marketEventDefCode;
    }

    public void setMarketEventDefCode(String marketEventDefCode) {
        this.marketEventDefCode = marketEventDefCode;
    }

    public String getMarketNotificationAction() {
        return marketNotificationAction;
    }

    public void setMarketNotificationAction(String marketNotificationAction) {
        this.marketNotificationAction = marketNotificationAction;
    }

    public void setMarketStatusTypeId(long marketStatusTypeId) {
        this.marketStatusTypeId = marketStatusTypeId;
    }

    public long getMarketStatusTypeId() {
        return marketStatusTypeId;
    }

    public void setMarketStatus(String marketStatus) {
        this.marketStatus = marketStatus;
    }

    public String getMarketStatus() {
        return marketStatus;
    }

    public void setMarketEventType(String marketEventType) {
        this.marketEventType = marketEventType;

    }

    public String getMarketEventType() {
        return marketEventType;
    }

    public String getMarketEventPubState() {
        return marketEventPubState;
    }

    public void setMarketEventPubState(String marketEventPubState) {
        this.marketEventPubState = marketEventPubState;
    }

    @Override
    public String toString() {

        return "marketPlanId :" + marketPlanId + "\n" + "marketRunId :" + marketRunId + "\n" + "marketEventScheduleId=" + marketEventScheduleId + "\n"
                + "marketEventFireDateTime :" + marketEventFireDateTime + "\n" + "marketDate :" + marketDate + "\n" + "marketDefintionId :" + marketDefintionId
                + "\n" + "marketDefClass :" + marketDefClass + "\n" + "marketDefType :" + marketDefType + "\n" + "marketDefDesc :" + marketDefDesc + "\n"
                + "marketEventDefId :" + marketEventDefId + "\n" + "marketEventDefDesc :" + marketEventDefDesc + "\n" + "marketEventDefNotificationName :"
                + marketEventDefNotificationName + "\n" + "marketEventDefNotificationMessage :" + marketEventDefNotificationMessage + "\n"
                + "marketNotificationAction :" + marketNotificationAction + "\n" + "marketEventDefCode :" + marketEventDefCode + "\n" + "marketHour :"
                + marketHour + "\n" + "marketStatusTypeId :" + marketStatusTypeId + "\n" + "marketStatus :" + marketStatus;

    }

}

package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MarketEventsToPublishResponse implements Serializable {

    /**
	 * 
	 */
    private static final long                serialVersionUID = 5340471314634331145L;
    private List<MarketEventNotificationDto> notifications;

    public List<MarketEventNotificationDto> getNotifications() {
        if (notifications == null) {
            notifications = new ArrayList<MarketEventNotificationDto>();
        }
        return notifications;
    }

    public void setNotifications(List<MarketEventNotificationDto> notifications) {
        this.notifications = notifications;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        List<MarketEventNotificationDto> list = getNotifications();

        for (MarketEventNotificationDto marketEventNotificationDto : list) {
            sb.append("[");
            sb.append(marketEventNotificationDto.toString());
            sb.append("]\n");
        }

        return sb.toString();
    }

}

package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MdsMsgLogDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    private Integer           marketId;
    private Integer           marketRunId;
    private Integer           marketEventHistryId;
    private Integer           mdsLogMsgTypeId;

    private Integer           mdsMktClsId;
    private Date              mdslogInsertDts;
    private String            messageSummary;
    private String            messageDetail;

    private Integer           mdsLogId;

    public Integer getMdsLogId() {
        return mdsLogId;
    }

    public void setMdsLogId(Integer mdsLogId) {
        this.mdsLogId = mdsLogId;
    }

    public Integer getMarketId() {
        return marketId;
    }

    public void setMarketId(Integer marketId) {
        this.marketId = marketId;
    }

    public Integer getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(Integer marketRunId) {
        this.marketRunId = marketRunId;
    }

    public Integer getMarketEventHistryId() {
        return marketEventHistryId;
    }

    public void setMarketEventHistryId(Integer marketEventHistryId) {
        this.marketEventHistryId = marketEventHistryId;
    }

    public Integer getMdsLogMsgTypeId() {
        return mdsLogMsgTypeId;
    }

    public void setMdsLogMsgTypeId(Integer mdsLogMsgTypeId) {
        this.mdsLogMsgTypeId = mdsLogMsgTypeId;
    }

    public Integer getMdsMktClsId() {
        return mdsMktClsId;
    }

    public void setMdsMktClsId(Integer mdsMktClsId) {
        this.mdsMktClsId = mdsMktClsId;
    }

    public Date getMdslogInsertDts() {
        return mdslogInsertDts;
    }

    public void setMdslogInsertDts(Date mdslogInsertDts) {
        this.mdslogInsertDts = mdslogInsertDts;
    }

    public String getMessageSummary() {
        return messageSummary;
    }

    public void setMessageSummary(String messageSummary) {
        this.messageSummary = messageSummary;
    }

    public String getMessageDetail() {
        return messageDetail;
    }

    public void setMessageDetail(String messageDetail) {
        this.messageDetail = messageDetail;
    }

}

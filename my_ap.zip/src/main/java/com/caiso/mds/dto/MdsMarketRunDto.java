package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MdsMarketRunDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    private String            marketId;

    private String            marketRunId;
    private String            marketType;
    private String            marketClass;

    private int               mdsMktClsId;
    private int               marketStatusId;
    private Date              mdsUpdateDts;
    private String            mdsUpdateUser;

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public int getMdsMktClsId() {
        return mdsMktClsId;
    }

    public void setMdsMktClsId(int mdsMktClsId) {
        this.mdsMktClsId = mdsMktClsId;
    }

    public int getMarketStatusId() {
        return marketStatusId;
    }

    public void setMarketStatusId(int marketStatusId) {
        this.marketStatusId = marketStatusId;
    }

    public Date getMdsUpdateDts() {
        return mdsUpdateDts;
    }

    public void setMdsUpdateDts(Date mdsUpdateDts) {
        this.mdsUpdateDts = mdsUpdateDts;
    }

    public String getMdsUpdateUser() {
        return mdsUpdateUser;
    }

    public void setMdsUpdateUser(String mdsUpdateUser) {
        this.mdsUpdateUser = mdsUpdateUser;
    }

    public String getMarketType() {
        return marketType;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType;
    }

    public String getMarketId() {
        return marketId;
    }

    public void setMarketId(String marketId) {
        this.marketId = marketId;
    }

    public String getMarketClass() {
        return marketClass;
    }

    public void setMarketClass(String marketClass) {
        this.marketClass = marketClass;
    }
}

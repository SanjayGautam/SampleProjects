package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MarketEventNotificationsRequest implements Serializable {

    /**
	 * 
	 */
    private static final long                serialVersionUID = -4500607966178034824L;
    private List<MarketEventNotificationDto> marketEventNotifications;

    public List<MarketEventNotificationDto> getMarketEventNotifications() {

        if (marketEventNotifications == null) {
            marketEventNotifications = new ArrayList<MarketEventNotificationDto>();
        }
        return marketEventNotifications;
    }

    public void setMarketEventNotifications(List<MarketEventNotificationDto> marketEventNotifications) {
        this.marketEventNotifications = marketEventNotifications;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        List<MarketEventNotificationDto> list = getMarketEventNotifications();
        for (MarketEventNotificationDto marketEventNotificationDto : list) {
            sb.append("[");
            sb.append(marketEventNotificationDto.toString());
            sb.append("]\n");
        }

        return sb.toString();
    }

}

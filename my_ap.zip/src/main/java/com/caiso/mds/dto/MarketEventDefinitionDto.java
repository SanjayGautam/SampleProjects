package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MarketEventDefinitionDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -2651308452806975371L;
    private long              marketEventDefId;
    private String            marketEventDefDesc;
    private String            marketEventNotificationName;
    private String            marketEventDefNotificationMsg;
    private String            marketEventDefCode;
    private long              associatedMarketDefId;
    private String            marketEventType;
    private boolean           isExternalEvent;
    private String            eventStartTime;
    private String            eventEndTime;
    private int               eventTimeOffset;
    private String            eventTimeOffsetUnit;
    private String            eventOffsetStartEntity;
    private int               eventRepeatInterval;
    private String            eventRepeatIntervalUnit;

    private Date              createdDate;
    private Date              updateDate;
    private String            updatedBy;
    private String            createdBy;

    public long getMarketEventDefId() {
        return marketEventDefId;
    }

    public void setMarketEventDefId(long marketEventDefId) {
        this.marketEventDefId = marketEventDefId;
    }

    public String getMarketEventDefDesc() {
        return marketEventDefDesc;
    }

    public void setMarketEventDefDesc(String marketEventDesc) {
        this.marketEventDefDesc = marketEventDesc;
    }

    public String getMarketEventNotificationName() {
        return marketEventNotificationName;
    }

    public void setMarketEventDefNotificationName(String marketEventNotificationName) {
        this.marketEventNotificationName = marketEventNotificationName;
    }

    public String getMarketEventDefNotificationMsg() {
        return marketEventDefNotificationMsg;
    }

    public void setMarketEventDefNotificationMsg(String marketEventMsg) {
        this.marketEventDefNotificationMsg = marketEventMsg;
    }

    public String getMarketEventDefCode() {
        return marketEventDefCode;
    }

    public void setMarketEventDefCode(String marketEventCode) {
        this.marketEventDefCode = marketEventCode;
    }

    public long getAssociatedMarketDefId() {
        return associatedMarketDefId;
    }

    public void setAssociatedMarketDefId(long associatedMarketDefId) {
        this.associatedMarketDefId = associatedMarketDefId;
    }

    public boolean isExternalEvent() {
        return isExternalEvent;
    }

    public void setExternalEvent(boolean isExternalEvent) {
        this.isExternalEvent = isExternalEvent;
    }

    public String getEventStartTime() {
        return eventStartTime;
    }

    public void setEventStartTime(String eventStartTime) {
        this.eventStartTime = eventStartTime;
    }

    public String getEventEndTime() {
        return eventEndTime;
    }

    public void setEventEndTime(String eventEndTime) {
        this.eventEndTime = eventEndTime;
    }

    public int getEventTimeOffset() {
        return eventTimeOffset;
    }

    public void setEventTimeOffset(int eventTimeOffset) {
        this.eventTimeOffset = eventTimeOffset;
    }

    public String getEventTimeOffsetUnit() {
        return eventTimeOffsetUnit;
    }

    public void setEventTimeOffsetUnit(String eventTimeOffsetUnit) {
        this.eventTimeOffsetUnit = eventTimeOffsetUnit;
    }

    public String getEventOffsetStartEntity() {
        return eventOffsetStartEntity;
    }

    public void setEventOffsetStartEntity(String eventOffsetStartEntity) {
        this.eventOffsetStartEntity = eventOffsetStartEntity;
    }

    public int getEventRepeatInterval() {
        return eventRepeatInterval;
    }

    public void setEventRepeatInterval(int eventRepeatInterval) {
        this.eventRepeatInterval = eventRepeatInterval;
    }

    public String getEventRepeatIntervalUnit() {
        return eventRepeatIntervalUnit;
    }

    public void setEventRepeatIntervalUnit(String eventRepeatIntervalUnit) {
        this.eventRepeatIntervalUnit = eventRepeatIntervalUnit;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getMarketEventType() {
        return marketEventType;
    }

    public void setMarketEventType(String associatedMarketStatus) {
        this.marketEventType = associatedMarketStatus;
    }

    public void setMarketEventNotificationName(String marketEventNotificationName) {
        this.marketEventNotificationName = marketEventNotificationName;
    }

    @Override
    public String toString() {

        return "marketEventDefId :" + marketEventDefId + "\n" + " marketEventDefDesc :" + marketEventDefDesc + "\n" + "marketEventNotificationName :"
                + marketEventNotificationName + "\n" + "marketEventDefNotificationMsg :" + marketEventDefNotificationMsg + "\n" + "marketEventDefCode :"
                + marketEventDefCode + "\n" + "associatedMarketDefId :" + associatedMarketDefId + "\n" + "marketEventType :" + marketEventType + "\n"
                + "isExternalEvent :" + isExternalEvent;

    }
}

package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MarketPlanServiceResponse implements Serializable {

    /**
	 * 
	 */
    private static final long   serialVersionUID = 7518934625510666077L;

    private MarketPlanDto       marketPlanDto    = null;
    private String              responseResult   = "NotFound";
    private List<MarketPlanDto> marketPlans;

    public MarketPlanDto getMarketPlanDto() {
        return marketPlanDto;
    }

    public void setMarketPlanDto(MarketPlanDto marketPlanDto) {
        this.marketPlanDto = marketPlanDto;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

    public void setMarketPlans(List<MarketPlanDto> marketPlans) {
        this.marketPlans = marketPlans;
    }

    public List<MarketPlanDto> getMarketPlans() {

        if (marketPlans == null) {
            marketPlans = new ArrayList<MarketPlanDto>();
        }
        return marketPlans;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();
        if (marketPlanDto != null) {
            sb.append(" Market Plan DTO " + marketPlanDto.toString());
        }

        sb.append("responseResult=" + responseResult);

        List<MarketPlanDto> marketPlansTemp = getMarketPlans();

        for (MarketPlanDto marketPlanDto : marketPlansTemp) {
            sb.append("[");
            sb.append(marketPlanDto.toString());
            sb.append("]/n");
        }

        return sb.toString();
    }
}

package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MarketStatusDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -5686769885928160721L;
    private String            marketRunId;
    private String            marketPlanId;
    private Date              marketStartTime;

    private String            currentStatus;
    private String            requestedStatus;
    private String            previousStatus;
    private Date              marketStatusTime;
    private String            marketType;
    private String            marketClass;

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public Date getMarketStartTime() {
        return marketStartTime;
    }

    public void setMarketStartTime(Date marketStartTime) {
        this.marketStartTime = marketStartTime;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getRequestedStatus() {
        return requestedStatus;
    }

    public void setRequestedStatus(String requestedStatus) {
        this.requestedStatus = requestedStatus;
    }

    public String getPreviousStatus() {
        return previousStatus;
    }

    public void setPreviousStatus(String previousStatus) {
        this.previousStatus = previousStatus;
    }

    public Date getMarketStatusTime() {
        return marketStatusTime;
    }

    public void setMarketStatusTime(Date marketStatusTime) {
        this.marketStatusTime = marketStatusTime;
    }

    public String getMarketType() {
        return marketType;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType;
    }

    public String getMarketClass() {
        return marketClass;
    }

    public void setMarketClass(String marketClass) {
        this.marketClass = marketClass;
    }

    @Override
    public String toString() {

        return "marketRunId :" + marketRunId + "\n" + "marketPlanId :" + marketPlanId + "\n" + "marketStartTime :" + marketStartTime + "\n" + "currentStatus :"
                + currentStatus + "\n" + "requestedStatus :" + requestedStatus + "\n" + "previousStatus :" + previousStatus + "\n" + "marketStatusTime :"
                + marketStatusTime + "\n" + "marketType :" + marketType + "\n" + "marketClass :" + marketClass;

    }

}

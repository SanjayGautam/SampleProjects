package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MarketEventHistoryDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 8284332206986201041L;
    private long              marketEventHistoryId;
    private String            marketPlanId;
    private String            marketRunId;
    private long              marketStatusHistoryId;
    private long              marketEventDefinitionId;
    private String            marketEventPubState;
    private Date              marketDate;
    private Date              updateDate;
    private String            updateBy;

    private Date              createDate;
    private String            createBy;

    public long getMarketEventHistoryId() {
        return marketEventHistoryId;
    }

    public void setMarketEventHistoryId(long marketEventHistoryId) {
        this.marketEventHistoryId = marketEventHistoryId;
    }

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public long getMarketStatusHistoryId() {
        return marketStatusHistoryId;
    }

    public void setMarketStatusHistoryId(long marketStatusHistoryId) {
        this.marketStatusHistoryId = marketStatusHistoryId;
    }

    public long getMarketEventDefinitionId() {
        return marketEventDefinitionId;
    }

    public void setMarketEventDefinitionId(long marketEventDefinitionId) {
        this.marketEventDefinitionId = marketEventDefinitionId;
    }

    public Date getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(Date marketDate) {
        this.marketDate = marketDate;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getMarketEventPubState() {
        return marketEventPubState;
    }

    public void setMarketEventPubState(String marketEventPubState) {
        this.marketEventPubState = marketEventPubState;
    }

    @Override
    public String toString() {

        return "marketEventHistoryId :" + marketEventHistoryId + "\n" + "marketPlanId :" + marketPlanId + "\n" + "marketRunId :" + marketRunId + "\n"
                + "marketStatusHistoryId :" + marketStatusHistoryId + "\n" + "marketEventDefinitionId :" + marketEventDefinitionId + "\n"
                + "marketEventPubState :" + marketEventPubState + "\n" + "marketDate :" + marketDate;

    }
}

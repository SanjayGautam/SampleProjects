package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MarketPlanServiceRequest implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -1632551480110643586L;

    private Date              marketDate;
    private long              marketDefId;
    private String            marketEventDefCode;

    public Date getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(Date marketDate) {
        this.marketDate = marketDate;
    }

    public long getMarketDefId() {
        return marketDefId;
    }

    public void setMarketDefId(long marketDefId) {
        this.marketDefId = marketDefId;
    }

    public String getMarketEventDefCode() {
        return marketEventDefCode;
    }

    public void setMarketEventDefCode(String marketEventDefCode) {
        this.marketEventDefCode = marketEventDefCode;
    }

    @Override
    public String toString() {
        return "marketDate :" + marketDate + "\n" + "marketDefId :" + marketDefId + "\n" + "marketEventDefCode :" + marketEventDefCode;

    }

}

package com.caiso.mds.dto;

import java.io.Serializable;
import java.util.Date;

public class MarketPlanDto implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 6227101719924418988L;
    private String            marketPlanId;
    private String            marketRunId;
    private String            marketDefinitionId;
    private long              marketStatusTypeId;
    private Date              marketDate;
    private String            marketHour;
    private String            recordStatus;
    private String            createdBy;
    private Date              createdDate;

    private String            updatedBy;
    private Date              updatedDate;
    private String            marketClass;
    private String            marketType;

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public String getMarketDefinitionId() {
        return marketDefinitionId;
    }

    public void setMarketDefinitionId(String marketDefinitionId) {
        this.marketDefinitionId = marketDefinitionId;
    }

    public long getMarketStatusTypeId() {
        return marketStatusTypeId;
    }

    public void setMarketStatusTypeId(long marketStatusTypeId) {
        this.marketStatusTypeId = marketStatusTypeId;
    }

    public Date getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(Date marketDate) {
        this.marketDate = marketDate;
    }

    public String getMarketHour() {
        return marketHour;
    }

    public void setMarketHour(String marketHour) {
        this.marketHour = marketHour;
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public void setMarketClass(String marketClass) {
        this.marketClass = marketClass;
    }

    public String getMarketClass() {
        return marketClass;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType;
    }

    public String getMarketType() {
        return this.marketType;
    }

    @Override
    public String toString() {

        return "marketPlanId :" + marketPlanId + "\n" + "marketRunId :" + marketRunId + "\n" + "marketDefinitionId :" + marketDefinitionId + "\n"
                + "marketStatusTypeId :" + marketStatusTypeId + "\n" + "marketDate :" + marketDate + "\n" + "marketHour :" + marketHour + "\n"
                + "recordStatus :" + recordStatus + "\n" + "marketClass :" + marketClass + "\n" + "marketType :" + marketType;

    }

}

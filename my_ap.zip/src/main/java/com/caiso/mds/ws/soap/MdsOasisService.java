package com.caiso.mds.ws.soap;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dao.oasis.MdsOasisNotificationCtlDao;
import com.caiso.mds.entity.oasis.MdsNotificationCtlOasis;
import com.caiso.mdsoasis.dto.OasisMarketToPublishRequest;
import com.caiso.mdsoasis.dto.OasisMarketToPublishResponse;
import com.caiso.mdsoasis.dto.OasisNotificationCtlDto;
import com.caiso.mdsoasis.dto.OasisNotificationRequest;
import com.caiso.mdsoasis.dto.OasisNotificationResponse;

@WebService(name = "MdsOasisService", portName = "MdsOasisServicePort", serviceName = "MdsOasisService", targetNamespace = "http://dto.mdsoasis.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MdsOasisService {

    private final static Logger        logger = LoggerFactory.getLogger(MdsOasisService.class);

    @Autowired
    private MdsOasisNotificationCtlDao mdsOasisNotificationCtlDao;

    @WebMethod(operationName = "createNotificationCtl")
    public void createNotificationCtl(OasisNotificationCtlDto oasisNotificationCtlDto) {
        logger.debug(" ====>>>  Service Method oasisNotificationCtlDto = >   " + oasisNotificationCtlDto);
        MdsNotificationCtlOasis mdsNotificationCtlOasis = createMdsNotificationCrlOasisObject(oasisNotificationCtlDto);

        logger.debug(" ====>>>  Service Method   " + mdsNotificationCtlOasis);
        mdsOasisNotificationCtlDao.createNotificationCtl(mdsNotificationCtlOasis);

        return;
    }

    @WebMethod(operationName = "updateNotificationCtl")
    public void updateNotificationCtl(OasisNotificationCtlDto oasisNotificationCtlDto) {
        logger.debug(" ====>>>  Service Method oasisNotificationCtlDto = >   " + oasisNotificationCtlDto);
        MdsNotificationCtlOasis mdsNotificationCtlOasis = createMdsNotificationCrlOasisObject(oasisNotificationCtlDto);

        logger.debug(" ====>>>  Service Method   " + mdsNotificationCtlOasis);
        mdsOasisNotificationCtlDao.updateNotificationCtl(mdsNotificationCtlOasis);

        return;
    }

    @WebMethod(operationName = "updateNotificationCtlDtos")
    public void updateNotificationCtlDtos(OasisNotificationRequest oasisNotificationRequest) {
        logger.debug(" ====>>>  Service Method oasisNotificationCtlDto = >   " + oasisNotificationRequest.getOasisNotificationCtlDtos());
        List<OasisNotificationCtlDto> oasisNotificationCtlDtos = oasisNotificationRequest.getOasisNotificationCtlDtos();
        for (OasisNotificationCtlDto oasisNotificationCtlDto : oasisNotificationCtlDtos) {
            MdsNotificationCtlOasis mdsNotificationCtlOasis = createMdsNotificationCrlOasisObject(oasisNotificationCtlDto);
            mdsOasisNotificationCtlDao.updateNotificationCtl(mdsNotificationCtlOasis);
        }

        logger.debug(" ====>>>  Service Method   ");

        return;
    }

    /**
     * 
     * @param status
     * @param mdsFlowState
     * @param notificationName
     * @return
     */
    @WebMethod(operationName = "getMarketToBePublished")
    @WebResult(name = "OasisMarketToPublishResponse")
    public OasisMarketToPublishResponse getOasisNotificationCtlInreadyStatusAndMdsFlowStatusNull(
            @WebParam(name = "OasisMarketToPublishRequest") OasisMarketToPublishRequest oasisMarketToPublishRequest) {

        MdsNotificationCtlOasis mdsNotificationCtlOasis = new MdsNotificationCtlOasis();

        mdsNotificationCtlOasis.setMdsFlowState(oasisMarketToPublishRequest.getMdsFlowState());
        mdsNotificationCtlOasis.setStatus(oasisMarketToPublishRequest.getStatus());
        mdsNotificationCtlOasis.setNotificationName(oasisMarketToPublishRequest.getNotificationName());

        mdsNotificationCtlOasis = mdsOasisNotificationCtlDao.getOasisNotificationCtlInReadyStatusAndMdsFlowStatusNull(mdsNotificationCtlOasis);

        OasisMarketToPublishResponse oasisMarketToPublishResponse = populateOasisNotificationCtlName(mdsNotificationCtlOasis);

        return oasisMarketToPublishResponse;

    }

    /**
     * 
     * @param status
     * @param mdsFlowState
     * @param notificationName
     * @return
     */
    @WebMethod(operationName = "getNotificationCtlRecordsByStatusByMdsFlowStateByNotificationName")
    @WebResult(name = "OasisNotificationResponse")
    public OasisNotificationResponse getNotificationCtlRecordsByStatusByMdsFlowStateByNotificationName(
            @WebParam(name = "OasisNotificationRequest") OasisNotificationRequest oasisNotificationRequest) {

        MdsNotificationCtlOasis mdsNotificationCtlOasis = new MdsNotificationCtlOasis();

        mdsNotificationCtlOasis.setMdsFlowState(oasisNotificationRequest.getMdsFlowState());
        mdsNotificationCtlOasis.setStatus(oasisNotificationRequest.getStatus());
        mdsNotificationCtlOasis.setNotificationNames(oasisNotificationRequest.getNotificationNames());

        List<MdsNotificationCtlOasis> oasisNotifications = mdsOasisNotificationCtlDao
                .getOasisNotificationRecordsByMdsFlowStateAndNotificationNames(mdsNotificationCtlOasis);

        OasisNotificationResponse oasisNotificationResponse = populateOasisNotificationResponse(oasisNotifications);

        return oasisNotificationResponse;

    }

    /**
     * 
     * @param rtpdRtdPriceRequest
     * @return
     */
    @WebMethod(operationName = "getOasisNotificationsRecordsByMdsFlowStateAndNotificationNames")
    @WebResult(name = "OasisNotificationResponse")
    public OasisNotificationResponse getRtdRtpdPublishRecords(@WebParam(name = "OasisNotificationRequest") OasisNotificationRequest oasisNotificationRequest) {

        MdsNotificationCtlOasis mdsNotificationCtlOasis = new MdsNotificationCtlOasis();

        mdsNotificationCtlOasis.setMdsFlowState(oasisNotificationRequest.getMdsFlowState());

        mdsNotificationCtlOasis.setNotificationNames(oasisNotificationRequest.getNotificationNames());

        mdsNotificationCtlOasis.setStatus(oasisNotificationRequest.getStatus());

        List<MdsNotificationCtlOasis> oasisNotifications = mdsOasisNotificationCtlDao
                .getOasisNotificationRecordsByMdsFlowStateAndNotificationNames(mdsNotificationCtlOasis);

        OasisNotificationResponse oasisNotificationResponse = populateOasisNotificationResponse(oasisNotifications);

        return oasisNotificationResponse;

    }

    /**
     * 
     * @param oasisNotifications
     * @return
     */
    private OasisNotificationResponse populateOasisNotificationResponse(List<MdsNotificationCtlOasis> oasisNotifications) {

        OasisNotificationResponse oasisNotificationResponse = new OasisNotificationResponse();
        List<OasisNotificationCtlDto> oasisNotificationCtlDtos = new ArrayList<OasisNotificationCtlDto>();
        if (oasisNotifications != null && oasisNotifications.size() > 0) {

            for (MdsNotificationCtlOasis oasisNotification : oasisNotifications) {
                OasisNotificationCtlDto oasisNotificationCtlDto = populateOasisNotificationCtlDto(oasisNotification);
                oasisNotificationCtlDtos.add(oasisNotificationCtlDto);
            }
            oasisNotificationResponse.setOasisNotificationCtlDtos(oasisNotificationCtlDtos);
            oasisNotificationResponse.setResponseResult("Found");

        } else {

            oasisNotificationResponse.setResponseResult("NotFound");

        }

        return oasisNotificationResponse;
    }

    /**
     * 
     * @param mdsOasisNotification
     * @return
     */

    private OasisNotificationCtlDto populateOasisNotificationCtlDto(MdsNotificationCtlOasis mdsOasisNotification) {

        OasisNotificationCtlDto oasisNotificationCtlDto = new OasisNotificationCtlDto();
        oasisNotificationCtlDto.setStatus(mdsOasisNotification.getStatus());
        oasisNotificationCtlDto.setCreatedDts(mdsOasisNotification.getCreatedDts());
        oasisNotificationCtlDto.setMarketId(mdsOasisNotification.getMarketId());
        oasisNotificationCtlDto.setMarketRunId(mdsOasisNotification.getMarketRunId());
        oasisNotificationCtlDto.setMdsFlowEndDts(mdsOasisNotification.getMdsFlowEndDts());
        oasisNotificationCtlDto.setMdsFlowStartDts(mdsOasisNotification.getMdsFlowStartDts());
        oasisNotificationCtlDto.setMdsFlowState(mdsOasisNotification.getMdsFlowState());
        oasisNotificationCtlDto.setNotificationCtlId(mdsOasisNotification.getNotificationCtlId());
        oasisNotificationCtlDto.setTradeDt(mdsOasisNotification.getTradeDt());
        oasisNotificationCtlDto.setNotificationName(mdsOasisNotification.getNotificationName());
        oasisNotificationCtlDto.setUpdatedDts(mdsOasisNotification.getUpdatedDts());
        oasisNotificationCtlDto.setUpdateUser("mds_bpm");

        return oasisNotificationCtlDto;
    }

    /**
     * 
     * @param mdsNotificationCtlOasis
     * @return
     */

    private OasisMarketToPublishResponse populateOasisNotificationCtlName(MdsNotificationCtlOasis mdsNotificationCtlOasis) {

        OasisMarketToPublishResponse oasisMarketToPublishResponse = new OasisMarketToPublishResponse();
        logger.debug(" inside populateOasisNotification  " + mdsNotificationCtlOasis);
        if (mdsNotificationCtlOasis != null) {
            OasisNotificationCtlDto oasisNotificationCtlDto = new OasisNotificationCtlDto();
            oasisNotificationCtlDto.setStatus(mdsNotificationCtlOasis.getStatus());
            oasisNotificationCtlDto.setCreatedDts(mdsNotificationCtlOasis.getCreatedDts());
            oasisNotificationCtlDto.setMarketId(mdsNotificationCtlOasis.getMarketId());
            oasisNotificationCtlDto.setMarketRunId(mdsNotificationCtlOasis.getMarketRunId());
            oasisNotificationCtlDto.setMdsFlowEndDts(mdsNotificationCtlOasis.getMdsFlowEndDts());
            oasisNotificationCtlDto.setMdsFlowStartDts(mdsNotificationCtlOasis.getMdsFlowStartDts());
            oasisNotificationCtlDto.setMdsFlowState(mdsNotificationCtlOasis.getMdsFlowState());
            oasisNotificationCtlDto.setNotificationCtlId(mdsNotificationCtlOasis.getNotificationCtlId());
            oasisNotificationCtlDto.setTradeDt(mdsNotificationCtlOasis.getTradeDt());
            oasisNotificationCtlDto.setNotificationName(mdsNotificationCtlOasis.getNotificationName());
            oasisNotificationCtlDto.setUpdatedDts(mdsNotificationCtlOasis.getUpdatedDts());
            oasisNotificationCtlDto.setUpdateUser("mds_bpm");
            oasisMarketToPublishResponse.setOasisNotificationCtlDto(oasisNotificationCtlDto);
            oasisMarketToPublishResponse.setResponseResult("Found");

        } else {

            oasisMarketToPublishResponse.setOasisNotificationCtlDto(null);
            oasisMarketToPublishResponse.setResponseResult("NotFound");
        }
        return oasisMarketToPublishResponse;
    }

    /**
     * 
     * @param oasisNotificationCtlDto
     * @return
     */
    private MdsNotificationCtlOasis createMdsNotificationCrlOasisObject(OasisNotificationCtlDto oasisNotificationCtlDto) {

        MdsNotificationCtlOasis mdsNotificationCtlOasis = new MdsNotificationCtlOasis();
        mdsNotificationCtlOasis.setMarketId(oasisNotificationCtlDto.getMarketId());
        mdsNotificationCtlOasis.setMarketRunId(oasisNotificationCtlDto.getMarketRunId());
        mdsNotificationCtlOasis.setNotificationCtlId(oasisNotificationCtlDto.getNotificationCtlId());

        mdsNotificationCtlOasis.setNotificationName(oasisNotificationCtlDto.getNotificationName());
        mdsNotificationCtlOasis.setNotificationComments(oasisNotificationCtlDto.getNotificationComments());
        mdsNotificationCtlOasis.setMdsFlowStartDts(oasisNotificationCtlDto.getMdsFlowStartDts());
        mdsNotificationCtlOasis.setMdsFlowEndDts(oasisNotificationCtlDto.getMdsFlowEndDts());

        mdsNotificationCtlOasis.setMdsProcessAfter(oasisNotificationCtlDto.getMdsProcessAfter());
        mdsNotificationCtlOasis.setMdsRetryCount(oasisNotificationCtlDto.getMdsRetryCount());

        mdsNotificationCtlOasis.setUpdatedDts(new Date());
        mdsNotificationCtlOasis.setUpdateUser("mds_bpm");
        mdsNotificationCtlOasis.setCreatedDts(oasisNotificationCtlDto.getCreatedDts());

        mdsNotificationCtlOasis.setStatus(oasisNotificationCtlDto.getStatus());
        mdsNotificationCtlOasis.setMdsFlowState(oasisNotificationCtlDto.getMdsFlowState());

        return mdsNotificationCtlOasis;
    }

}

package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketStatusDto;
import com.caiso.mds.external.ws.service.MdsToSibrService;

@WebService(name = "MarketStatusBroadcastToSibrService", portName = "MarketStatusBroadcastToSibrServicePort", serviceName = "MarketStatusBroadcastToSibrService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketStatusBroadcastToSibrWebService {

    private final Logger     logger = LoggerFactory.getLogger(MarketStatusBroadcastToSibrWebService.class);

    @Autowired
    private MdsToSibrService mdsToSibrService;

    @Autowired
    private Boolean          mdsToSibrBroadcastSwitchEnabled;

    /**
     * This service will help any one to publish the SIBR market status provided
     * . The service will use the urls which are provided in the database and if
     * there are multple endpoints the service will try to send to one url and
     * if it succeed it will not try to send to the next one. It will try one
     * after other endpoint if doesnt succeed method will just exit.
     * 
     * @param marketStatusDto
     */
    @WebMethod(operationName = "broadcastMarketStatusToSibr")
    public void broadcastMarketStatusToSibr(@WebParam(name = "marketStatusDto") MarketStatusDto marketStatusDto) {

        logger.info("*****  Entered Web Service Broad cast Market status  ********");
        logger.info(" Requested Status  		" + marketStatusDto.getRequestedStatus());
        logger.info(" Market Run Id   			" + marketStatusDto.getMarketRunId());
        logger.info(" Market Plan Id   			" + marketStatusDto.getMarketPlanId());
        logger.info(" Market Type    			" + marketStatusDto.getMarketType());
        logger.info(" Market Class   			" + marketStatusDto.getMarketClass());
        logger.info(" Market Start Time    		" + marketStatusDto.getMarketStartTime());
        logger.info(" Market Market Status Time " + marketStatusDto.getMarketStatusTime());
        logger.info("MDS to SIBR mdsToSibrBroadcastSwitchEnabled ={}", mdsToSibrBroadcastSwitchEnabled);

        if (mdsToSibrBroadcastSwitchEnabled) {
            mdsToSibrService.sendMarketStatusToSibr(marketStatusDto);
        } else {
            logger.warn("Message will not be sent to the SIBR as it is disabled in the MDS..Please enable the it from properties file.");
        }

        logger.info("*****  Exiting Publishing to SIBR ********");

    }

}

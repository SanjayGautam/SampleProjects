package com.caiso.mds.ws.soap;

import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dao.cmri.MdsCmriNotificationCtlDao;
import com.caiso.mds.entity.cmri.MdsNotificationCtlCmri;
import com.caiso.mds.entity.cmri.MdsOasisStatusCtl;
import com.caiso.mds.entity.cmri.MdsOasisStatusCtlId;
import com.caiso.mdscmri.dto.CmriMarketToPublishRequest;
import com.caiso.mdscmri.dto.CmriMarketToPublishResponse;
import com.caiso.mdscmri.dto.CmriNotificationCtlDto;
import com.caiso.mdscmri.dto.CmriNotificationRequest;
import com.caiso.mdscmri.dto.CmriOasisStatusCtlDto;

@WebService(name = "MdsCmriService", portName = "MdsCmriServicePort", serviceName = "MdsCmriService", targetNamespace = "http://dto.mdscmri.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MdsCmriService {

    private final static Logger       logger = LoggerFactory.getLogger(MdsCmriService.class);

    @Autowired
    private MdsCmriNotificationCtlDao mdsCmriNotificationCtlDao;

    /**
     * 
     * @param cmriNotificationCtlDto
     * @return
     */
    @WebMethod(operationName = "createCmriNotification")
    public MdsNotificationCtlCmri createCmriNotification(@WebParam(name = "cmriNotificationCtlDto") CmriNotificationCtlDto cmriNotificationCtlDto) {

        logger.debug("*****************************Enter Service Method createCmriNotification *******************************************");
        logger.debug("Notification Ctl ID : " + cmriNotificationCtlDto.getNotificationCtlId());
        MdsNotificationCtlCmri mdsNotificationCtlCmri = populateNotificationCtlCmriObject(cmriNotificationCtlDto);

        mdsNotificationCtlCmri = mdsCmriNotificationCtlDao.createCmriNotification(mdsNotificationCtlCmri);

        logger.debug("*****************************Enter Service Method createCmriNotification *******************************************");

        return mdsNotificationCtlCmri;
    }

    /**
     * 
     * @param cmriNotificationCtlDto
     * @return
     */

    private MdsNotificationCtlCmri populateNotificationCtlCmriObject(CmriNotificationCtlDto cmriNotificationCtlDto) {
        MdsNotificationCtlCmri mdsNotificationCtlCmri = new MdsNotificationCtlCmri();
        mdsNotificationCtlCmri.setMarketId(cmriNotificationCtlDto.getMarketId());
        mdsNotificationCtlCmri.setMarketRunId(cmriNotificationCtlDto.getMarketRunId());
        mdsNotificationCtlCmri.setMdsFlowEndDts(cmriNotificationCtlDto.getMdsFlowEndDts());
        mdsNotificationCtlCmri.setMdsFlowStartDts(cmriNotificationCtlDto.getMdsFlowStartDts());
        mdsNotificationCtlCmri.setMdsFlowState(cmriNotificationCtlDto.getMdsFlowState());
        mdsNotificationCtlCmri.setMdsProcessAfter(cmriNotificationCtlDto.getMdsProcessAfter());
        mdsNotificationCtlCmri.setMdsRetryCount(cmriNotificationCtlDto.getMdsRetryCount());
        mdsNotificationCtlCmri.setNotificationComments(cmriNotificationCtlDto.getNotificationComments());
        mdsNotificationCtlCmri.setNotificationName(cmriNotificationCtlDto.getNotificationName());
        mdsNotificationCtlCmri.setNotificationCtlId(cmriNotificationCtlDto.getNotificationCtlId());
        mdsNotificationCtlCmri.setStatus(cmriNotificationCtlDto.getStatus());
        mdsNotificationCtlCmri.setTradeDt(cmriNotificationCtlDto.getTradeDt());
        mdsNotificationCtlCmri.setUpdatedDts(new Date());
        mdsNotificationCtlCmri.setUpdateUser("mds_bpm");

        mdsNotificationCtlCmri.setCreatedDts(cmriNotificationCtlDto.getCreatedDts());

        return mdsNotificationCtlCmri;
    }

    /**
     * 
     * @param cmriNotificationRequest
     */

    @WebMethod(operationName = "createCmriNotificationCtls")
    public void createCmriNotificationCtls(@WebParam(name = "CmriNotificationRequest") CmriNotificationRequest cmriNotificationRequest) {

        logger.debug("*****************************Enter Service Method createCmriNotification *******************************************");
        List<CmriNotificationCtlDto> cmriNotificationCtlDtos = cmriNotificationRequest.getCmriNotificationCtlDtos();
        for (CmriNotificationCtlDto cmriNotificationCtlDto : cmriNotificationCtlDtos) {

            MdsNotificationCtlCmri mdsNotificationCtlCmri = populateNotificationCtlCmriObject(cmriNotificationCtlDto);
            mdsCmriNotificationCtlDao.createCmriNotification(mdsNotificationCtlCmri);
        }

        logger.debug("*****************************Enter Service Method createCmriNotification *******************************************");

        return;
    }

    @WebMethod(operationName = "createCmriMdsOasisStatusCtls")
    public void createCmriMdsOasisStatusCtls(@WebParam(name = "CmriNotificationRequest") CmriNotificationRequest cmriNotificationRequest) {

        logger.debug("*****************************Enter Service Method createCmriNotification *******************************************");
        List<CmriOasisStatusCtlDto> cmriOasisStatusCtlDtos = cmriNotificationRequest.getCmriOasisStatusCtlDtos();
        for (CmriOasisStatusCtlDto cmriOasisStatusCtlDto : cmriOasisStatusCtlDtos) {
            MdsOasisStatusCtl mdsOasisStatusCtl = populateOasisStatusCtl(cmriOasisStatusCtlDto);
            mdsCmriNotificationCtlDao.createMdsOasisStatusCtlRecord(mdsOasisStatusCtl);
        }

        logger.debug("*****************************Enter Service Method createCmriNotification *******************************************");

        return;
    }

    /**
     * 
     * @param cmriNotificationCtlDto
     */

    @WebMethod(operationName = "updateCmriNotification")
    public void updateCmriNotification(@WebParam(name = "cmriNotificationCtlDto") CmriNotificationCtlDto cmriNotificationCtlDto) {

        logger.debug("*****************************Enter Service Method updateCmriNotification *******************************************");
        logger.debug("Notification Ctl ID : " + cmriNotificationCtlDto.getNotificationCtlId());
        MdsNotificationCtlCmri mdsNotificationCtlCmri = populateNotificationCtlCmriObject(cmriNotificationCtlDto);

        mdsCmriNotificationCtlDao.updateCmriNotification(mdsNotificationCtlCmri);

        logger.debug("*****************************Enter Service Method updateCmriNotification *******************************************");

        return;
    }

    /**
     * 
     * @param cmriNotificationCtlDto
     * @return
     */

    @WebMethod(operationName = "getCmriNotificationCtlByMarketId")
    @WebResult(name = "CmriNotificationCtlDto")
    public CmriNotificationCtlDto getCmriNotificationCtlByMarketId(@WebParam(name = "cmriNotificationCtlDto") CmriNotificationCtlDto cmriNotificationCtlDto) {

        logger.debug("******************* Enter Web Service Method getCmriNotificationCtlByMarketIDAndStatus *******************");

        MdsNotificationCtlCmri mdsNotificationCtlCmri = new MdsNotificationCtlCmri();
        mdsNotificationCtlCmri.setMarketId(cmriNotificationCtlDto.getMarketId());
        mdsNotificationCtlCmri.setStatus(cmriNotificationCtlDto.getStatus());

        logger.debug("CMRI Market Plan Id 		:" + cmriNotificationCtlDto.getMarketId());
        logger.debug("Cmri Market Status 	:" + cmriNotificationCtlDto.getStatus());

        mdsNotificationCtlCmri = mdsCmriNotificationCtlDao.getCmriNotificationCtlByMarketId(mdsNotificationCtlCmri);

        if (mdsNotificationCtlCmri != null) {

            logger.debug("CMRI Record with MarketId Found with ID 	:" + mdsNotificationCtlCmri.getNotificationCtlId());

            enrichMdsNotificationCtlCmriObject(cmriNotificationCtlDto, mdsNotificationCtlCmri);
            logger.debug(" cmriNotificationCtlDto Status 				:" + cmriNotificationCtlDto.getStatus());
            logger.debug(" cmriNotificationCtlDto.getNotificationCtlId 	:" + cmriNotificationCtlDto.getNotificationCtlId());

        } else {

            logger.debug("No Record for Market Plan Id Found :" + cmriNotificationCtlDto.getMarketId());

        }

        logger.debug("************************* Exiting Service Method getCmriNotificationCtlByMarketIDAndStatus *************************");

        return cmriNotificationCtlDto;
    }

    /**
     * 
     * @param cmriNotificationCtlDto
     * @param mdsNotificationCtlCmri
     */
    private void enrichMdsNotificationCtlCmriObject(CmriNotificationCtlDto cmriNotificationCtlDto, MdsNotificationCtlCmri mdsNotificationCtlCmri) {
        cmriNotificationCtlDto.setMarketId(mdsNotificationCtlCmri.getMarketId());
        cmriNotificationCtlDto.setMarketRunId(mdsNotificationCtlCmri.getMarketRunId());
        cmriNotificationCtlDto.setNotificationCtlId(mdsNotificationCtlCmri.getNotificationCtlId());
        cmriNotificationCtlDto.setNotificationComments(mdsNotificationCtlCmri.getNotificationComments());
        cmriNotificationCtlDto.setStatus(mdsNotificationCtlCmri.getStatus());
        cmriNotificationCtlDto.setCreatedDts(mdsNotificationCtlCmri.getCreatedDts());
        cmriNotificationCtlDto.setMdsFlowEndDts(mdsNotificationCtlCmri.getMdsFlowEndDts());
        cmriNotificationCtlDto.setMdsFlowStartDts(mdsNotificationCtlCmri.getMdsFlowStartDts());
        cmriNotificationCtlDto.setMdsFlowState(mdsNotificationCtlCmri.getMdsFlowState());
        cmriNotificationCtlDto.setNotificationName(mdsNotificationCtlCmri.getNotificationName());
        cmriNotificationCtlDto.setTradeDt(mdsNotificationCtlCmri.getTradeDt());
        cmriNotificationCtlDto.setUpdatedDts(mdsNotificationCtlCmri.getUpdatedDts());
        cmriNotificationCtlDto.setUpdateUser("mds_bpm");
    }

    /**
     * 
     * @param cmriNotificationCtlDto
     * @return
     */
    @WebMethod(operationName = "getCmriNotificationCtlInReadyStatusAndMdsFlowStatusNull")
    @WebResult(name = "CmriNotificationCtlDto")
    public CmriMarketToPublishResponse getCmriNotificationCtlInReadyStatusAndMdsFlowStatusNull(
            @WebParam(name = "CmriMarketToPublishRequest") CmriMarketToPublishRequest cmriMarketToPublishRequest) {

        logger.debug("*****************************Enter Service Method getCmriNotificationCtlByMarketIDAndStatus *****************************************************");
        logger.debug(" Dto Object    " + cmriMarketToPublishRequest);
        CmriNotificationCtlDto cmriNotificationCtlDto = null;
        CmriMarketToPublishResponse cmriMarketToPublishResponse = null;

        MdsNotificationCtlCmri mdsNotificationCtlCmri = new MdsNotificationCtlCmri();

        mdsNotificationCtlCmri.setStatus(cmriMarketToPublishRequest.getCmriStatus());
        mdsNotificationCtlCmri.setMdsFlowState(cmriMarketToPublishRequest.getMdsFlowState());
        mdsNotificationCtlCmri.setNotificationName(cmriMarketToPublishRequest.getNotificationName());

        mdsNotificationCtlCmri = mdsCmriNotificationCtlDao.getCmriNotificationCtlInReadyStatusAndMdsFlowStatusNull(mdsNotificationCtlCmri);

        if (mdsNotificationCtlCmri != null) {

            logger.debug(" Found The row  ");
            cmriNotificationCtlDto = new CmriNotificationCtlDto();
            enrichMdsNotificationCtlCmriObject(cmriNotificationCtlDto, mdsNotificationCtlCmri);

            cmriMarketToPublishResponse = new CmriMarketToPublishResponse();
            cmriMarketToPublishResponse.setCmriNotificationCtlDto(cmriNotificationCtlDto);
            cmriMarketToPublishResponse.setResponseResult("Found");

            logger.debug(" newInstance Notification Ctl Id : " + mdsNotificationCtlCmri.getNotificationCtlId());
            logger.debug(" cmriNotificationCtlDto Status :" + mdsNotificationCtlCmri.getStatus());
            logger.debug(" cmriNotificationCtlDto.getNotificationCtlId :" + mdsNotificationCtlCmri.getNotificationCtlId());

        } else {

            cmriMarketToPublishResponse = new CmriMarketToPublishResponse();
            cmriMarketToPublishResponse.setCmriNotificationCtlDto(cmriNotificationCtlDto);
            cmriMarketToPublishResponse.setResponseResult("NotFound");

        }

        logger.debug("*****************************Exiting Service Method getCmriNotificationCtlByMarketIDAndStatus *****************************************************");

        return cmriMarketToPublishResponse;
    }

    /**
     * 
     * @param cmriOasisStatusCtlDto
     */
    @WebMethod(operationName = "createMdsOasisStatusCtl")
    public void createMdsOasisStatusCtl(@WebParam(name = "cmriOasisStatusCtlDto") CmriOasisStatusCtlDto cmriOasisStatusCtlDto) {

        logger.debug("*****************************Enter Service Method saveOrUpdateMdsOasisStatusCtl *******************************************");
        MdsOasisStatusCtl mdsOasisStatusCtl = populateOasisStatusCtl(cmriOasisStatusCtlDto);

        mdsCmriNotificationCtlDao.createMdsOasisStatusCtlRecord(mdsOasisStatusCtl);
        logger.debug("*****************************Exiting Service Method saveOrUpdateMdsOasisStatusCtl *******************************************");
        return;
    }

    /**
     * 
     * @param cmriOasisStatusCtlDto
     * @return
     */
    private MdsOasisStatusCtl populateOasisStatusCtl(CmriOasisStatusCtlDto cmriOasisStatusCtlDto) {
        MdsOasisStatusCtl mdsOasisStatusCtl = new MdsOasisStatusCtl();
        MdsOasisStatusCtlId mdsOasisStatusCtlId = new MdsOasisStatusCtlId();
        mdsOasisStatusCtlId.setStatus(cmriOasisStatusCtlDto.getStatus());
        mdsOasisStatusCtlId.setMarketId(cmriOasisStatusCtlDto.getMarketId());
        mdsOasisStatusCtlId.setMarketRunId(cmriOasisStatusCtlDto.getMarketRunId());
        mdsOasisStatusCtlId.setNotificationName(cmriOasisStatusCtlDto.getNotificationName());
        mdsOasisStatusCtlId.setNotificationComments(cmriOasisStatusCtlDto.getNotificationComments());
        mdsOasisStatusCtlId.setCreatedDts(new Date());
        mdsOasisStatusCtl.setId(mdsOasisStatusCtlId);
        return mdsOasisStatusCtl;
    }

}

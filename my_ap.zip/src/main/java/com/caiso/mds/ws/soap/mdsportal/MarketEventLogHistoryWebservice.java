package com.caiso.mds.ws.soap.mdsportal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.soa.proxies.mdsportal.marketeventlog.FaultReturnType;
import com.caiso.soa.proxies.mdsportal.marketeventlog.MarketEventLog;
import com.caiso.soa.proxies.mdsportal.marketeventlog.MarketEventLogMSG;
import com.caiso.soa.proxies.mdsportal.marketeventlog.MarketEventLogProcessRequest;

public class MarketEventLogHistoryWebservice implements MarketEventLog {

    @Autowired
    private MarketEventLogHistoryWebserviceHelper marketEventLogHistoryWebserviceHelper;

    private final static Logger                   logger = LoggerFactory.getLogger(MarketEventLogHistoryWebservice.class);

    @Override
    public MarketEventLogMSG process(MarketEventLogProcessRequest payload) throws FaultReturnType {

        String inputString = payload.getInput();
        logger.debug("********** ENTERING MDS PORTAL REQUEST ************************");
        MarketEventLogMSG marketEventLogMSG = marketEventLogHistoryWebserviceHelper.getMarketEventLogMsg(inputString);
        logger.debug("********** EXITING MDS PORTAL REQUEST ************************");
        return marketEventLogMSG;
    }
}

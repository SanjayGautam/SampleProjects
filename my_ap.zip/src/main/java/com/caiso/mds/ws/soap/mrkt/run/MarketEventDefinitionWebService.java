package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.mrkt.run.service.MarketEventDefinitionService;

@WebService(name = "MarketEventDefinitionService", portName = "MarketEventDefinitionServicePort", serviceName = "MarketEventDefinitionService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketEventDefinitionWebService {

    private final Logger                 logger = LoggerFactory.getLogger(MarketEventDefinitionWebService.class);

    @Autowired
    private MarketEventDefinitionService marketEventDefinitionService;

    /**
     * For market event code it gets the market event details from the database
     * 
     * @param marketEventDefinitionDto
     * @return
     */
    @WebMethod(operationName = "getMarketEventDefinitionDetails")
    @WebResult(name = "MarketEventNotificationDto")
    public MarketEventDefinitionDto getMarketEventDefinitionDetails(
            @WebParam(name = "marketEventDefinitionDto", targetNamespace = "http://dto.mds.caiso.com/") MarketEventDefinitionDto marketEventDefinitionDto) {
        logger.debug("*****  Entering Method getMarketEventDefinitionDetails ********");

        marketEventDefinitionDto = marketEventDefinitionService.getMarketEventDefinitionByEventDefCode(marketEventDefinitionDto);

        logger.debug("*****  Exiting Method getMarketEventDefinitionDetails ********");

        return marketEventDefinitionDto;
    }

    /**
     * This service will get the Market Event Definition for the Market Event
     * Type and Market Def Id Provided
     * 
     * @param marketEventDefId
     * @param marketEventType
     * @return
     */

    @WebMethod(operationName = "getMarketEventDefinitionForMarketEventTypeAndMarketDefId")
    @WebResult(name = "MarketEventNotificationDto")
    public MarketEventDefinitionDto getMarketEventDefinitionForMarketEventTypeAndMarketDefId(@WebParam(name = "marketEventDefId") long marketEventDefId,
            @WebParam(name = "marketEventType") String marketEventType) {
        logger.debug("*****  Entering Method getMarketEventDefinitionForMarketEventTypeAndMarketDefId ********");

        MarketEventDefinitionDto marketEventDefinitionDto = marketEventDefinitionService.getMarketEventDefinitionForMarketEventTypeAndMarketDefId(
                marketEventDefId, marketEventType);

        logger.debug("*****  Exiting Method getMarketEventDefinitionForMarketEventTypeAndMarketDefId ********");

        return marketEventDefinitionDto;
    }
}

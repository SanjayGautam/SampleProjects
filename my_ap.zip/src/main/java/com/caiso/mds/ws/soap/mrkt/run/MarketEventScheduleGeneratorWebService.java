package com.caiso.mds.ws.soap.mrkt.run;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.dto.MarketEventNotificationsRequest;
import com.caiso.mds.exception.MdsBpmException;
import com.caiso.mds.exception.ServiceException;
import com.caiso.mds.exception.ServiceExceptionDetails;
import com.caiso.mds.exception.ServiceExceptionName;
import com.caiso.mds.mrkt.run.service.MarketEventScheduleGeneratorService;

@WebService(name = "MarketEventScheduleGeneratorService", portName = "MarketEventScheduleGeneratorServicePort", serviceName = "MarketEventScheduleGeneratorService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketEventScheduleGeneratorWebService {

    private final Logger                        logger = LoggerFactory.getLogger(MarketEventScheduleGeneratorWebService.class);

    @Autowired
    private MarketEventScheduleGeneratorService marketEventScheduleGeneratorService;

    /**
     * This method will generate Market Events Schedule based on the number of
     * days the generator is configured. This service is controlled by timer and
     * whenever this service is called it checks for the market schedule already
     * in the database and if there are less than 7 days of data from the
     * sysdate then it goes ahead and creates the market schedules from the last
     * record which is available.
     * 
     * 
     * @throws ServiceException
     */
    @WebMethod(operationName = "generateMarketEventsSchedule")
    public void generateMarketEventsSchedule() throws ServiceException {
        logger.debug("**** Entered generateMarketEventSchedules ******** ");
        try {
            marketEventScheduleGeneratorService.generateEventSchedules();
        } catch (MdsBpmException e) {

            throw new ServiceException(ServiceExceptionName.UnableToGenerateEventsSchedule.getMessage(), prepareException(e));

        }
        logger.debug("**** Exiting generateMarketEventSchedules ******** ");
    }

    /**
     * 
     * @param marketEventNotificationDto
     */
    @WebMethod(operationName = "updateMarketEventSchedule")
    public void updateMarketEventSchedule(
            @WebParam(name = "marketEventNotificationDto", targetNamespace = "http://dto.mds.caiso.com/") MarketEventNotificationDto marketEventNotificationDto) {
        logger.debug("**** Entered generateMarketEventSchedules ******** ");
        try {
            marketEventScheduleGeneratorService.updateMarketEventSchedule(marketEventNotificationDto);

        } catch (Exception e) {
            logger.error("Error while updating the market schedules  ", e);
        }
        logger.debug("**** Exiting generateMarketEventSchedules ******** ");
    }

    /**
     * 
     * @param marketEventNotificationDto
     */

    @WebMethod(operationName = "updateMarketEventSchedules")
    public void updateMarketEventSchedules(
            @WebParam(name = "marketEventNotificationsRequest", targetNamespace = "http://dto.mds.caiso.com/") MarketEventNotificationsRequest marketEventNotificationsRequest) {

        logger.debug("**** Entered generateMarketEventSchedules ******** ");
        try {

            List<MarketEventNotificationDto> marketEventNotificationDtos = marketEventNotificationsRequest.getMarketEventNotifications();

            for (MarketEventNotificationDto marketEventNotificationDto : marketEventNotificationDtos) {
                marketEventScheduleGeneratorService.updateMarketEventSchedule(marketEventNotificationDto);
            }

        } catch (Exception e) {
            logger.error("Error while updating the market schedules  ", e);
        }
        logger.debug("**** Exiting generateMarketEventSchedules ******** ");
    }

    /**
     * 
     * @param e
     * @return
     */
    private ServiceExceptionDetails[] prepareException(MdsBpmException e) {
        ServiceExceptionDetails expDetails = new ServiceExceptionDetails();
        expDetails.setFaultCode(ServiceExceptionName.UnableToGenerateEventsSchedule.getErrorCode());
        expDetails.setUserFriendlyExceptionMessage(ServiceExceptionName.UnableToGenerateEventsSchedule.getMessage());
        expDetails.setDetailedExceptionMessage(e.getMessage());
        ServiceExceptionDetails details[] = { expDetails };
        return details;
    }
}

package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.mrkt.run.service.MarketSysOperatorMsgService;

@WebService(name = "MdsMarketOperatingMessagesToOasisSyncService", portName = "MdsMarketOperatingMessagesToOasisSyncServicePort", serviceName = "MdsMarketOperatingMessagesToOasisSyncService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MdsMarketOperatingMessagesToOasisSyncWebService {

    private final Logger                logger = LoggerFactory.getLogger(MdsMarketOperatingMessagesToOasisSyncWebService.class);

    @Autowired
    private MarketSysOperatorMsgService marketSysOperatorMsgService;

    /**
     * For market event code it gets the market event details from the database
     * 
     * @param marketEventDefinitionDto
     * @return
     */
    @WebMethod(operationName = "syncMdsOperatingMessagesToOasis")
    @WebResult(name = "SyncResult")
    public String syncMdsAndOasisOperatingMessages() {
        logger.debug("*****  Entering Method syncMdsAndOasisOperatingMessages ********");

        marketSysOperatorMsgService.syncMdsOperatingMessageToOasis();
        logger.debug("*****  Entering Method syncMdsAndOasisOperatingMessages ********");

        return "Done";
    }

}

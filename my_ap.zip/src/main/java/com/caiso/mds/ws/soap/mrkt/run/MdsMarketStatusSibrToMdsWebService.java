package com.caiso.mds.ws.soap.mrkt.run;

import java.util.UUID;

import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.external.ws.service.MdsToMnsService;
import com.caiso.mds.mrkt.run.service.MarketEventsToPublishService;
import com.caiso.mds.mrkt.run.service.MarketPlanServiceHelper;
import com.caiso.mds.mrkt.run.service.MarketStatusService;
import com.caiso.mds.util.DateUtil;
import com.caiso.mds.util.OutputTypeResponseHelper;
import com.caiso.soa.proxies.mds.marketstatus.BroadcastSIBRMarketStatusV1;
import com.caiso.soa.proxies.mds.marketstatus.FaultReturnType;
import com.caiso.soa.proxies.mds.marketstatus.MarketStatus;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@SOAPBinding(style = Style.DOCUMENT)
public class MdsMarketStatusSibrToMdsWebService implements BroadcastSIBRMarketStatusV1 {

    private final static Logger          logger = LoggerFactory.getLogger(MdsMarketStatusSibrToMdsWebService.class);

    @Autowired
    private MarketStatusService          marketStatusService;

    @Autowired
    private DateUtil                     dateUtil;

    @Autowired
    private OutputTypeResponseHelper     outputTypeResponseHelper;

    @Autowired
    private MdsToMnsService              mdsToMnsService;

    @Autowired
    private MarketPlanServiceHelper      marketPlanServiceHelper;

    @Autowired
    private MarketEventsToPublishService marketEventsToPublishService;

    /**
     * This method is for the incoming from SIBR and it will update the database
     * with the market status provided to it. Market status history table will
     * also get updated.
     * 
     */
    @Override
    public OutputDataType broadcastSIBRMarketStatusV1(MarketStatus marketStatus) throws FaultReturnType {

        logger.info("********* Recieved Request From SIBR: ************ ");

        OutputDataType outputDataType = null;

        if (marketStatus != null) {
            logger.info("Message Received from SIBR:" + marketStatus.getMarketRun());
        }

        try {
            if (marketStatus != null) {

                marketStatusService.changeMarketStatusesInMds(marketStatus, "Updated By SIBR requests");

                marketEventsToPublishService.updateEventHistoryAndSendMnsMessages(marketStatus);

                outputDataType = outputTypeResponseHelper.prepareResponse("SCSS0001", UUID.randomUUID().toString(), "broadcastMarketStatus_v1",
                        "broadcastMarketStatus_v1 : Received Data From SIBR ", "INFO", "SVC", "broadcastMarketStatus_v1 : Received Data From SIBR",
                        "broadcastMarketStatus_v1 : Received Data From SIBR");
            }

        } catch (Exception e) {
            logger.error("Error while processing request from SIBR MdsMarketStatusSibrToMdsWebService", e);

            outputDataType = outputTypeResponseHelper.prepareResponse("SVC0001", UUID.randomUUID().toString(), "System Error",
                    "An unexpected error occured while processing your request. Please check the logs for more details.", "ERROR", "GNRL0001",
                    "Failed to update the Market Status in MDS", " Failed to update MarketStatus in MDS");
        }

        logger.info("****** Successfully Processed the Message From SIBR *****************");

        return outputDataType;
    }

}

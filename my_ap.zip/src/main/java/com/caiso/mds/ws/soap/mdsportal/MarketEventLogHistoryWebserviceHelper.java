package com.caiso.mds.ws.soap.mdsportal;

import java.util.List;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.mrkt.run.service.MarketEventHistoryService;
import com.caiso.mds.ui.vo.MarketEventNotificationLogsResultVO;
import com.caiso.mds.ui.vo.MarketEventNotificationVO;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mdsportal.marketeventlog.MarketEventLogMSG;
import com.caiso.soa.proxies.mdsportal.marketeventlog.MarketEventLogResp;
import com.caiso.soa.proxies.mdsportal.marketeventlog.ObjectFactory;

@Component
public class MarketEventLogHistoryWebserviceHelper {

    @SuppressWarnings("unused")
    private final static Logger       logger                   = LoggerFactory.getLogger(MarketEventLogHistoryWebserviceHelper.class);

    @Autowired
    private MarketEventHistoryService marketEventHistoryService;

    @Autowired
    private DateUtil                  dateUtil;

    private ObjectFactory             marketEventLogObjFactory = new ObjectFactory();

    /**
     * 
     * @param inputString
     * @return
     */
    public MarketEventLogMSG getMarketEventLogMsg(String inputString) {

        MarketEventNotificationLogsResultVO eventLog = marketEventHistoryService.getMarketEventNotificationLog(1);

        int pageCount = eventLog.getTotalPagesCount();

        MarketEventLogMSG allMarketEventLog = marketEventLogObjFactory.createMarketEventLogMSG();

        for (int i = 1; i <= pageCount; i++) {

            MarketEventNotificationLogsResultVO eventLogMsg = marketEventHistoryService.getMarketEventNotificationLog(i);

            List<MarketEventNotificationVO> list = eventLogMsg.getMarketEventNotificationLogs();
            for (MarketEventNotificationVO marketEventNotificationVO : list) {
                MarketEventLogResp marketEventResp = marketEventLogObjFactory.createMarketEventLogResp();
                marketEventResp.setEventID(marketEventNotificationVO.getMarketEventDefCode());
                marketEventResp.setEventTime(dateUtil.getGeorgianDate(marketEventNotificationVO.getMarketEventTime()));
                marketEventResp.setNotificationMessage(marketEventNotificationVO.getMarketEventNotificationMsg());
                marketEventResp.setTradeHour(marketEventNotificationVO.getMarketHour());
                marketEventResp.setTradeDate(dateUtil.convertDateToStringFormat(marketEventNotificationVO.getMarketDate(), DateUtil.PATTERN_MM_dd_yyyy,
                        TimeZone.getTimeZone("US/Pacific")));
                allMarketEventLog.getMarketEventLog().add(marketEventResp);
            }

        }

        return allMarketEventLog;
    }
}

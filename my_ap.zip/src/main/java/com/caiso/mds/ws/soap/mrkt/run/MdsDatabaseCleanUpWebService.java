package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.mrkt.run.service.DatabaseCleanUpService;

@WebService(name = "MdsDatabaseCleanUpService", portName = "MdsDatabaseCleanUpServicePort", serviceName = "MdsDatabaseCleanUpService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MdsDatabaseCleanUpWebService {

    private final Logger           logger = LoggerFactory.getLogger(MdsDatabaseCleanUpWebService.class);

    @Autowired
    private DatabaseCleanUpService databaseCleanUpService;

    /**
     * For market event code it gets the market event details from the database
     * 
     * @param marketEventDefinitionDto
     * @return
     */
    @WebMethod(operationName = "mdsDatabaseCleanUp")
    @WebResult(name = "cleanUpResults")
    public String syncMdsAndOasisOperatingMessages() {
        logger.debug("*****  Entering Method MdsDatabaseCleanUpWebService ********");

        int recordsDeleted = databaseCleanUpService.cleanupDatabase();
        logger.debug("*****  Entering Method MdsDatabaseCleanUpWebService ********");

        return "Records Deleted In MDSCleanUpJob :" + recordsDeleted;
    }

}

package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MdsLogDto;
import com.caiso.mds.mrkt.run.service.MdsLogService;

@WebService(name = "MdsLoggingService", portName = "MdsLoggingServicePort", serviceName = "MdsLoggingService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MdsLogWebService {

    private final Logger  logger = LoggerFactory.getLogger(MdsLogWebService.class);

    @Autowired
    private MdsLogService mdsLogService;

    @WebMethod(operationName = "log")
    public void log(@WebParam(name = "mdsLog", targetNamespace = "http://dto.mds.caiso.com/") MdsLogDto mdsLogDto) {
        logger.info("***** Entered the log ******** ");
        mdsLogService.log(mdsLogDto);
        logger.info("**** Exiting the log ****** ");

    }

}

package com.caiso.mds.ws.soap.mdsportal;

import java.util.List;

import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.mrkt.run.service.MarketSysOperatorMsgService;
import com.caiso.mds.ui.vo.MarketSystemOperatorMessageVO;
import com.caiso.soa.proxies.mdsportal.operatormsg.FaultReturnType;
import com.caiso.soa.proxies.mdsportal.operatormsg.MarketMessages;
import com.caiso.soa.proxies.mdsportal.operatormsg.MarketMessagesOutput;
import com.caiso.soa.proxies.mdsportal.operatormsg.MarketMessagesProcessRequest;

@SOAPBinding(style = Style.DOCUMENT)
public class OperatorMarketMessagesWebService implements MarketMessages {

    private final static Logger                 logger = LoggerFactory.getLogger(OperatorMarketMessagesWebService.class);

    @Autowired
    private MarketSysOperatorMsgService         marketSysOperatorMsgService;

    @Autowired
    private OperatorMarketMessagesServiceHelper operatorMarketMessagesServiceHelper;

    @Override
    public MarketMessagesOutput process(MarketMessagesProcessRequest payload) throws FaultReturnType {

        logger.info("******************* Entered the MDS Portal request Webservice *********************");
        String requestFromMdsPortal = payload.getInput();
        logger.info("requestFromMdsPortal :" + requestFromMdsPortal);

        List<MarketSystemOperatorMessageVO> operatorMessages = marketSysOperatorMsgService.getLast24HourOperatorMessages();
        MarketMessagesOutput marketMessagesOut = operatorMarketMessagesServiceHelper.getMarketMessagesOuput(operatorMessages);

        return marketMessagesOut;
    }

}

package com.caiso.mds.ws.soap.mrkt.run;

import java.util.Date;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.dto.MarketPlanServiceResponse;
import com.caiso.mds.exception.MdsBpmException;
import com.caiso.mds.exception.ServiceException;
import com.caiso.mds.exception.ServiceExceptionDetails;
import com.caiso.mds.exception.ServiceExceptionName;
import com.caiso.mds.mrkt.run.service.MarketPlanService;
import com.caiso.mds.types.MarketPlanGenerationOptions;
import com.caiso.mds.types.MarketType;

@WebService(name = "MarketPlanService", portName = "MarketPlanServicePort", serviceName = "MarketPlanService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketPlanWebService {

    private final Logger      logger = LoggerFactory.getLogger(MarketPlanWebService.class);

    @Autowired
    private MarketPlanService marketPlanService;

    /**
     * This service method generate the market plan for the market dates in
     * advance, The method will generate market plans and store it in database
     * and market plans only generated when the records in the database is not
     * enough for the next seven days. Keeping the DA Ahead market cycle.
     * 
     * 
     * @param marketPlanGenerationOptions
     * @throws ServiceException
     */
    @WebMethod(operationName = "generateMarketPlan")
    public void generateMarketPlan(@WebParam(name = "marketPlanGenerationOption") String marketPlanGenerationOptions) throws ServiceException {

        try {
            switch (MarketPlanGenerationOptions.valueOf(marketPlanGenerationOptions)) {
            case GENERATE_DAM:
                generateMarketPlan(MarketPlanGenerationOptions.valueOf(marketPlanGenerationOptions), MarketType.DAM);
                break;
            case GENERATE_RTM:
                generateMarketPlan(MarketPlanGenerationOptions.valueOf(marketPlanGenerationOptions), MarketType.RTM);
                break;
            case GENERATE_BOTH:
                generateMarketPlan(MarketPlanGenerationOptions.valueOf(marketPlanGenerationOptions), MarketType.RTM);
                generateMarketPlan(MarketPlanGenerationOptions.valueOf(marketPlanGenerationOptions), MarketType.DAM);
                break;
            default:
                break;
            }
        } catch (MdsBpmException e) {

            throw new ServiceException(ServiceExceptionName.UnableToGenerateMarketPlans.getMessage(), prepareException(e));

        }

    }

    /**
     * This method provides the market details i.e. Market Plans for the market
     * Plan and market Run id if it is present in the database
     * 
     * @param marketPlanId
     * @param marketRunId
     * @return
     */

    @WebMethod(operationName = "getMarketDetails")
    @WebResult(name = "MarketPlanServiceResponse")
    public MarketPlanServiceResponse getMarketDetails(@WebParam(name = "marketPlanId") String marketPlanId, @WebParam(name = "marketRunId") String marketRunId) {

        logger.debug("******* Entering Get Market Details  ******** ");
        MarketPlanServiceResponse marketPlanServiceResponse = marketPlanService.getMarketDetails(marketPlanId, marketRunId);
        logger.debug("******* Exciting Get Market Details ******** ");

        return marketPlanServiceResponse;

    }

    /**
     * This service method will return all the market plans which are on the
     * market date and belong to the market defid provided
     * 
     * @param marketDate
     * @param marketDefId
     * @return
     */
    @WebMethod(operationName = "getMarketPlans")
    @WebResult(name = "MarketPlanServiceResponse")
    public MarketPlanServiceResponse getMarketPlans(@WebParam(name = "marketDate") Date marketDate, @WebParam(name = "marketDefId") Long marketDefId) {

        MarketPlanServiceResponse response = new MarketPlanServiceResponse();

        logger.debug("******* Entering method getMarketPlans  ******** ");
        logger.info("getting Marketplans for Market plan trade date :{}  and for market def id :{}", marketDate.toString(), marketDefId);

        List<MarketPlanDto> marketPlanDtos = marketPlanService.getMarketPlanDtos(marketDate, marketDefId);

        if (marketPlanDtos.size() > 0) {
            response.setMarketPlans(marketPlanDtos);
            response.setResponseResult("Found");
            logger.info("Market Plans Found :{} for Market plan trade date :{}  and for market def id :{}", marketPlanDtos.size(), marketDate.toString(),
                    marketDefId);
        } else {

            response.setMarketPlans(marketPlanDtos);
            response.setResponseResult("NoDataFound");
            logger.info("Market Plans Not Found for Market plan trade date :{}  and for market def id :{}", marketDate.toString(), marketDefId);
        }

        logger.debug("******* Exiting method getMarketPlans  ******** ");

        return response;

    }

    /**
     * This service method will provide market plans for the market plan id and
     * Market Def Id Provide to the methods
     * 
     * @param marketPlanId
     * @param marketDefId
     * @return
     */
    @WebMethod(operationName = "getMarketPlansForMarketPlanIdAndMarketDefId")
    @WebResult(name = "MarketPlanServiceResponse")
    public MarketPlanServiceResponse getMarketPlansForMarketPlanIdAndMarketDefId(@WebParam(name = "marketPlanId") String marketPlanId,
            @WebParam(name = "marketDefId") Long marketDefId) {

        logger.debug("******* Entered method getMarketPlansForMarketPlanIdAndMarketDefId  ******** ");

        List<MarketPlanDto> marketPlanDtos = marketPlanService.getMarketPlansForMarketPlanIdAndMarketDefId(marketPlanId, marketDefId);

        MarketPlanServiceResponse marketPlanServiceResponse = null;

        if (marketPlanDtos != null && !marketPlanDtos.isEmpty()) {
            marketPlanServiceResponse = new MarketPlanServiceResponse();
            marketPlanServiceResponse.setMarketPlans(marketPlanDtos);
            marketPlanServiceResponse.setResponseResult("Found");
            logger.info("Market Plans for Market Plan id:{} and Market Def id:{} Found ", marketPlanId, marketDefId);

        } else {

            marketPlanServiceResponse = new MarketPlanServiceResponse();
            marketPlanServiceResponse.setResponseResult("NotFound");
            logger.info("Market Plans for Market Plan id:{} and Market Def id:{} Not Found", marketPlanId, marketDefId);
        }

        logger.debug("******* Exiting method getMarketPlansForMarketPlanIdAndMarketDefId  ******** ");

        return marketPlanServiceResponse;

    }

    /**
     * This service method will provide the market status for the market plan id
     * and market Def id provided to this method. We should use when we want to
     * find out the whether market is open close pre_close or post_close state.
     * 
     * @param marketPlanId
     * @param marketDefId
     * @return
     */

    @WebMethod(operationName = "getMarketStatus")
    @WebResult(name = "marketStatus")
    public String getMarketStatus(@WebParam(name = "marketPlanId") String marketPlanId, @WebParam(name = "marketDefId") Long marketDefId) {

        logger.info("******* Entering Get Market Details  ******** ");

        String marketStatus = marketPlanService.getMarketStatus(marketPlanId, marketDefId);

        logger.info("******* Exciting Get Market Details ******** ");

        return marketStatus;

    }

    /**
     * This method is util method to generate the market plan for the market
     * type and the market operations.
     * 
     * @param marketPlanGenerationOptions
     * @param marketType
     * @throws MdsBpmException
     */

    private void generateMarketPlan(MarketPlanGenerationOptions marketPlanGenerationOptions, MarketType marketType) throws MdsBpmException {
        logger.info(" Got the request to Generate Market Plans for  Market Type " + marketType.getName() + " Generation Option was :"
                + marketPlanGenerationOptions.getName());
        marketPlanService.generateMarketPlanByMarketType(marketType);
        logger.info(" **** Existing Market Plan Generator Services ********* ");
    }

    /**
     * 
     * @param e
     * @return
     */
    private ServiceExceptionDetails[] prepareException(MdsBpmException e) {
        ServiceExceptionDetails expDetails = new ServiceExceptionDetails();
        expDetails.setFaultCode(ServiceExceptionName.UnableToGenerateMarketPlans.getErrorCode());
        expDetails.setUserFriendlyExceptionMessage(ServiceExceptionName.UnableToGenerateMarketPlans.getMessage());
        expDetails.setDetailedExceptionMessage(e.getMessage());
        ServiceExceptionDetails details[] = new ServiceExceptionDetails[1];
        // details[]= {expDetails};
        details[0] = expDetails;
        return details;
    }
}

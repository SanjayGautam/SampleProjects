package com.caiso.mds.ws.soap.mdsportal;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.mrkt.run.service.MarketPlanService;
import com.caiso.mds.types.MarketType;
import com.caiso.mds.ui.vo.BidAndSchedulesStatusVO;
import com.caiso.mds.ui.vo.InterScTradesStatusVO;
import com.caiso.mds.ui.vo.MarketStatusVO;
import com.caiso.mds.ui.vo.MarketStatuses;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mdsportal.marketstatus.MarketRunMktStatusMsg;
import com.caiso.soa.proxies.mdsportal.marketstatus.MarketStatus;
import com.caiso.soa.proxies.mdsportal.marketstatus.MarketStatusType;
import com.caiso.soa.proxies.mdsportal.marketstatus.ObjectFactory;

@Component
public class MarketStatusHistoryWebserviceHelper {

    @Autowired
    private MarketPlanService marketPlanService;
    @Autowired
    private DateUtil          dateUtil;

    private ObjectFactory     marketstatusObjectFactory = new ObjectFactory();

    public MarketStatus getMarketStatusForAllMarkets(Date tradeDate) {

        MarketStatus allMarketStatus = marketstatusObjectFactory.createMarketStatus();

        List<MarketStatusVO> damStatus = getDamStatus(tradeDate);
        for (MarketStatusVO marketStatusVO : damStatus) {
            setMarketStatuses(allMarketStatus, marketStatusVO);
        }

        List<MarketStatusVO> rtmStatus = getRtmStatus(tradeDate);
        for (MarketStatusVO marketStatusVO : rtmStatus) {
            setMarketStatuses(allMarketStatus, marketStatusVO);
        }

        return allMarketStatus;
    }

    /**
     * 
     * @param allMarketStatus
     * @param marketStatusVO
     */

    private void setMarketStatuses(MarketStatus allMarketStatus, MarketStatusVO marketStatusVO) {
        MarketRunMktStatusMsg bidsAndSchedulesStatus = setBidAndSchedulesStatus(marketStatusVO);
        allMarketStatus.getMarketRun().add(bidsAndSchedulesStatus);

        MarketRunMktStatusMsg interScTradesMarketStatus = setInterScTradesStatus(marketStatusVO);
        allMarketStatus.getMarketRun().add(interScTradesMarketStatus);
    }

    /**
     * 
     * @param tradeDate
     * @return
     */

    private List<MarketStatusVO> getRtmStatus(Date tradeDate) {
        MarketStatuses rtmMarketStatuses = marketPlanService.getMarketStatusForMainMarkets(MarketType.RTM, tradeDate);
        List<MarketStatusVO> rtmStatus = rtmMarketStatuses.getMarketStatusForRtmMarkets();
        return rtmStatus;
    }

    /**
     * 
     * @param tradeDate
     * @return
     */
    private List<MarketStatusVO> getDamStatus(Date tradeDate) {
        MarketStatuses damMarketStatuses = marketPlanService.getMarketStatusForMainMarkets(MarketType.DAM, tradeDate);
        List<MarketStatusVO> damStatus = damMarketStatuses.getMarketStatusForDamMarkets();
        return damStatus;
    }

    /**
     * 
     * @param marketStatusVO
     * @return
     */
    private MarketRunMktStatusMsg setInterScTradesStatus(MarketStatusVO marketStatusVO) {
        MarketRunMktStatusMsg marketRunStatusMsg = marketstatusObjectFactory.createMarketRunMktStatusMsg();

        InterScTradesStatusVO interScTradesStatusVO = marketStatusVO.getInterScTradesStatus();

        marketRunStatusMsg.setMarketID(interScTradesStatusVO.getMarketPlanId());
        marketRunStatusMsg.setMarketRunID(interScTradesStatusVO.getMarketRunId());
        marketRunStatusMsg.setMarketStartTime(dateUtil.getGeorgianDate(interScTradesStatusVO.getMarketDate()));
        marketRunStatusMsg.setMarketStatusTime(dateUtil.getGeorgianDate(new Date()));
        marketRunStatusMsg.setCurrentStatus(getCustomMarketStatusForMdsPortal(MarketStatusType.valueOf(interScTradesStatusVO.getMarketCurrentStatus())));
        marketRunStatusMsg.setMarketType(com.caiso.soa.proxies.mdsportal.marketstatus.MarketType.valueOf(interScTradesStatusVO.getMarketType()));
        marketRunStatusMsg.setMarketClass(com.caiso.soa.proxies.mdsportal.marketstatus.MarketClassType.valueOf(interScTradesStatusVO.getMarketClass()));
        return marketRunStatusMsg;

    }

    /**
     * As the MDS PORTAL is not having the schema in sync with the SIBR schema
     * we have to do this customisation. as they expecting PUBLISHED in the
     * sharepoint apis. instead of PUBLISH.
     * 
     * @param marketStatus
     * @return
     */

    private MarketStatusType getCustomMarketStatusForMdsPortal(MarketStatusType marketStatusType) {

        if (MarketStatusType.PUBLISH.equals(marketStatusType) || MarketStatusType.PUBLISHED.equals(marketStatusType)) {
            return MarketStatusType.PUBLISHED;
        } else {
            return marketStatusType;
        }

    }

    /**
     * 
     * @param marketStatusVO
     * @return
     */

    private MarketRunMktStatusMsg setBidAndSchedulesStatus(MarketStatusVO marketStatusVO) {
        MarketRunMktStatusMsg marketRunStatusMsg = marketstatusObjectFactory.createMarketRunMktStatusMsg();

        BidAndSchedulesStatusVO bidAndSchedulesStatusVO = marketStatusVO.getBidAndSchedulesStatus();

        marketRunStatusMsg.setMarketID(bidAndSchedulesStatusVO.getMarketPlanId());
        marketRunStatusMsg.setMarketRunID(bidAndSchedulesStatusVO.getMarketRunId());
        marketRunStatusMsg.setMarketStartTime(dateUtil.getGeorgianDate(bidAndSchedulesStatusVO.getMarketDate()));
        marketRunStatusMsg.setMarketStatusTime(dateUtil.getGeorgianDate(new Date()));
        marketRunStatusMsg.setCurrentStatus(getCustomMarketStatusForMdsPortal(MarketStatusType.valueOf(bidAndSchedulesStatusVO.getMarketCurrentStatus())));
        marketRunStatusMsg.setMarketType(com.caiso.soa.proxies.mdsportal.marketstatus.MarketType.valueOf(bidAndSchedulesStatusVO.getMarketType()));
        marketRunStatusMsg.setMarketClass(com.caiso.soa.proxies.mdsportal.marketstatus.MarketClassType.valueOf(bidAndSchedulesStatusVO.getMarketClass()));

        return marketRunStatusMsg;
    }
}

package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketPlanDto;
import com.caiso.mds.mrkt.run.service.MarketStatusService;

@WebService(name = "MarketStatusHistoryService", portName = "MarketStatusHistoryServicePort", serviceName = "MarketStatusHistoryService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketStatusWebService {

    private final Logger        logger = LoggerFactory.getLogger(MarketStatusWebService.class);

    @Autowired
    private MarketStatusService marketStatusService;

    /**
     * This method help in the changing the market status of the market inside
     * the mds databse This will also update the market status history details
     * in the database.
     * 
     * @param marketPlanDto
     */
    @WebMethod(operationName = "changeMarketStatus")
    public void changeMarketStatus(@WebParam(name = "marketPlan", targetNamespace = "http://dto.mds.caiso.com/") MarketPlanDto marketPlanDto,
            @WebParam(name = "changeStatusComment") String changeStatusComment) {
        logger.info("**** Entered change Market Status ********");
        logger.info(" Instance " + marketStatusService);
        marketStatusService.changeMarketStatus(marketPlanDto, changeStatusComment);

        logger.info("**** Exiting change Market Status ********");

    }

    /**
     * This method will provide the market status for the market plan id
     * provided
     * 
     * @param marketPlanId
     * @return
     */

    @WebMethod(operationName = "getLastMarketStatusForMarketRunId")
    public Long getLastMarketStatusForMarketRunId(@WebParam(name = "marketRunId") String marketRunId) {
        logger.info("**** Entered change Market Status ********");
        logger.info(" Instance " + marketStatusService);
        Long marketStatusHistoryId = marketStatusService.getLastMarketStatusForMarketRunId(marketRunId);
        if (marketStatusHistoryId == null) {
            logger.info("This is done as a hack , does not impacts the business rules.");
            marketStatusHistoryId = marketStatusService.getMaxMarketStatusHistoryId();
        }
        logger.info("**** Exiting change Market Status ********");
        return marketStatusHistoryId;
    }

}

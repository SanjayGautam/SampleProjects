package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketEventHistoryDto;
import com.caiso.mds.mrkt.run.service.MarketEventHistoryService;

@WebService(name = "MarketEventHistoryService", portName = "MarketEventHistoryServicePort", serviceName = "MarketEventHistoryService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketEventHistoryWebService {

    private final Logger              logger = LoggerFactory.getLogger(MarketEventHistoryWebService.class);

    @Autowired
    private MarketEventHistoryService marketEventHistoryService;

    /**
     * This creates the market event History record with the event details.
     * 
     * @param marketEventHistoryDto
     */
    @WebMethod(operationName = "createMarketEventHistory")
    public void createMarketEventHistory(
            @WebParam(name = "marketEventHistoryDto", targetNamespace = "http://dto.mds.caiso.com/") MarketEventHistoryDto marketEventHistoryDto) {
        logger.debug("*****  Entering Method createMarketEventHistory ********");
        marketEventHistoryService.createMarketEventHistory(marketEventHistoryDto);
        logger.debug("*****  Exiting Method createMarketEventHistory ********");

    }

}

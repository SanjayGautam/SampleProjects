package com.caiso.mds.ws.rest.mrkt.run;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.mrkt.run.service.MarketEventHistoryService;
import com.caiso.mds.ui.vo.MarketEventNotificationLogsResultVO;
import com.caiso.mds.util.DateUtil;

public class MarketEventNotificationLogRestService {

    private final static Logger       logger = LoggerFactory.getLogger(MarketEventNotificationLogRestService.class);

    @Autowired
    private MarketEventHistoryService marketEventHistoryService;

    @Autowired
    private DateUtil                  dateUtil;

    @GET
    @Path("/marketEventNotificationLogs/")
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.APPLICATION_FORM_URLENCODED })
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response getMarketEventNotificationLogs(@QueryParam("pageNumber") int pageNumber) {

        logger.info("****  Entering the  REST Market Event Notification History   **************");
        MarketEventNotificationLogsResultVO marketEventNotificationLogsResultVO = marketEventHistoryService.getMarketEventNotificationLog(pageNumber);

        logger.info("****  Exiting the  REST Market Event Notification History   **************");
        return Response.ok(marketEventNotificationLogsResultVO).build();
    }

}
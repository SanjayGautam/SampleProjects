package com.caiso.mds.ws.soap.mrkt.run;

import java.util.Date;
import java.util.TimeZone;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketEventHistoryDto;
import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.external.ws.service.MdsToMnsService;
import com.caiso.mds.mrkt.run.service.MarketEventHistoryService;
import com.caiso.mds.mrkt.run.service.MarketStatusService;
import com.caiso.mds.util.DateUtil;

@WebService(name = "MarketEventNotificationPublisherService", portName = "MarketEventNotificationPublisherServicePort", serviceName = "MarketEventNotificationPublisherService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketEventNotificationPublisherWebService {

    private final Logger              logger = LoggerFactory.getLogger(MarketEventNotificationPublisherWebService.class);

    @Autowired
    private MdsToMnsService           mdsToMnsService;

    @Autowired
    private Boolean                   mdsToMnsBroadcastSwitchEnabled;

    @Autowired
    private MarketEventHistoryService marketEventHistoryService;

    @Autowired
    private MarketStatusService       marketStatusService;

    @Autowired
    private DateUtil                  dateUtil;

    /**
     * This service method publishes the market Event Notifications to the
     * market participants. This will do the broadcast to all the market
     * participants simultaneously, the urls or endpoints are stored in the
     * database which are dynamically looked up and then sent.
     * 
     * @param marketEventNotificationDto
     */
    @WebMethod(operationName = "publishMarketEventNotification")
    public void publishMarketEventNotification(
            @WebParam(name = "marketEventNotificationDto", targetNamespace = "http://dto.mds.caiso.com/") MarketEventNotificationDto marketEventNotificationDto) {

        logger.info("*****  Entered Publishing to NMS  ********");
        logger.info("Run Id  						" + marketEventNotificationDto.getMarketRunId());
        logger.info("Plan Id                        " + marketEventNotificationDto.getMarketPlanId());
        logger.info("Event Code                     " + marketEventNotificationDto.getMarketEventDefCode());
        logger.info("Event Def ID   				" + marketEventNotificationDto.getMarketEventDefId());
        logger.info("Event Notification Name  		" + marketEventNotificationDto.getMarketEventDefNotificationName());
        logger.info("Event Notification Message     " + marketEventNotificationDto.getMarketEventDefNotificationMessage());
        logger.info("Event Notification ACTION   	" + marketEventNotificationDto.getMarketNotificationAction());
        logger.info("Market Start Date 			   	" + marketEventNotificationDto.getMarketDate());
        logger.info("MDS to MNS broadcastSwitchEnabled ", mdsToMnsBroadcastSwitchEnabled);

        if (mdsToMnsBroadcastSwitchEnabled) {
            // last minute hack cant help :-(
            if ("DADE".equals(marketEventNotificationDto.getMarketEventDefCode())) {

                MarketEventHistoryDto marketEventHistoryDto = populateHistory(marketEventNotificationDto);
                marketEventHistoryService.createMarketEventHistory(marketEventHistoryDto);
            }

            mdsToMnsService.sendMarketEventNotificationToMnsByHttpClient(marketEventNotificationDto);
        } else {
            logger.warn("Message Will not be sent to the Market Notification System as it is Disabled in MDS");
        }

        logger.info("*****  Exiting Publishing to NMS ********");

    }

    /**
     * This method is a dummy method , I dont know which market should be
     * associated as per Leads it shouldnt not be assosicated with any. and
     * hence to over come and not change i am associating it with the day ahead
     * market and checking the status .
     * 
     * @param marketEventNotificationDto
     * @return
     */
    private MarketEventHistoryDto populateHistory(MarketEventNotificationDto marketEventNotificationDto) {

        MarketEventHistoryDto marketEventHistoryDto = new MarketEventHistoryDto();
        marketEventHistoryDto.setCreateBy("mds_bpm");
        marketEventHistoryDto.setCreateDate(new Date());
        marketEventHistoryDto.setMarketDate(marketEventNotificationDto.getMarketDate());
        marketEventHistoryDto.setMarketEventDefinitionId(marketEventNotificationDto.getMarketEventDefId());

        marketEventHistoryDto.setMarketEventPubState("PUBLISHED");
        // this is dummy calculation not required since there is no ids in CMRI
        String yymmdd = dateUtil.convertDateToStringFormat(new Date(), DateUtil.PATTERN_yyMMdd, TimeZone.getTimeZone("US/Pacific"));
        marketEventHistoryDto.setMarketPlanId(yymmdd + "00");
        marketEventHistoryDto.setMarketRunId("1" + yymmdd + "00");

        marketEventNotificationDto.setMarketRunId("1" + yymmdd + "00");
        marketEventNotificationDto.setMarketPlanId(yymmdd + "00");
        // this is just a hack for the unreasonable requirements it does not
        // impact business rules.
        Long statusHistoryid = marketStatusService.getLastMarketStatusForMarketRunId("1" + yymmdd + "00");
        if (statusHistoryid == null) {
            statusHistoryid = marketStatusService.getMaxMarketStatusHistoryId();
            logger.warn("market status history id was null and hence taking max history id in the table ");
        }
        marketEventHistoryDto.setMarketStatusHistoryId(statusHistoryid);
        marketEventHistoryDto.setUpdateBy("mds_bpm");
        marketEventHistoryDto.setUpdateDate(new Date());

        return marketEventHistoryDto;
    }

}

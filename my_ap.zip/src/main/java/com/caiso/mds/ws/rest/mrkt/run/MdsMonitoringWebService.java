package com.caiso.mds.ws.rest.mrkt.run;

public class MdsMonitoringWebService {

}

package com.caiso.mds.ws.soap.mdsportal;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mdsportal.marketstatus.FaultReturnType;
import com.caiso.soa.proxies.mdsportal.marketstatus.MarketRefreshBPELProcess;
import com.caiso.soa.proxies.mdsportal.marketstatus.MarketStatus;
import com.caiso.soa.proxies.mdsportal.marketstatus.RequestMarketStatusMsg;

public class MarketStatusLogHistoryWebservice implements MarketRefreshBPELProcess {

    @Autowired
    private DateUtil                            dateUtil;

    @Autowired
    private MarketStatusHistoryWebserviceHelper helper;

    @Override
    public MarketStatus process(RequestMarketStatusMsg payload) throws FaultReturnType {

        Date tradeDate = dateUtil.getUtilDateFromXmlGeorgianDate(payload.getMarketStatus().getTradeDay());
        MarketStatus marketStatus = helper.getMarketStatusForAllMarkets(tradeDate);
        return marketStatus;
    }
}

package com.caiso.mds.ws.soap.mrkt.run;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.dto.MarketEventNotificationsRequest;
import com.caiso.mds.dto.MarketEventsToPublishResponse;
import com.caiso.mds.mrkt.run.service.MarketEventsToPublishService;
import com.caiso.mds.mrkt.run.service.MarketPlanService;
import com.caiso.mds.types.MarketDefintionType;

@WebService(name = "MarketEventsToPublishService", portName = "MarketEventsToPublishServicePort", serviceName = "MarketEventsToPublishService", targetNamespace = "http://dto.mds.caiso.com/")
@SOAPBinding(style = Style.RPC)
public class MarketEventsToPublishWebService {

    private final Logger                 logger = LoggerFactory.getLogger(MarketEventsToPublishWebService.class);

    @Autowired
    private MarketEventsToPublishService marketEventsToPublishService;

    @Autowired
    private MarketPlanService            marketPlanService;

    /**
     * This gets the single market event to be published to the MNS
     * participiants
     * 
     * @param marketDefinition
     * @return
     */
    @WebMethod(operationName = "getMarketEventsToPublish")
    @WebResult(name = "MarketEventsToPublishResponse")
    public MarketEventsToPublishResponse getMarketEventsToPublish(@WebParam(name = "marketDefinition") String marketDefinition) {
        logger.debug("*****  Entering Get Market Events ********");
        logger.debug(" Market Definition " + marketDefinition + " Enum  " + MarketDefintionType.valueOf(marketDefinition));
        List<MarketEventNotificationDto> notificationEvents = marketEventsToPublishService.getMarketEventsNotificationForMarketDef(MarketDefintionType
                .valueOf(marketDefinition));

        logger.info("Notification Event List  " + notificationEvents);
        logger.info(" SizeWeb Service  " + notificationEvents.size());
        MarketEventsToPublishResponse response = new MarketEventsToPublishResponse();
        response.setNotifications(notificationEvents);
        logger.debug("*****  Exiting Get Market Events ********");

        return response;
    }

    /**
     * This service method gets you all the market events to be publish at the
     * moment this method is run.
     * 
     * @return
     */
    @WebMethod(operationName = "getAllMarketEventsToPublishNow")
    @WebResult(name = "MarketEventsToPublishResponse")
    public MarketEventsToPublishResponse getAllMarketEventsToPublishNow(@WebParam(name = "marketEventPubState") String marketEventPubState) {
        logger.debug("*****  Entering Get All Market Events Web Services ********");

        List<MarketEventNotificationDto> notificationEvents = marketEventsToPublishService.getAllMarketEventsToPublishNow(marketEventPubState);

        logger.info("Notification Event List  " + notificationEvents);
        logger.info(" SizeWeb Service  " + notificationEvents.size());
        MarketEventsToPublishResponse response = new MarketEventsToPublishResponse();
        response.setNotifications(notificationEvents);
        logger.debug("*****  Exiting Get All Market Events Web Services ********");

        return response;
    }

    /**
     * 
     * @param marketEventPubState
     * @return
     */

    @WebMethod(operationName = "getAllOpenMarketEventsNotPublishedYet")
    @WebResult(name = "MarketEventsToPublishResponse")
    public MarketEventsToPublishResponse getAllOpenMarketEventsNotPublishedYet(@WebParam(name = "marketEventPubState") String marketEventPubState,
            @WebParam(name = "mrktEvntType") String mrktEvntType, @WebParam(name = "lastHours") int lastHours) {
        logger.debug("*****  Entering getAllOpenMarketEventsNotPublishedYet ********");

        List<MarketEventNotificationDto> notificationEvents = marketEventsToPublishService.getAllOpenMarketEventsNotPublishedYet(marketEventPubState,
                mrktEvntType, lastHours);

        logger.info("Notifications Fetched getAllOpenMarketEventsNotPublishedYet" + notificationEvents);
        logger.info("No of Events fetched getAllOpenMarketEventsNotPublishedYet " + notificationEvents.size());
        MarketEventsToPublishResponse response = new MarketEventsToPublishResponse();
        response.setNotifications(notificationEvents);
        logger.debug("*****  Exiting getAllOpenMarketEventsNotPublishedYet  ********");

        return response;
    }

    /**
     * This method will publish the Market Events which are provided to this
     * method to the MNS participaints
     * 
     * @param marketEventNotificationRequests
     * @return
     */

    @WebMethod(operationName = "publishMarketEventNotificationsToMarket")
    @WebResult(name = "MarketEventsToPublishResponse")
    public MarketEventsToPublishResponse publishMarketEventNotificationsToMarket(
            @WebParam(name = "marketEventNotificationsRequest", targetNamespace = "http://soap.ws.mds.caiso.com/") MarketEventNotificationsRequest marketEventNotificationRequests) {
        logger.info("*****  Entering method publishMarketEventNotificationsToMarket ********");

        List<MarketEventNotificationDto> notificationEvents = null;

        try {
            if (marketEventNotificationRequests.getMarketEventNotifications() != null
                    && !marketEventNotificationRequests.getMarketEventNotifications().isEmpty()) {

                logger.info("Going to Market Notifications to MNS Market Participants Market Events are :{}", marketEventNotificationRequests
                        .getMarketEventNotifications().size());

                notificationEvents = marketEventsToPublishService.publishMarketEventNotificationsToMarket(marketEventNotificationRequests
                        .getMarketEventNotifications());

            } else {
                logger.warn("Nothing to sent to Market MNS Systems ");
            }
        } catch (Exception e) {
            logger.error("Error while sending the MNS Messages to the endpoints eating this exceptions ", e);
        }

        logger.info("Notification Event List  " + notificationEvents);
        logger.info(" SizeWeb Service  " + notificationEvents.size());
        MarketEventsToPublishResponse response = new MarketEventsToPublishResponse();
        response.setNotifications(notificationEvents);
        logger.info("*****  Exiting method publishMarketEventNotificationsToMarket ********");

        return response;
    }

    @WebMethod(operationName = "updateMarketDatesForMarketEventNotifications")
    @WebResult(name = "MarketEventsToPublishResponse")
    public MarketEventsToPublishResponse updateMarketDatesForMarketEventNotifications(
            @WebParam(name = "marketEventNotificationsRequest", targetNamespace = "http://soap.ws.mds.caiso.com/") MarketEventNotificationsRequest marketEventNotificationRequests) {
        logger.info("*****  Entering method updateMarketDatesForMarketEventNotifications ********");

        List<MarketEventNotificationDto> marketEventNotificationDtos = new ArrayList<MarketEventNotificationDto>();

        try {
            if (marketEventNotificationRequests.getMarketEventNotifications() != null
                    && !marketEventNotificationRequests.getMarketEventNotifications().isEmpty()) {

                marketEventNotificationDtos = marketPlanService.updateMarketDatesForMarketEventNotifications(marketEventNotificationRequests
                        .getMarketEventNotifications());

            } else {
                logger.warn("No Market Events were updated with the market dates.");
            }
        } catch (Exception e) {
            logger.error("Error while sending the MNS Messages to the endpoints eating this exceptions ", e);
            MarketEventsToPublishResponse response = new MarketEventsToPublishResponse();
            response.setNotifications(marketEventNotificationDtos);
        }

        logger.info(" SizeWeb Service  " + marketEventNotificationDtos.size());
        MarketEventsToPublishResponse response = new MarketEventsToPublishResponse();
        response.setNotifications(marketEventNotificationDtos);

        logger.info("*****  Exiting method updateMarketDatesForMarketEventNotifications ********");

        return response;
    }
}

package com.caiso.mds.ws.soap.mrkt.run;

import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.caiso.soa.proxies.mns.ExternalNotificationMsg;
import com.caiso.soa.proxies.mns.FaultReturnType;
import com.caiso.soa.proxies.mns.OutputDataType;

/**
 * 
 * This class is just to simulate the urls for the MNS participants.
 * 
 * @author sgautam
 * 
 */
@SOAPBinding(style = Style.DOCUMENT)
public class MarketMnsSimulatedMpSecondWebService implements ReceiveExternalNotificationTwo {

    private final static Logger logger = LoggerFactory.getLogger(MarketMnsSimulatedMpSecondWebService.class);

    @Override
    public OutputDataType receiveExternalNotification(ExternalNotificationMsg externalNotification) throws FaultReturnType {
        logger.info("******** Entered method receiveExternalNotification ********************* ");

        if (externalNotification != null) {
            logger.info(" External Notificaion Details " + externalNotification.getExternalNotification().getNotificationMessage());
        } else {
            logger.warn(" No data received");
        }

        logger.info("******** Exiting method receiveExternalNotification ********************* ");
        return null;
    }

}

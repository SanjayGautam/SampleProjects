package com.caiso.mds.ws.soap.mdsportal;

import java.util.List;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.ui.vo.MarketSystemOperatorMessageVO;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mdsportal.operatormsg.MarketMessagesOutput;
import com.caiso.soa.proxies.mdsportal.operatormsg.MarketSeverityMsg;
import com.caiso.soa.proxies.mdsportal.operatormsg.ObjectFactory;

@Component
public class OperatorMarketMessagesServiceHelper {

    private ObjectFactory objFactory = new ObjectFactory();

    @Autowired
    private DateUtil      dateUtil;

    /**
     * 
     * @param operatorMessages
     * @return
     */

    public MarketMessagesOutput getMarketMessagesOuput(List<MarketSystemOperatorMessageVO> operatorMessages) {

        MarketMessagesOutput marketMessagesOut = objFactory.createMarketMessagesOutput();

        for (MarketSystemOperatorMessageVO marketSystemOperatorMessageVO : operatorMessages) {
            MarketSeverityMsg marketSeverityMsg = getMarketSeverityMsgObj(marketSystemOperatorMessageVO);
            marketMessagesOut.getMarketMsg().add(marketSeverityMsg);
        }

        return marketMessagesOut;
    }

    /**
     * 
     * @param marketSystemOperatorMessageVO
     * @return
     */

    public MarketSeverityMsg getMarketSeverityMsgObj(MarketSystemOperatorMessageVO marketSystemOperatorMessageVO) {

        MarketSeverityMsg marketSeverityMsg = objFactory.createMarketSeverityMsg();
        marketSeverityMsg.setSeverity(marketSystemOperatorMessageVO.getMdsSeverityName());
        marketSeverityMsg.setText(marketSystemOperatorMessageVO.getSeverityMessage());
        marketSeverityMsg.setTime(dateUtil.convertDateToStringFormat(marketSystemOperatorMessageVO.getSeverityInsertDate(),
                DateUtil.PATTERN_yyyy_MM_dd_HH_mm_ss, TimeZone.getTimeZone("US/Pacific")));

        return marketSeverityMsg;
    }
}

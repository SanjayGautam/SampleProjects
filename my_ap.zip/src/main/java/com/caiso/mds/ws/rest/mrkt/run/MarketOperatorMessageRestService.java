package com.caiso.mds.ws.rest.mrkt.run;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.mrkt.run.service.MarketSysOperatorMsgService;
import com.caiso.mds.types.OperatorMessageSeverityType;
import com.caiso.mds.ui.vo.MarketSystemOperatorMessageSeveritiesVO;
import com.caiso.mds.ui.vo.MarketSystemOperatorMessageSeverityVO;
import com.caiso.mds.ui.vo.MarketSystemOperatorMessageVO;
import com.caiso.mds.ui.vo.MarketSystemOperatorMessagesVO;
import com.caiso.mds.util.DateUtil;

public class MarketOperatorMessageRestService {

    private final static Logger         logger = LoggerFactory.getLogger(MarketOperatorMessageRestService.class);

    @Autowired
    private MarketSysOperatorMsgService marketSysOperatorMsgService;

    @Autowired
    private DateUtil                    dateUtil;

    @POST
    @Path("/operatorMessages/")
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.APPLICATION_FORM_URLENCODED })
    public Response createOperatorMessage(MarketSystemOperatorMessageVO marketSystemOperatorMessageVO) {

        logger.info("****  Entering the  REST createOperatorMessage  **************");
        logger.info(" Test " + marketSystemOperatorMessageVO);

        if (marketSystemOperatorMessageVO.getMdsSeverityId() == 0 && marketSystemOperatorMessageVO.getMdsSeverityName() != null) {
            long sevId = OperatorMessageSeverityType.valueOf(marketSystemOperatorMessageVO.getMdsSeverityName().toUpperCase()).getId();
            logger.info(" Sev IDDD " + sevId);
            marketSystemOperatorMessageVO.setMdsSeverityId(sevId);
        } else {

            // TODO chec and throw errors
            logger.error("Should throw erroir ");
        }

        marketSystemOperatorMessageVO = marketSysOperatorMsgService.createMarketSysOperatorMessage(marketSystemOperatorMessageVO);

        logger.info("****  Exiting the  REST createOperatorMessage  **************");
        return Response.ok(marketSystemOperatorMessageVO).build();
    }

    @GET
    @Path("/last24HourOperatorMessages/")
    public Response getLast24HourOperatorMessages() {

        MarketSystemOperatorMessagesVO marketSystemOperatorMessages = null;

        List<MarketSystemOperatorMessageVO> operatorMessages = marketSysOperatorMsgService.getLast24HourOperatorMessages();
        if (operatorMessages.isEmpty()) {
            marketSystemOperatorMessages = new MarketSystemOperatorMessagesVO();
            marketSystemOperatorMessages.setResponseResult("No Data Found");
        } else {
            marketSystemOperatorMessages = new MarketSystemOperatorMessagesVO();
            marketSystemOperatorMessages.setOperatorMessages(operatorMessages);
            marketSystemOperatorMessages.setResponseResult("Found");
        }

        return Response.ok(marketSystemOperatorMessages).build();

    }

    @GET
    @Path("/messageSeverities/")
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.APPLICATION_FORM_URLENCODED })
    @Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
    public Response getAllMessageSeverities() {

        MarketSystemOperatorMessageSeveritiesVO marketSystemOperatorMessageSeverities = null;

        List<MarketSystemOperatorMessageSeverityVO> severities = marketSysOperatorMsgService.getAllMdsSeverities();
        if (severities.isEmpty()) {
            marketSystemOperatorMessageSeverities = new MarketSystemOperatorMessageSeveritiesVO();
            marketSystemOperatorMessageSeverities.setResponseResult("No Data Found");
        } else {
            marketSystemOperatorMessageSeverities = new MarketSystemOperatorMessageSeveritiesVO();
            marketSystemOperatorMessageSeverities.setSystemOperatorMessageSeverity(severities);
            marketSystemOperatorMessageSeverities.setResponseResult("Found");
        }

        return Response.ok(marketSystemOperatorMessageSeverities).build();

    }

    @PUT
    @Path("/operatorMessages/")
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.APPLICATION_FORM_URLENCODED })
    public Response updateSystemOperatorMessage(MarketSystemOperatorMessageVO marketSystemOperatorMessageVO) {

        marketSysOperatorMsgService.updateMarketSysOperatorMessage(marketSystemOperatorMessageVO);

        return Response.ok().build();
    }

}
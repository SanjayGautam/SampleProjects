package com.caiso.mds.ws.rest.mrkt.run;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Date;
import java.util.TimeZone;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.mds.mrkt.run.service.MarketPlanService;
import com.caiso.mds.types.MarketType;
import com.caiso.mds.ui.vo.MarketStatuses;
import com.caiso.mds.util.DateUtil;

public class MarketStatusRestService {

    private final static Logger logger = LoggerFactory.getLogger(MarketStatusRestService.class);

    @Autowired
    private MarketPlanService   marketPlanService;

    @Autowired
    private DateUtil            dateUtil;

    @GET
    @Path("/marketStatusHistory/")
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.APPLICATION_FORM_URLENCODED })
    public Response getMarketStatusHistoryByTypeAndMarketDate(@QueryParam("marketType") String marketType, @QueryParam("marketDate") String marketDate) {

        String dateString;
        MarketStatuses marketStatuses = null;

        try {
            dateString = URLDecoder.decode(marketDate, "UTF-8");
            logger.info(" Date Received ==>> " + dateString);
            Date marketDateInPST = dateUtil.createDateFromString(dateString, DateUtil.PATTERN_MMddyyyy, TimeZone.getTimeZone("US/Pacific"));
            logger.info(" Date Received ==>> " + marketDateInPST);
            logger.info(" Market Type  => " + marketType);
            marketStatuses = marketPlanService.getMarketStatusForMainMarkets(MarketType.valueOf(marketType), marketDateInPST);

        } catch (UnsupportedEncodingException e) {
            logger.error("Error while  encoding", e);
        }

        return Response.ok(marketStatuses).build();
    }

    @GET
    @Path("/marketStatusCurrentHour/")
    @Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML, MediaType.APPLICATION_FORM_URLENCODED })
    public Response getRtmCurrentHourMarketStatus(@QueryParam("marketType") String marketType) {

        MarketStatuses marketStatuses = null;
        logger.info(" Market Type  => " + marketType);
        marketStatuses = marketPlanService.getMarketStatusForMainMarketsForCurrentHour(MarketType.valueOf(marketType));

        return Response.ok(marketStatuses).build();
    }

}
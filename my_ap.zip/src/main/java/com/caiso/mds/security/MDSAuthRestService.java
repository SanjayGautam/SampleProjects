package com.caiso.mds.security;

import java.util.Collection;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.caiso.integration.security.authservice.AuthService;
import com.caiso.integration.security.authservice.AuthServiceFactory;
import com.caiso.mds.ui.vo.SecurityStatusVO;
import com.caiso.mds.ws.rest.mrkt.run.MarketEventNotificationLogRestService;

public class MDSAuthRestService {
    private final static Logger logger = LoggerFactory.getLogger(MarketEventNotificationLogRestService.class);

    @Autowired
    private String              mdsOperatorAccess;

    @Autowired
    private String              mdsUserAccess;

    @GET
    @Path("/mdsAuthService/")
    public Response getUserAccess(@Context HttpHeaders headers) {
        logger.info("****  Entering the REST MDSAuthService   **************");
        logger.info("mdsOperatorAccess-------------------:" + mdsOperatorAccess);
        logger.info("mdsUserAccess-------------------:" + mdsUserAccess);
        String mdsOperator = mdsOperatorAccess;
        String mdsUser = mdsUserAccess;

        SecurityStatusVO securityStatusVO = new SecurityStatusVO();
        if (headers.getRequestHeader("ct-remote-user") == null) {
            securityStatusVO.setUserAccess("N");
            securityStatusVO.setMdsUserName("Unknown");
        } else {
            String userName = headers.getRequestHeader("ct-remote-user").get(0);
            if (userName == null) {
                logger.info("Username is null");
                securityStatusVO.setUserAccess("N");
                securityStatusVO.setMdsUserName("Unknown");
            } else {
                logger.info("Username : " + userName);
                securityStatusVO.setMdsUserName(userName);
                String mdsOperatorAccess = isUserInRole(userName, mdsOperator);
                String mdsUserAccess = isUserInRole(userName, mdsUser);
                logger.info("mdsOperatorAccess:" + mdsOperatorAccess);
                logger.info("mdsUserAccess:" + mdsUserAccess);
                if ("Y".equals(mdsOperatorAccess) || "Y".equals(mdsUserAccess)) {
                    securityStatusVO.setUserAccess("Y");
                    if ("Y".equals(mdsOperatorAccess)) {
                        logger.info("mdsUserAccess: Set to Y");
                        securityStatusVO.setMDSOperator("Y");
                    } else {
                        logger.info("mdsUserAccess: Set to N");
                        securityStatusVO.setMDSOperator("N");
                    }
                } else {
                    securityStatusVO.setUserAccess("N");
                }
            }

        }

        logger.info("****  Exit the REST MDSAuthService   **************");
        return Response.ok(securityStatusVO).build();
    }

    @SuppressWarnings("unchecked")
    protected String isUserInRole(String userName, String role) {
        String userHasAccess = "N";
        try {
            AuthService authService = AuthServiceFactory.findAuthService();
            Collection<String> authorizedRoles = authService.findRolesForUser(userName, role);

            if (authorizedRoles.size() > 0) {
                System.out.println("authorizedRoles:::::" + authorizedRoles.size());
                userHasAccess = "Y";
            }
        } catch (Exception e) {
            throw new UnsupportedOperationException("Auth Service threw an exception:" + e.getMessage(), e);
        }
        System.out.println("userHasAccess:::::" + userHasAccess);
        return userHasAccess;
    }

}

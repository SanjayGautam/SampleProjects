package com.caiso.mds.external.ws.clients;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketStatusDto;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mds.marketstatus.MarketClassType;
import com.caiso.soa.proxies.mds.marketstatus.MarketRunMktStatusMsg;
import com.caiso.soa.proxies.mds.marketstatus.MarketStatus;
import com.caiso.soa.proxies.mds.marketstatus.MarketStatusType;
import com.caiso.soa.proxies.mds.marketstatus.MarketType;
import com.caiso.soa.proxies.mds.marketstatus.ReqMarketStatusType;

@Component
public class MdsToSibrWebserviceClientHelper {

    @Autowired
    private DateUtil     dateUtil;

    private final Logger logger = LoggerFactory.getLogger(MdsToSibrWebserviceClientHelper.class);

    /**
     * 
     * @param marketStatusDto
     * @return
     */
    public MarketStatus getMarketStatusProxyObject(MarketStatusDto marketStatusDto) {

        MarketStatus _broadcastMarketStatusV1_marketStatus = new MarketStatus();

        List<MarketRunMktStatusMsg> list = _broadcastMarketStatusV1_marketStatus.getMarketRun();
        MarketRunMktStatusMsg mrMarketRunMktStatusMsg = new MarketRunMktStatusMsg();

        mrMarketRunMktStatusMsg.setMarketClass(MarketClassType.valueOf(marketStatusDto.getMarketClass()));
        mrMarketRunMktStatusMsg.setMarketID(marketStatusDto.getMarketPlanId());
        mrMarketRunMktStatusMsg.setMarketRunID(marketStatusDto.getMarketRunId());
        mrMarketRunMktStatusMsg.setMarketType(MarketType.valueOf(marketStatusDto.getMarketType()));

        mrMarketRunMktStatusMsg.setMarketStatusTime(dateUtil.getGeorgianDate(new Date()));
        mrMarketRunMktStatusMsg.setMarketStartTime(dateUtil.getGeorgianDate(marketStatusDto.getMarketStartTime()));

        if (marketStatusDto.getPreviousStatus() != null) {
            mrMarketRunMktStatusMsg.setPreviousStatus(MarketStatusType.valueOf(marketStatusDto.getPreviousStatus()));
        } else {
            logger.info("Previous status was not set for the market status with Market run ID {} ", marketStatusDto.getMarketRunId());
        }
        mrMarketRunMktStatusMsg.setRequestedStatus(ReqMarketStatusType.valueOf(marketStatusDto.getRequestedStatus()));
        mrMarketRunMktStatusMsg.setCurrentStatus(MarketStatusType.valueOf(marketStatusDto.getCurrentStatus()));

        list.add(mrMarketRunMktStatusMsg);
        return _broadcastMarketStatusV1_marketStatus;
    }

}

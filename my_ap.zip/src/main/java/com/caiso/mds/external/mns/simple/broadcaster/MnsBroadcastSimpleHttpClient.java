package com.caiso.mds.external.mns.simple.broadcaster;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import com.caiso.mds.dao.mds.ExternalSystemEndpointDao;
import com.caiso.mds.entity.mds.ExternalSystemEndpoint;
import com.caiso.mds.types.ExternalSystemName;
import com.caiso.mds.util.DateUtil;
import com.caiso.mds.util.SoapHelper;
import com.caiso.soa.common.util.Base64;

@Component
public class MnsBroadcastSimpleHttpClient {

    private final Logger              logger        = LoggerFactory.getLogger(MnsBroadcastSimpleHttpClient.class);

    @Autowired
    private SoapHelper                soapHelper;

    @Autowired
    private DateUtil                  dateUtil;

    private String                    soapStartEnv  = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                                                            + "<env:Envelope xmlns:env=\"http://schemas.xmlsoap.org/soap/envelope/\">";
    private String                    soapStartBody = "<env:Body id=\"Body\">";
    private String                    soapEndBody   = "</env:Body>";
    private String                    soapEndEnv    = "</env:Envelope>";

    @Autowired
    private ExternalSystemEndpointDao externalSystemEndpointDao;

    /**
     * @param url
     * @param message
     * @return process or service output or error message
     */

    public void sendNotifications(String message) {

        String normalMsg = null;
        String signedMsg = null;
        String soapAction = "";
        ExecutorService executorService = Executors.newFixedThreadPool(10);

        try {
            // Create and send SOAP message to service at URL
            normalMsg = new String(createSoapMessageXml(message));
            signedMsg = createSOAPMsgWithCAISOHeader(message);

            List<ExternalSystemEndpoint> mdsEndPoints = externalSystemEndpointDao.getActiveExternalSystemEndPointsBySystemName(ExternalSystemName.MNS);

            if (mdsEndPoints.size() < 1) {
                logger.warn("Please configure the table for the external endpoints. ");
            }

            for (ExternalSystemEndpoint externalSystemEndpoint : mdsEndPoints) {
                if ("Y".equals(externalSystemEndpoint.getSignMsg())) {
                    executorService.execute(new MnsBroadcastSimpleHttpSender(signedMsg, externalSystemEndpoint.getExternalSystemIntEndpoint(), soapAction));
                } else {
                    executorService.execute(new MnsBroadcastSimpleHttpSender(normalMsg, externalSystemEndpoint.getExternalSystemIntEndpoint(), soapAction));
                }
            }

        } catch (Exception ex) {
            logger.error("Exception while sending the MNS messages message [\n" + message + "\n]", ex);
        } finally {
            executorService.shutdown();
        }
    }

    private String createSoapMessageXml(String message) {

        StringBuilder sb = new StringBuilder();

        sb.append(soapStartEnv);
        sb.append(soapStartBody);
        sb.append(message);
        sb.append(soapEndBody);
        sb.append(soapEndEnv);

        return sb.toString();
    }

    /**
     * @param message
     * @return SOAP message with CASISOWSHeader and SOAP body wrapping message
     *         content as XML element(s)
     */
    private String createSOAPMsgWithCAISOHeader(String message) throws SOAPException, SAXException, IOException, ParserConfigurationException {
        StringBuilder sb = new StringBuilder();
        sb.append(soapStartEnv);
        sb.append(buildCaisoHeader());
        sb.append(soapStartBody);
        sb.append(message);
        sb.append(soapEndBody);
        sb.append(soapEndEnv);
        return sb.toString();
    }

    private String buildCaisoHeader() {

        String nonce = "Nonce" + String.valueOf(new Random().nextInt());
        String encodedNonce = Base64.encodeBytes(nonce.getBytes());

        String templateString = "<env:Header>"
                + "<CAISOWSHeader mustUnderstand=\"0\" actor=\"\"  xmlns=\"http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd\">"
                + "<CAISOUsernameToken xmlns=\"http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd\">"
                + "<Username xmlns=\"http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd\">"
                + "mnsServer.caiso.com"
                + "</Username>"
                + "<Nonce EncodingType=\"http://docs.oasisopen.org/wss/2004/01/oasis-200401wss-soap-message-security-1.0#Base64Binary\" xmlns=\"http://schemas.xmlsoap.org/ws/2002/07/secext\">"
                + encodedNonce + "</Nonce>" + "<Created xmlns=\"http://schemas.xmlsoap.org/ws/2002/07/utility\">" + dateUtil.getGeorgianDate(new Date())
                + "</Created>" + "</CAISOUsernameToken>" + "<CAISOMessageInfo xmlns=\"http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd\">"
                + "<MessageID xmlns=\"http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd\">" + String.valueOf(new Random().nextInt()) + "</MessageID>"
                + "<Timestamp xmlns=\"http://www.caiso.com/soa/2006-09-30/CAISOWSHeader.xsd\">"
                + "<Created xmlns=\"http://schemas.xmlsoap.org/ws/2002/07/utility\">" + dateUtil.getGeorgianDate(new Date()) + "</Created>"
                + "<Expires xmlns=\"http://schemas.xmlsoap.org/ws/2002/07/utility\">" + dateUtil.getGeorgianDate(dateUtil.addHoursToNow(2)) + "</Expires>"
                + "</Timestamp>" + "</CAISOMessageInfo>" + "</CAISOWSHeader>" + "</env:Header>";
        return templateString;
    }
}

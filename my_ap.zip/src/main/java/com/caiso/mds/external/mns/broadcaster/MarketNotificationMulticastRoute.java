package com.caiso.mds.external.mns.broadcaster;

import java.util.List;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.dataformat.soap.SoapJaxbDataFormat;
import org.apache.camel.dataformat.soap.name.ServiceInterfaceStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.ExternalSystemEndpointDao;
import com.caiso.mds.entity.mds.ExternalSystemEndpoint;
import com.caiso.mds.types.ExternalSystemName;
import com.caiso.soa.proxies.mns.ReceiveExternalNotification;

@Component
public class MarketNotificationMulticastRoute extends RouteBuilder {

    private final Logger              logger                        = LoggerFactory.getLogger(MarketNotificationMulticastRoute.class);

    @Autowired
    private ExternalSystemEndpointDao externalSystemEndpointDao;

    private String[]                  marketParticipantsSignedUrl   = null;

    private String[]                  marketParticipantsUnSignedUrl = null;

    @Autowired
    private String                    mdsToMnsMulticastRoute;

    /*
     * @Autowired
     * 
     * @Qualifier("marketParticipantsSignedUrl") private String[]
     * marketParticipantsSignedUrl;
     */

    public String[] getMarketParticipantsUrl() {
        return marketParticipantsSignedUrl;
    }

    public void setMarketParticipantsUrl(String[] marketParticipantsUrl) {
        this.marketParticipantsSignedUrl = marketParticipantsUrl;
    }

    /**
     * 
     * MNS Details MNS pertains to all the End points which comes under Market
     * Participants , They can be Internal AI end points or they can be totally
     * External EndPoints on the extranet . These End points may be totally
     * belong to different system different organizations Objective is to create
     * buckets.
     * 
     * All the messages will be sent to all the end points at the same time
     * simultaneously
     */

    @Override
    public void configure() throws Exception {

        logger.debug("********* Entered method configure  **********");
        marketParticipantsSignedUrl = getMarketParticipiantsUris("Y");
        marketParticipantsUnSignedUrl = getMarketParticipiantsUris("N");

        SoapJaxbDataFormat soapBody = new SoapJaxbDataFormat("com.caiso.soa.proxies.mns", new ServiceInterfaceStrategy(ReceiveExternalNotification.class, true));
        soapBody.setVersion("1.1");
        soapBody.setPrettyPrint(true);
        from("direct:sendMnsMessageWithNoHeader").marshal(soapBody).multicast().parallelProcessing().to(marketParticipantsUnSignedUrl).end()
                .process(new ReplyProcessor());

        from("direct:sendMnsMessageWithHeader").marshal(soapBody).bean(new CaisoHeaderProcessor(), "process").multicast().parallelProcessing()
                .to(marketParticipantsSignedUrl).end().process(new ReplyProcessor());

        logger.debug("********* Exiting method configure  **********");

    }

    /**
     * 
     * @return
     * @throws Exception
     */

    private String[] getMarketParticipiantsUris(String signed) throws Exception {

        List<ExternalSystemEndpoint> list = externalSystemEndpointDao.getActiveExternalSystemEndPointsBySystemNameAndSignFlag(ExternalSystemName.MNS, signed);

        if (list != null && list.isEmpty()) {
            logger.error("Market Participants URLs are not configured in database, you might have to restart server if not already there as routes are cached");
            throw new Exception("Market Participants are not configured in database.");
        }

        String[] marketParticipantUrls = new String[list.size()];

        for (int i = 0; i < marketParticipantUrls.length; i++) {

            marketParticipantUrls[i] = list.get(i).getExternalSystemIntEndpoint();
            logger.info("URLs route will mutlicast simultaneously are =>:{}", marketParticipantUrls[i]);
        }

        return marketParticipantUrls;

    }
}

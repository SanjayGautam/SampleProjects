package com.caiso.mds.external.mns.simple.broadcaster;

import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MnsBroadcastSimpleJaxmSender implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(MnsBroadcastSimpleJaxmSender.class);

    private SOAPMessage  soapMsg;
    private String       endPointURL;

    public MnsBroadcastSimpleJaxmSender(SOAPMessage vSoapMsg, String vEndPointUrl) {
        this.soapMsg = vSoapMsg;
        this.endPointURL = vEndPointUrl;
    }

    public void run() {

        SOAPConnection soapCon = null;
        logger.info("Acquired the SoapConnection going to send MNS Message ");

        try {
            soapCon = SOAPConnectionFactory.newInstance().createConnection();
            soapCon.call(soapMsg, endPointURL);
            soapCon.close();
            soapCon = null;
            logger.info("Message Sent Successfully to MNS Endpoint : " + endPointURL);

        } catch (Exception ex) {
            logger.warn("Was unable to send MNS Message to the MNSUnableToSendURL [" + endPointURL + "]", ex);
        } finally {
            soapMsg = null;
            soapCon = null;
        }
    }
}

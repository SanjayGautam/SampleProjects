package com.caiso.mds.external.mns.broadcaster;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.impl.DefaultCamelContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.ExternalSystemEndpointDao;
import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mns.ExternalNotificationMsg;
import com.caiso.soa.proxies.mns.MsgExternalNotification;
import com.caiso.soa.proxies.mns.NotificationActionType;
import com.caiso.soa.proxies.mns.ObjectFactory;

@Component
public class MdsToMnsMulticastCamelClient {

    private final Logger                     logger = LoggerFactory.getLogger(MdsToMnsMulticastCamelClient.class);

    @Autowired
    private DateUtil                         dateUtil;

    @Autowired
    private String                           mdsToMnsMulticastRoute;

    @Autowired
    private MarketNotificationMulticastRoute marketNotificationMulticastRoute;

    private CamelContext                     camelContext;

    @Autowired
    private ExternalSystemEndpointDao        externalSystemEndpointDao;

    /**
     * 
     * @param marketEventNotificationDto
     */
    public void broadcastExternalNotificaionMsg(MarketEventNotificationDto marketEventNotificationDto) {

        logger.debug("************  Entered Method  broadcastExternalNotificaionMsg **********");
        try {

            // marketNotificationMulticastRoute.configure();

            if (camelContext == null) {
                logger.info("Camel Context was null instantiating it for the first time. ");
                camelContext = new DefaultCamelContext();
                camelContext.getProperties().put(Exchange.MAXIMUM_CACHE_POOL_SIZE, "1");
                camelContext.addRoutes(marketNotificationMulticastRoute);
                logMnsUrls();
                camelContext.startAllRoutes();
                camelContext.start();

            } else {
                logMnsUrls();
                logger.info("Using existing camel context ");
            }

        } catch (Exception e) {
            logger.error("Error while initialising camel context ", e);
        }

        logger.debug("Invoking receiveExternalNotification...");
        ExternalNotificationMsg externalNotification = prepareExternalNotificationMsg(marketEventNotificationDto);

        try {

            ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
            producerTemplate.setMaximumCacheSize(-1);
            producerTemplate.sendBody("direct:sendMnsMessageWithNoHeader", externalNotification);
            producerTemplate.sendBody("direct:sendMnsMessageWithHeader", externalNotification);

        } catch (Exception e1) {
            logger.error("Error while sending the camel multicast message via routes", e1);
        }

        logger.debug("************  Exiting method broadcastExternalNotificaionMsg **********");

    }

    /**
     * 
     */
    private void logMnsUrls() {

        logger.info("MDS_TO_AI_MNS_URLS Route Details are :{}", marketNotificationMulticastRoute);
        if (marketNotificationMulticastRoute != null && marketNotificationMulticastRoute.getMarketParticipantsUrl() != null) {
            logger.info("MDS_TO_AI_MNS_URLS Configured are :{}", marketNotificationMulticastRoute.getMarketParticipantsUrl().length);
        } else {
            logger.warn("MDS_TO_AI_MNS_URLS Route not configured Properly");
        }
    }

    /**
     * 
     * @param marketEventNotificationDto
     * @return
     */

    private ExternalNotificationMsg prepareExternalNotificationMsg(MarketEventNotificationDto marketEventNotificationDto) {

        ObjectFactory factory = new ObjectFactory();

        ExternalNotificationMsg externalNotificationMsg = factory.createExternalNotificationMsg();
        MsgExternalNotification msgExternalNotification = factory.createMsgExternalNotification();
        logger.debug("InWebService Setting Start Date In the External Notification Object marketDate :" + marketEventNotificationDto.getMarketDate());

        msgExternalNotification.setMarketStartTime(dateUtil.getGeorgianDate(marketEventNotificationDto.getMarketDate()));

        msgExternalNotification.setNotificationAction(NotificationActionType.valueOf(marketEventNotificationDto.getMarketNotificationAction()));
        msgExternalNotification.setNotificationCode(marketEventNotificationDto.getMarketEventDefCode());
        msgExternalNotification.setNotificationMessage(marketEventNotificationDto.getMarketEventDefNotificationMessage());

        externalNotificationMsg.setExternalNotification(msgExternalNotification);

        return externalNotificationMsg;
    }

}

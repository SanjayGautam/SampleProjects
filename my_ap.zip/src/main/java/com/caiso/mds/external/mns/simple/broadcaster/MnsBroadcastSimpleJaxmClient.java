package com.caiso.mds.external.mns.simple.broadcaster;

import java.io.IOException;
import java.io.StringReader;
import java.util.List;
import java.util.Random;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.caiso.mds.dao.mds.ExternalSystemEndpointDao;
import com.caiso.mds.entity.mds.ExternalSystemEndpoint;
import com.caiso.mds.types.ExternalSystemName;
import com.caiso.mds.util.DateUtil;
import com.caiso.mds.util.SoapHelper;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOWSHeaderType;

@Component
public class MnsBroadcastSimpleJaxmClient {

    private static final String       DUMMY_ROOT = "aeDummyRoot";

    private final Logger              logger     = LoggerFactory.getLogger(MnsBroadcastSimpleJaxmClient.class);

    @Autowired
    private SoapHelper                soapHelper;

    @Autowired
    private DateUtil                  dateUtil;

    @Autowired
    private ExternalSystemEndpointDao externalSystemEndpointDao;

    /**
     * @param url
     * @param message
     * @return process or service output or error message
     */

    public void sendNotifications(String message) {

        SOAPMessage normalMsg = null;
        SOAPMessage signedMsg = null;

        try {
            // Create and send SOAP message to service at URL
            normalMsg = createSOAPMessage(message);
            normalMsg.getMimeHeaders().addHeader("SOAPAction", "http://www.caiso.com/soa/2007-08-15/receiveExternalNotification");

            signedMsg = createSOAPMsgWithCAISOHeader(message);
            signedMsg.getMimeHeaders().addHeader("SOAPAction", "http://www.caiso.com/soa/2007-08-15/receiveExternalNotification");

            List<ExternalSystemEndpoint> mdsEndPoints = externalSystemEndpointDao.getActiveExternalSystemEndPointsBySystemName(ExternalSystemName.MNS);

            if (mdsEndPoints.size() < 1) {
                logger.warn("Please configure the table for the external endpoints. ");
            }

            for (ExternalSystemEndpoint externalSystemEndpoint : mdsEndPoints) {
                if ("Y".equals(externalSystemEndpoint.getSignMsg())) {
                    new Thread(new MnsBroadcastSimpleJaxmSender(signedMsg, externalSystemEndpoint.getExternalSystemIntEndpoint())).start();
                } else {
                    new Thread(new MnsBroadcastSimpleJaxmSender(normalMsg, externalSystemEndpoint.getExternalSystemIntEndpoint())).start();
                }
            }
        } catch (Exception ex) {
            logger.error("Exception while sending the MNS messages message [\n" + message + "\n]", ex);
        }
    }

    /**
     * @param message
     * @return SOAP message with body wrapping message content as XML element(s)
     */
    private SOAPMessage createSOAPMessage(String message) throws SOAPException, SAXException, IOException, ParserConfigurationException {

        MessageFactory msgFactory = MessageFactory.newInstance();
        SOAPMessage requestMsg = msgFactory.createMessage();
        requestMsg.getSOAPHeader().detachNode();
        Document doc = createDocument(message);
        createSOAPBody(doc, requestMsg);
        requestMsg.saveChanges();

        return requestMsg;
    }

    /**
     * @param message
     * @return SOAP message with CASISOWSHeader and SOAP body wrapping message
     *         content as XML element(s)
     */
    private SOAPMessage createSOAPMsgWithCAISOHeader(String message) throws SOAPException, SAXException, IOException, ParserConfigurationException {

        MessageFactory msgFactory = MessageFactory.newInstance();
        SOAPMessage soapMessage = msgFactory.createMessage();

        // construct custom CAISO WS header
        CAISOWSHeaderType CAISOWSHeader = soapHelper.createCaisoWsHeaderTypeObject("mnsServer.caiso.com", "Nonce" + String.valueOf(new Random().nextInt()),
                String.valueOf(new Random().nextInt()));

        SOAPHeader soapHeader = soapMessage.getSOAPPart().getEnvelope().getHeader();
        soapHelper.createSoapHeaderForCaisoWsHeaderType(soapHeader, CAISOWSHeader);

        // add the custom header to SOAP header
        Document doc = createDocument(message);

        createSOAPBody(doc, soapMessage);
        soapMessage.saveChanges();

        return soapMessage;

    }

    /**
     * @param message
     * @return Document containing message string (wrapped with DUMMY_ROOT
     *         element if has multiple root elements).
     */
    private Document createDocument(String message) throws SAXException, IOException, ParserConfigurationException {

        Document doc = null;
        try {
            doc = stringToDocument(message);
        } catch (SAXParseException spe) { // In case message contains multiple
            // root elements, wrap them with one
            String s = "<" + DUMMY_ROOT + ">\n" + message + "\n</" + DUMMY_ROOT + ">";
            doc = stringToDocument(s);
        }
        return doc;
    }

    /**
     * Adds doc to env's SOAP body
     * 
     * @param doc
     * @param env
     * @throws SOAPException
     */
    private void createSOAPBody(Document doc, SOAPMessage message) throws SOAPException {

        Element rootElement = doc.getDocumentElement();
        String rootElementName = rootElement.getLocalName();
        if (rootElementName.equals(DUMMY_ROOT) || rootElementName.equals("Body")) {
            // Copy child elements to SOAP body element
            NodeList nl = rootElement.getChildNodes();
            for (int i = 0; i < nl.getLength(); i++) {
                Node node = nl.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Node e = message.getSOAPPart().importNode(node, true);
                    message.getSOAPBody().appendChild(e);
                }
            }
        } else {
            message.getSOAPBody().addDocument(doc);
        }

        message.getSOAPBody().setAttribute("id", "Body");
    }

    /**
     * @param xml
     * @return Document containing xml string
     */
    private Document stringToDocument(String xml) throws SAXException, IOException, ParserConfigurationException {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        // Use the default (false) for now: factory.setValidating(true);
        factory.setNamespaceAware(true);
        return factory.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
    }

}

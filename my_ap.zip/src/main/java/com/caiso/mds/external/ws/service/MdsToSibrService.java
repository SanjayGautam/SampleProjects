package com.caiso.mds.external.ws.service;

import java.util.Date;
import java.util.List;

import javax.xml.ws.soap.SOAPFaultException;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dao.mds.ExternalSystemEndpointDao;
import com.caiso.mds.dao.mds.MdsMarketPlanDao;
import com.caiso.mds.dao.mds.MdsToSibrMsgLogDao;
import com.caiso.mds.dto.MarketStatusDto;
import com.caiso.mds.entity.mds.ExternalSystemEndpoint;
import com.caiso.mds.entity.mds.MdsToSibrMsgLog;
import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktStatusHistory;
import com.caiso.mds.external.ws.clients.MdsToSibrWebServiceClient;
import com.caiso.mds.external.ws.clients.MdsToSibrWebserviceClientHelper;
import com.caiso.mds.soa.parser.sax.SaxJaxbBindingUtil;
import com.caiso.mds.types.ExternalSystemName;
import com.caiso.soa.proxies.mds.marketstatus.FaultReturnType;
import com.caiso.soa.proxies.mds.marketstatus.MarketStatus;
import com.caiso.soa.proxies.mds.marketstatus.OutputDataType;

@Component
public class MdsToSibrService {

    @Autowired
    private MdsMarketPlanDao          mdsMarketPlanDaoOracle;

    @Autowired
    private MdsToSibrWebServiceClient mdsToSibrWebServiceClient;

    @Autowired
    private ExternalSystemEndpointDao externalSystemEndpointDao;

    @Autowired
    private String                    mdsToSibrBoadcastMarketStatusServiceName;

    @Autowired
    MdsToSibrWebserviceClientHelper   mdsToSibrWebserviceClientHelper;

    @Autowired
    private MdsToSibrMsgLogDao        mdsToSibrMsgLogDaoOracle;

    private final Logger              logger = LoggerFactory.getLogger(MdsToSibrService.class);

    /**
     * This main issue here is that when we are going to send the status , bpm
     * has already changed the status in the table and probably the as the flow
     * traverse to the next activity , I am pretty much sure as per the behavior
     * that data gets written and once it is done then we have already changed
     * the status inside the mDS but we are going to send to SIBR in the next
     * step and hence below logic of current previous and requested is little
     * lousy here.
     * 
     * 
     * @param marketStatusDto
     */
    public void sendMarketStatusToSibr(MarketStatusDto marketStatusDto) {

        MrktPlan mrktPlan = mdsMarketPlanDaoOracle.getMarketPlan(marketStatusDto.getMarketPlanId(), marketStatusDto.getMarketRunId());
        // This method will set the current , requested and previous status
        setMarketStatusInsideMrktPlan(marketStatusDto, mrktPlan);
        // This is WSDL URLS it is not a HTTP type Looking at the WSDL url it
        // will get the other details automatically
        List<ExternalSystemEndpoint> sibrExternalSystemWsdlUrls = externalSystemEndpointDao
                .getActiveExternalSystemEndPointsBySystemName(ExternalSystemName.SIBR);

        logger.info("Urls configured for the MDS TO SIBR AI Endpoint are :{}", sibrExternalSystemWsdlUrls.size());

        if (sibrExternalSystemWsdlUrls != null && sibrExternalSystemWsdlUrls.size() > 0) {
            tryToSendMessageToSibrEndpoint(marketStatusDto, sibrExternalSystemWsdlUrls);
        } else {
            saveMarketSibrRequestInDatabaseForManualRetry(marketStatusDto);
        }

    }

    /**
     * 
     * @param marketStatusDto
     */

    private void saveMarketSibrRequestInDatabaseForManualRetry(MarketStatusDto marketStatusDto) {

        logger.warn("Zero Mds to SIBR Endpoints are configured in Database skipping the request");
        MdsToSibrMsgLog mdsToSibrMsgLog = populateMdsToSibrLogObj(marketStatusDto, "FAILED", "NO_SIBR_ENDPOINT_CONFIGURED", "");
        mdsToSibrMsgLogDaoOracle.createMdsToSibrMsgLog(mdsToSibrMsgLog);

    }

    private MdsToSibrMsgLog populateMdsToSibrLogObj(MarketStatusDto marketStatusDto, String responseStatus, String serviceRequest, String serviceResponse) {

        MdsToSibrMsgLog mdsToSibrMsgLog = new MdsToSibrMsgLog();
        mdsToSibrMsgLog.setMrktPlanId(marketStatusDto.getMarketPlanId());
        mdsToSibrMsgLog.setMrktRunId(marketStatusDto.getMarketRunId());
        mdsToSibrMsgLog.setPreviousStatus(marketStatusDto.getPreviousStatus());
        mdsToSibrMsgLog.setRequestedStatus(marketStatusDto.getRequestedStatus());
        mdsToSibrMsgLog.setMrktDate(new DateTime(marketStatusDto.getMarketStartTime()));
        mdsToSibrMsgLog.setMrktType(marketStatusDto.getMarketType());
        mdsToSibrMsgLog.setMrktClass(marketStatusDto.getMarketClass());

        mdsToSibrMsgLog.setRequestResult(responseStatus);
        mdsToSibrMsgLog.setServiceRequest(serviceRequest);
        mdsToSibrMsgLog.setServiceResponse(serviceResponse);

        mdsToSibrMsgLog.setCreatedBy("mds_bpm");
        mdsToSibrMsgLog.setCreatedDt(new Date());
        mdsToSibrMsgLog.setUpdatedBy("mds_bpm");
        mdsToSibrMsgLog.setUpdatedDt(new Date());

        return mdsToSibrMsgLog;
    }

    /**
     * SIBR Details External systems are exposed via AI and hence when we tell
     * external system url we trying to map it to the AI internal URLS or End
     * Points. All the one with SIBR is broadcastSIBR AI , All MDS TO SIBR
     * message will be first send to first Endpoint and if that is not up and
     * running it will try second one.
     * 
     * @param marketStatusDto
     * @param sibrExternalSystemWsdlUrls
     * @param successfullySent
     * @return
     */

    private void tryToSendMessageToSibrEndpoint(MarketStatusDto marketStatusDto, List<ExternalSystemEndpoint> sibrExternalSystemWsdlUrls) {

        boolean successfullySent = false;

        for (ExternalSystemEndpoint externalSystemEndpoint : sibrExternalSystemWsdlUrls) {

            if (externalSystemEndpoint.getIsHttpEndPoint() != null && externalSystemEndpoint.getIsHttpEndPoint().equals("N")) {

                try {
                    OutputDataType outputDataType = mdsToSibrWebServiceClient.broadcastMarketStatusV1(externalSystemEndpoint.getExternalSystemIntEndpoint(),
                            mdsToSibrBoadcastMarketStatusServiceName, marketStatusDto);
                    processSuccessResponseFromSibr(marketStatusDto, outputDataType);
                    successfullySent = true;

                } catch (FaultReturnType e) {
                    logger.warn("Failed to Broadcast to SIBR Using Wsdl URL Endpoint:{} Count of URL :{}", externalSystemEndpoint.getIsHttpEndPoint(),
                            sibrExternalSystemWsdlUrls.indexOf(externalSystemEndpoint), e);
                    processErrorResponseFromSibr(marketStatusDto, e);
                } catch (SOAPFaultException e) {
                    logger.warn("Failed to Broadcast to SIBR Using Wsdl URL Endpoint:{} Count of URL :{}", externalSystemEndpoint.getIsHttpEndPoint(),
                            sibrExternalSystemWsdlUrls.indexOf(externalSystemEndpoint), e);
                    processErrorResponseFromSibr(marketStatusDto, e);
                } catch (Exception e) {
                    logger.warn("Failed to Broadcast to SIBR Using Wsdl URL Endpoint:{} Count of URL :{}", externalSystemEndpoint.getIsHttpEndPoint(),
                            sibrExternalSystemWsdlUrls.indexOf(externalSystemEndpoint), e);
                    processErrorResponseFromSibr(marketStatusDto, e);
                }
            } else {
                logger.warn("Url seems to be down URL:{} or Not Configured Correctly make sure it should be HTTP End point",
                        externalSystemEndpoint.getExternalSystemIntEndpoint());
            }

            if (successfullySent) {
                logger.info("Since broadcast happen successfully no need to look up another url for SIBR");
                break;
            }

        }

    }

    /**
     * 
     * @param marketStatusDto
     * @param mrktPlan
     */

    private void setMarketStatusInsideMrktPlan(MarketStatusDto marketStatusDto, MrktPlan mrktPlan) {
        List<MrktStatusHistory> marketHistory = mrktPlan.getMrktStatusHistories();
        if (marketHistory != null && marketHistory.size() >= 3) {
            marketStatusDto.setRequestedStatus(marketHistory.get(0).getMrktStatusType().getMrktStatusTypeName());
            marketStatusDto.setCurrentStatus(marketHistory.get(1).getMrktStatusType().getMrktStatusTypeName());
            marketStatusDto.setPreviousStatus(marketHistory.get(2).getMrktStatusType().getMrktStatusTypeName());

        } else if (marketHistory != null && marketHistory.size() == 2) {

            marketStatusDto.setRequestedStatus(marketHistory.get(0).getMrktStatusType().getMrktStatusTypeName());
            marketStatusDto.setCurrentStatus(marketHistory.get(1).getMrktStatusType().getMrktStatusTypeName());
            marketStatusDto.setPreviousStatus(marketHistory.get(1).getMrktStatusType().getMrktStatusTypeName());

        } else {

            marketStatusDto.setRequestedStatus(marketHistory.get(0).getMrktStatusType().getMrktStatusTypeName());
            marketStatusDto.setCurrentStatus(marketHistory.get(0).getMrktStatusType().getMrktStatusTypeName());
            marketStatusDto.setPreviousStatus(marketHistory.get(0).getMrktStatusType().getMrktStatusTypeName());

        }
    }

    private void processErrorResponseFromSibr(MarketStatusDto marketStatusDto, Exception e) {

        String responseStatus = "FAILED";
        String serviceRequest = getServiceRequest(marketStatusDto);
        String serviceResponse = e.getMessage();

        MdsToSibrMsgLog mdsToSibrMsgLog = populateMdsToSibrLogObj(marketStatusDto, responseStatus, serviceRequest, serviceResponse);
        mdsToSibrMsgLogDaoOracle.createMdsToSibrMsgLog(mdsToSibrMsgLog);

    }

    /**
     * 
     * @param marketStatusDto
     * @param e
     */
    private void processErrorResponseFromSibr(MarketStatusDto marketStatusDto, FaultReturnType e) {

        String responseStatus = "FAILED";
        String serviceRequest = getServiceRequest(marketStatusDto);
        String serviceResponse = getServiceReponse(e.getFaultInfo());

        MdsToSibrMsgLog mdsToSibrMsgLog = populateMdsToSibrLogObj(marketStatusDto, responseStatus, serviceRequest, serviceResponse);
        mdsToSibrMsgLogDaoOracle.createMdsToSibrMsgLog(mdsToSibrMsgLog);

    }

    /**
     * 
     * @param marketStatusDto
     * @param e
     */
    private void processErrorResponseFromSibr(MarketStatusDto marketStatusDto, SOAPFaultException e) {

        String responseStatus = "FAILED";
        String serviceRequest = getServiceRequest(marketStatusDto);
        String serviceResponse = e.getFault().getFaultString();

        MdsToSibrMsgLog mdsToSibrMsgLog = populateMdsToSibrLogObj(marketStatusDto, responseStatus, serviceRequest, serviceResponse);
        mdsToSibrMsgLogDaoOracle.createMdsToSibrMsgLog(mdsToSibrMsgLog);

    }

    /**
     * 
     * @param marketStatusDto
     * @param outputDataType
     */

    private void processSuccessResponseFromSibr(MarketStatusDto marketStatusDto, OutputDataType outputDataType) {

        String responseStatus = "SUCCESS";
        String serviceRequest = getServiceRequest(marketStatusDto);
        String serviceResponse = getServiceReponse(outputDataType);

        MdsToSibrMsgLog mdsToSibrMsgLog = populateMdsToSibrLogObj(marketStatusDto, responseStatus, serviceRequest, serviceResponse);
        mdsToSibrMsgLogDaoOracle.createMdsToSibrMsgLog(mdsToSibrMsgLog);

    }

    /**
     * 
     * @param outputDataType
     * @return
     */

    private String getServiceReponse(OutputDataType outputDataType) {

        SaxJaxbBindingUtil<OutputDataType> jaxbBindingUtil;
        String response = null;

        try {
            jaxbBindingUtil = new SaxJaxbBindingUtil<OutputDataType>("com.caiso.soa.proxies.mds.marketstatus");

            String nameSpaceUri = "http://www.caiso.com/soa/2006-06-13/StandardOutput.xsd";
            String namePart = "OutputDataType";
            response = jaxbBindingUtil.marshal(nameSpaceUri, namePart, OutputDataType.class, outputDataType);

        } catch (Exception e) {
            logger.warn("Error While marhsalling OutputDataType to the Xml String using JaxbContext", e);
        }
        return response;
    }

    /**
     * 
     * @param marketStatusDto
     * @return
     */
    private String getServiceRequest(MarketStatusDto marketStatusDto) {

        MarketStatus marketStatus = mdsToSibrWebserviceClientHelper.getMarketStatusProxyObject(marketStatusDto);

        SaxJaxbBindingUtil<MarketStatus> jaxbBindingUtil;
        String request = null;

        try {
            jaxbBindingUtil = new SaxJaxbBindingUtil<MarketStatus>("com.caiso.soa.proxies.mds.marketstatus");

            String nameSpaceUri = "http://www.caiso.com/soa/MarketStatus_v1.xsd";
            String namePart = "MarketStatus";
            request = jaxbBindingUtil.marshal(nameSpaceUri, namePart, MarketStatus.class, marketStatus);

        } catch (Exception e) {
            logger.warn("Error While marhsalling OutputDataType to the Xml String using JaxbContext", e);
        }
        return request;

    }
}

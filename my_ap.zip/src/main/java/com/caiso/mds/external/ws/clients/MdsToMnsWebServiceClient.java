package com.caiso.mds.external.ws.clients;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mns.ExternalNotificationMsg;
import com.caiso.soa.proxies.mns.FaultReturnType;
import com.caiso.soa.proxies.mns.MsgExternalNotification;
import com.caiso.soa.proxies.mns.NotificationActionType;
import com.caiso.soa.proxies.mns.ObjectFactory;
import com.caiso.soa.proxies.mns.ReceiveExternalNotification;
import com.caiso.soa.proxies.mns.ReceiveExternalNotificationService;

@Component
public class MdsToMnsWebServiceClient {

    private final Logger logger = LoggerFactory.getLogger(MdsToMnsWebServiceClient.class);

    @Autowired
    private DateUtil     dateUtil;

    /**
     * 
     * @param mdsToMnsMarketNotificationMsgWsdlUrlStr
     * @param mdsToMnsMarketNotificationMsgServiceName
     * @param marketEventNotificationDto
     */
    public void broadcastExternalNotificaionMsg(String mdsToMnsMarketNotificationMsgWsdlUrlStr, String mdsToMnsMarketNotificationMsgServiceName,
            MarketEventNotificationDto marketEventNotificationDto) {

        logger.debug("************ Entered Method broadcastExternalNotificaionMsg **********");

        URL wsdlURL = null;

        try {
            if (mdsToMnsMarketNotificationMsgWsdlUrlStr.length() > 0 && mdsToMnsMarketNotificationMsgWsdlUrlStr != null
                    && !"".equals(mdsToMnsMarketNotificationMsgWsdlUrlStr)) {

                wsdlURL = new URL(mdsToMnsMarketNotificationMsgWsdlUrlStr);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
            logger.error("Error while parsing the URL ", e);
        }

        QName SERVICE_NAME = new QName("http://www.caiso.com/soa/2007-08-15/receiveExternalNotification.wsdl", "ReceiveExternalNotificationService");

        ReceiveExternalNotificationService ss = new ReceiveExternalNotificationService(wsdlURL, SERVICE_NAME);
        ReceiveExternalNotification port = ss.getReceiveExternalNotificationServicePort();

        {

            ExternalNotificationMsg _receiveExternalNotification_externalNotification = prepareExternalNotificationMsg(marketEventNotificationDto);

            try {

                logger.info("Calling webservice clients to send to MNS AI");
                com.caiso.soa.proxies.mns.OutputDataType _receiveExternalNotification__return = port
                        .receiveExternalNotification(_receiveExternalNotification_externalNotification);
                logger.info("receiveExternalNotification.result=" + _receiveExternalNotification__return);

            } catch (FaultReturnType e) {
                logger.error("Expected eception:faultReturnType has occured", e);
            }
        }

        logger.debug("************  Exiting Method broadcastExternalNotificaionMsg  **********");

    }

    /**
     * 
     * @param marketEventNotificationDto
     * @return
     */

    private ExternalNotificationMsg prepareExternalNotificationMsg(MarketEventNotificationDto marketEventNotificationDto) {

        ObjectFactory factory = new ObjectFactory();

        ExternalNotificationMsg externalNotificationMsg = factory.createExternalNotificationMsg();
        MsgExternalNotification msgExternalNotification = factory.createMsgExternalNotification();

        msgExternalNotification.setMarketStartTime(dateUtil.getGeorgianDate(marketEventNotificationDto.getMarketDate()));

        msgExternalNotification.setNotificationAction(NotificationActionType.valueOf(marketEventNotificationDto.getMarketNotificationAction()));
        msgExternalNotification.setNotificationCode(marketEventNotificationDto.getMarketEventDefCode());
        msgExternalNotification.setNotificationMessage(marketEventNotificationDto.getMarketEventDefNotificationMessage());

        externalNotificationMsg.setExternalNotification(msgExternalNotification);

        return externalNotificationMsg;
    }

}

package com.caiso.mds.external.ws.service;

import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.dto.MarketEventHistoryDto;
import com.caiso.mds.dto.MarketEventNotificationDto;
import com.caiso.mds.external.mns.broadcaster.MdsToMnsMulticastCamelClient;
import com.caiso.mds.external.mns.simple.broadcaster.MnsBroadcastSimpleHttpClient;
import com.caiso.mds.external.mns.simple.broadcaster.MnsBroadcastSimpleJaxmClient;
import com.caiso.mds.external.ws.clients.MdsToMnsWebServiceClient;
import com.caiso.mds.mrkt.run.service.MarketEventDefinitionService;
import com.caiso.mds.mrkt.run.service.MarketEventHistoryService;
import com.caiso.mds.mrkt.run.service.MarketStatusService;
import com.caiso.mds.util.DateUtil;
import com.caiso.soa.proxies.mns.NotificationActionType;

@Component
public class MdsToMnsService {

    @Autowired
    private MdsToMnsWebServiceClient     mdsToMnsWebServiceClient;

    @Autowired
    private MdsToMnsMulticastCamelClient mdsToMnsMulticastCamelClient;

    @Autowired
    private MnsBroadcastSimpleJaxmClient mnsBroadcastSimpleJaxmClient;

    @Autowired
    private MnsBroadcastSimpleHttpClient mnsBroadcastSimpleHttpClient;

    @Autowired
    private String                       mdsToMnsMarketNotificationMsgWsdlUrl;

    @Autowired
    private String                       mdsToMnsMarketNotificationMsgServiceName;

    @Autowired
    private MarketEventDefinitionService marketEventDefinitionService;

    @Autowired
    private MarketEventHistoryService    marketEventHistoryService;

    private final Logger                 logger                            = LoggerFactory.getLogger(MdsToMnsService.class);

    private final static String          MARKET_NOTIFICATION_INSERT_ACTION = "INSERT";

    @Autowired
    private Boolean                      mdsToMnsBroadcastSwitchEnabled;

    @Autowired
    private MarketStatusService          marketStatusService;

    @Autowired
    private DateUtil                     dateUtil;

    /**
     * This method only sends the web service call to ESB it doesn't update the
     * market event history details in the MDS Database.
     * 
     * @param marketEventNotificationDto
     */
    public void sendMarketEventNotificationToMns(MarketEventNotificationDto marketEventNotificationDto) {
        logger.info("Will be sending with the Simple Unicast MNS client ");
        mdsToMnsWebServiceClient.broadcastExternalNotificaionMsg(mdsToMnsMarketNotificationMsgWsdlUrl, mdsToMnsMarketNotificationMsgServiceName,
                marketEventNotificationDto);
    }

    public void sendMarketEventNotificationToMnsByCamel(MarketEventNotificationDto marketEventNotificationDto) {
        logger.info("Will be sending with the Multicast MNS camel client ");
        mdsToMnsMulticastCamelClient.broadcastExternalNotificaionMsg(marketEventNotificationDto);
    }

    public void sendMarketEventNotificationToMnsByJaxmClient(MarketEventNotificationDto marketEventNotificationDto) {
        logger.info("Will sending MNS via SimpleJAXMClient");
        String mnsMessage = createMNSMessageFromDto(marketEventNotificationDto);
        mnsBroadcastSimpleJaxmClient.sendNotifications(mnsMessage);
    }

    public void sendMarketEventNotificationToMnsByHttpClient(MarketEventNotificationDto marketEventNotificationDto) {
        logger.info("Will sending MNS via SimpleHTTPClient");
        String mnsMessage = createMNSMessageFromDto(marketEventNotificationDto);
        mnsBroadcastSimpleHttpClient.sendNotifications(mnsMessage);
    }

    private String createMNSMessageFromDto(MarketEventNotificationDto marketEventNotificationDto) {

        String mnsMessageStr = "<ExternalNotificationMsg  xmlns=\"http://www.caiso.com/soa/2007-08-15/ExternalNotificationMsg.xsd\">"
                + "<ExternalNotification    xmlns=\"http://www.caiso.com/soa/2007-08-15/ExternalNotificationMsg.xsd\"> "
                + "<notificationAction    xmlns=\"http://www.caiso.com/soa/2007-08-15/ExternalNotificationMsg.xsd\">"
                + NotificationActionType.valueOf(marketEventNotificationDto.getMarketNotificationAction()) + "</notificationAction> "
                + "<notificationMessage   xmlns=\"http://www.caiso.com/soa/2007-08-15/ExternalNotificationMsg.xsd\">"
                + marketEventNotificationDto.getMarketEventDefNotificationMessage() + "</notificationMessage>"
                + "<notificationCode  xmlns=\"http://www.caiso.com/soa/2007-08-15/ExternalNotificationMsg.xsd\">"
                + marketEventNotificationDto.getMarketEventDefCode() + "</notificationCode>"
                + "<marketStartTime  xmlns=\"http://www.caiso.com/soa/2007-08-15/ExternalNotificationMsg.xsd\">"
                + dateUtil.getGeorgianDate(marketEventNotificationDto.getMarketDate()).toString() + "</marketStartTime>" + "</ExternalNotification>"
                + "</ExternalNotificationMsg>";

        return mnsMessageStr;
    }

    /**
     * This method is equivalent to the MDS Send MNS Market Event Publisher. It
     * will update the Market Event History Table It will also send the Market
     * Event Notification to the MNS service.
     * 
     * @param marketEventNotificationDto
     */
    public void marketNotificationBpmFlowWrapper(String marketPlanId, String marketRunId, XMLGregorianCalendar marketDate,
            MarketEventDefinitionDto marketEventDefinitionDto) {

        logger.info("*****  Entering marketNotificationBpmFlowWrapper  via Camel  ********");

        MarketEventNotificationDto marketEventNotificationDto = new MarketEventNotificationDto();

        marketEventDefinitionDto = marketEventDefinitionService.getMarketEventDefinitionByEventDefCode(marketEventDefinitionDto);

        marketEventNotificationDto = prepareMarketEventNotification(marketPlanId, marketRunId, marketDate.toGregorianCalendar().getTime(),
                marketEventDefinitionDto);

        logger.info("*****  Before Sending Market Event To MNS   ********");
        logger.info("Run Id  						 " + marketEventNotificationDto.getMarketRunId());
        logger.info("Plan Id  						 " + marketEventNotificationDto.getMarketPlanId());
        logger.info("Event Code  					" + marketEventNotificationDto.getMarketEventDefCode());
        logger.info("Event Def ID   				" + marketEventNotificationDto.getMarketEventDefId());
        logger.info("Event Notification Name  		" + marketEventNotificationDto.getMarketEventDefNotificationName());
        logger.info("Event Notification Messages	" + marketEventNotificationDto.getMarketEventDefNotificationMessage());
        logger.info("Event Notification ACTION   	" + marketEventNotificationDto.getMarketNotificationAction());
        logger.info("Market Trade Date 			   	" + marketEventNotificationDto.getMarketDate());
        logger.info("*****  End of Log MNS Message Still to be Sent  ********");

        long lastMarketStatusHistoryId = marketStatusService.getLastMarketStatusForMarketRunId(marketRunId);

        MarketEventHistoryDto marketEventHistoryDto = prepareMarketEventHistoryDetails(marketEventNotificationDto, lastMarketStatusHistoryId);

        marketEventHistoryService.createMarketEventHistory(marketEventHistoryDto);

        if (mdsToMnsBroadcastSwitchEnabled) {
            logger.info("switch is enabled and hence we will send by JAXM endpoint ");
            sendMarketEventNotificationToMnsByHttpClient(marketEventNotificationDto);
        } else {
            logger.info("Sending to MNS is not enabled {}, Please update the Properties to enable the Message Sending ", mdsToMnsBroadcastSwitchEnabled);
        }

        logger.info("*****  Exiting marketNotificationBpmFlowWrapper  via Camel  ********");

    }

    /**
     * 
     * @param pvMarketNotificationEvent
     * @param lastMarketStatusHistoryId
     * @return
     */
    private MarketEventHistoryDto prepareMarketEventHistoryDetails(MarketEventNotificationDto pvMarketNotificationEvent, long lastMarketStatusHistoryId) {
        MarketEventHistoryDto dto = new MarketEventHistoryDto();
        dto.setMarketPlanId(pvMarketNotificationEvent.getMarketPlanId());
        dto.setMarketRunId(pvMarketNotificationEvent.getMarketRunId());
        dto.setMarketEventDefinitionId(pvMarketNotificationEvent.getMarketEventDefId());
        dto.setMarketStatusHistoryId(lastMarketStatusHistoryId);
        logger.info(" Date Data " + pvMarketNotificationEvent.getMarketDate());

        if (pvMarketNotificationEvent.getMarketDate() != null) {
            dto.setMarketDate(pvMarketNotificationEvent.getMarketDate());
        } else {
            logger.warn("No Market date provide in the Market Notification event ");
        }

        dto.setMarketEventPubState("PUBLISHED");
        return dto;
    }

    /**
     * 
     * @param marketPlanId
     * @param marketRunId
     * @param marketEventDefinitionDto
     * @return
     */
    private MarketEventNotificationDto prepareMarketEventNotification(String marketPlanId, String marketRunId, Date marketStartDate,
            MarketEventDefinitionDto marketEventDefinitionDto) {

        MarketEventNotificationDto marketEventNotificationDto = new MarketEventNotificationDto();

        marketEventNotificationDto.setMarketEventDefNotificationMessage(marketEventDefinitionDto.getMarketEventDefNotificationMsg());
        marketEventNotificationDto.setMarketEventDefNotificationName(marketEventDefinitionDto.getMarketEventNotificationName());
        marketEventNotificationDto.setMarketEventDefCode(marketEventDefinitionDto.getMarketEventDefCode());
        marketEventNotificationDto.setMarketNotificationAction(MARKET_NOTIFICATION_INSERT_ACTION);
        marketEventNotificationDto.setMarketEventDefId(marketEventDefinitionDto.getMarketEventDefId());
        marketEventNotificationDto.setMarketDate(marketStartDate);
        marketEventNotificationDto.setMarketRunId(marketRunId);
        marketEventNotificationDto.setMarketPlanId(marketPlanId);

        return marketEventNotificationDto;
    }

}

package com.caiso.mds.external.mns.simple.broadcaster;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@SuppressWarnings("deprecation")
public class MnsBroadcastSimpleHttpSender implements Runnable {

    private final Logger logger = LoggerFactory.getLogger(MnsBroadcastSimpleHttpSender.class);

    private String       soapMsg;
    private String       endPointURL;
    private String       soapAction;

    public MnsBroadcastSimpleHttpSender(String vSoapMsg, String vEndPointUrl, String soapAction) {
        this.soapMsg = vSoapMsg;
        this.endPointURL = vEndPointUrl;
        this.soapAction = soapAction;
    }

    public void run() {

        HttpClient httpclient = null;
        HttpPost post = null;
        HttpResponse response = null;
        logger.info("Acquired the SoapConnection going to send MNS Message ");

        try {

            StringEntity strEntity = new StringEntity(soapMsg);
            post = new HttpPost(endPointURL);
            post.setHeader("Content-Type", "text/xml; charset=utf-8");
            post.setHeader("SOAPAction", soapAction);
            post.setEntity(strEntity);
            logger.info("Going to create HTTPClient : " + endPointURL);
            httpclient = new DefaultHttpClient();
            logger.info("execute  : " + endPointURL);
            response = httpclient.execute(post);

            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                logger.info("Message Sent Successfully to MNS Endpoint : " + endPointURL);
            } else {
                logger.warn("Was unable to send MNS Message to the ResponseCode [" + response.getStatusLine().getStatusCode() + "]" + " MNSEndpointUrl ["
                        + endPointURL + "]");
            }

        } catch (Exception ex) {
            logger.warn("Was unable to send MNS Message to the MNSUnableToSendURL [" + endPointURL + "]", ex);
        } finally {
            httpclient = null;
            post = null;
            response = null;
        }
    }
}

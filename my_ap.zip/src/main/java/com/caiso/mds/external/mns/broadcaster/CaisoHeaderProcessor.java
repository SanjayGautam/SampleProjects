/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.caiso.mds.external.mns.broadcaster;

import java.util.Random;

import javax.xml.bind.JAXBException;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.caiso.mds.util.DateUtil;
import com.caiso.mds.util.SoapHelper;
import com.caiso.soa._2006_09_30.caisowsheader.CAISOWSHeaderType;

@Component
public class CaisoHeaderProcessor {

    private final Logger       logger = LoggerFactory.getLogger(CaisoHeaderProcessor.class);

    private DateUtil           dateUtil;

    @Autowired
    private SoapHelper         soapHelper;

    public static final String SHA_1  = "SHA-1";

    public CaisoHeaderProcessor() {
        soapHelper = new SoapHelper();
    }

    public void process(Exchange exchange) throws Exception {

        Message camelMessage = exchange.getIn();

        /*
         * byte[] soapBodyPayload = (byte[]) exchange.getIn().getBody();
         * 
         * MessageFactory msgFactory = MessageFactory.newInstance();
         * ByteArrayInputStream bf = new ByteArrayInputStream(soapBodyPayload);
         */

        byte[] soapBodyPayload = (byte[]) exchange.getIn().getBody();

        logger.info(soapBodyPayload.toString());
        MimeHeaders mimeHdrs = soapHelper.getMimeHeaders(exchange);

        logger.info(" Headers Information " + mimeHdrs);
        SOAPMessage soapMessage = soapHelper.getSoapMessage(exchange);

        // envelope.addNamespaceDeclaration("env",
        // "http://schemas.xmlsoap.org/soap/envelope/");
        // SOAPBody soapBody = envelope.getBody();

        setSoapHeader(soapMessage);
        // setSoapBody(soapMessage);

        // soapBody.setNodeValue(soapBodyPayload.toString());
        camelMessage.setBody(soapMessage.getSOAPPart().getContent());
        exchange.setOut(camelMessage);

    }

    /**
     * 
     * @param soapMessage
     * @param envelope
     * @return
     * @throws SOAPException
     * @throws JAXBException
     */
    private SOAPHeader setSoapHeader(SOAPMessage soapMessage) throws SOAPException, JAXBException {

        /*
         * envelope.addNamespaceDeclaration("env",
         * "http://schemas.xmlsoap.org/soap/envelope/");
         * envelope.removeNamespaceDeclaration("ns2");
         */

        SOAPPart part = soapMessage.getSOAPPart();
        SOAPEnvelope envelope = part.getEnvelope();
        envelope.removeNamespaceDeclaration("ns3");
        envelope.removeNamespaceDeclaration("ns2");
        envelope.removeNamespaceDeclaration("ns4");
        // envelope.setPrefix("env");
        // envelope.addNamespaceDeclaration("env",
        // "http://schemas.xmlsoap.org/soap/envelope/");

        SOAPHeader soapHeader = soapMessage.getSOAPHeader();
        if (soapHeader == null) {
            soapHeader = envelope.addHeader();
        }

        CAISOWSHeaderType CAISOWSHeader = soapHelper.createCaisoWsHeaderTypeObject("mnsServer.caiso.com", "Nonce" + String.valueOf(new Random().nextInt()),
                String.valueOf(new Random().nextInt()));

        /*
         * ByteArrayOutputStream caisoHeaderByteArray =
         * soapHelper.marshal(CAISOWSHeader, true); soapHeader.addTextNode(new
         * String(caisoHeaderByteArray.toByteArray(),
         * StandardCharsets.ISO_8859_1));
         */

        soapHelper.createSoapHeaderForCaisoWsHeaderType(soapHeader, CAISOWSHeader);
        soapMessage.saveChanges();

        return soapHeader;
    }

    /**
     * 
     * @return
     */

    public DateUtil getDateUtil() {
        return dateUtil;
    }

    public void setDateUtil(DateUtil dateUtil) {
        this.dateUtil = dateUtil;
    }

}

package com.caiso.mds.exception;

import java.io.Serializable;

public class MdsBpmException extends Exception implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1323162467395101455L;

    public MdsBpmException(String message, Throwable faultInfo) {
        super(message, faultInfo);
    }

    public MdsBpmException(Throwable faultInfo) {
        super(faultInfo);
    }

    public MdsBpmException(String message) {
        super(message);
    }

}

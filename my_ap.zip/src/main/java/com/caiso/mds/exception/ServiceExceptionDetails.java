package com.caiso.mds.exception;

import java.io.Serializable;

public class ServiceExceptionDetails implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1847524737597952889L;

    private String            faultCode;
    private String            userFriendlyExceptionMessage;
    private String            detailedExceptionMessage;

    public ServiceExceptionDetails() {

    }

    public String getFaultCode() {
        return faultCode;
    }

    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }

    public String getUserFriendlyExceptionMessage() {
        return userFriendlyExceptionMessage;
    }

    public void setUserFriendlyExceptionMessage(String userFriendlyExceptionMessage) {
        this.userFriendlyExceptionMessage = userFriendlyExceptionMessage;
    }

    public String getDetailedExceptionMessage() {
        return detailedExceptionMessage;
    }

    public void setDetailedExceptionMessage(String detailedExceptionMessage) {
        this.detailedExceptionMessage = detailedExceptionMessage;
    }

}

package com.caiso.mds.exception;

public enum ServiceExceptionName {

    UnableToGenerateEventsSchedule("001", "Unable to Generate Event Schedules"), UnableToGenerateMarketPlans("002", "Unable to Generate Market Plans");

    private String errorCode = null;
    private String message   = null;

    ServiceExceptionName(String errorCode, String message) {
        this.setErrorCode(errorCode);
        this.setMessage(message);
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}

package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "marketStatusForRtmMarketType")
public class MarketStatusHistoryForRtmMarketTypeVO implements Serializable {

    /**
	 * 
	 */
    private static final long    serialVersionUID = 5661594922530938786L;

    private List<MarketStatusVO> marketStatusForRtmMarket;

    public List<MarketStatusVO> getMarketStatusForRtmMarket() {
        if (marketStatusForRtmMarket == null) {
            marketStatusForRtmMarket = new ArrayList<MarketStatusVO>();
        }
        return marketStatusForRtmMarket;
    }

    public void setMarketStatusForRtmMarket(List<MarketStatusVO> marketStatusForRtmMarket) {
        this.marketStatusForRtmMarket = marketStatusForRtmMarket;
    }

}

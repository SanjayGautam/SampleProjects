package com.caiso.mds.ui.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "marketStatusDetails")
public class MarketStatusVO implements Serializable {

    /**
	 * 
	 */

    private static final long       serialVersionUID = 7730580680187739643L;

    private String                  hourEnding;
    private BidAndSchedulesStatusVO bidAndSchedulesStatus;
    private InterScTradesStatusVO   interScTradesStatus;

    public String getHourEnding() {
        return hourEnding;
    }

    public void setHourEnding(String hourEnding) {
        this.hourEnding = hourEnding;
    }

    public BidAndSchedulesStatusVO getBidAndSchedulesStatus() {
        return bidAndSchedulesStatus;
    }

    public void setBidAndSchedulesStatus(BidAndSchedulesStatusVO bidAndSchedulesStatus) {
        this.bidAndSchedulesStatus = bidAndSchedulesStatus;
    }

    public InterScTradesStatusVO getInterScTradesStatus() {
        return interScTradesStatus;
    }

    public void setInterScTradesStatus(InterScTradesStatusVO interScTradesStatus) {
        this.interScTradesStatus = interScTradesStatus;
    }

}

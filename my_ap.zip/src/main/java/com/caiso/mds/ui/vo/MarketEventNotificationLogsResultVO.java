package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "marketEventNotificationLogsResult")
public class MarketEventNotificationLogsResultVO implements Serializable {

    /**
	 * 
	 */
    private static final long               serialVersionUID = -6256954642368237155L;

    private List<MarketEventNotificationVO> marketEventNotificationLogs;

    private long                            totalRowsCount;
    private int                             totalPagesCount;
    private int                             currentPageNumber;
    private int                             currentPageSize;

    public List<MarketEventNotificationVO> getMarketEventNotificationLogs() {
        return marketEventNotificationLogs;
    }

    public void setMarketEventNotificationLogs(List<MarketEventNotificationVO> marketEventNotificationLogs) {
        this.marketEventNotificationLogs = marketEventNotificationLogs;
    }

    public long getTotalRowsCount() {
        return totalRowsCount;
    }

    public void setTotalRowsCount(long totalRowsCount) {
        this.totalRowsCount = totalRowsCount;
    }

    public int getTotalPagesCount() {
        return totalPagesCount;
    }

    public void setTotalPagesCount(int totalPagesCount) {
        this.totalPagesCount = totalPagesCount;
    }

    public int getCurrentPageNumber() {
        return currentPageNumber;
    }

    public void setCurrentPageNumber(int currentPageNumber) {
        this.currentPageNumber = currentPageNumber;
    }

    public int getCurrentPageSize() {
        return currentPageSize;
    }

    public void setCurrentPageSize(int currentPageSize) {
        this.currentPageSize = currentPageSize;
    }

}

package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "mdsToSibrRequestLogsResult")
public class MdsToSibrRequestLogsResultVO implements Serializable {

    /**
	 * 
	 */
    private static final long           serialVersionUID = 3513507079895416733L;

    private List<MdsToSibrRequestLogVO> mdsToSibrRequestLogs;

    private long                        totalRowsCount;
    private int                         totalPagesCount;
    private int                         currentPageNumber;
    private int                         currentPageSize;

    public long getTotalRowsCount() {
        return totalRowsCount;
    }

    public void setTotalRowsCount(long totalRowsCount) {
        this.totalRowsCount = totalRowsCount;
    }

    public int getTotalPagesCount() {
        return totalPagesCount;
    }

    public void setTotalPagesCount(int totalPagesCount) {
        this.totalPagesCount = totalPagesCount;
    }

    public int getCurrentPageNumber() {
        return currentPageNumber;
    }

    public void setCurrentPageNumber(int currentPageNumber) {
        this.currentPageNumber = currentPageNumber;
    }

    public int getCurrentPageSize() {
        return currentPageSize;
    }

    public void setCurrentPageSize(int currentPageSize) {
        this.currentPageSize = currentPageSize;
    }

    public List<MdsToSibrRequestLogVO> getMdsToSibrRequestLogs() {
        return mdsToSibrRequestLogs;
    }

    public void setMdsToSibrRequestLogs(List<MdsToSibrRequestLogVO> mdsToSibrRequestLogs) {
        this.mdsToSibrRequestLogs = mdsToSibrRequestLogs;
    }

}

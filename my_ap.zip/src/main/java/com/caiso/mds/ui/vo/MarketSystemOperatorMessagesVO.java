package com.caiso.mds.ui.vo;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "operatorMessages")
public class MarketSystemOperatorMessagesVO {

    List<MarketSystemOperatorMessageVO> operatorMessages;

    private String                      responseResult = "No Data Found";

    public List<MarketSystemOperatorMessageVO> getOperatorMessages() {

        if (operatorMessages == null) {
            operatorMessages = new ArrayList<MarketSystemOperatorMessageVO>();
        }

        return operatorMessages;
    }

    public void setOperatorMessages(List<MarketSystemOperatorMessageVO> operatorMessages) {
        this.operatorMessages = operatorMessages;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

}

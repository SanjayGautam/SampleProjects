package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "bidAndSchedulesStatus")
public class BidAndSchedulesStatusVO implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -6020890648973841592L;
    private String            marketPlanId;
    private String            marketRunId;
    private String            marketCurrentStatus;
    private Date              marketDate;
    private long              marketDefId;
    private String            marketType;
    private String            marketClass;

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public String getMarketCurrentStatus() {
        return marketCurrentStatus;
    }

    public void setMarketCurrentStatus(String marketCurrentStatus) {
        this.marketCurrentStatus = marketCurrentStatus;
    }

    public Date getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(Date marketDate) {
        this.marketDate = marketDate;
    }

    public long getMarketDefId() {
        return marketDefId;
    }

    public void setMarketDefId(long marketDefId) {
        this.marketDefId = marketDefId;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType;

    }

    public void setMarketClass(String marketClass) {
        this.marketClass = marketClass;
    }

    public String getMarketType() {
        return marketType;
    }

    public String getMarketClass() {
        return marketClass;
    }

}

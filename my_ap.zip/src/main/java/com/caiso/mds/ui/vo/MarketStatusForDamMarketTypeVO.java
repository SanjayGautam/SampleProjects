package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "marketStatusForDamMarketType")
public class MarketStatusForDamMarketTypeVO implements Serializable {

    /**
	 * 
	 */
    private static final long    serialVersionUID = 6717995061978861759L;
    private List<MarketStatusVO> marketStatusForDamMarket;

    public List<MarketStatusVO> getMarketStatusForDamMarket() {
        if (marketStatusForDamMarket == null) {
            marketStatusForDamMarket = new ArrayList<MarketStatusVO>();
        }

        return marketStatusForDamMarket;
    }

    public void setMarketStatusForDamMarket(List<MarketStatusVO> marketStatusForDamMarket) {
        this.marketStatusForDamMarket = marketStatusForDamMarket;
    }

}

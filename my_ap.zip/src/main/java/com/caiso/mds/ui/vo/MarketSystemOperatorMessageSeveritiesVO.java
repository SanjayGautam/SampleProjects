package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "systemOperatorMessageSeverities")
public class MarketSystemOperatorMessageSeveritiesVO implements Serializable {

    /**
	 * 
	 */
    private static final long                           serialVersionUID              = 5161774014971319851L;

    private List<MarketSystemOperatorMessageSeverityVO> systemOperatorMessageSeverity = null;
    private String                                      responseResult                = "Data Not Found";

    public List<MarketSystemOperatorMessageSeverityVO> getSystemOperatorMessageSeverity() {
        return systemOperatorMessageSeverity;
    }

    public void setSystemOperatorMessageSeverity(List<MarketSystemOperatorMessageSeverityVO> systemOperatorMessageSeverities) {
        this.systemOperatorMessageSeverity = systemOperatorMessageSeverities;
    }

    public String getResponseResult() {
        return responseResult;
    }

    public void setResponseResult(String responseResult) {
        this.responseResult = responseResult;
    }

}

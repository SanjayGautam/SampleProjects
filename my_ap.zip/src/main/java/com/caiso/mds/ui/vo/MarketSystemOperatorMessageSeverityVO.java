package com.caiso.mds.ui.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "systemOperatorMessageSeverity")
public class MarketSystemOperatorMessageSeverityVO implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 7503299413418299892L;
    private long              messageSeverityId;
    private String            messageSeverityName;
    private String            messageSeverityDesc;

    public long getMessageSeverityId() {
        return messageSeverityId;
    }

    public void setMessageSeverityId(long messageSeverityId) {
        this.messageSeverityId = messageSeverityId;
    }

    public String getMessageSeverityName() {
        return messageSeverityName;
    }

    public void setMessageSeverityName(String messageSeverityName) {
        this.messageSeverityName = messageSeverityName;
    }

    public String getMessageSeverityDesc() {
        return messageSeverityDesc;
    }

    public void setMessageSeverityDesc(String messageSeverityDesc) {
        this.messageSeverityDesc = messageSeverityDesc;
    }

}

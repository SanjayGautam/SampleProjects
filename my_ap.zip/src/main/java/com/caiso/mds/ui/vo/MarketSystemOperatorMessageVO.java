package com.caiso.mds.ui.vo;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "operatorMessage")
public class MarketSystemOperatorMessageVO {

    private long   systemOperatorMessageId;
    private long   mdsSeverityId;
    private String mdsSeverityName;
    private Date   severityInsertDate;
    private String severityMessage;
    private String pollStatus;
    private String messageSubmittedBy;

    private String requestResult = "Error";

    public long getSystemOperatorMessageId() {
        return systemOperatorMessageId;
    }

    public void setSystemOperatorMessageId(long systemOperatorMessageId) {
        this.systemOperatorMessageId = systemOperatorMessageId;
    }

    public String getMdsSeverityName() {
        return mdsSeverityName;
    }

    public String getMessageSubmittedBy() {
        return messageSubmittedBy;
    }

    public void setMessageSubmittedBy(String messageSubmittedBy) {
        this.messageSubmittedBy = messageSubmittedBy;
    }

    public void setMdsSeverityName(String mdsSeverityName) {
        this.mdsSeverityName = mdsSeverityName;
    }

    public Date getSeverityInsertDate() {
        return severityInsertDate;
    }

    public void setSeverityInsertDate(Date severityInsertDate) {
        this.severityInsertDate = severityInsertDate;
    }

    public String getSeverityMessage() {
        return severityMessage;
    }

    public void setSeverityMessage(String severityMessage) {
        this.severityMessage = severityMessage;
    }

    public String getPollStatus() {
        return pollStatus;
    }

    public void setPollStatus(String pollStatus) {
        this.pollStatus = pollStatus;
    }

    public long getMdsSeverityId() {
        return mdsSeverityId;
    }

    public void setMdsSeverityId(long mdsSeverityId) {
        this.mdsSeverityId = mdsSeverityId;
    }

    public String getRequestResult() {
        return requestResult;
    }

    public void setRequestResult(String requestResult) {
        this.requestResult = requestResult;
    }

}

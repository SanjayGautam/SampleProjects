package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "marketEventNotification")
public class MarketEventNotificationVO implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 864534720793389404L;

    private Date              marketEventTime;
    private String            marketEventDefCode;
    private String            marketEventNotificationMsg;
    private Date              marketDate;
    private String            marketHour;
    private String            marketRunId;

    public Date getMarketEventTime() {
        return marketEventTime;
    }

    public void setMarketEventTime(Date marketEventTime) {
        this.marketEventTime = marketEventTime;
    }

    public String getMarketEventDefCode() {
        return marketEventDefCode;
    }

    public void setMarketEventDefCode(String marketEventDefCode) {
        this.marketEventDefCode = marketEventDefCode;
    }

    public String getMarketEventNotificationMsg() {
        return marketEventNotificationMsg;
    }

    public void setMarketEventNotificationMsg(String marketEventNotificationMsg) {
        this.marketEventNotificationMsg = marketEventNotificationMsg;
    }

    public Date getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(Date marketDate) {
        this.marketDate = marketDate;
    }

    public String getMarketHour() {
        return marketHour;
    }

    public void setMarketHour(String marketHour) {
        this.marketHour = marketHour;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

}

package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "marketStatuses")
public class MarketStatuses implements Serializable {

    /**
	 * 
	 */
    private static final long    serialVersionUID = -3898729078557935472L;

    private List<MarketStatusVO> marketStatusForDamMarkets;
    private List<MarketStatusVO> marketStatusForRtmMarkets;

    public List<MarketStatusVO> getMarketStatusForDamMarkets() {
        if (marketStatusForDamMarkets == null) {
            marketStatusForDamMarkets = new ArrayList<MarketStatusVO>();
        }
        return marketStatusForDamMarkets;
    }

    public void setMarketStatusForDamMarkets(List<MarketStatusVO> marketStatusForDamMarkets) {
        this.marketStatusForDamMarkets = marketStatusForDamMarkets;
    }

    public List<MarketStatusVO> getMarketStatusForRtmMarkets() {
        if (marketStatusForRtmMarkets == null) {
            marketStatusForRtmMarkets = new ArrayList<MarketStatusVO>();
        }
        return marketStatusForRtmMarkets;
    }

    public void setMarketStatusForRtmMarkets(List<MarketStatusVO> marketStatusForRtmMarkets) {
        this.marketStatusForRtmMarkets = marketStatusForRtmMarkets;
    }

}

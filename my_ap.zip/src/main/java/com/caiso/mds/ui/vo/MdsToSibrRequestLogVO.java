package com.caiso.mds.ui.vo;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "mdsToSibrRequestLog")
public class MdsToSibrRequestLogVO implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 864534720793389404L;

    private Date              requestedTime;
    private String            marketRunId;
    private String            marketPlanId;
    private Date              marketDate;
    private String            marketType;
    private String            marketClass;
    private String            serviceRequest;
    private String            serviceShortRequest;

    private String            serviceResponse;
    private String            serviceShortResponse;

    public Date getRequestedTime() {
        return requestedTime;
    }

    public void setRequestedTime(Date requestedTime) {
        this.requestedTime = requestedTime;
    }

    public String getMarketRunId() {
        return marketRunId;
    }

    public void setMarketRunId(String marketRunId) {
        this.marketRunId = marketRunId;
    }

    public String getMarketPlanId() {
        return marketPlanId;
    }

    public void setMarketPlanId(String marketPlanId) {
        this.marketPlanId = marketPlanId;
    }

    public Date getMarketDate() {
        return marketDate;
    }

    public void setMarketDate(Date marketDate) {
        this.marketDate = marketDate;
    }

    public String getMarketType() {
        return marketType;
    }

    public void setMarketType(String marketType) {
        this.marketType = marketType;
    }

    public String getMarketClass() {
        return marketClass;
    }

    public void setMarketClass(String marketClass) {
        this.marketClass = marketClass;
    }

    public String getServiceRequest() {
        return serviceRequest;
    }

    public void setServiceRequest(String serviceRequest) {
        this.serviceRequest = serviceRequest;
    }

    public String getServiceShortRequest() {
        return serviceShortRequest;
    }

    public void setServiceShortRequest(String serviceShortRequest) {
        this.serviceShortRequest = serviceShortRequest;
    }

    public String getServiceResponse() {
        return serviceResponse;
    }

    public void setServiceResponse(String serviceResponse) {
        this.serviceResponse = serviceResponse;
    }

    public String getServiceShortResponse() {
        return serviceShortResponse;
    }

    public void setServiceShortResponse(String serviceShortResponse) {
        this.serviceShortResponse = serviceShortResponse;
    }

}

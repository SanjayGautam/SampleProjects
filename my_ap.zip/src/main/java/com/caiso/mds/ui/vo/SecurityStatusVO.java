package com.caiso.mds.ui.vo;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "securityStatusDetails")
public class SecurityStatusVO implements Serializable {

    private static final long serialVersionUID = 7730581681187739644L;

    private String            userAccess;
    private String            mdsOperator;
    private String            mdsUserName;

    public String getMdsUserName() {
        return mdsUserName;
    }

    public void setMdsUserName(String mdsUserName) {
        this.mdsUserName = mdsUserName;
    }

    public String getUserAccess() {
        return userAccess;
    }

    public void setUserAccess(String userAccess) {
        this.userAccess = userAccess;
    }

    public String getMDSOperator() {
        return mdsOperator;
    }

    public void setMDSOperator(String mdsOperator) {
        this.mdsOperator = mdsOperator;
    }
}

package com.caiso.mds.dao.mds;

import java.util.List;

import com.caiso.mds.entity.mds.MrktStatusHistory;

public interface MdsMarketStatusHistoryDao {

    /**
     * 
     * @param mrktStatusHistory
     * @return
     */
    public MrktStatusHistory createMarketStatusHistory(MrktStatusHistory mrktStatusHistory);

    /**
     * 
     * @param mrktStatusHistories
     */
    public void createMarketStatusHistories(List<MrktStatusHistory> mrktStatusHistories);

    /**
     * 
     * @param marketPlanId
     * @return
     */
    public Long getLastMarketStatusForMarketRunId(String marketPlanId);

    /**
     * 
     * @param mdsPurgingNumberOfDaysInPast
     * @return
     */
    public int deleteMarketStatusHistoryBasedOnDaysInPast(Integer daysInPast);

    /**
     * 
     * @return
     */
    public Long getMaxMarketStatusHistoryId();

}

package com.caiso.mds.dao.mds;

import java.util.List;

import com.caiso.mds.entity.mds.MrktMdsSeverity;

public interface MdsOperatorMsgSeverityDao {

    /**
     * 
     * @return
     */
    public List<MrktMdsSeverity> getAllMdsSeverities();

}

package com.caiso.mds.dao.mds;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.ExternalSystemEndpoint;
import com.caiso.mds.types.ExternalSystemName;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class ExternalSystemEndpointDaoImpl implements ExternalSystemEndpointDao {

    private final Logger  logger = LoggerFactory.getLogger(ExternalSystemEndpointDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    /**
     * 
     * Logic of sending messages Logic of sending may differ, one may be send
     * message on one Endpoint in group and then if fails try to send message on
     * the other url till message goes and then fail.
     * 
     * SIBR Details External systems are exposed via AI and hence when we tell
     * external system url we trying to map it to the AI internal URLS or End
     * Points. All the one with SIBR is broadcastSIBR AI , All MDS TO SIBR
     * message will be first send to first Endpoint and if that is not up and
     * running it will try second one.
     * 
     * MNS Details MNS pertains to all the Endpoints which comes under Market
     * Participants , They can be Internal AI endpoints or they can be totally
     * External EndPoints on the extranet . These Endpoints may be totally
     * belong to different system different organisations Objective is to create
     * buckets.
     * 
     * All the messages will be sent to all the endpoints at the same time
     * simultanesoulsy
     * 
     * 
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<ExternalSystemEndpoint> getActiveExternalSystemEndPointsBySystemNameAndSignFlag(ExternalSystemName externalSystemName, String signMsg) {

        logger.debug(" **** Entering method getAllActiveMrktParticipants *****  ");
        Query mpEndpointsQuery = mdsEntityManager
                .createQuery("FROM ExternalSystemEndpoint mp WHERE mp.externalSystemSrvcEnabled=:mpSrvcEnabled  and mp.externalSystemName=:externalSystemName and mp.signMsg=:signMsg ");
        mpEndpointsQuery.setParameter("mpSrvcEnabled", "Y");
        mpEndpointsQuery.setParameter("signMsg", signMsg);
        mpEndpointsQuery.setParameter("externalSystemName", externalSystemName.getName());

        List<ExternalSystemEndpoint> list = mpEndpointsQuery.getResultList();
        logger.info("Fetched Active market participants of size :{}", list.size());
        logger.debug(" **** Exiting method getAllActiveMrktParticipants *****  ");
        return list;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<ExternalSystemEndpoint> getActiveExternalSystemEndPointsBySystemName(ExternalSystemName externalSystemName) {
        logger.debug(" **** Entering method getAllActiveMrktParticipants *****  ");
        Query mpEndpointsQuery = mdsEntityManager
                .createQuery("FROM ExternalSystemEndpoint mp WHERE mp.externalSystemSrvcEnabled=:mpSrvcEnabled  and mp.externalSystemName=:externalSystemName");
        mpEndpointsQuery.setParameter("mpSrvcEnabled", "Y");
        mpEndpointsQuery.setParameter("externalSystemName", externalSystemName.getName());

        List<ExternalSystemEndpoint> list = mpEndpointsQuery.getResultList();
        logger.info("Fetched Active market participants of size :{}", list.size());
        logger.debug(" **** Exiting method getAllActiveMrktParticipants *****  ");
        return list;
    }
}

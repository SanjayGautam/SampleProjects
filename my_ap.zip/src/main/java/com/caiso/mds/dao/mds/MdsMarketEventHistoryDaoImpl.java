package com.caiso.mds.dao.mds;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktEventLogResults;
import com.caiso.mds.entity.mds.MrktEvntHistory;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMarketEventHistoryDaoImpl implements MdsMarketEventHistoryDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMarketEventHistoryDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public MrktEvntHistory createMrktEvntHistory(MrktEvntHistory mrktEvntHistory) {

        logger.debug("**** Entering createMrktEvntHistory *****  ");
        mdsEntityManager.persist(mrktEvntHistory);
        logger.info(" Market Event History record was created successfully with Market Event History Id:{}", mrktEvntHistory.getMrktEvntHistoryId());
        logger.debug("**** Exiting createMrktEvntHistory *****  ");
        return mrktEvntHistory;
    }

    @SuppressWarnings("unchecked")
    @Override
    public MrktEventLogResults getMrtEventHistoryLog(int pageNumber, int pageSize, Date lastCreatedDateInPst) {

        logger.debug("**** Entering getMrtEventHistoryLog *****  ");
        List<MrktEvntHistory> marketEventHistories = null;
        MrktEventLogResults marketEventLogResults = null;
        Query marketEventHistoryQuery = mdsEntityManager.createQuery("	FROM MrktEvntHistory meh "
                + "	WHERE meh.createdDt >= :lastCreatedDate order by meh.createdDt DESC");

        Query queryTotal = mdsEntityManager.createQuery("SELECT count(meh.mrktStatusHistoryId) " + " FROM MrktEvntHistory meh "
                + "	WHERE meh.createdDt >= :lastCreatedDate order by meh.createdDt");

        queryTotal.setParameter("lastCreatedDate", lastCreatedDateInPst);
        long totalRowCount = (long) queryTotal.getSingleResult();

        // + 1 because first results indexed at 0
        int totalPageCount = (int) ((totalRowCount / pageSize) + 1);
        logger.info("calculation for queryTotal:{} and totalPageCount:{}", totalRowCount, totalPageCount);

        if (pageNumber < totalRowCount) {
            marketEventHistoryQuery.setFirstResult((pageNumber - 1) * pageSize);
            marketEventHistoryQuery.setMaxResults(pageSize);
            marketEventHistoryQuery.setParameter("lastCreatedDate", lastCreatedDateInPst);
            marketEventHistories = marketEventHistoryQuery.getResultList();
            logger.info("Fetched the market event history records for pageNumber:{}, pageSize:{} , lastCreatedDateInPst:{}", pageNumber, pageSize,
                    lastCreatedDateInPst);
            marketEventLogResults = new MrktEventLogResults();
            marketEventLogResults.setCurrentPageNumber(pageNumber);
            marketEventLogResults.setCurrentPageSize(pageSize);
            marketEventLogResults.setMarketEventHistories(marketEventHistories);
            marketEventLogResults.setTotalPagesCount(totalPageCount);
            marketEventLogResults.setTotalRowsCount(totalRowCount);
            logger.info("Market Event History Records size:{}", marketEventHistories.size());

        } else {
            logger.warn("Issue while pagination pageNumber:{} was smaller than total row count:{} returned", pageNumber, totalRowCount);
        }

        logger.debug("**** Exiting getMrtEventHistoryLog *****  ");

        return marketEventLogResults;

    }

    @Override
    public int deleteMarketEventHistoryBasedOnDaysInPast(Integer daysInPast) {
        logger.debug("***** Entered deleteMarketEventHistoryBasedOnDaysInPast() ********** ");

        Calendar dayInPast = Calendar.getInstance();
        dayInPast.roll(Calendar.DAY_OF_YEAR, -daysInPast);

        Query query = mdsEntityManager.createQuery("delete from MrktEvntHistory r where r.createdDt < :dateInPast ").setParameter("dateInPast",
                dayInPast.getTime());

        int recordsDeleted = query.executeUpdate();

        logger.debug("***** Exit deleteMarketEventHistoryBasedOnDaysInPast() ********** ");
        return recordsDeleted;
    }

}

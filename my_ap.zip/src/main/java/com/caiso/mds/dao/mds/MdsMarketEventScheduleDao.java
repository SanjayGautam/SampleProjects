package com.caiso.mds.dao.mds;

import java.util.List;

import org.joda.time.DateTime;

import com.caiso.mds.entity.mds.MrktEvntNotification;
import com.caiso.mds.entity.mds.MrktEvntSchd;

public interface MdsMarketEventScheduleDao {

    public void createMarketEventSchedule(MrktEvntSchd mrktEvntSchd);

    /**
     * 
     * @return
     */
    public DateTime getLastMarketDateSchedule();

    /**
     * 
     * @param mrktEvntSchds
     */
    public void createMarketEventSchedules(List<MrktEvntSchd> mrktEvntSchds);

    /**
     * 
     * @param marketEventDefinitionId
     */
    public List<MrktEvntNotification> getMarketEventNotifications(long marketEventDefinitionId);

    /**
     * 
     * @return
     */
    public List<MrktEvntNotification> getAllMarketEventsToPublishNow(String marketEventPubState);

    /**
     * 
     * @param mrktEvntSchd
     */
    public void updateMrktEvntSchd(MrktEvntSchd mrktEvntSchd);

    /**
     * 
     * @param marketEventPubState
     * @return
     */
    public List<MrktEvntNotification> getAllOpenMarketEventsNotPublishedYet(String marketEventPubState, String mrktEvntType, int lastHours);

}

package com.caiso.mds.dao.mds;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktSysOperatorMsg;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMarketSysOperatorMsgDaoImpl implements MdsMarketSysOperatorMsgDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMarketSysOperatorMsgDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public MrktSysOperatorMsg createMrktSysOperatorMsg(MrktSysOperatorMsg mrktSysOperatorMsg) {
        logger.debug("****** Entering  method createMrktSysOperatorMsg *******  ");
        mdsEntityManager.persist(mrktSysOperatorMsg);
        logger.info("Created MarketSystem System Operating Message successfully with id :{}", mrktSysOperatorMsg.getMrkSysOperatorMsgId());
        logger.debug("****** Exiting  method createMrktSysOperatorMsg *******  ");

        return mrktSysOperatorMsg;
    }

    @Override
    public List<MrktSysOperatorMsg> getMrktSysOperatorMsgsForLastHours(int lastHours) {

        logger.debug("****** Entering  method getMrktSysOperatorMsgsForLastHours *******  ");

        String ql = " FROM com.caiso.mds.entity.mds.MrktSysOperatorMsg as msom " + " WHERE " + " msom.severityInsertDts >=  :last24Hours  "
                + " ORDER BY msom.severityInsertDts desc ";

        TypedQuery<MrktSysOperatorMsg> mrktSysOperatorMsgQuery = mdsEntityManager.createQuery(ql, MrktSysOperatorMsg.class);

        DateTime marketDateInPST = new DateTime();

        mrktSysOperatorMsgQuery.setParameter("last24Hours", marketDateInPST.minusHours(lastHours).toDate());

        List<MrktSysOperatorMsg> list = mrktSysOperatorMsgQuery.getResultList();

        logger.info("Last {} Hours System operator messages record size:{}", lastHours, list.size());

        logger.debug("****** Existing  method getMrktSysOperatorMsgsForLastHours *******  ");
        return list;
    }

    @Override
    public void updateMrktSysOperatorMsg(MrktSysOperatorMsg mrktSysOperatorMsg) {
        logger.debug("****** Entering  method updateMrktSysOperatorMsg *******  ");
        mdsEntityManager.merge(mrktSysOperatorMsg);
        logger.info("Market System System Operating Message updated for ID:{} successfully", mrktSysOperatorMsg.getMrkSysOperatorMsgId());
        logger.debug("****** Exiting  method updateMrktSysOperatorMsg *******  ");
    }

    /**
     * 
     */
    @Override
    public List<MrktSysOperatorMsg> getOperatingMessagesNotPublishedToOasis(String oasisPublishedStatus) {

        CriteriaBuilder builder = mdsEntityManager.getCriteriaBuilder();
        CriteriaQuery<MrktSysOperatorMsg> criteriaQuery = builder.createQuery(MrktSysOperatorMsg.class);
        Root<MrktSysOperatorMsg> notificationCtlRoot = criteriaQuery.from(MrktSysOperatorMsg.class);

        Predicate mdsFlowStatePredicate = builder.equal(notificationCtlRoot.get("oasisPublishedStatus"), oasisPublishedStatus);

        criteriaQuery = criteriaQuery.select(notificationCtlRoot).where(mdsFlowStatePredicate)
                .orderBy(builder.asc(notificationCtlRoot.get("severityInsertDts")));

        List<MrktSysOperatorMsg> list = mdsEntityManager.createQuery(criteriaQuery).getResultList();

        return list;
    }

}

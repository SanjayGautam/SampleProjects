package com.caiso.mds.dao.mds;

import java.util.List;

import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.entity.mds.MrktEvntDef;

public interface MdsMarketEventDefinitionDao {

    /**
     * 
     * @param isExternalEvent
     * @param enabled
     * @param hasFixedEventTriggerTime
     * @return
     */
    public List<MrktEvntDef> getMarketEventDef(boolean isExternalEvent, boolean enabled, boolean hasFixedEventTriggerTime);

    /**
     * 
     * @param marketEventDefinitionDto
     * @return
     */
    public MrktEvntDef getMarketDefinitionByEventCode(MarketEventDefinitionDto marketEventDefinitionDto);

    /**
     * 
     * @param marketEventDefId
     * @param marketEventType
     * @return
     */
    public MrktEvntDef getMarketDefinitionByMarketDefIdAndMarketEventType(long marketEventDefId, String marketEventType);

}

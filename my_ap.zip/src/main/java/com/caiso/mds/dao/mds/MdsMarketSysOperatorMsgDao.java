package com.caiso.mds.dao.mds;

import java.util.List;

import com.caiso.mds.entity.mds.MrktSysOperatorMsg;

public interface MdsMarketSysOperatorMsgDao {

    /**
     * 
     * @param mrktSysOperatorMsg
     * @return
     */
    public MrktSysOperatorMsg createMrktSysOperatorMsg(MrktSysOperatorMsg mrktSysOperatorMsg);

    /**
     * 
     * @param lastHours
     * @return
     */
    public List<MrktSysOperatorMsg> getMrktSysOperatorMsgsForLastHours(int lastHours);

    /**
     * 
     * @param mrktSysOperatorMsg
     */
    public void updateMrktSysOperatorMsg(MrktSysOperatorMsg mrktSysOperatorMsg);

    /**
     * 
     * @param string
     * @return
     */
    public List<MrktSysOperatorMsg> getOperatingMessagesNotPublishedToOasis(String oasisPublishedStatus);

}

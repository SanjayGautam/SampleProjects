package com.caiso.mds.dao.mds;

import com.caiso.mds.entity.mds.MdsLog;

public interface MdsLogDao {

    /**
     * 
     * @param mdsLog
     * @return
     */
    public MdsLog createMdsLogRecord(MdsLog mdsLog);

    /**
     * 
     * @param daysInPast
     */
    public int deleteMdsLogRecordsBasedOnDaysInPast(Integer daysInPast);

}

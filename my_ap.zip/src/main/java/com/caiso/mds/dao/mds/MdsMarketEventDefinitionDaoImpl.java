package com.caiso.mds.dao.mds;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.dto.MarketEventDefinitionDto;
import com.caiso.mds.entity.mds.MrktEvntDef;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMarketEventDefinitionDaoImpl implements MdsMarketEventDefinitionDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMarketEventDefinitionDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    /**
     * This Method We want only to get the events for which MDS is responsible
     * to generate and dispatch, There are some events in this table which come
     * actually happens in Market Or Other System MDS is not responsible for its
     * scheduled dispatch to Market a.k.a SIBR. All the responsibility of MDS is
     * to just pass them through to other systems. we will not need them for
     * generating scheduled events. To identify those market events we have
     * discriminatory isExternalEvnt.
     */

    @Override
    public List<MrktEvntDef> getMarketEventDef(boolean isExternalEvent, boolean enabled, boolean hasFixedEventTriggerTime) {

        logger.debug("***  Entering the getMarketEventDef ********* ");
        String query = "SELECT med FROM MrktEvntDef med WHERE med.isExternalEvnt = :isExternalEvnt AND med.isEnabled = :enabled AND med.hasFixedEventTriggerTime = :hasFixedEventTriggerTime";

        List<MrktEvntDef> list = mdsEntityManager.createQuery(query, MrktEvntDef.class).setParameter("isExternalEvnt", isExternalEvent)
                .setParameter("enabled", enabled).setParameter("hasFixedEventTriggerTime", hasFixedEventTriggerTime).getResultList();

        logger.info(" Market Event Defintion Fetched with {} {} {} in DAO Size= {}	:", isExternalEvent, enabled, hasFixedEventTriggerTime, list.size());
        logger.debug("***  Exiting the getMarketEventDef ********* ");
        return list;
    }

    @Override
    public MrktEvntDef getMarketDefinitionByEventCode(MarketEventDefinitionDto marketEventDefinitionDto) {
        logger.debug("***  Entering getMarketDefinitionByEventCode By Event Code  ********* ");
        String query = "SELECT med FROM MrktEvntDef med WHERE med.mrktEvntCd = :mrktEvntDefCode";

        MrktEvntDef mrktEvntDef = mdsEntityManager.createQuery(query, MrktEvntDef.class)
                .setParameter("mrktEvntDefCode", marketEventDefinitionDto.getMarketEventDefCode()).getSingleResult();
        if (mrktEvntDef != null) {
            logger.info(" Market Event Definition For Event Code:{} is Market Event Def Id :{}", marketEventDefinitionDto.getMarketEventDefCode(),
                    mrktEvntDef.getMrktEvntDefId());
        } else {
            logger.warn(" Market Event Definition For Event Code:{} is not found ");
        }
        logger.debug("***  Exiting getMarket Definition By Event Code ********* ");
        return mrktEvntDef;
    }

    @Override
    public MrktEvntDef getMarketDefinitionByMarketDefIdAndMarketEventType(long associatedMarketDefintion, String marketEventType) {
        logger.debug("***  get Market Defintion By market Def Id and Marker Event Type   ********* ");
        String query = "SELECT med FROM MrktEvntDef med WHERE med.assocMrktDefinitionId = :assocMrktDefinitionId and med.mrktEvntType =:mrktEvntType ";

        MrktEvntDef mrktEvntDef = mdsEntityManager.createQuery(query, MrktEvntDef.class).setParameter("assocMrktDefinitionId", associatedMarketDefintion)
                .setParameter("mrktEvntType", marketEventType).getSingleResult();
        if (mrktEvntDef != null) {
            logger.info("Market Event Definition For associatedMarketDefinition:{} is MarketEventType:{} is found", associatedMarketDefintion, marketEventType,
                    mrktEvntDef.getMrktEvntDefId());
        } else {
            logger.warn("Market Event Definition For associatedMarketDefinition:{} is MarketEventType:{} is not found");
        }

        logger.debug("***  Exiting Market Defintion By market Def Id and Marker Event Type   ********* ");
        return mrktEvntDef;

    }

}

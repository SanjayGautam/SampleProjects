package com.caiso.mds.dao.mds;

import java.util.List;

import com.caiso.mds.entity.mds.MrktDefinition;
import com.caiso.mds.types.MarketType;

public interface MdsMarketDefinitionDao {

    /**
     * 
     * @param marketType
     * @return
     */
    public List<MrktDefinition> getMarketDefintionByMarketType(MarketType marketType);
}

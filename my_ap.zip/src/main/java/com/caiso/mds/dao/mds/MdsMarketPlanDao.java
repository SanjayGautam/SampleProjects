package com.caiso.mds.dao.mds;

import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;

import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktPlanAndStatusDetails;
import com.caiso.mds.types.MarketType;

public interface MdsMarketPlanDao {

    /**
     * 
     * @return
     */
    public DateTime getLastMarketPlanDate();

    /**
     * 
     * @param mrktPlans
     */
    public void createMrktPlans(List<MrktPlan> mrktPlans);

    /**
     * 
     * @param mrktPlan
     */
    public void createMrktPlan(MrktPlan mrktPlan);

    /**
     * 
     * @param mrktPlan
     */
    public void updateMrktPlan(MrktPlan mrktPlan);

    /**
     * 
     * @param marketType
     * @return
     */
    public DateTime getLastMarketPlanDateByMarketType(MarketType marketType);

    /**
     * 
     * @param marketPlanId
     * @param marketRunId
     * @return
     */
    public MrktPlan getMarketPlan(String marketPlanId, String marketRunId);

    /**
     * 
     * @param marketDate
     * @param marketDefId
     * @return
     */
    public List<MrktPlan> getMarketPlans(Date marketDate, Long marketDefId);

    /**
     * 
     * @param marketPlanId
     * @param marketRunId
     * @return
     */
    public List<MrktPlan> getMarketPlansForMarketPlanIdAndMarketDefId(String marketPlanId, Long marketRunId);

    /**
     * 
     * @param marketPlanId
     * @param marketDefId
     * @return
     */
    public String getMarketStatusForMarketPlanIdAndDefId(String marketPlanId, Long marketDefId);

    /**
     * 
     * @param marketDateInPST
     * @param marketDefIds
     * @return
     */
    public List<MrktPlanAndStatusDetails> getMarketStatusForMainMarketDate(Date marketDateInPST, List<Long> marketDefIds);

    /**
     * 
     * @param marketDateInPST
     * @param marketDefIds
     * @return
     */
    public List<MrktPlanAndStatusDetails> getMarketStatusForMainMarketsForCurrentHour(Date marketDateInPST, List<Long> marketDefIds);

}

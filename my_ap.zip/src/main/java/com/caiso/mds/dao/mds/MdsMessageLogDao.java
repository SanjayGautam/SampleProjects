package com.caiso.mds.dao.mds;

import javax.persistence.EntityManager;

import com.caiso.mds.entity.mds.MdsLog;

public interface MdsMessageLogDao {

    /**
     * 
     * @return
     */
    public EntityManager getMdsEntityManager();

    /**
     * 
     * @param mdsEntityManager
     */
    public void setMdsEntityManager(EntityManager mdsEntityManager);

    /**
     * 
     * @param mdsLog
     * @return
     */
    public MdsLog createMessageLogRecord(MdsLog mdsLog);

    /**
     * 
     * @param mktClass
     * @param mktType
     * @param mktId
     * @return
     */
    public Integer getMarketRunId(String mktClass, String mktType, String mktId);

    /**
     * 
     * @param mktId
     * @return
     */
    public String getTradeDateForMarketId(String mktId);
}

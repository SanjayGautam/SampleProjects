package com.caiso.mds.dao.oasis;

import java.util.List;

import javax.persistence.EntityManager;

import com.caiso.mds.entity.oasis.MdsAweNotification;
import com.caiso.mds.entity.oasis.MdsNotificationCtlOasis;

public interface MdsOasisNotificationCtlDao {

    /**
     * 
     * @return
     */
    public EntityManager getMdsCmriEntityManager();

    /**
     * 
     * @param mdsCmriEntityManager
     */
    public void setMdsCmriEntityManager(EntityManager mdsCmriEntityManager);

    /**
     * 
     * @param mdsNotificationCtlOasis
     */
    public void updateNotificationCtl(MdsNotificationCtlOasis mdsNotificationCtlOasis);

    /**
     * 
     * @param mdsNotificationCtlOasis
     */
    public void createNotificationCtl(MdsNotificationCtlOasis mdsNotificationCtlOasis);

    /**
     * 
     * @param mdsNotificationCtlOasis
     * @return
     */
    public MdsNotificationCtlOasis getOasisNotificationCtlInReadyStatusAndMdsFlowStatusNull(MdsNotificationCtlOasis mdsNotificationCtlOasis);

    /**
     * 
     * @param mdsNotificationCtlOasis
     * @return
     */
    public List<MdsNotificationCtlOasis> getOasisNotificationRecordsByMdsFlowStateAndNotificationNames(MdsNotificationCtlOasis mdsNotificationCtlOasis);

    /**
     * 
     * @param mdsAweNotification
     */
    public void createMdsAweNotifications(MdsAweNotification mdsAweNotification);

}

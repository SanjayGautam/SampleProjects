package com.caiso.mds.dao.mds;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktEvntNotification;
import com.caiso.mds.entity.mds.MrktEvntSchd;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMarketEventScheduleDaoImpl implements MdsMarketEventScheduleDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMarketEventScheduleDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public void createMarketEventSchedule(MrktEvntSchd mrktEvntSchd) {
        logger.debug("*************** Entered createMarketEventSchedule ********** ");
        mdsEntityManager.persist(mrktEvntSchd);
        logger.info("Market Event Schedule created successfully with id:{}", mrktEvntSchd.getMrktEvntSchdId());
        logger.debug("*************** Exiting createMarketEventSchedule ********** ");
    }

    @Override
    public void createMarketEventSchedules(List<MrktEvntSchd> mrktEvntSchds) {
        logger.debug("*************** Entered createMarketEventSchedules ********** ");

        for (MrktEvntSchd mrktEvntSchd : mrktEvntSchds) {
            mdsEntityManager.persist(mrktEvntSchd);
        }

        logger.info("Successfully Inserted the Market EVent Schedule in table ");

        logger.debug("*************** Exiting createMarketEventSchedules ********** ");

    }

    @Override
    public DateTime getLastMarketDateSchedule() {

        logger.debug("*************** Entered getLastMarketDateSchedule ********** ");
        Query getMaxMrktDateQuery = mdsEntityManager.createQuery(" SELECT max(mrktDate) from MrktEvntSchd ");
        DateTime maxMarketDate = (DateTime) getMaxMrktDateQuery.getSingleResult();
        if (maxMarketDate != null) {
            logger.info(" last market date schedule event obtained is :{}", maxMarketDate);
        } else {
            logger.warn(" last market date schedule event's market date is null");
        }

        logger.debug("*************** Exiting getLastMarketDateSchedule ********** ");
        return maxMarketDate;
    }

    @Override
    public List<MrktEvntNotification> getMarketEventNotifications(long marketEventDefinitionId) {

        logger.debug("*************** Entered getMarketEventNotifications ********** ");

        String ql = " SELECT NEW com.caiso.mds.entity.mds.MrktEvntNotification( mrktPlan.id.mrktPlanId , mrktPlan.id.mrktRunId, "
                + " mrktEvntSchd.mrktEvntSchdId, mrktEvntSchd.mrktEvntFireDate, mrktEvntSchd.mrktDate,  mrktEvntSchd.mrktDefinition.mrktDefinitionId, "
                + " mrktEvntSchd.mrktDefinition.mrktType, mrktEvntSchd.mrktDefinition.mrktClass , mrktEvntSchd.mrktDefinition.mrktDefDesc , "
                + " mrktEvntSchd.mrktEvntDef.mrktEvntDefId , mrktEvntSchd.mrktEvntDef.mrktEvntDesc , mrktEvntSchd.mrktEvntDef.mrktEvntNotificationName,  "
                + " mrktEvntSchd.mrktEvntDef.mrktEvntNotificationMsg , mrktEvntSchd.mrktEvntDef.mrktEvntCd, " + " mrktPlan.mrktHour) "
                + " FROM  MrktEvntSchd as mrktEvntSchd  , MrktPlan as mrktPlan " + " WHERE mrktEvntSchd.mrktDefinition.mrktDefinitionId= :mrktDefinitionId "
                + " AND   mrktEvntSchd.mrktEvntFireDate = :currDateTruncatedToMinute " + " AND   mrktEvntSchd.mrktDate = mrktPlan.mrktDate "
                + " AND   mrktplan.mrktDefinition.mrktDefinitionId = mrktEvntSchd.mrktDefinition.mrktDefinitionId "
                + " ORDER BY mrktEvntSchd.mrktEvntFireDate asc , mrktplan.mrktHour asc ";

        TypedQuery<MrktEvntNotification> mrktEventNotificationsQuery = mdsEntityManager.createQuery(ql, MrktEvntNotification.class);
        mrktEventNotificationsQuery.setParameter("mrktDefinitionId", marketEventDefinitionId);
        DateTime sysdate = DateTime.now();
        sysdate = sysdate.withSecondOfMinute(0);
        sysdate = sysdate.withMillisOfSecond(0);
        mrktEventNotificationsQuery.setParameter("currDateTruncatedToMinute", sysdate);

        List<MrktEvntNotification> list = mrktEventNotificationsQuery.getResultList();

        logger.info("Sysdate at the time of comparision " + sysdate.toString());
        logger.info("Market Defintion Id for which Scheduled Market Events are fetched for :{}", marketEventDefinitionId);
        logger.info("Number of Scheduled Market Events fetched :{}", list.size());

        logger.debug("*************** Exiting getMarketEventNotifications ********** ");
        return list;
    }

    @Override
    public List<MrktEvntNotification> getAllMarketEventsToPublishNow(String marketEventPubState) {

        logger.debug("*************** Entering getAllMarketEventsToPublishNow ********** ");

        String ql = " SELECT NEW com.caiso.mds.entity.mds.MrktEvntNotification( mrktPlan.id.mrktPlanId , mrktPlan.id.mrktRunId, "
                + " mrktEvntSchd.mrktEvntSchdId, mrktEvntSchd.mrktEvntFireDate, mrktEvntSchd.mrktDate,  mrktEvntSchd.mrktDefinition.mrktDefinitionId, "
                + " mrktEvntSchd.mrktDefinition.mrktType, mrktEvntSchd.mrktDefinition.mrktClass , mrktEvntSchd.mrktDefinition.mrktDefDesc , "
                + " mrktEvntSchd.mrktEvntDef.mrktEvntDefId , mrktEvntSchd.mrktEvntDef.mrktEvntDesc , mrktEvntSchd.mrktEvntDef.mrktEvntType , mrktEvntSchd.mrktEvntDef.mrktEvntNotificationName,  "
                + " mrktEvntSchd.mrktEvntDef.mrktEvntNotificationMsg , mrktEvntSchd.mrktEvntDef.mrktEvntCd,  mrktPlan.mrktHour, mrktEvntSchd.mrktEvntPubState) "
                + " FROM  MrktEvntSchd as mrktEvntSchd  , MrktPlan as mrktPlan " + " WHERE mrktEvntSchd.mrktEvntFireDate = :currDateTruncatedToMinute "
                + " AND   mrktEvntSchd.mrktDate = mrktPlan.mrktDate "
                + " AND   mrktplan.mrktDefinition.mrktDefinitionId = mrktEvntSchd.mrktDefinition.mrktDefinitionId "
                + " AND   mrktEvntSchd.mrktEvntPubState =:marketEventPubState "

                + " ORDER BY mrktEvntSchd.mrktEvntFireDate asc , mrktplan.mrktHour asc ";

        TypedQuery<MrktEvntNotification> mrktEventNotificationsQuery = mdsEntityManager.createQuery(ql, MrktEvntNotification.class);

        DateTime sysdate = DateTime.now();
        sysdate = sysdate.withSecondOfMinute(0);
        sysdate = sysdate.withMillisOfSecond(0);
        mrktEventNotificationsQuery.setParameter("currDateTruncatedToMinute", sysdate);
        mrktEventNotificationsQuery.setParameter("marketEventPubState", marketEventPubState);

        List<MrktEvntNotification> list = mrktEventNotificationsQuery.getResultList();

        logger.info("Events Fetched for Schedule Time:{} at the time of comparision with database market date", sysdate);
        logger.info("Number of Scheduled Market Events fetched : {} ", list.size());
        logger.debug("*************** Exiting getAllMarketEventsToPublishNow ********** ");
        return list;
    }

    @Override
    public void updateMrktEvntSchd(MrktEvntSchd mrktEvntSchd) {
        mdsEntityManager.merge(mrktEvntSchd);
    }

    /**
     * 
     */
    @Override
    public List<MrktEvntNotification> getAllOpenMarketEventsNotPublishedYet(String marketEventPubState, String mrktEvntType, int lastHours) {
        logger.debug("*************** Entering MdsMarketEventScheduleDaoImpl.getAllOpenMarketEventsNotPublishedYet ********** ");

        String ql = " SELECT NEW com.caiso.mds.entity.mds.MrktEvntNotification( mrktPlan.id.mrktPlanId , mrktPlan.id.mrktRunId, "
                + " mrktEvntSchd.mrktEvntSchdId, mrktEvntSchd.mrktEvntFireDate, mrktEvntSchd.mrktDate,  mrktEvntSchd.mrktDefinition.mrktDefinitionId, "
                + " mrktEvntSchd.mrktDefinition.mrktType, mrktEvntSchd.mrktDefinition.mrktClass , mrktEvntSchd.mrktDefinition.mrktDefDesc , "
                + " mrktEvntSchd.mrktEvntDef.mrktEvntDefId , mrktEvntSchd.mrktEvntDef.mrktEvntDesc , mrktEvntSchd.mrktEvntDef.mrktEvntType , mrktEvntSchd.mrktEvntDef.mrktEvntNotificationName,  "
                + " mrktEvntSchd.mrktEvntDef.mrktEvntNotificationMsg , mrktEvntSchd.mrktEvntDef.mrktEvntCd,  mrktPlan.mrktHour, mrktEvntSchd.mrktEvntPubState) "
                + " FROM  MrktEvntSchd as mrktEvntSchd  , MrktPlan as mrktPlan "
                + " WHERE mrktEvntSchd.mrktEvntFireDate BETWEEN :lastHourTruncatedToMinute AND :currDateTruncatedToMinute"
                + " AND   mrktEvntSchd.mrktDate = mrktPlan.mrktDate "
                + " AND   mrktplan.mrktDefinition.mrktDefinitionId = mrktEvntSchd.mrktDefinition.mrktDefinitionId "
                + " AND   mrktEvntSchd.mrktEvntPubState =:marketEventPubState " + " AND   mrktEvntSchd.mrktEvntDef.mrktEvntType =:mrktEvntType "

                + " ORDER BY mrktEvntSchd.mrktEvntFireDate asc , mrktplan.mrktHour asc ";

        TypedQuery<MrktEvntNotification> mrktEventNotificationsQuery = mdsEntityManager.createQuery(ql, MrktEvntNotification.class);

        DateTime sysdate = DateTime.now();
        sysdate = sysdate.withSecondOfMinute(0);
        sysdate = sysdate.withMillisOfSecond(0);
        mrktEventNotificationsQuery.setParameter("currDateTruncatedToMinute", sysdate);

        DateTime lastHourDateTime = DateTime.now();
        lastHourDateTime = lastHourDateTime.minusHours(lastHours);
        lastHourDateTime = lastHourDateTime.withSecondOfMinute(0);
        lastHourDateTime = lastHourDateTime.withMillisOfSecond(0);
        mrktEventNotificationsQuery.setParameter("lastHourTruncatedToMinute", lastHourDateTime);

        mrktEventNotificationsQuery.setParameter("marketEventPubState", marketEventPubState);
        mrktEventNotificationsQuery.setParameter("mrktEvntType", mrktEvntType);

        List<MrktEvntNotification> list = mrktEventNotificationsQuery.getResultList();

        logger.info("Market Event Fetched between LastHour :{} and Sysdate :{} with Event Type :{} which are not Published ", lastHourDateTime, sysdate,
                mrktEvntType);
        logger.info("Number of Missed Scheduled Market Events fetched : {} ", list.size());
        logger.debug("*************** Exiting MdsMarketEventScheduleDaoImpl.getAllOpenMarketEventsNotPublishedYet ********** ");
        return list;
    }

    /*
     * @Override public List<MrktEvntNotification> get() { String ql =
     * " SELECT NEW com.caiso.mds.entity.mds.MrktEvntNotification( mrktPlan.id.mrktPlanId , mrktPlan.id.mrktRunId, "
     * +
     * " mrktEvntSchd.mrktEvntSchdId, mrktEvntSchd.mrktEvntFireDate, mrktEvntSchd.mrktDate,  mrktEvntSchd.mrktDefinition.mrktDefinitionId, "
     * +
     * " mrktEvntSchd.mrktDefinition.mrktType, mrktEvntSchd.mrktDefinition.mrktClass , mrktEvntSchd.mrktDefinition.mrktDefDesc , "
     * +
     * " mrktEvntSchd.mrktEvntDef.mrktEvntDefId , mrktEvntSchd.mrktEvntDef.mrktEvntDesc , mrktEvntSchd.mrktEvntDef.mrktEvntNotificationName,  "
     * +
     * " mrktEvntSchd.mrktEvntDef.mrktEvntNotificationMsg , mrktEvntSchd.mrktEvntDef.mrktEvntCd, "
     * + " mrktPlan.mrktHour) " +
     * " FROM  MrktEvntSchd as mrktEvntSchd  , MrktPlan as mrktPlan " +
     * " WHERE mrktEvntSchd.mrktEvntFireDate = :currDateTruncatedToMinute " +
     * " AND   mrktEvntSchd.mrktDate = mrktPlan.mrktDate " +
     * " AND   mrktplan.mrktDefinition.mrktDefinitionId = mrktEvntSchd.mrktDefinition.mrktDefinitionId "
     * + " AND   mrktEvntSchd.hasFixedEvntTriggerTime = 1 " +
     * " ORDER BY mrktEvntSchd.mrktEvntFireDate asc , mrktplan.mrktHour asc ";
     * 
     * TypedQuery<MrktEvntNotification> mrktEventNotificationsQuery =
     * mdsEntityManager.createQuery(ql, MrktEvntNotification.class);
     * 
     * DateTime sysdate = DateTime.now(); sysdate =
     * sysdate.withSecondOfMinute(0); sysdate = sysdate.withMillisOfSecond(0);
     * mrktEventNotificationsQuery.setParameter("currDateTruncatedToMinute",
     * sysdate);
     * 
     * List<MrktEvntNotification> list =
     * mrktEventNotificationsQuery.getResultList();
     * 
     * logger.info("Sysdate Time When Date Comparision was done " +
     * sysdate.toString()); logger.info(" Events Notification Fetched " +
     * list.size());
     * 
     * return list; }
     */

}

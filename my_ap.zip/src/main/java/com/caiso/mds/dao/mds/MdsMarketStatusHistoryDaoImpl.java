package com.caiso.mds.dao.mds;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktStatusHistory;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMarketStatusHistoryDaoImpl implements MdsMarketStatusHistoryDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMarketStatusHistoryDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public MrktStatusHistory createMarketStatusHistory(MrktStatusHistory mrktStatusHistory) {

        logger.debug("*** Entered method createMarketStatusHistory *********");
        mdsEntityManager.persist(mrktStatusHistory);
        logger.info("Market Status History record was created successfully with id :{}", mrktStatusHistory.getMrktStatusHistoryId());
        logger.debug("*** Exiting method createMarketStatusHistory *********");

        return mrktStatusHistory;
    }

    @Override
    public Long getLastMarketStatusForMarketRunId(String mrktRunId) {

        logger.debug("*** Entered method getLastMarketStatusForMarketRunId *********");

        String query = "SELECT max(msh.mrktStatusHistoryId) FROM MrktStatusHistory msh WHERE msh.mrktPlan.id.mrktRunId = :mrktRunId ";

        Long marketStatuHistoryId = mdsEntityManager.createQuery(query, Long.class).setParameter("mrktRunId", mrktRunId).getSingleResult();

        logger.info("Last Market Status id :{} for Market with Market Run Id :{}  ", marketStatuHistoryId, mrktRunId);

        logger.debug("*** Exiting method getLastMarketStatusForMarketRunId *********");
        return marketStatuHistoryId;
    }

    @Override
    public void createMarketStatusHistories(List<MrktStatusHistory> mrktStatusHistories) {

        logger.debug("*** Entered method createMarketStatusHistories *********");
        for (MrktStatusHistory mrktStatusHistory : mrktStatusHistories) {
            createMarketStatusHistory(mrktStatusHistory);
        }

        logger.debug("*** Exiting method createMarketStatusHistories *********");
    }

    @Override
    public int deleteMarketStatusHistoryBasedOnDaysInPast(Integer daysInPast) {
        logger.debug("***** Entered deleteMarketEventHistoryBasedOnDaysInPast() ********** ");

        Calendar dayInPast = Calendar.getInstance();
        dayInPast.roll(Calendar.DAY_OF_YEAR, -daysInPast);

        Query query = mdsEntityManager.createQuery("delete from MrktStatusHistory r where r.createdDt < :dateInPast ").setParameter("dateInPast",
                dayInPast.getTime());

        int recordsDeleted = query.executeUpdate();

        logger.debug("***** Exit deleteMarketEventHistoryBasedOnDaysInPast() ********** ");
        return recordsDeleted;
    }

    @Override
    public Long getMaxMarketStatusHistoryId() {
        String query = "SELECT max(msh.mrktStatusHistoryId) FROM MrktStatusHistory msh";
        Long marketStatuHistoryId = mdsEntityManager.createQuery(query, Long.class).getSingleResult();
        return marketStatuHistoryId;
    }
}

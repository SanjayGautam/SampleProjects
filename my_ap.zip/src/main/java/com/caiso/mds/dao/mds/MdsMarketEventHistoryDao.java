package com.caiso.mds.dao.mds;

import java.util.Date;

import com.caiso.mds.entity.mds.MrktEventLogResults;
import com.caiso.mds.entity.mds.MrktEvntHistory;

public interface MdsMarketEventHistoryDao {

    /**
     * 
     * @param mrktEvntHistory
     * @return
     */
    public MrktEvntHistory createMrktEvntHistory(MrktEvntHistory mrktEvntHistory);

    /**
     * 
     * @param pageNumber
     * @param pageSize
     * @param lastCreatedDateInPst
     * @return
     */
    public MrktEventLogResults getMrtEventHistoryLog(int pageNumber, int pageSize, Date lastCreatedDateInPst);

    public int deleteMarketEventHistoryBasedOnDaysInPast(Integer daysInPast);
}

package com.caiso.mds.dao.mds;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MdsLog;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMessageLogDaoImpl implements MdsMessageLogDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMessageLogDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public EntityManager getMdsEntityManager() {
        return mdsEntityManager;
    }

    @Override
    public void setMdsEntityManager(EntityManager mdsEntityManager) {
        this.mdsEntityManager = mdsEntityManager;
    }

    @Override
    public MdsLog createMessageLogRecord(MdsLog mdsLog) {

        logger.debug(" ********** Entering method createMessageLogRecord ***********  ");
        mdsEntityManager.persist(mdsLog);
        logger.info("Message Log created successfully with id:{} ", mdsLog.getMdsLogId());
        logger.debug(" ********** Exiting method createMessageLogRecord  ***********  ");
        return mdsLog;

    }

    /*
     * SELECT MARKET_RUN_ID FROM MARKET_RUN MR, MARKET_PLAN MP, MDS_MARKET MKT,
     * MARKET_DEFINITION MD WHERE MD.MARKET_CLASS = #MKT_CLASS AND
     * MD.MARKET_TYPE = #MKT_TYPE AND MD.MARKET_DEFINITION_ID =
     * MKT.MARKET_DEFINITION_ID AND MKT.MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID AND
     * MP.MARKET_MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID AND MP.MARKET_ID = #MKT_ID
     */

    @Override
    public Integer getMarketRunId(String mktClass, String mktType, String mktId) {

        logger.debug(" ********** Entering method getMarketRunId ***********  ");

        String hql = " SELECT MARKET_RUN_ID  " + "	FROM MARKET_RUN MR, MARKET_PLAN MP, " + " MDS_MARKET MKT, MARKET_DEFINITION MD " + " WHERE "
                + " MD.MARKET_CLASS = :mktClass " + "	AND MD.MARKET_TYPE = :mktType " + "	AND MD.MARKET_DEFINITION_ID = MKT.MARKET_DEFINITION_ID "
                + "	AND MKT.MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID " + "	AND MP.MARKET_MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID" + "	AND MP.MARKET_ID = :mktId ";

        javax.persistence.Query query = mdsEntityManager.createNativeQuery(hql);
        query.setParameter("mktClass", mktClass);
        query.setParameter("mktType", mktType);
        query.setParameter("mktId", mktId);

        Integer marketRunId = (Integer) query.getSingleResult();

        logger.info("Market Run Id for " + marketRunId);

        logger.debug(" ********** Exiting method getMarketRunId ***********  ");

        return marketRunId;
    }

    /*
     * 
     * SELECT MKT.MDS_MKT_CLS_ID,MP.MARKET_ID,MP.MARKET_MDS_MKT_CLS_ID,MP.
     * TRADE_MDS_MKT_CLS_ID, TO_CHAR(MKT.MARKET_DATE,&APOS;YYYY-MM-DD&APOS;)
     * ||&APOS;T&APOS;||
     * TO_CHAR(MKT.MARKET_DATE,&APOS;HH24:MI:SS.FF3TZH:TZM&APOS;)
     * MARKET_DATE,MKT.MARKET_HOUR,MKT.MARKET_DEFINITION_ID FROM MARKET_PLAN MP,
     * MDS_MARKET MKT WHERE MP.MARKET_ID = #MKTID AND MP.MARKET_MDS_MKT_CLS_ID =
     * MKT.MDS_MKT_CLS_ID
     */

    @Override
    public String getTradeDateForMarketId(String mktId) {

        logger.debug(" ********** Entering method getTradeDateForMarketId ***********  ");

        String hql = " SELECT MKT.MARKET_DATE " + " FROM MARKET_PLAN MP, MDS_MARKET MKT " + "	  WHERE " + "		MP.MARKET_ID = :mktId "
                + "		AND MP.MARKET_MDS_MKT_CLS_ID = MKT.MDS_MKT_CLS_ID ";

        javax.persistence.Query query = mdsEntityManager.createNativeQuery(hql);

        query.setParameter("mktId", mktId);

        Date tradeDate = (Date) query.getSingleResult();

        DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
        df.setTimeZone(TimeZone.getTimeZone("GMT"));
        String reportDate = df.format(tradeDate);

        logger.info("Fetched market trade:{} of market id:{}", reportDate, mktId);
        logger.debug(" ********** Exiting method getTradeDateForMarketId ***********  ");

        return reportDate;
    }

}

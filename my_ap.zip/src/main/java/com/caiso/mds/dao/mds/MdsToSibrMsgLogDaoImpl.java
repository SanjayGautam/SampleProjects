package com.caiso.mds.dao.mds;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MdsToSibrMsgLog;
import com.caiso.mds.entity.mds.MdsToSibrRequestLogResults;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsToSibrMsgLogDaoImpl implements MdsToSibrMsgLogDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsToSibrMsgLogDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public MdsToSibrMsgLog createMdsToSibrMsgLog(MdsToSibrMsgLog mdsToSibrMsgLog) {
        logger.info("************* Entered the createMdsToSibrMsgLog ****************");
        mdsEntityManager.persist(mdsToSibrMsgLog);
        logger.info("************* Exiting the createMdsToSibrMsgLog ****************");
        return mdsToSibrMsgLog;
    }

    @SuppressWarnings("unchecked")
    @Override
    public MdsToSibrRequestLogResults getMdsToSibrRequestLogs(int pageNumber, Integer pageSize, Date lastCreatedDateInPst) {
        logger.debug("**** Entering getMdsToSibrRequestLogs *****  ");
        List<MdsToSibrMsgLog> mdstoSibrMsgLogs = null;
        MdsToSibrRequestLogResults mdsToSibrRequestLogResults = null;
        Query mdsToSibrMsgLogQuery = mdsEntityManager.createQuery("	FROM MdsToSibrMsgLog meh "
                + "	WHERE meh.createdDt >= :lastCreatedDate order by meh.createdDt DESC");

        Query queryTotal = mdsEntityManager.createQuery("SELECT count(meh.mdsToSibrMsgLogId) " + " FROM MdsToSibrMsgLog meh "
                + "	WHERE meh.createdDt >= :lastCreatedDate order by meh.createdDt");

        queryTotal.setParameter("lastCreatedDate", lastCreatedDateInPst);
        long totalRowCount = (long) queryTotal.getSingleResult();

        // + 1 because first results indexed at 0
        int totalPageCount = (int) ((totalRowCount / pageSize) + 1);
        logger.info("calculation for queryTotal:{} and totalPageCount:{}", totalRowCount, totalPageCount);

        if (pageNumber < totalRowCount) {
            mdsToSibrMsgLogQuery.setFirstResult((pageNumber - 1) * pageSize);
            mdsToSibrMsgLogQuery.setMaxResults(pageSize);
            mdsToSibrMsgLogQuery.setParameter("lastCreatedDate", lastCreatedDateInPst);
            mdstoSibrMsgLogs = mdsToSibrMsgLogQuery.getResultList();
            logger.info("Fetched the mdsToSibr Request Details  for pageNumber:{}, pageSize:{} , lastCreatedDateInPst:{}", pageNumber, pageSize,
                    lastCreatedDateInPst);
            mdsToSibrRequestLogResults = new MdsToSibrRequestLogResults();
            mdsToSibrRequestLogResults.setCurrentPageNumber(pageNumber);
            mdsToSibrRequestLogResults.setCurrentPageSize(pageSize);
            mdsToSibrRequestLogResults.setMdsToSibrMsgLogs(mdstoSibrMsgLogs);
            mdsToSibrRequestLogResults.setTotalPagesCount(totalPageCount);
            mdsToSibrRequestLogResults.setTotalRowsCount(totalRowCount);
            logger.info("Mds To Sibr Records Received  size:{}", mdstoSibrMsgLogs.size());

        } else {
            logger.warn("Issue while pagination pageNumber:{} was smaller than total row count:{} returned", pageNumber, totalRowCount);
        }

        logger.debug("**** Exiting getMdsToSibrRequestLogs *****  ");

        return mdsToSibrRequestLogResults;
    }

    @Override
    public int deleteMdsToSibrLogRecordsBasedOnDaysInPast(Integer daysInPast) {
        logger.debug("***** Entered MdsToSibrLogRecord() ********** ");

        Calendar dayInPast = Calendar.getInstance();
        dayInPast.roll(Calendar.DAY_OF_YEAR, -daysInPast);

        Query query = mdsEntityManager.createQuery("delete from MdsToSibrMsgLog r where r.createdDt < :dateInPast ").setParameter("dateInPast",
                dayInPast.getTime());

        int recordsDeleted = query.executeUpdate();

        logger.debug("***** Exit MdsToSibrLogRecord() ********** ");
        return recordsDeleted;
    }
}

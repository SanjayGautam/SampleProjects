package com.caiso.mds.dao.mds;

import java.util.Date;

import com.caiso.mds.entity.mds.MdsToSibrMsgLog;
import com.caiso.mds.entity.mds.MdsToSibrRequestLogResults;

public interface MdsToSibrMsgLogDao {

    /**
     * 
     * @param mdsToSibrMsgLog
     * @return
     */
    public MdsToSibrMsgLog createMdsToSibrMsgLog(MdsToSibrMsgLog mdsToSibrMsgLog);

    /**
     * 
     * @param pageNumber
     * @param pageSize
     * @param lastCreatedDateInPst
     * @return
     */

    public MdsToSibrRequestLogResults getMdsToSibrRequestLogs(int pageNumber, Integer pageSize, Date lastCreatedDateInPst);

    /**
     * 
     * @param daysInPast
     */
    public int deleteMdsToSibrLogRecordsBasedOnDaysInPast(Integer daysInPast);

}

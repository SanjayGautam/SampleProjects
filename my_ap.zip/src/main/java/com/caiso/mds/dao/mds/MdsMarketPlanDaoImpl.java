package com.caiso.mds.dao.mds;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktPlan;
import com.caiso.mds.entity.mds.MrktPlanAndStatusDetails;
import com.caiso.mds.entity.mds.MrktPlanPK;
import com.caiso.mds.types.MarketType;
import com.caiso.mds.util.DateUtil;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMarketPlanDaoImpl implements MdsMarketPlanDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMarketPlanDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Autowired
    private DateUtil      dateUtil;

    @Override
    public DateTime getLastMarketPlanDate() {

        logger.debug("*************** Entered method getLastMarketPlanDate ********** ");
        Query getMaxMrktDateQuery = mdsEntityManager.createQuery(" SELECT max(mrktDate) from MrktPlan ");
        DateTime maxMarketDate = (DateTime) getMaxMrktDateQuery.getSingleResult();
        if (maxMarketDate != null) {
            logger.info("Last Market Plan Date available in database :{}.", maxMarketDate.toString());
        } else {
            logger.warn("There is no market plan date available in database , market plans will get generated on next market run.");
        }

        logger.debug("*************** Exiting method getLastMarketPlanDate ********** ");
        return maxMarketDate;
    }

    @Override
    public DateTime getLastMarketPlanDateByMarketType(MarketType marketType) {

        logger.debug("*************** Entered method  getLastMarketPlanDateByMarketType ********** ");
        Query getMaxMrktDateQuery = mdsEntityManager.createQuery(" SELECT max(mrktDate) from MrktPlan Where mrktDefinition.mrktType=:marketType");
        getMaxMrktDateQuery.setParameter("marketType", marketType.getName());
        DateTime maxMarketDate = (DateTime) getMaxMrktDateQuery.getSingleResult();
        if (maxMarketDate != null) {
            logger.info("Last Market Plan Date fetched from database is :{} for market Type :{} ", maxMarketDate.toString(), marketType.getName());
        } else {
            logger.warn("Last Market Plan Date fetched from database is NULL for market Type :{} ", marketType.getName());
        }

        logger.debug("*************** Exiting method  getLastMarketPlanDateByMarketType ********** ");
        return maxMarketDate;
    }

    @Override
    public void createMrktPlans(List<MrktPlan> mrktPlans) {
        logger.debug("*************** Entering saveMrktPlans ********** ");
        for (Iterator<MrktPlan> iterator = mrktPlans.iterator(); iterator.hasNext();) {
            MrktPlan mrktPlan = iterator.next();
            createMrktPlan(mrktPlan);
            logger.info("Market Plan was created successfully with marketPlanid:{} and marketRunId:{}", mrktPlan.getId().getMrktPlanId(), mrktPlan.getId()
                    .getMrktRunId());
        }

        logger.debug("*************** Exiting method  saveMrktPlans ********** ");

    }

    @Override
    public void createMrktPlan(MrktPlan mrktPlan) {
        try {
            mdsEntityManager.persist(mrktPlan);
        } catch (Exception e) {
            logger.error("Error while creating market plans ", e);
        }
    }

    @Override
    public void updateMrktPlan(MrktPlan mrktPlan) {

        logger.debug("******** Entered method updateMrktPlan  ********** ");

        mdsEntityManager.merge(mrktPlan);
        logger.info(" Market Plan got updated successfully with market Run id :{}", mrktPlan.getId().getMrktRunId());
        logger.debug("******** Exiting method updateMrktPlan********** ");
    }

    @Override
    public MrktPlan getMarketPlan(String marketPlanId, String marketRunId) {

        logger.debug("******** Entered method getMarketPlan  ********** ");
        MrktPlanPK pk = new MrktPlanPK();
        pk.setMrktPlanId(marketPlanId);
        pk.setMrktRunId(marketRunId);

        MrktPlan mrktPlan = mdsEntityManager.find(MrktPlan.class, pk);

        if (mrktPlan == null) {
            logger.warn("No market plan exists for market run id:{}", marketRunId);
        }

        logger.debug("******** Exiting method getMarketPlan  ********** ");

        return mrktPlan;
    }

    @Override
    public List<MrktPlan> getMarketPlans(Date marketDateInPST, Long marketDefId) {

        logger.debug("*************** Entering method GetMarketPlans ********** ");

        Query getMarketPlansQuery = mdsEntityManager.createQuery("from MrktPlan mp " + " Where  mp.mrktDefinition.mrktDefinitionId=:mrktDefId "
                + " AND  mp.mrktDate between :mrktDateUtcPstStartOfDay and :mrktDateUtcPstEndOFDay " + " ORDER BY mp.mrktDate ASC ");

        DateTime marketDateInCST = new DateTime(marketDateInPST);
        marketDateInCST = marketDateInCST.withTimeAtStartOfDay();
        marketDateInCST = marketDateInCST.toDateTime(DateTimeZone.UTC);

        getMarketPlansQuery.setParameter("mrktDateUtcPstStartOfDay", marketDateInCST);
        getMarketPlansQuery.setParameter("mrktDateUtcPstEndOFDay", marketDateInCST.plusHours(23));

        getMarketPlansQuery.setParameter("mrktDefId", marketDefId);

        @SuppressWarnings("unchecked")
        List<MrktPlan> mrktPlans = getMarketPlansQuery.getResultList();
        if (mrktPlans.size() > 0) {

            logger.info("Number of market plans fetched :{} for market date in pst:{} and market def id :{}", mrktPlans.size(), marketDateInPST, marketDefId);

        } else {
            logger.warn("No Market Plans were found for market Date in pst :{} and for Market Def Id:{}", marketDateInPST, marketDefId);
        }

        logger.debug("*************** Exiting method GetMarketPlans ********** ");

        return mrktPlans;
    }

    @Override
    public List<MrktPlan> getMarketPlansForMarketPlanIdAndMarketDefId(String marketPlanId, Long marketDefId) {
        logger.debug("*************** Entering method getMarketPlansForMarketPlanIdAndMarketDefId ********** ");

        Query getMarketPlansQuery = mdsEntityManager.createQuery("FROM MrktPlan mp " + "WHERE  mp.mrktDefinition.mrktDefinitionId=:marketDefId "
                + " AND  mp.id.mrktPlanId=:marketPlanId");

        getMarketPlansQuery.setParameter("marketPlanId", marketPlanId);
        getMarketPlansQuery.setParameter("marketDefId", marketDefId);

        @SuppressWarnings("unchecked")
        List<MrktPlan> mrktPlans = getMarketPlansQuery.getResultList();

        logger.info("Market Plans fetched :{} for market plan id:{} and market def id :{}", mrktPlans.size(), marketPlanId, marketDefId);

        logger.debug("*************** Exiting method getMarketPlansForMarketPlanIdAndMarketDefId ********** ");

        return mrktPlans;
    }

    @Override
    public String getMarketStatusForMarketPlanIdAndDefId(String marketPlanId, Long marketDefId) {

        logger.debug("*************** Entering method getMarketStatusForMarketPlanIdAndDefId ********** ");
        String status = "";

        Query getMarketPlansQuery = mdsEntityManager.createQuery("FROM MrktPlan mp " + "WHERE  mp.mrktDefinition.mrktDefinitionId=:marketDefId "
                + " AND  mp.id.mrktPlanId=:marketPlanId");

        getMarketPlansQuery.setParameter("marketPlanId", marketPlanId);
        getMarketPlansQuery.setParameter("marketDefId", marketDefId);

        MrktPlan mrktPlan = (MrktPlan) getMarketPlansQuery.getSingleResult();

        if (mrktPlan != null) {

            status = mrktPlan.getMrktStatusType().getMrktStatusTypeName();
            logger.info("Market Status:{} for marketPlanId:{} marketRunId :{} and market def id :{}", status, marketPlanId, mrktPlan.getId().getMrktRunId(),
                    marketDefId);
        } else {

            status = "NoStatusFound";
            logger.warn("Market Status:{} for marketPlanId:{} and market def id :{}", status, marketPlanId, marketDefId);
        }

        logger.debug("*************** Exiting method getMarketStatusForMarketPlanIdAndDefId ********** ");
        return status;
    }

    /**
     * This is a pseudo definition of markets and i took liberty to define them
     * as main markets. This method is used to get the status and details for
     * the mds portal and hence actually named as main markets. actually they
     * should show statuses of other markets as well.
     * 
     * Main market means Market def id in (1,2,3,4 )
     * 
     * @param marketDate
     * @return
     */
    @Override
    public List<MrktPlanAndStatusDetails> getMarketStatusForMainMarketDate(Date marketDateInPST, List<Long> marketDefIds) {

        logger.debug("*************** Entering method getMarketStatusForMainMarketDate ********** ");

        String ql = " SELECT NEW com.caiso.mds.entity.mds.MrktPlanAndStatusDetails(" + " mrktPlan.id.mrktPlanId , mrktPlan.id.mrktRunId, "
                + " mrktPlan.mrktDefinition ,  mrktPlan.mrktDate,  " + " mrktPlan.mrktStatusType.mrktStatusTypeName ,  mrktPlan.mrktHour)"
                + " FROM  MrktStatusType as mrktStatusType  , MrktPlan as mrktPlan "
                + " WHERE mrktPlan.mrktStatusType.mrktStatusTypeId = mrktStatusType.mrktStatusTypeId  "
                + " AND   mrktPlan.mrktDefinition.mrktDefinitionId IN  :mrktDefinitionIds"
                + " AND   mrktPlan.mrktDate between :mrktDateUtcStartOfDay and :mrktDateUtcEndOFDay "
                + " ORDER BY mrktPlan.mrktDefinition.mrktDefinitionId asc , mrktplan.mrktHour asc ";

        TypedQuery<MrktPlanAndStatusDetails> mrktPlanAndStatusDetailsQuery = mdsEntityManager.createQuery(ql, MrktPlanAndStatusDetails.class);
        logger.info(" Input Market Date Conveted  " + marketDateInPST);

        DateTime marketDateInPst = new DateTime(marketDateInPST);
        marketDateInPst = marketDateInPst.withTimeAtStartOfDay();
        DateTime marketDateInUtc = marketDateInPst.toDateTime(DateTimeZone.UTC);

        mrktPlanAndStatusDetailsQuery.setParameter("mrktDateUtcStartOfDay", marketDateInUtc);
        mrktPlanAndStatusDetailsQuery.setParameter("mrktDateUtcEndOFDay", marketDateInUtc.plusHours(23));
        mrktPlanAndStatusDetailsQuery.setParameter("mrktDefinitionIds", marketDefIds);

        List<MrktPlanAndStatusDetails> list = mrktPlanAndStatusDetailsQuery.getResultList();

        logger.info("Number of Market Main Plans:{} whose Status was Fetched for market date start in PST:{} for different Market Def Ids ", list.size(),
                marketDateInPst);

        logger.debug("*************** Exiting method getMarketStatusForMainMarketDate ********** ");

        return list;
    }

    @Override
    public List<MrktPlanAndStatusDetails> getMarketStatusForMainMarketsForCurrentHour(Date marketDateCurrentDateAndHourInPST, List<Long> marketDefIds) {

        logger.debug("*************** Entering method getMarketStatusForMainMarketDate ********** ");

        String ql = " SELECT NEW com.caiso.mds.entity.mds.MrktPlanAndStatusDetails(" + " mrktPlan.id.mrktPlanId , mrktPlan.id.mrktRunId, "
                + " mrktPlan.mrktDefinition ,  mrktPlan.mrktDate,  " + " mrktPlan.mrktStatusType.mrktStatusTypeName ,  mrktPlan.mrktHour) "
                + " FROM  MrktStatusType as mrktStatusType  , MrktPlan as mrktPlan "
                + " WHERE mrktPlan.mrktStatusType.mrktStatusTypeId = mrktStatusType.mrktStatusTypeId  "
                + " AND   mrktPlan.mrktDefinition.mrktDefinitionId IN  :mrktDefinitionIds" + " AND   mrktPlan.mrktDate = :marketDateAndHourInCST "
                + " ORDER BY mrktPlan.mrktDefinition.mrktDefinitionId asc , mrktplan.mrktHour asc ";

        TypedQuery<MrktPlanAndStatusDetails> mrktPlanAndStatusDetailsQuery = mdsEntityManager.createQuery(ql, MrktPlanAndStatusDetails.class);
        logger.info(" Current Market Date and Hour in PST  " + marketDateCurrentDateAndHourInPST);

        DateTime marketDateAndHourInPst = new DateTime(marketDateCurrentDateAndHourInPST);
        marketDateAndHourInPst = marketDateAndHourInPst.toDateTime(DateTimeZone.UTC);
        marketDateAndHourInPst = marketDateAndHourInPst.withMinuteOfHour(0);
        marketDateAndHourInPst = marketDateAndHourInPst.withSecondOfMinute(0);
        marketDateAndHourInPst = marketDateAndHourInPst.withMillisOfSecond(0);

        logger.info("Market Date and Hour in PST:{}" + marketDateAndHourInPst);

        mrktPlanAndStatusDetailsQuery.setParameter("marketDateAndHourInCST", marketDateAndHourInPst);
        mrktPlanAndStatusDetailsQuery.setParameter("mrktDefinitionIds", marketDefIds);

        List<MrktPlanAndStatusDetails> list = mrktPlanAndStatusDetailsQuery.getResultList();

        logger.info("Market Status fetched size() " + list.size());

        logger.debug("*************** Exiting method getMarketStatusForMainMarketDate ********** ");

        return list;

    }
}

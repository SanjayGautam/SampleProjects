package com.caiso.mds.dao.oasis;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.oasis.MdsAweNotification;
import com.caiso.mds.entity.oasis.MdsNotificationCtlOasis;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsOasisNotificationCtlDaoImpl implements MdsOasisNotificationCtlDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsOasisNotificationCtlDaoImpl.class);

    @Autowired()
    private EntityManager mdsOasisEntityManager;

    @Override
    public EntityManager getMdsCmriEntityManager() {
        return mdsOasisEntityManager;
    }

    @Override
    public void setMdsCmriEntityManager(EntityManager mdsEntityManager) {
        this.mdsOasisEntityManager = mdsEntityManager;
    }

    @Override
    public void createNotificationCtl(MdsNotificationCtlOasis mdsNotificationCtlOasis) {
        logger.debug("********* Entered method createNotificationCtl **********");
        mdsOasisEntityManager.persist(mdsNotificationCtlOasis);
        logger.info("Notification CTL record in OASIS  created successfully with id :{}:", mdsNotificationCtlOasis.getNotificationCtlId());
        logger.debug("********* Exiting method createNotificationCtl **********");
    }

    @Override
    public void updateNotificationCtl(MdsNotificationCtlOasis mdsNotificationCtlOasis) {
        logger.debug("********* Entered method updateNotificationCtl **********");
        mdsOasisEntityManager.merge(mdsNotificationCtlOasis);
        logger.info("Notification CRL Record in OASIS was updated successfully with id :{} ", mdsNotificationCtlOasis.getNotificationCtlId());
        logger.debug("********* Exiting method updateNotificationCtl **********");
    }

    @Override
    public MdsNotificationCtlOasis getOasisNotificationCtlInReadyStatusAndMdsFlowStatusNull(MdsNotificationCtlOasis mdsNotificationCtlOasis) {

        logger.debug("********* Entered method getOasisNotificationCtlInReadyStatusAndMdsFlowStatusNull **********");
        CriteriaBuilder builder = mdsOasisEntityManager.getCriteriaBuilder();
        CriteriaQuery<MdsNotificationCtlOasis> criteriaQuery = builder.createQuery(MdsNotificationCtlOasis.class);
        Root<MdsNotificationCtlOasis> notificationCtlRoot = criteriaQuery.from(MdsNotificationCtlOasis.class);

        /*
         * Swap criteria statements if you would like to try out type-safe
         * criteria queries, a new feature in JPA 2.0
         * criteria.select(member).orderBy(cb.asc(member.get(Member_.name)));
         */

        Predicate mdsFlowStatePredicate = null;

        if (mdsNotificationCtlOasis.getMdsFlowState() == null || mdsNotificationCtlOasis.getMdsFlowState().equalsIgnoreCase("NULL")) {
            mdsFlowStatePredicate = builder.isNull(notificationCtlRoot.get("mdsFlowState"));
        } else {
            mdsFlowStatePredicate = builder.equal(notificationCtlRoot.get("mdsFlowState"), mdsNotificationCtlOasis.getMdsFlowState());
        }

        criteriaQuery = criteriaQuery.select(notificationCtlRoot)
                .where(mdsFlowStatePredicate, builder.equal(notificationCtlRoot.get("notificationName"), mdsNotificationCtlOasis.getNotificationName()),
                        builder.equal(notificationCtlRoot.get("status"), mdsNotificationCtlOasis.getStatus()))
                .orderBy(builder.desc(notificationCtlRoot.get("createdDts")));

        List<MdsNotificationCtlOasis> list = mdsOasisEntityManager.createQuery(criteriaQuery).getResultList();
        MdsNotificationCtlOasis result = null;
        logger.info("Notification Oasis Ctl Records Found =" + list.size());

        logger.info("Number of Records Returned with Given Condition of mdsFlowState {} notificationName {} status {} Records Return = {}",
                mdsNotificationCtlOasis.getMdsFlowState(), mdsNotificationCtlOasis.getNotificationName(), mdsNotificationCtlOasis.getStatus(), list.size());

        if (list != null & list.size() > 0) {
            logger.info("Fetched Notification Record in OASIS with Status:{}; Notification Name :{}; MdsFlowState:{} ", mdsNotificationCtlOasis.getStatus(),
                    mdsNotificationCtlOasis.getNotificationName(), mdsNotificationCtlOasis.getMdsFlowState());
            result = list.get(0);
        } else {
            logger.warn("No Notification Record was found in OASIS with Status:{}; Notification Name :{}; MdsFlowState:{}", mdsNotificationCtlOasis.getStatus(),
                    mdsNotificationCtlOasis.getNotificationName(), mdsNotificationCtlOasis.getMdsFlowState());
        }

        logger.debug("********* Exiting method getOasisNotificationCtlInReadyStatusAndMdsFlowStatusNull **********");
        return result;

    }

    @Override
    public List<MdsNotificationCtlOasis> getOasisNotificationRecordsByMdsFlowStateAndNotificationNames(MdsNotificationCtlOasis mdsNotificationCtlOasis) {

        logger.debug("********* Entered method getOasisNotificationRecordsByMdsFlowStateAndNotificationName **********");
        CriteriaBuilder builder = mdsOasisEntityManager.getCriteriaBuilder();
        CriteriaQuery<MdsNotificationCtlOasis> criteriaQuery = builder.createQuery(MdsNotificationCtlOasis.class);
        Root<MdsNotificationCtlOasis> notificationCtlRoot = criteriaQuery.from(MdsNotificationCtlOasis.class);

        Predicate mdsFlowStatePredicate = null;

        if (mdsNotificationCtlOasis.getMdsFlowState().equalsIgnoreCase("NULL")) {
            mdsFlowStatePredicate = builder.isNull(notificationCtlRoot.get("mdsFlowState"));
        } else {
            mdsFlowStatePredicate = builder.equal(notificationCtlRoot.get("mdsFlowState"), mdsNotificationCtlOasis.getMdsFlowState());
        }

        Expression<String> notificationExpression = notificationCtlRoot.get("notificationName");
        Predicate predicateNotificationNamesPredicate = notificationExpression.in(mdsNotificationCtlOasis.getNotificationNames());

        logger.info("****  MDS ");
        if (mdsNotificationCtlOasis.getStatus() == null) {
            criteriaQuery = criteriaQuery.select(notificationCtlRoot).where(mdsFlowStatePredicate, predicateNotificationNamesPredicate);
        } else {
            Predicate statusPredicate = builder.equal(notificationCtlRoot.get("status"), mdsNotificationCtlOasis.getStatus());
            criteriaQuery = criteriaQuery.select(notificationCtlRoot).where(mdsFlowStatePredicate, predicateNotificationNamesPredicate, statusPredicate);
        }

        List<MdsNotificationCtlOasis> oasisNotifications = mdsOasisEntityManager.createQuery(criteriaQuery).getResultList();

        if (oasisNotifications != null && oasisNotifications.size() > 0) {
            logger.info("Fetched Notification Ctl Record in OASIS with Status:{}; Notification Name :{}; MdsFlowState:{}", mdsNotificationCtlOasis.getStatus(),
                    mdsNotificationCtlOasis.getNotificationNames(), mdsNotificationCtlOasis.getMdsFlowState());
        } else {

            logger.warn("Notification Record Not Found in OASIS with Status:{}; Notification Name :{}; MdsFlowState:{}", mdsNotificationCtlOasis.getStatus(),
                    mdsNotificationCtlOasis.getNotificationNames(), mdsNotificationCtlOasis.getMdsFlowState());
        }

        logger.debug("********* Exiting method getOasisNotificationRecordsByMdsFlowStateAndNotificationName **********");

        return oasisNotifications;
    }

    /**
     * 
     */
    @Override
    public void createMdsAweNotifications(MdsAweNotification mdsAweNotification) {
        logger.debug("********* Entered method createNotificationCtl **********");
        mdsOasisEntityManager.persist(mdsAweNotification);
        logger.info("Notification CTL record in OASIS  created successfully with id :{}:", mdsAweNotification.getMessageId());
        logger.debug("********* Exiting method createNotificationCtl **********");
    }

}

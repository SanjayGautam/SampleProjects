package com.caiso.mds.dao.mds;

import java.util.List;

import com.caiso.mds.entity.mds.ExternalSystemEndpoint;
import com.caiso.mds.types.ExternalSystemName;

public interface ExternalSystemEndpointDao {

    /**
     * 
     * @param externalSystemName
     * @return
     */
    public List<ExternalSystemEndpoint> getActiveExternalSystemEndPointsBySystemNameAndSignFlag(ExternalSystemName externalSystemName, String signMsg);

    /**
     * 
     * @param externalSystemName
     * @return
     */
    public List<ExternalSystemEndpoint> getActiveExternalSystemEndPointsBySystemName(ExternalSystemName externalSystemName);

}

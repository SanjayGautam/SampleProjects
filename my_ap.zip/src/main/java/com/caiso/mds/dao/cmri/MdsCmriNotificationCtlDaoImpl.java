package com.caiso.mds.dao.cmri;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.cmri.MdsNotificationCtlCmri;
import com.caiso.mds.entity.cmri.MdsOasisStatusCtl;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsCmriNotificationCtlDaoImpl implements MdsCmriNotificationCtlDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsCmriNotificationCtlDaoImpl.class);

    @Autowired()
    private EntityManager mdsCmriEntityManager;

    @Override
    public EntityManager getMdsCmriEntityManager() {
        return mdsCmriEntityManager;
    }

    @Override
    public void setMdsCmriEntityManager(EntityManager mdsEntityManager) {
        this.mdsCmriEntityManager = mdsEntityManager;
    }

    /**
     * 
     */
    @Override
    public MdsNotificationCtlCmri createCmriNotification(MdsNotificationCtlCmri mdsNotificationCtlCmri) {

        logger.debug(" ********** Entering the updateCmriNotification DAO Method ***********  ");
        mdsCmriEntityManager.persist(mdsNotificationCtlCmri);
        logger.info(" Created a record in MDS_NOTIFICATION_CTL in CMRI table with ID" + mdsNotificationCtlCmri.getNotificationCtlId());
        logger.debug(" ********** Exiting the updateCmriNotification DAO Method ***********  ");

        return mdsNotificationCtlCmri;

    }

    /**
     * 
     */

    @Override
    public void updateCmriNotification(MdsNotificationCtlCmri mdsNotificationCtlCmri) {
        logger.debug(" ********** Entering the updateCmriNotification DAO Method ***********  ");
        mdsCmriEntityManager.merge(mdsNotificationCtlCmri);
        logger.info(" Updated a record in MDS_NOTIFICATION_CTL in CMRI table with ID" + mdsNotificationCtlCmri.getNotificationCtlId());
        logger.debug(" ********** Exiting the updateCmriNotification DAO Method ***********  ");
    }

    /**
     * 
     */
    @Override
    public void createMdsOasisStatusCtlRecord(MdsOasisStatusCtl mdsOasisStatusCtl) {
        logger.debug(" ********** Entering the createMdsOasisStatusCtlRecord DAO Method ***********  ");
        mdsCmriEntityManager.persist(mdsOasisStatusCtl);
        logger.info("created a record in MDS_OASIS_STATUS_CTL in CMRI table " + mdsOasisStatusCtl.getId().getOasisStatusId());
        logger.debug(" ********** Exiting the createMdsOasisStatusCtlRecord DAO Method ***********  ");

    }

    @Override
    public MdsNotificationCtlCmri getCmriNotificationCtlInReadyStatusAndMdsFlowStatusNull(MdsNotificationCtlCmri mdsNotificationCtlCmri) {

        logger.debug(" ********** Entering the getCmriNotificationCtlInReadyStatusAndMdsFlowStatusNull DAO Method ***********  ");

        CriteriaBuilder builder = mdsCmriEntityManager.getCriteriaBuilder();
        CriteriaQuery<MdsNotificationCtlCmri> criteriaQuery = builder.createQuery(MdsNotificationCtlCmri.class);
        Root<MdsNotificationCtlCmri> notificationCtlRoot = criteriaQuery.from(MdsNotificationCtlCmri.class);

        /*
         * Swap criteria statements if you would like to try out type-safe
         * criteria queries, a new feature in JPA 2.0
         * criteria.select(member).orderBy(cb.asc(member.get(Member_.name)));
         */
        logger.info("Getting record from NOTIFICATION_CTL in CMRI table with Search Criteria as below ");
        logger.info("Record Status 		:" + mdsNotificationCtlCmri.getStatus());
        logger.info("Notification Name 	:" + mdsNotificationCtlCmri.getNotificationName());
        logger.info("MDS Status Flow  	:" + mdsNotificationCtlCmri.getMdsFlowState());

        Predicate mdsFlowStatePredicate = null;

        if (mdsNotificationCtlCmri.getMdsFlowState() == null || mdsNotificationCtlCmri.getMdsFlowState().equalsIgnoreCase("NULL")) {
            mdsFlowStatePredicate = builder.isNull(notificationCtlRoot.get("mdsFlowState"));
        } else {
            mdsFlowStatePredicate = builder.equal(notificationCtlRoot.get("mdsFlowState"), mdsNotificationCtlCmri.getMdsFlowState());
        }

        criteriaQuery = criteriaQuery.select(notificationCtlRoot)
                .where(mdsFlowStatePredicate, builder.equal(notificationCtlRoot.get("notificationName"), mdsNotificationCtlCmri.getNotificationName()),
                        builder.equal(notificationCtlRoot.get("status"), mdsNotificationCtlCmri.getStatus()))
                .orderBy(builder.desc(notificationCtlRoot.get("createdDts")));

        List<MdsNotificationCtlCmri> list = mdsCmriEntityManager.createQuery(criteriaQuery).getResultList();
        MdsNotificationCtlCmri result = null;

        if (list != null & list.size() > 0) {
            logger.info(" Notification Record was found in CMRI with status size is :{} should be always 1", list.size());
            result = list.get(0);
        } else {
            logger.warn("No records were found in the table for Notification_CTL in CMRI table with Status => Ready And MdsFlowStatus => Null ");
        }

        logger.debug(" ********** Exiting the getCmriNotificationCtlInReadyStatusAndMdsFlowStatusNull DAO Method ***********  ");
        return result;

    }

    @Override
    public MdsNotificationCtlCmri getCmriNotificationCtlByMarketId(MdsNotificationCtlCmri mdsNotificationCtlCmri) {

        logger.debug(" ********** Entering the getCmriNotificationCtlByMarketId DAO Method ***********  ");

        CriteriaBuilder builder = mdsCmriEntityManager.getCriteriaBuilder();
        CriteriaQuery<MdsNotificationCtlCmri> criteria = builder.createQuery(MdsNotificationCtlCmri.class);
        Root<MdsNotificationCtlCmri> notificationCtl = criteria.from(MdsNotificationCtlCmri.class);

        criteria.select(notificationCtl).where(builder.equal(notificationCtl.get("marketId"), mdsNotificationCtlCmri.getMarketId()));

        List<MdsNotificationCtlCmri> list = mdsCmriEntityManager.createQuery(criteria).getResultList();
        MdsNotificationCtlCmri result = null;

        if (list != null & list.size() > 0) {
            logger.info("Got atleast one record for Notification Ctl in CMRI with Market Id :{}", mdsNotificationCtlCmri.getMarketId());
            result = list.get(0);
        } else {
            logger.warn("No records were found in the table for Notification Ctl in CMRI with Market Id:{}", mdsNotificationCtlCmri.getMarketId());
        }

        logger.debug(" ********** Exiting the getCmriNotificationCtlByMarketId DAO Method ***********  ");
        return result;

    }

}

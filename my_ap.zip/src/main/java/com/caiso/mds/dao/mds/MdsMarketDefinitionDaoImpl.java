package com.caiso.mds.dao.mds;

import java.util.List;

import javax.persistence.EntityManager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktDefinition;
import com.caiso.mds.types.MarketType;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsMarketDefinitionDaoImpl implements MdsMarketDefinitionDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsMarketDefinitionDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public List<MrktDefinition> getMarketDefintionByMarketType(MarketType marketType) {

        logger.debug("****** Entered Method getMarketDefintionByMarketType() ****************   ");
        String query = "SELECT md FROM MrktDefinition md WHERE md.mrktType = :mrktType";

        List<MrktDefinition> list = mdsEntityManager.createQuery(query, MrktDefinition.class).setParameter("mrktType", marketType.getName()).getResultList();
        logger.info(" Market Defintions fetched :" + list.size());
        logger.debug("****** Exiting Method getMarketDefintionByMarketType() ****************   ");
        return list;
    }

}

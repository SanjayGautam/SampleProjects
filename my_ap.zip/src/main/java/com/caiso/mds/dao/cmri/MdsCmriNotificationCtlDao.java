package com.caiso.mds.dao.cmri;

import javax.persistence.EntityManager;

import com.caiso.mds.entity.cmri.MdsNotificationCtlCmri;
import com.caiso.mds.entity.cmri.MdsOasisStatusCtl;

public interface MdsCmriNotificationCtlDao {

    public EntityManager getMdsCmriEntityManager();

    public void setMdsCmriEntityManager(EntityManager mdsCmriEntityManager);

    public MdsNotificationCtlCmri createCmriNotification(MdsNotificationCtlCmri mdsNotificationCtlCmri);

    public void updateCmriNotification(MdsNotificationCtlCmri mdsNotificationCtlCmri);

    public void createMdsOasisStatusCtlRecord(MdsOasisStatusCtl mdsOasisStatusCtl);

    public MdsNotificationCtlCmri getCmriNotificationCtlByMarketId(MdsNotificationCtlCmri mdsNotificationCtlCmri);

    public MdsNotificationCtlCmri getCmriNotificationCtlInReadyStatusAndMdsFlowStatusNull(MdsNotificationCtlCmri mdsNotificationCtlCmri);

}

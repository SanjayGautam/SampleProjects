package com.caiso.mds.dao.mds;

import java.util.Calendar;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MdsLog;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsLogDaoImpl implements MdsLogDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsLogDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @Override
    public MdsLog createMdsLogRecord(MdsLog mdsLog) {
        logger.debug("***** Entered saveOrUpdateMdsLog() ********** ");
        mdsEntityManager.persist(mdsLog);
        logger.info("mds log was created with id 	:" + mdsLog.getMdsLogId());
        logger.debug("***** Exit saveOrUpdateMdsLog() ********** ");
        return mdsLog;
    }

    @Override
    public int deleteMdsLogRecordsBasedOnDaysInPast(Integer daysInPast) {
        logger.debug("***** Entered saveOrUpdateMdsLog() ********** ");

        Calendar dayInPast = Calendar.getInstance();
        dayInPast.roll(Calendar.DAY_OF_YEAR, -daysInPast);

        Query query = mdsEntityManager.createQuery("delete from MdsLog r where r.mdsLogInsertDts < :dateInPast ").setParameter("dateInPast",
                dayInPast.getTime());

        int recordsDeleted = query.executeUpdate();

        logger.debug("***** Exit saveOrUpdateMdsLog() ********** ");

        return recordsDeleted;

    }
}

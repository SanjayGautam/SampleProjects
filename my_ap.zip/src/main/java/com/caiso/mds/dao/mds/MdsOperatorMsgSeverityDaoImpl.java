package com.caiso.mds.dao.mds;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.caiso.mds.entity.mds.MrktMdsSeverity;

@Repository
@Transactional(propagation = Propagation.REQUIRED)
public class MdsOperatorMsgSeverityDaoImpl implements MdsOperatorMsgSeverityDao {

    private final Logger  logger = LoggerFactory.getLogger(MdsOperatorMsgSeverityDaoImpl.class);

    @Autowired
    private EntityManager mdsEntityManager;

    @SuppressWarnings("unchecked")
    @Override
    public List<MrktMdsSeverity> getAllMdsSeverities() {
        logger.debug(" **** Entering method getAllMdsSeverities *****  ");
        Query mdsSeverityQuery = mdsEntityManager.createQuery("FROM MrktMdsSeverity ms ");

        List<MrktMdsSeverity> list = mdsSeverityQuery.getResultList();
        logger.info("Fetched the MDs Severties size:{}", list.size());
        logger.debug(" **** Exiting method getAllMdsSeverities *****  ");
        return list;
    }

}

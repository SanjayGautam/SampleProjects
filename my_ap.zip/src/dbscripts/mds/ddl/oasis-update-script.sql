set echo on
Set define off;

spool oasis_db_1_1_0.log

alter session set current_schema=OASIS_INT;
  
ALTER TABLE MDS_NOTIFICATION_CTL  ADD ( TRADE_DT  TIMESTAMP(6) ,  UPDATED_DTS TIMESTAMP(6) );

commit;

spool off;  
  
    
  
  
  
  
  
 
                          
  
  
  
  
  



set echo on
Set define off;

spool mds-mstr_db_1_1_0_b80_maptest_2.log

alter session set current_schema=MDS_MSTR;


--
-- CREATE UTLITY FUNCTIONS
--
-- checks for existance of db object
CREATE OR REPLACE FUNCTION IS_OBJECT_EXISTS ( objectName VARCHAR2) RETURN BOOLEAN 
  AUTHID CURRENT_USER AS
  v_object VARCHAR2(32);
BEGIN
  SELECT object_name INTO v_object FROM user_objects WHERE Upper(object_name) = Upper(objectName) AND SUBOBJECT_NAME IS NULL;
  RETURN UPPER(v_object) = UPPER(objectName);
EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END IS_OBJECT_EXISTS;
/
-- drops a sequence if it exists
CREATE OR REPLACE PROCEDURE DROP_SEQ_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP SEQUENCE ' || objectName;
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_SEQ_IF_EXISTS;
/
-- drops a trigger if it exists
CREATE OR REPLACE PROCEDURE DROP_TRIGGER_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP TRIGGER ' || objectName;
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_TRIGGER_IF_EXISTS;
/
-- drops a table if it exists
CREATE OR REPLACE PROCEDURE DROP_TABLE_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP TABLE ' || objectName || ' CASCADE CONSTRAINTS';
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_TABLE_IF_EXISTS;
/
-- drops a view if it exists
CREATE OR REPLACE PROCEDURE DROP_VIEW_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP VIEW ' || objectName;
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_VIEW_IF_EXISTS;
/
-- returns the data type information for the specified column
CREATE OR REPLACE FUNCTION GET_COLUMN_DATATYPE ( tableName VARCHAR2, columnName VARCHAR2) RETURN VARCHAR2 
  AUTHID CURRENT_USER AS
  v_object VARCHAR2(60);
BEGIN
  SELECT data_type || Decode(data_type, 'VARCHAR2', '(' || data_length || ')', 'CHAR', '(' || data_length || ')', 'NUMBER',  '(' || data_precision || ',' || data_scale || ')', '') INTO v_object FROM USER_TAB_COLUMNS WHERE Upper(table_name) = Upper(tableName) AND Upper(column_name) = Upper(columnName);
  RETURN v_object;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END GET_COLUMN_DATATYPE;
/
-- returns true if the specified column exists
CREATE OR REPLACE FUNCTION IS_COLUMN_EXISTS ( tableName VARCHAR2, columnName VARCHAR2) RETURN BOOLEAN 
  AUTHID CURRENT_USER AS
BEGIN
  RETURN GET_COLUMN_DATATYPE( tableName, columnName ) IS NOT NULL;
EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END IS_COLUMN_EXISTS;
/
-- looks for old uid field and drops table if found marking it for upgrade
CREATE OR REPLACE PROCEDURE DROP_IF_OLD_UID ( tableName VARCHAR2, columnName VARCHAR2) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists(tableName) THEN
    IF GET_COLUMN_DATATYPE(tableName, columnName) = 'NUMBER(15,0)' THEN
       DBMS_OUTPUT.PUT_LINE('Old UID column detected IN ' || tableName || ', upgrading table, data will be lost.');
       EXECUTE IMMEDIATE 'DROP TABLE ' || tableName;
    END IF;
  END IF;
END DROP_IF_OLD_UID;
/
-- creates the standard update trigger
CREATE OR REPLACE PROCEDURE CREATE_UPDATE_TRIGGER ( tableName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  EXECUTE IMMEDIATE
    'CREATE OR REPLACE TRIGGER UPD_' || tableName ||
    '  before update on ' || tableName || ' for each row  ' ||
    'begin  ' ||
    '   :new.update_user := USER;  ' ||
    '   :new.update_date := SYSDATE;  ' ||
    ' end UPD_' || tableName || ';';
END CREATE_UPDATE_TRIGGER;
/

--
-- CREATE/UPDATE DATABASE SCHEMA
--
BEGIN


  -- create tables if they do not exist  
  IF NOT is_object_exists('MRKT_STATUS_TYPE') THEN
  
  
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_STATUS_TYPE ( 
           MRKT_STATUS_TYPE_ID      INTEGER             NOT NULL,
           MRKT_STATUS_TYPE_NAME   VARCHAR2(20 BYTE)      NOT NULL,
           MRKT_STATUS_TYPE_DESC    VARCHAR2(100 BYTE)     NOT NULL          
    )';
    
      EXECUTE IMMEDIATE 'ALTER TABLE MRKT_STATUS_TYPE ADD (
                          CONSTRAINT PK_MRKT_STATUS_TYPE_ID
                          PRIMARY KEY
                          (MRKT_STATUS_TYPE_ID)
                          ENABLE VALIDATE) ';
    -- TODO sg May be Grants also 
      EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, UPDATE , DELETE ON MRKT_STATUS_TYPE TO MDS_APP';
    
  END IF;
  
  IF NOT is_object_exists('MRKT_ACTIVITY') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_ACTIVITY
                        (
                          MRKT_ACTIVITY_ID    NUMBER,
                          MRKT_ACTIVITY_NAME  VARCHAR2(30 BYTE),
                          MRKT_ACTIVITY_DESC  VARCHAR2(100 BYTE),
                          MRKT_ACTIVITY_CD    CHAR(1 BYTE)
                        )' ;
        
  -- TODO sg May be Grants also 
      EXECUTE IMMEDIATE  'GRANT SELECT, INSERT,  UPDATE , DELETE ON MRKT_ACTIVITY TO MDS_APP ';
  
    EXECUTE IMMEDIATE 'ALTER TABLE MRKT_ACTIVITY ADD (
                              CONSTRAINT PK_MRKT_ACTIVITY_ID
                          PRIMARY KEY
                          (MRKT_ACTIVITY_ID)
                          ENABLE VALIDATE)';
                          
  
  

    
  END IF;
  
  
    IF NOT is_object_exists('MRKT_DEFINITION') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_DEFINITION
        (
          MRKT_DEFINITION_ID  INTEGER                 NOT NULL,
          MRKT_TYPE           VARCHAR2(20 BYTE)       NOT NULL,
          MRKT_CLASS          VARCHAR2(20 BYTE)       NOT NULL,
          MRKT_DEF_DESC       VARCHAR2(100 BYTE)      NOT NULL,
          MRKT_ACTIVITY_ID    INTEGER                 NOT NULL
        )' ;
        
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_DEFINITION ADD (
                          CONSTRAINT PK_MRKT_DEFINITION_ID
                          PRIMARY KEY
                          (MRKT_DEFINITION_ID)
                          ENABLE VALIDATE) ';
                          
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_DEFINITION ADD (
                              FOREIGN KEY (MRKT_ACTIVITY_ID) 
                              REFERENCES MRKT_ACTIVITY (MRKT_ACTIVITY_ID)
                              ENABLE VALIDATE)';
  

  -- TODO sg May be Grants also 
  EXECUTE IMMEDIATE  'GRANT SELECT, INSERT,  UPDATE , DELETE ON MRKT_DEFINITION TO MDS_APP ';

    
  END IF;
  
  
  IF NOT is_object_exists('MRKT_EVNT_DEF') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_EVNT_DEF
        (
          MRKT_EVNT_DEF_ID                             INTEGER                  NOT NULL,
          MRKT_EVNT_DESC                            VARCHAR2(255 BYTE)         NOT NULL,
          MRKT_EVNT_NOTIFICATION_NAME                 VARCHAR2(100 BYTE),
          MRKT_EVNT_NOTIFICATION_MSG                VARCHAR2(150 BYTE),
          MRKT_EVNT_CD                                VARCHAR2(50 BYTE),
          ENABLED                                    NUMBER(1),
          ASSOC_MRKT_DEFINITION_ID                    INTEGER,
          MRKT_EVNT_TYPE                            VARCHAR2(20 BYTE),
          IS_EXTERNAL_EVNT                            NUMBER(1),
          HAS_FIXED_EVNT_TRGR_TIME                    NUMBER(1),
          EVNT_START_TIME                            VARCHAR2(6 BYTE) ,
          EVNT_END_TIME                                VARCHAR2(6 BYTE) ,
          EVNT_TIME_OFFSET                            INTEGER,    
          EVNT_TIME_OFFSET_UNIT                        VARCHAR2(30) ,
          EVNT_TIME_OFFSET_STRT_ENTTY                VARCHAR2(30) ,
          EVNT_RPT_INTRVL                            INTEGER,
          EVNT_RPT_INTRVL_UNIT                        VARCHAR2(30) ,
          EVNT_RPT_INTRVL_OCCRANCE                    INTEGER,    
          COMMENTS                                    VARCHAR2(250) ,
          CREATED_BY                                 VARCHAR2(30) ,
          CREATED_DT                                DATE DEFAULT SYSDATE NOT NULL,
          
          UPDATED_BY                                    VARCHAR2(30) ,    
          UPDATED_DT                                DATE DEFAULT SYSDATE NOT NULL
                     
        )';
        
        
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_DEF ADD (
                          CONSTRAINT PK_MRKT_EVNT_DEF_ID
                          PRIMARY KEY
                          (MRKT_EVNT_DEF_ID)
                          ENABLE VALIDATE)';
                          
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_DEF  ADD CONSTRAINT EVNT_TIME_OFFSET_UNIT_CK  CHECK (EVNT_TIME_OFFSET_UNIT IN (''DAYS'', ''MINS'', ''HOURS'' , ''SECS''))';                         
  
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_DEF  ADD CONSTRAINT EVNT_TIME_OFFSET_STRT_ENTTY_CK  CHECK (EVNT_TIME_OFFSET_STRT_ENTTY IN (''MRKT_HOUR'', ''MRKT_DT'' ))';
  
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_DEF  ADD CONSTRAINT EVNT_RPT_INTRVL_UNIT_CK  CHECK (EVNT_RPT_INTRVL_UNIT IN (''EVERY_HOUR'', ''EVERY_MINUTE'' ))';

  
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_DEF ADD (
                              FOREIGN KEY (ASSOC_MRKT_DEFINITION_ID) 
                                REFERENCES MRKT_DEFINITION (MRKT_DEFINITION_ID)
                              ON DELETE CASCADE
                              ENABLE VALIDATE )';
  
  
  
  -- TODO sg May be Grants also 
  EXECUTE IMMEDIATE  'GRANT SELECT, INSERT , UPDATE , DELETE ON MRKT_EVNT_DEF TO MDS_APP ';
     
  END IF;
  
 

  
  IF NOT is_object_exists('MRKT_PLAN') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_PLAN
        (
          MRKT_PLAN_ID                     VARCHAR2(11)     NOT NULL,
          MRKT_RUN_ID                   VARCHAR2(11)         NOT NULL,
          MRKT_DEFINITION_ID            INTEGER             NOT NULL,
          MRKT_STATUS_TYPE_ID           INTEGER              NOT NULL,

          MRKT_DT                    DATE DEFAULT SYSDATE NOT NULL,
          MRKT_HOUR                    VARCHAR2(2), 
          REC_STATUS                   VARCHAR2(10),

          CREATED_BY                 VARCHAR2(30) ,
          CREATED_DT                DATE DEFAULT SYSDATE NOT NULL,
          UPDATED_BY                VARCHAR2(30) ,  
          UPDATED_DT                DATE DEFAULT SYSDATE NOT NULL  

        )';
        
    
    EXECUTE IMMEDIATE '    ALTER TABLE MRKT_PLAN ADD (
                              CONSTRAINT CMPK_MRKT_PLAN
                              PRIMARY KEY
                              (MRKT_PLAN_ID, MRKT_RUN_ID)
                              ENABLE VALIDATE)';
                              
        
    EXECUTE IMMEDIATE '    ALTER TABLE MRKT_PLAN ADD (

                              FOREIGN KEY (MRKT_DEFINITION_ID) 
                                REFERENCES MRKT_DEFINITION (MRKT_DEFINITION_ID)
                              ON DELETE CASCADE
                              ENABLE VALIDATE,

                              FOREIGN KEY (MRKT_STATUS_TYPE_ID) 
                              REFERENCES MRKT_STATUS_TYPE (MRKT_STATUS_TYPE_ID)
                            ON DELETE CASCADE
                              ENABLE VALIDATE)';
  
  EXECUTE IMMEDIATE  'GRANT SELECT, INSERT,  UPDATE , DELETE ON MRKT_PLAN TO MDS_APP ';
    
  END IF;
  
 
  
   IF NOT is_object_exists('MRKT_STATUS_HISTORY') THEN
   
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_STATUS_HISTORY
        (
          MRKT_STATUS_HISTORY_ID         INTEGER              NOT NULL,
          MRKT_PLAN_ID                   VARCHAR2(11)        NOT NULL,
          MRKT_RUN_ID                    VARCHAR2(11)        NOT NULL,
          MRKT_STATUS_TYPE_ID            INTEGER              NOT NULL,
          COMMENTS                        VARCHAR2(2000) ,

          CREATED_DT                    DATE DEFAULT SYSDATE NOT NULL  ,
          CREATED_BY                     VARCHAR2(30) , 
          UPDATED_DT                    DATE DEFAULT SYSDATE NOT NULL  ,
          UPDATED_BY                    VARCHAR2(30)           
        )';
        
    EXECUTE IMMEDIATE 'ALTER TABLE MRKT_STATUS_HISTORY ADD (
                          CONSTRAINT PK_MRKT_STATUS_HISTORY_ID
                          PRIMARY KEY
                          (MRKT_STATUS_HISTORY_ID)
                          ENABLE VALIDATE) ';
                          
    EXECUTE IMMEDIATE '    ALTER TABLE MRKT_STATUS_HISTORY ADD (
                              FOREIGN KEY     (MRKT_PLAN_ID , MRKT_RUN_ID) 
                                REFERENCES         MRKT_PLAN         (MRKT_PLAN_ID , MRKT_RUN_ID)
                              ON DELETE CASCADE
                              ENABLE VALIDATE,

                            FOREIGN KEY     (MRKT_STATUS_TYPE_ID) 
                              REFERENCES         MRKT_STATUS_TYPE         (MRKT_STATUS_TYPE_ID)
                            ON DELETE CASCADE
                              ENABLE VALIDATE )';
    

       EXECUTE IMMEDIATE  'GRANT SELECT,INSERT,  UPDATE , DELETE ON MRKT_STATUS_HISTORY TO MDS_APP ';
       
  END IF;
  
 
  
  IF NOT is_object_exists('MRKT_EVNT_HISTORY') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_EVNT_HISTORY
        (
          MRKT_EVNT_HISTORY_ID          INTEGER              NOT NULL,
          MRKT_PLAN_ID                  VARCHAR2(11)        NOT NULL,
          MRKT_RUN_ID                   VARCHAR2(11)        NOT NULL,
          MRKT_STATUS_HISTORY_ID        INTEGER              NOT NULL,
          MRKT_EVNT_DEF_ID              INTEGER              NOT NULL,
          MRKT_EVNT_PUB_STATE             VARCHAR2(30),
          MRKT_DT                     DATE DEFAULT SYSDATE NOT NULL,
          
          CREATED_BY                    VARCHAR2(30),
          CREATED_DT                    DATE DEFAULT SYSDATE NOT NULL  ,
          UPDATED_BY                    VARCHAR2(30),
          UPDATED_DT                    DATE DEFAULT SYSDATE NOT NULL  

        )';
        
    EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_HISTORY ADD (
                          CONSTRAINT PK_MRKT_EVNT_HISTORY_ID
                          PRIMARY KEY
                          (MRKT_EVNT_HISTORY_ID)
                          ENABLE VALIDATE) ';
                          
    EXECUTE IMMEDIATE '    ALTER TABLE MRKT_EVNT_HISTORY ADD (
                              FOREIGN KEY     (MRKT_PLAN_ID , MRKT_RUN_ID) 
                                REFERENCES         MRKT_PLAN         (MRKT_PLAN_ID , MRKT_RUN_ID)
                              ON DELETE CASCADE
                              ENABLE VALIDATE,

                            FOREIGN KEY     (MRKT_STATUS_HISTORY_ID) 
                              REFERENCES         MRKT_STATUS_HISTORY         (MRKT_STATUS_HISTORY_ID)
                            ON DELETE CASCADE
                              ENABLE VALIDATE , 

                            FOREIGN KEY     (MRKT_EVNT_DEF_ID) 
                              REFERENCES         MRKT_EVNT_DEF         (MRKT_EVNT_DEF_ID)
                            ON DELETE CASCADE
                              ENABLE VALIDATE )';
                              
      EXECUTE IMMEDIATE  'GRANT SELECT, INSERT, UPDATE , DELETE ON MRKT_EVNT_HISTORY TO MDS_APP ';
    
  END IF;
  
 
  BEGIN
  IF NOT is_object_exists('MDS_JOB') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MDS_JOB
        (
          MDS_JOB_ID  INTEGER               NOT NULL,
          MRKT_PLAN_ID                      VARCHAR2(11)       NOT NULL,
          MRKT_RUN_ID                       VARCHAR2(11)       NOT NULL,
          MRKT_JOB_DESC                     VARCHAR2(100 BYTE)      NOT NULL
        )' ;
        
  EXECUTE IMMEDIATE 'ALTER TABLE MDS_JOB ADD (
                          CONSTRAINT PK_MDS_JOB_ID_ID
                          PRIMARY KEY
                          (MDS_JOB_ID)
                          ENABLE VALIDATE) ';

  EXECUTE IMMEDIATE '    ALTER TABLE MDS_JOB ADD (
                              FOREIGN KEY     (MRKT_PLAN_ID , MRKT_RUN_ID) 
                                REFERENCES         MRKT_PLAN         (MRKT_PLAN_ID , MRKT_RUN_ID)
                              ON DELETE CASCADE
                              ENABLE VALIDATE 
                            )';

                              
                          
  -- TODO sg May be Grants also 
  EXECUTE IMMEDIATE  'GRANT SELECT,INSERT,  UPDATE , DELETE ON MDS_JOB TO MDS_APP ';

    
  END IF;
  END;
 
  

  IF NOT is_object_exists('MDS_LOG_MSG_TYPE') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MDS_LOG_MSG_TYPE
                        (
                          MDS_LOG_MSG_TYPE_ID    INTEGER,
                          MDS_LOG_MSG_TYPE_NAME  VARCHAR2(100 BYTE)     NOT NULL,
                          MDS_LOG_MSG_TYPE_DESC  VARCHAR2(100 BYTE)     NOT NULL
                        )' ;
        
  EXECUTE IMMEDIATE 'ALTER TABLE MDS_LOG_MSG_TYPE ADD (
                          CONSTRAINT PK_MDS_LOG_MSG_TYPE_ID
                          PRIMARY KEY
                          (MDS_LOG_MSG_TYPE_ID)
                          ENABLE VALIDATE) ';

  -- TODO sg May be Grants also 
  EXECUTE IMMEDIATE  'GRANT SELECT, INSERT, UPDATE , DELETE ON MDS_LOG_MSG_TYPE TO MDS_APP ';

    
  END IF;

  
  IF NOT is_object_exists('MDS_LOG') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MDS_LOG
                        (
                          MDS_LOG_ID                       INTEGER,
                          MRKT_PLAN_ID                     VARCHAR2(11)       ,
                          MRKT_RUN_ID                      VARCHAR2(11)       ,
                          MRKT_EVNT_HISTORY_ID          INTEGER,
                          MRKT_STATUS_HISTORY_ID          INTEGER,
                          MDS_LOG_MSG_TYPE_ID              INTEGER,                          
                          MDS_LOG_INSERT_DT            DATE DEFAULT SYSDATE NOT NULL  ,
                          MESSAGE_SUMMARY                  VARCHAR2(100 BYTE),
                          MESSAGE_DETAIL                   VARCHAR2(4000 BYTE)
                        )' ;
        
  EXECUTE IMMEDIATE 'ALTER TABLE MDS_LOG ADD (
                          CONSTRAINT PK_MDS_LOG_ID_ID
                          PRIMARY KEY
                          (MDS_LOG_ID)
                          ENABLE VALIDATE) ';

  EXECUTE IMMEDIATE '    ALTER TABLE MDS_LOG ADD (
                            
                                FOREIGN KEY     (MDS_LOG_MSG_TYPE_ID) 
                                  REFERENCES         MDS_LOG_MSG_TYPE (MDS_LOG_MSG_TYPE_ID)
                                ON DELETE CASCADE
                              ENABLE VALIDATE
 
                            )';

                              
                          
  -- TODO sg May be Grants also 
  EXECUTE IMMEDIATE  'GRANT SELECT, INSERT, UPDATE , DELETE ON MDS_LOG TO MDS_APP ';

    
  END IF;

  
  
  IF NOT is_object_exists('MRKT_STATUS_HISTORY_ID_SEQ') THEN
      EXECUTE IMMEDIATE 'CREATE SEQUENCE MRKT_STATUS_HISTORY_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 20';
      EXECUTE IMMEDIATE  'GRANT SELECT  ON MRKT_STATUS_HISTORY_ID_SEQ TO MDS_APP ';
      
  END IF;

  IF NOT is_object_exists('MDS_LOG_ID_SEQ') THEN
      EXECUTE IMMEDIATE 'CREATE SEQUENCE MDS_LOG_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 20';
      EXECUTE IMMEDIATE  'GRANT SELECT  ON MDS_LOG_ID_SEQ TO MDS_APP ';
      
  END IF;
  
  
  IF NOT is_object_exists('MRKT_EVNT_HISTORY_ID_SEQ') THEN
      EXECUTE IMMEDIATE 'CREATE SEQUENCE MRKT_EVNT_HISTORY_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 20';
      EXECUTE IMMEDIATE  'GRANT SELECT  ON MRKT_EVNT_HISTORY_ID_SEQ TO MDS_APP ';
      
  END IF;

  
  IF NOT is_object_exists('MRKT_EVNT_SCHD') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MRKT_EVNT_SCHD
                        (
                          MRKT_EVNT_SCHD_ID                       INTEGER,
                          MRKT_EVNT_DEF_ID                        INTEGER,
                          MRKT_DEFINITION_ID                    INTEGER,
                          
                          MRKT_EVNT_FIRE_DT                    DATE DEFAULT SYSDATE NOT NULL,
                          MRKT_DT                                DATE DEFAULT SYSDATE NOT NULL,

                          MRKT_EVNT_PUB_STATE                    VARCHAR2(30 BYTE)       NOT NULL,
                          MRKT_EVNT_ACT_STATUS                   VARCHAR2(30 BYTE)       NOT NULL,

                          CREATED_BY                    VARCHAR2(30),
                            CREATED_DT                    DATE DEFAULT SYSDATE NOT NULL  ,
                            UPDATED_BY                    VARCHAR2(30),
                            UPDATED_DT                    DATE DEFAULT SYSDATE NOT NULL
                          
                        )' ;
        
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_SCHD ADD (
                          CONSTRAINT PK_MRKT_EVNT_SCHD_ID
                          PRIMARY KEY
                          (MRKT_EVNT_SCHD_ID)
                          ENABLE VALIDATE) ';

  EXECUTE IMMEDIATE '    ALTER TABLE MRKT_EVNT_SCHD ADD (
                              FOREIGN KEY     (MRKT_EVNT_DEF_ID) 
                                REFERENCES         MRKT_EVNT_DEF         (MRKT_EVNT_DEF_ID)
                                  ON DELETE CASCADE
                              ENABLE VALIDATE,

                              FOREIGN KEY     (MRKT_DEFINITION_ID) 
                                  REFERENCES         MRKT_DEFINITION (MRKT_DEFINITION_ID)
                                ON DELETE CASCADE
                              ENABLE VALIDATE
                             
                            )';

                              
                          
  -- TODO sg May be Grants also 
  EXECUTE IMMEDIATE  'GRANT SELECT, INSERT, UPDATE , DELETE ON MRKT_EVNT_SCHD TO MDS_APP ';

  
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_SCHD  ADD CONSTRAINT MRKT_EVNT_PUB_STATE_CK  CHECK (MRKT_EVNT_PUB_STATE IN (''PROCESSING'' , ''SCHEDULED'', ''PUBLISHED'' , ''ERROR_IN_PUBLISHING'' ))';
  --  MRKT_EVNT_ACT_STATUS  
  EXECUTE IMMEDIATE 'ALTER TABLE MRKT_EVNT_SCHD  ADD CONSTRAINT MRKT_EVNT_ACT_STATUS_CK  CHECK (MRKT_EVNT_ACT_STATUS IN (''ENABLED'', ''DISABLED'' ))';
  
  END IF;
  
  IF NOT is_object_exists('MRKT_EVNT_SCHD_ID_SEQ') THEN
      EXECUTE IMMEDIATE 'CREATE SEQUENCE MRKT_EVNT_SCHD_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 20';
      EXECUTE IMMEDIATE  'GRANT SELECT  ON MRKT_EVNT_SCHD_ID_SEQ TO MDS_APP ';
      
  END IF;
  
  
  IF NOT is_object_exists('MDS_SEVERITY') THEN
  
  
    EXECUTE IMMEDIATE 'CREATE TABLE MDS_SEVERITY
                        (
                          MDS_SEVERITY_ID    INTEGER,
                          MDS_SEVERITY_NAME  VARCHAR2(100 BYTE),
                          MDS_SEVERITY_DESC  VARCHAR2(1000 BYTE)
                        )';
    
    EXECUTE IMMEDIATE 'ALTER TABLE MDS_SEVERITY ADD (
                          CONSTRAINT PK_MDS_SEVERITY_ID
                          PRIMARY KEY
                          (MDS_SEVERITY_ID)
                          ENABLE VALIDATE) ';
      
    -- TODO sg May be Grants also 
      EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, UPDATE , DELETE ON MDS_SEVERITY TO MDS_APP';
    
  END IF;
  
  
  
  IF NOT is_object_exists('SYS_OPER_MESSAGE') THEN
  
  
    EXECUTE IMMEDIATE 'CREATE TABLE SYS_OPER_MESSAGE
                        (
                          SYS_OPER_MESSAGE_ID     INTEGER,
                          MDS_SEVERITY_ID         INTEGER,
                          SEVERITY_INSERT_DTS     TIMESTAMP(6) WITH TIME ZONE,
                          SEVERITY_PAYLOAD        VARCHAR2(4000 BYTE),
                          POLL_STATUS             VARCHAR2(20 BYTE),
                          OASIS_PUBLISHED_STATUS  VARCHAR2(14 BYTE),
                          MSG_SUBMITTED_BY        VARCHAR2(225 BYTE)
                        )';
    
    EXECUTE IMMEDIATE 'GRANT SELECT, INSERT, UPDATE , DELETE ON SYS_OPER_MESSAGE TO MDS_APP';
    
    EXECUTE IMMEDIATE 'ALTER TABLE SYS_OPER_MESSAGE ADD (
                          CONSTRAINT PK_SYS_OPER_MESSAGE_ID
                          PRIMARY KEY
                          (SYS_OPER_MESSAGE_ID)
                          ENABLE VALIDATE) ';
                          
      EXECUTE IMMEDIATE 'ALTER TABLE SYS_OPER_MESSAGE ADD (
                          FOREIGN KEY (MDS_SEVERITY_ID) 
                          REFERENCES MDS_SEVERITY (MDS_SEVERITY_ID)
                          ON DELETE CASCADE
                          ENABLE VALIDATE)';
    -- TODO sg May be Grants also 
      
    
  END IF;
  
  
  IF NOT is_object_exists('SEQ_OPER_MSG_ID_SEQ') THEN
  
      EXECUTE IMMEDIATE 'CREATE SEQUENCE SEQ_OPER_MSG_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 20';
      EXECUTE IMMEDIATE  'GRANT SELECT  ON SEQ_OPER_MSG_ID_SEQ TO MDS_APP ';
      
  END IF;
  
  
    IF NOT is_object_exists('EXTRNL_ENDPOINT') THEN
  
  
    EXECUTE IMMEDIATE 'CREATE TABLE EXTRNL_ENDPOINT
                        (
                          EXTRNL_ENDPOINT_ID            INTEGER                     NOT NULL,
                          EXTRNL_APP_NAME               VARCHAR2(50 BYTE),
                          EXTRNL_SRVC_SEQ_NUM           INTEGER,
                          EXTRNL_INT_ENDPOINT           VARCHAR2(500 BYTE),
                          IS_HTTP_ENDPOINT                VARCHAR2(500 BYTE),    
                          EXTRNL_REAL_ENDPOINT          VARCHAR2(500 BYTE),
                          EXTRNL_SRVC_ENABLED           CHAR(1 BYTE),
                          SIGN_MSG                      CHAR(1 BYTE),
                          UPDT_LOG                      VARCHAR2(500 BYTE),
                          EXTRNL_APP_DESC               VARCHAR2(50 BYTE),
                          CREATED_BY                    VARCHAR2(30),
                            CREATED_DT                    DATE DEFAULT SYSDATE NOT NULL,
                            UPDATED_BY                    VARCHAR2(30),
                            UPDATED_DT                    DATE DEFAULT SYSDATE NOT NULL
                        )';
    
    EXECUTE IMMEDIATE  'GRANT SELECT, INSERT, UPDATE , DELETE  ON EXTRNL_ENDPOINT TO MDS_APP ';
    
    
    EXECUTE IMMEDIATE 'ALTER TABLE EXTRNL_ENDPOINT ADD (
                              CONSTRAINT SERENAB
                              CHECK (EXTRNL_SRVC_ENABLED IN(''Y'',''N''))
                              ENABLE VALIDATE,
                              PRIMARY KEY
                              (EXTRNL_ENDPOINT_ID))';
    
      
      
      
      END IF;
      

    IF NOT is_object_exists('EXTRNL_ENDPOINT_ID_SEQ') THEN
      
      EXECUTE IMMEDIATE 'CREATE SEQUENCE EXTRNL_ENDPOINT_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 20';
      EXECUTE IMMEDIATE  'GRANT SELECT  ON EXTRNL_ENDPOINT_ID_SEQ TO MDS_APP ';
      
      END IF;

  
IF NOT is_object_exists('MDS_TO_SIBR_MSG_LOG') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE MDS_MSTR.MDS_TO_SIBR_MSG_LOG
                        (
                          MDS_TO_SIBR_MSG_LOG_ID  INTEGER,
                          MRKT_RUN_ID             VARCHAR2(11 BYTE),
                          MRKT_PLAN_ID            VARCHAR2(13 BYTE),
                          MRKT_DT               DATE                  NOT NULL,
                          MRKT_TYPE               VARCHAR2(20 BYTE),
                          MRKT_CLASS              VARCHAR2(20 BYTE),
                          REQUESTED_STATUS        VARCHAR2(20 BYTE),
                          CURRENT_STATUS          VARCHAR2(20 BYTE),
                          PREVIOUS_STATUS         VARCHAR2(20 BYTE),
                          REQUEST_RESULT          VARCHAR2(30 BYTE),
                          SERVICE_RESPONSE        CLOB,
                            SERVICE_REQUEST         CLOB,
                          CREATED_BY                    VARCHAR2(30),
                            CREATED_DT                    DATE DEFAULT SYSDATE NOT NULL,
                            UPDATED_BY                    VARCHAR2(30),
                            UPDATED_DT                    DATE DEFAULT SYSDATE NOT NULL
                        )' ;
                        
  EXECUTE IMMEDIATE  'GRANT SELECT, INSERT, UPDATE , DELETE ON MDS_TO_SIBR_MSG_LOG TO MDS_APP ';
        
  EXECUTE IMMEDIATE 'ALTER TABLE MDS_TO_SIBR_MSG_LOG ADD (
                          CONSTRAINT PK_MDS_TO_SIBR_MSG_LOG_ID
                          PRIMARY KEY
                          (MDS_TO_SIBR_MSG_LOG_ID)
                          ENABLE VALIDATE) ';
  
  EXECUTE IMMEDIATE 'ALTER TABLE MDS_TO_SIBR_MSG_LOG  ADD CONSTRAINT REQUEST_RESULT_CK  CHECK (REQUEST_RESULT IN (''SUCCESS'', ''FAILED'' , ''ERROR_IN_PUBLISHING'' ))';
  
  END IF;
  
  IF NOT is_object_exists('MDS_TO_SIBR_MSG_LOG_ID_SEQ') THEN
      
      EXECUTE IMMEDIATE 'CREATE SEQUENCE MDS_TO_SIBR_MSG_LOG_ID_SEQ MINVALUE 1 START WITH 1 INCREMENT BY 1 CACHE 20';
      EXECUTE IMMEDIATE  'GRANT SELECT  ON MDS_TO_SIBR_MSG_LOG_ID_SEQ TO MDS_APP ';
      
  END IF;
  
  
  IF NOT is_object_exists('PATCH_APPLIED') THEN
  
    EXECUTE IMMEDIATE 'CREATE TABLE PATCH_APPLIED
                        (
                          APP            VARCHAR2(50 BYTE),
                          APP_COMPONENT  VARCHAR2(50 BYTE),
                          PATCH_VERSION  VARCHAR2(50 BYTE),
                          APPLIED_DATE   DATE                           DEFAULT sysdate,
                          HOST           VARCHAR2(30 BYTE),
                          INSTALLER      VARCHAR2(50 BYTE),
                          EXECUTED_AS    VARCHAR2(50 BYTE),
                          ACTION         VARCHAR2(1 BYTE),
                          SUCCESS_YN     VARCHAR2(1 BYTE)
                        )' ;
                        
      EXECUTE IMMEDIATE  'GRANT SELECT, INSERT, UPDATE , DELETE ON PATCH_APPLIED TO MDS_APP ';
      
   END IF;
   

       
   
   
  
END;
  

INSERT INTO MDS_MSTR.PATCH_APPLIED (
   APP, APP_COMPONENT, PATCH_VERSION, 
   APPLIED_DATE, HOST, INSTALLER, 
   EXECUTED_AS, ACTION, SUCCESS_YN) 
VALUES ( 'MDS_APP',
 'DB',
 'mds-app-1.1.0_b80',
  sysdate,
  sys_context('USERENV','TERMINAL'),
  sys_context('USERENV','OS_USER'),
  user,
 'I',
 'Y');


 
COMMIT;

spool off;


    
  
  
  
  
  
 
                          
  
  
  
  
  



CREATE OR REPLACE PROCEDURE MIGRATE_MRKT_BEPL_TO_BPM IS

/******************************************************************************
   NAME:       MIGRATE_MRKT_BEPL_TO_BPM
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        10/30/2015   sgautam       1. Created this procedure.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     MIGRATE_MRKT_BEPL_TO_BPM
      Sysdate:         10/30/2015
      Date and Time:   10/30/2015, 4:52:42 PM, and 10/30/2015 4:52:42 PM
      Username:        sgautam (set in TOAD Options, Procedure Editor)
      Table Name:       (set in the "New PL/SQL Object" dialog)

******************************************************************************/
 

    CURSOR mds_mrkt_open_curr IS
     SELECT MP.MARKET_ID , MR.MARKET_RUN_ID , MM.MARKET_DATE , MM.MARKET_HOUR , MM.MARKET_DEFINITION_ID , MR.MARKET_STATUS_ID   
     FROM  mds.market_plan mp , mds.market_run mr , mds.mds_market mm 
     WHERE  MP.MARKET_MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
            AND  MM.MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
            AND  MM.MARKET_DATE  BETWEEN sysdate  and sysdate +7
            AND  MR.MARKET_STATUS_ID   >= 10 
     ORDER BY MM.MARKET_DATE asc, mm.market_hour asc;
 
     timeZoneVar  varchar2(4 char);
    
BEGIN
   
   
   
   
   FOR mds_mrk_open_rec
   IN mds_mrkt_open_curr
   LOOP 
   
    DBMS_OUTPUT.PUT_LINE(' Looping through the update Loop ');
    
    select extract(timezone_abbr from cast(sysdate  as timestamp) at time zone 'US/Pacific'  ) into timeZoneVar from dual ;
        
    DBMS_OUTPUT.PUT_LINE(' Time Zone Found :' || timeZoneVar);
    
    UPDATE MDS_MSTR.MRKT_PLAN mp 
    SET MP.MRKT_PLAN_ID = mds_mrk_open_rec.MARKET_ID ,
        MP.MRKT_RUN_ID = mds_mrk_open_rec.MARKET_RUN_ID,
        MP.MRKT_STATUS_TYPE_ID = mds_mrk_open_rec.MARKET_STATUS_ID,
        MP.UPDATED_BY ='mig-script',
        MP.UPDATED_DT = sysdate 
    WHERE MP.MRKT_DEFINITION_ID = mds_mrk_open_rec.MARKET_DEFINITION_ID
    AND to_number(MP.MRKT_HOUR) = mds_mrk_open_rec.MARKET_HOUR
    AND MP.MRKT_DT = NEW_TIME( mds_mrk_open_rec.MARKET_DATE , extract(timezone_abbr from cast(mds_mrk_open_rec.MARKET_DATE  as timestamp) at time zone 'US/Pacific'  ) , 'GMT')   ;
        
   
   END LOOP;
   
   
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('No data found to update ');
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       DBMS_OUTPUT.PUT_LINE('Error while executing the migration scripts ');
       RAISE;
END MIGRATE_MRKT_BEPL_TO_BPM;
/





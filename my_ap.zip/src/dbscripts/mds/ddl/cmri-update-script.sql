

--
-- CREATE UTLITY FUNCTIONS
--
-- checks for existance of db object
CREATE OR REPLACE FUNCTION IS_OBJECT_EXISTS ( objectName VARCHAR2) RETURN BOOLEAN 
  AUTHID CURRENT_USER AS
  v_object VARCHAR2(32);
BEGIN
  SELECT object_name INTO v_object FROM user_objects WHERE Upper(object_name) = Upper(objectName) AND SUBOBJECT_NAME IS NULL;
  RETURN UPPER(v_object) = UPPER(objectName);
EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END IS_OBJECT_EXISTS;
/
-- drops a sequence if it exists
CREATE OR REPLACE PROCEDURE DROP_SEQ_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP SEQUENCE ' || objectName;
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_SEQ_IF_EXISTS;
/
-- drops a trigger if it exists
CREATE OR REPLACE PROCEDURE DROP_TRIGGER_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP TRIGGER ' || objectName;
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_TRIGGER_IF_EXISTS;
/
-- drops a table if it exists
CREATE OR REPLACE PROCEDURE DROP_TABLE_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP TABLE ' || objectName || ' CASCADE CONSTRAINTS';
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_TABLE_IF_EXISTS;
/
-- drops a view if it exists
CREATE OR REPLACE PROCEDURE DROP_VIEW_IF_EXISTS ( objectName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists ( objectName ) THEN
    EXECUTE IMMEDIATE 'DROP VIEW ' || objectName;
    DBMS_OUTPUT.PUT_LINE('Dropped ' || objectName);
  END IF;
END DROP_VIEW_IF_EXISTS;
/
-- returns the data type information for the specified column
CREATE OR REPLACE FUNCTION GET_COLUMN_DATATYPE ( tableName VARCHAR2, columnName VARCHAR2) RETURN VARCHAR2 
  AUTHID CURRENT_USER AS
  v_object VARCHAR2(60);
BEGIN
  SELECT data_type || Decode(data_type, 'VARCHAR2', '(' || data_length || ')', 'CHAR', '(' || data_length || ')', 'NUMBER',  '(' || data_precision || ',' || data_scale || ')', '') INTO v_object FROM USER_TAB_COLUMNS WHERE Upper(table_name) = Upper(tableName) AND Upper(column_name) = Upper(columnName);
  RETURN v_object;
EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END GET_COLUMN_DATATYPE;
/
-- returns true if the specified column exists
CREATE OR REPLACE FUNCTION IS_COLUMN_EXISTS ( tableName VARCHAR2, columnName VARCHAR2) RETURN BOOLEAN 
  AUTHID CURRENT_USER AS
BEGIN
  RETURN GET_COLUMN_DATATYPE( tableName, columnName ) IS NOT NULL;
EXCEPTION
    WHEN OTHERS THEN
        RETURN FALSE;
END IS_COLUMN_EXISTS;
/
-- looks for old uid field and drops table if found marking it for upgrade
CREATE OR REPLACE PROCEDURE DROP_IF_OLD_UID ( tableName VARCHAR2, columnName VARCHAR2) 
  AUTHID CURRENT_USER AS
BEGIN
  IF is_object_exists(tableName) THEN
    IF GET_COLUMN_DATATYPE(tableName, columnName) = 'NUMBER(15,0)' THEN
       DBMS_OUTPUT.PUT_LINE('Old UID column detected IN ' || tableName || ', upgrading table, data will be lost.');
       EXECUTE IMMEDIATE 'DROP TABLE ' || tableName;
    END IF;
  END IF;
END DROP_IF_OLD_UID;
/
-- creates the standard update trigger
CREATE OR REPLACE PROCEDURE CREATE_UPDATE_TRIGGER ( tableName VARCHAR2 ) 
  AUTHID CURRENT_USER AS
BEGIN
  EXECUTE IMMEDIATE
    'CREATE OR REPLACE TRIGGER UPD_' || tableName ||
    '  before update on ' || tableName || ' for each row  ' ||
    'begin  ' ||
    '   :new.update_user := USER;  ' ||
    '   :new.update_date := SYSDATE;  ' ||
    ' end UPD_' || tableName || ';';
END CREATE_UPDATE_TRIGGER;
/

--
-- CREATE/UPDATE DATABASE SCHEMA
--
BEGIN

 
  
END;
  
  
    
  
  
  
  
  
 
                          
  
  
  
  
  



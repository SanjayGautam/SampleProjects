
SET DEFINE OFF;

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 08:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 09:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 10:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 11:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate ) ;

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 12:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 13:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 14:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 15:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 16:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );


insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 17:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 18:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );




insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 19:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );


insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 20:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 21:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 22:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

   
insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/06/2016 23:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );


insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 00:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );


insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 01:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );


insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 02:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 03:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 04:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 05:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );


insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 06:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

insert into MRKT_EVNT_SCHD values (MRKT_EVNT_SCHD_ID_SEQ.nextval , 55 , 7 , 
TO_DATE('02/04/2016 00:30:00', 'MM/DD/YYYY HH24:MI:SS'), 
TO_DATE('02/07/2016 07:00:00', 'MM/DD/YYYY HH24:MI:SS') ,
'SCHEDULED' ,'ENABLED' , 'MDS', sysdate , 'mds' , sysdate );

COMMIT;

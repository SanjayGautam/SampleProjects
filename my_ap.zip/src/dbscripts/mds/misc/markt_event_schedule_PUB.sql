select * from MRKT_PLAN mp  where MP.MRKT_DEFINITION_ID =6
order by MRKT_DT asc
 and  trunc(mp.MRKT_DT) = '14-Aug-2015'

select * from MDS_MSTR.MRKT_EVNT_DEF med where MED.ASSOC_MRKT_DEFINITION_ID = 1  and MED.MRKT_EVNT_DEF_ID= 41

select * from MRKT_EVNT_SCHD me 
where 
ME.MRKT_DEFINITION_ID =6
-- and   
--trunc(ME.MRKT_EVNT_FIRE_DT) = '14-Aug-2015'
-- AND ME.MRKT_EVNT_DEF_ID = 35
Order by ME.MRKT_EVNT_FIRE_DT asc

select * from MRKT_EVNT_SCHD me 
where 
ME.MRKT_DEFINITION_ID =4 and   
me.MRKT_EVNT_FIRE_DT = TO_DATE('14-08-2015 2:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' )
-- AND ME.MRKT_EVNT_DEF_ID = 35
Order by ME.MRKT_EVNT_FIRE_DT asc


select * from MRKT_EVNT_SCHD me 
where 
ME.MRKT_DEFINITION_ID =4 and   
me.MRKT_EVNT_FIRE_DT between  TO_DATE('14-08-2015 6:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('15-08-2015 7:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' )
AND ME.MRKT_EVNT_DEF_ID = 39
Order by ME.MRKT_EVNT_FIRE_DT asc


select * from MRKT_EVNT_SCHD me 
where 
ME.MRKT_DEFINITION_ID =4 and   
me.MRKT_EVNT_FIRE_DT between  TO_DATE('14-08-2015 6:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('15-08-2015 6:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' )
AND ME.MRKT_EVNT_DEF_ID = 40
Order by ME.MRKT_EVNT_FIRE_DT asc

select * from MRKT_EVNT_SCHD me 
where 
ME.MRKT_DEFINITION_ID =4 
-- and   
--me.MRKT_EVNT_FIRE_DT between  TO_DATE('14-08-2015 6:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('15-08-2015 7:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' )
AND ME.MRKT_EVNT_DEF_ID = 41
Order by ME.MRKT_EVNT_FIRE_DT asc , me.MRKT_DT asc




-- THIS QUERY WILL GIVE US THE ALL THE EVENTSTO BE FIRED FOR MARKET DEF ID =1 FOR SYSDATE I.E 04-AUG-2015   
---   TO_DATE('04-08-2015 1:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' )
select * from MRKT_EVNT_SCHD MS,  MRKT_PLAN mp 
where MS.MRKT_DEFINITION_ID=4
AND MS.MRKT_EVNT_DEF_ID=41
and  MS.MRKT_EVNT_FIRE_DT between TO_DATE('18-10-2015 7:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('19-10-2015 6:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' ) 
and MS.MRKT_DT = mp.MRKT_DT
and Mp.MRKT_DEFINITION_ID = ms.MRKT_DEFINITION_ID
order by MS.MRKT_EVNT_FIRE_DT asc , mrkt_hour asc 

-- GOOD QUERY 
select * from MRKT_EVNT_SCHD MS,  MRKT_PLAN mp 
where MS.MRKT_DEFINITION_ID=4
AND MS.MRKT_EVNT_DEF_ID=41
and  MS.MRKT_EVNT_FIRE_DT between TO_DATE('14-08-2015 3:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('15-08-2015 7:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' ) 
and MS.MRKT_DT = mp.MRKT_DT
and Mp.MRKT_DEFINITION_ID = ms.MRKT_DEFINITION_ID
and MS.MRKT_DT = TO_DATE('08/14/2015 6:00:00 AM' , 'mm/dd/yyyy HH:MI:SS AM' ) 
order by MS.MRKT_EVNT_FIRE_DT asc , mrkt_hour asc 

-- FINAL QUERY 
select MS.MRKT_EVNT_SCHD_ID, MS.MRKT_EVNT_FIRE_DT , MS.MRKT_DT , MS.MRKT_DEFINITION_ID , MS.MRKT_EVNT_DEF_ID , MP.MRKT_DT , MP.MRKT_HOUR , MP.MRKT_DEFINITION_ID ,
MP.MRKT_PLAN_ID , MP.MRKT_RUN_ID 
from MRKT_EVNT_SCHD MS,  MRKT_PLAN mp 
where MS.MRKT_DEFINITION_ID=3
-- AND MS.MRKT_EVNT_DEF_ID=39
 and  MS.MRKT_EVNT_FIRE_DT between TO_DATE('24-09-2015 7:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('25-09-2015 7:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' )
  --and  MS.MRKT_EVNT_FIRE_DT  = TRUNC(SYSDATE , 'mi')   
and MS.MRKT_DT = mp.MRKT_DT
and Mp.MRKT_DEFINITION_ID = ms.MRKT_DEFINITION_ID
--and MS.HAS_FIXED_EVNT_TRGR_TIME=
--AND MP.MRKT_PLAN_ID LIKE '208152015%'
order by MS.MRKT_EVNT_FIRE_DT asc , mrkt_hour asc 

select MS.MRKT_EVNT_SCHD_ID, MS.MRKT_EVNT_FIRE_DT , MS.MRKT_DT , MS.MRKT_DEFINITION_ID , MS.MRKT_EVNT_DEF_ID , MP.MRKT_DT , MP.MRKT_HOUR , MP.MRKT_DEFINITION_ID ,
MP.MRKT_PLAN_ID , MP.MRKT_RUN_ID 
from MRKT_EVNT_SCHD MS,  MRKT_PLAN mp 
where MS.MRKT_DEFINITION_ID=6
-- AND MS.MRKT_EVNT_DEF_ID=39
 and  MS.MRKT_EVNT_FIRE_DT between TO_DATE('19-08-2015 11:10 P.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('21-08-2015 7:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' )
  -- and  MS.MRKT_EVNT_FIRE_DT  = TRUNC(SYSDATE , 'mi')   
and MS.MRKT_DT = mp.MRKT_DT
and Ms.MRKT_DEFINITION_ID = mp.MRKT_DEFINITION_ID
--and MS.HAS_FIXED_EVNT_TRGR_TIME =1
--AND MP.MRKT_PLAN_ID LIKE '208152015%'
order by MS.MRKT_EVNT_FIRE_DT asc , mrkt_hour asc 

select mrktplan1_.MRKT_PLAN_ID as col_0_0_, mrktplan1_.MRKT_RUN_ID as col_1_0_, mrktevntsc0_.MRKT_EVNT_SCHD_ID as col_2_0_, 
mrktevntsc0_.MRKT_EVNT_FIRE_DT as col_3_0_, mrktevntsc0_.MRKT_DT as col_4_0_, mrktevntsc0_.MRKT_DEFINITION_ID as col_5_0_, mrktevntsc0_.MRKT_EVNT_DEF_ID as 
col_6_0_, mrktplan1_.MRKT_HOUR as col_7_0_
from MDS_APP.MRKT_EVNT_SCHD mrktevntsc0_ 
cross join MDS_APP.MRKT_PLAN mrktplan1_ where mrktevntsc0_.MRKT_DEFINITION_ID=4 and mrktevntsc0_.MRKT_EVNT_FIRE_DT > TO_DATE('18-08-2015 12:30 A.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and mrktevntsc0_.MRKT_DT=mrktplan1_.MRKT_DT 
and mrktplan1_.MRKT_DEFINITION_ID=mrktevntsc0_.MRKT_DEFINITION_ID order by mrktevntsc0_.MRKT_EVNT_FIRE_DT asc, mrktplan1_.MRKT_HOUR asc

select max(mrktevntsc0_.MRKT_DT) as col_0_0_ from MDS_APP.MRKT_EVNT_SCHD mrktevntsc0_


select sysdate from  dual
SELECT TRUNC(SYSDATE , 'mi')
as new_year FROM DUAL; 

select * from MRKT_EVNT_SCHD MS  
where MS.MRKT_DEFINITION_ID=2 and  MS.MRKT_EVNT_FIRE_DT = TO_DATE('14-08-2015 2:00 P.M.' , 'dd-mm-yyyy HH:MI A.M.' ) 
and trunc(MS.MRKT_DT) in ( Select trunc(mp.MRKT_DT) from MRKT_PLAN mp where trunc(MP.MRKT_DT) = trunc(MS.MRKT_DT) ) 
order by MS.MRKT_EVNT_FIRE_DT asc 



select * from MRKT_PLAN mp  where MP.MRKT_DEFINITION_ID =1   and  trunc(mp.MRKT_DT) = '11-Aug-2015'


select * from mrkt_plan mp where MP.MRKT_PLAN_ID like '108052015%'
 
select * from MRKT_EVNT_SCHD me 
where 
ME.MRKT_DEFINITION_ID =2 and  trunc(me.MRKT_DT) = '04-aug-2015'
Order by ME.MRKT_EVNT_FIRE_DT asc

and ME.MRKT_DAT E


select * from MDS_MSTR.MRKT_EVNT_DEF med where MED.ASSOC_MRKT_DEFINITION_ID = 2


select * from MRKT_EVNT_SCHD me , MRKT_PLAN mp
where 
ME.MRKT_DEFINITION_ID =1 and  trunc(me.MRKT_DT) = '04-Aug-2015'
-- and MP.MRKT_DT = ME.MRKT_DT
Order by ME.MRKT_EVNT_FIRE_DT asc

select * from MRKT_EVNT_SCHD me 
where ME.MRKT_DEFINITION_ID=1 and  trunc(ME.MRKT_EVNT_FIRE_DT) = '04-Aug-2015' 
order by ME.MRKT_EVNT_FIRE_DT asc 

-- THIS QUERY WILL GIVE US THE ALL THE EVENTSTO BE FIRED FOR MARKET DEF ID =1 FOR SYSDATE I.E 04-AUG-2015 
select * from MRKT_EVNT_SCHD me,  MRKT_PLAN mp 
where ME.MRKT_DEFINITION_ID=2 and  trunc(ME.MRKT_EVNT_FIRE_DT) = '14-Aug-2015' 
and trunc(me.MRKT_DT) = trunc(mp.MRKT_DT)
and me.MRKT_DEFINITION_ID = mp.MRKT_DEFINITION_ID
order by ME.MRKT_EVNT_FIRE_DT asc 

select * from MRKT_EVNT_SCHD me,  MRKT_PLAN mp 
where  trunc(ME.MRKT_EVNT_FIRE_DT) > sysdate 
and me.MRKT_DT = trunc(mp.MRKT_DT)
and me.MRKT_DEFINITION_ID = mp.MRKT_DEFINITION_ID
order by ME.MRKT_EVNT_FIRE_DT asc 


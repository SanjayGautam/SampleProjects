-- this will get you the market dates for the range of market defintion.  

SELECT * FROM MRKT_EVNT_SCHD
WHERE MRKT_DEFINITION_ID = 4
 AND MRKT_EVNT_DEF_ID = 39
 AND MRKT_DT BETWEEN TO_DATE('02/06/2016 08:00:00', 'MM/DD/YYYY HH24:MI:SS')
 AND TO_DATE('02/07/2016 07:00:00', 'MM/DD/YYYY HH24:MI:SS')
 
-- update tehe timing for the fire event trigger when ever it is needed.  
 
UPDATE MRKT_EVNT_SCHD T
SET  T.MRKT_EVNT_FIRE_DT= TO_DATE('02/04/2016 19:30:00', 'MM/DD/YYYY HH24:MI:SS')
WHERE MRKT_DEFINITION_ID = 4
 AND MRKT_EVNT_DEF_ID = 39
 AND MRKT_DT BETWEEN TO_DATE('02/06/2016 08:00:00', 'MM/DD/YYYY HH24:MI:SS')
 AND TO_DATE('02/07/2016 07:00:00', 'MM/DD/YYYY HH24:MI:SS')
 


select MP.MRKT_DEFINITION_ID, MP.MRKT_RUN_ID , MP.MRKT_PLAN_ID , MP.MRKT_DT, MST.MRKT_STATUS_TYPE_NAME , MP.MRKT_HOUR  
from  mrkt_plan mp , MDS_MSTR.MRKT_STATUS_TYPE mst  
where 
MP.MRKT_STATUS_TYPE_ID = MST.MRKT_STATUS_TYPE_ID
and MP.MRKT_DEFINITION_ID in (1,2,3,4 )
and MP.MRKT_DT between TO_DATE('03-10-2015 7:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' ) and TO_DATE('04-10-2015 6:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' )  
order by MP.MRKT_DEFINITION_ID asc , MP.MRKT_HOUR asc   

select trunc(TO_DATE('03-10-2015 7:00 A.M.' , 'dd-mm-yyyy HH:MI A.M.' )) from dual

desc MDS_MSTR.MRKT_EVNT_HISTORY;

select t1.CREATED_DT , T2.MRKT_DT ,T2.MRKT_HOUR , T3.MRKT_EVNT_CD , T3.MRKT_EVNT_NOTIFICATION_MSG 
from MRKT_EVNT_HISTORY t1 , mrkt_plan  t2, MRKT_EVNT_DEF t3
where t1.MRKT_PLAN_ID = t2.MRKT_PLAN_ID
and t1.MRKT_RUN_ID = t2.MRKT_RUN_ID
and t1.MRKT_EVNT_DEF_ID = t3.MRKT_EVNT_DEF_ID
and t1.CREATED_DT > TO_DATE('23/09/2015 9:00 A.M.'  , 'dd/mm/yyyy HH:MI A.M.' )
order by t1.CREATED_DT  desc

t1.event_definition_id=t3.event_definition_id 
and t1.MARKET_STATUS_HISTORY_ID = t4.MARKET_STATUS_HISTORY_ID 
and t4.market_run_id =t5.market_run_id 
and t5.MDS_MKT_CLS_ID=t2.MDS_MKT_CLS_ID 
and t1.market_insert_dts &gt; (sysdate-1) 
UNION 
select unique t1.market_insert_dts,t1.market_date,0 as market_hour, t3.event_cd, t3.event_notification_message 
from market_event_history t1,event_definition t3 
where t1.event_definition_id=t3.event_definition_id 
and t1.event_definition_id in(6,8,17) 
and t1.market_insert_dts &gt; (sysdate-1) 
order by 1 desc

-- date funtion details .

SELECT TO_CHAR(NEW_TIME(TO_DATE('25/05/2006 5:45:00 AM',
    'DD/MM/YYYY HH:MI:SS AM'), 'PST', 'GMT'), 'DD/MM/YYYY HH:MI:SS AM')
    FROM dual;
    

  -- Market Class Id  170781    Trade Class ID 170730
select * from market_plan  mp where MP.MARKET_ID =109357

select * from market_plan mp where MP.MARKET_MDS_MKT_CLS_ID in ( 45207 ,45208,45209 ,45210 ,45211 ,45212 ,45213 ,45214 ,45215 ,45216, 45217, 45218 ,45219 ,45220, 45221 ,45222, 45223 )

-- Market Run ID for Market = 170031   Market Run Ids Trade  169980  

Select * from market_run mr where MR.MDS_MKT_CLS_ID  in ( 170781  , 170730)

Select * from market_run mr where MR.MDS_MKT_CLS_ID  in ( 45207 ,45208,45209 ,45210 ,45211 ,45212 ,45213 ,45214 ,45215 ,45216, 45217, 45218 ,45219 ,45220, 45221 ,45222, 45223 )                                   



-- Found ony Market Def ID 3 
Select * from MDS_Market mm  where MM.MDS_MKT_CLS_ID =   170781

-- Found ony Market Def ID 4
Select * from MDS_Market mm  where MM.MDS_MKT_CLS_ID =   170730

-- Market Def Id 
Select * from MDS_Market mm   
where MM.MARKET_DEFINITION_ID =3 
and MM.MDS_MKT_CLS_ID in ( 45207 ,45208,45209 ,45210 ,45211 ,45212 ,45213 ,45214 ,45215 ,45216, 45217, 45218 ,45219 ,45220, 45221 ,45222, 45223 )  
order by mm.market_Date 

Select * from MDS_Market mm   
where MM.MARKET_DEFINITION_ID =4

-- all the markets are ther in this table. 
Select unique MM.MARKET_DEFINITION_ID from MDS_Market mm  order by 1

select  * from MDS_Market mm where MM.MARKET_DEFINITION_ID =7 order by MM.MARKET_DATE asc   
select  * from MDS_Market mm where MM.MARKET_DEFINITION_ID =2 order by MM.MARKET_DATE asc

--  Market . 

select MP.MARKET_ID , MR.MARKET_RUN_ID , MM.MARKET_DATE , MM.MARKET_HOUR , MM.MARKET_DEFINITION_ID   from  market_plan mp , market_run mr , mds_market mm 
where 
MP.MARKET_MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MARKET_DEFINITION_ID in (1)   
and MM.MARKET_DATE  between TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') and TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') +7
-- order by MM.MARKET_DATE
union 
-- Trades 
select MP.MARKET_ID , MR.MARKET_RUN_ID , MM.MARKET_DATE , MM.MARKET_HOUR , MM.MARKET_DEFINITION_ID   from  market_plan mp , market_run mr , mds_market mm 
where 
MP.TRADE_MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MARKET_DEFINITION_ID in (2)   
and MM.MARKET_DATE  between TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') and TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') +7 
order by 3


select MP.MARKET_ID , MR.MARKET_RUN_ID , MM.MARKET_DATE , MM.MARKET_HOUR , MM.MARKET_DEFINITION_ID   from  market_plan mp , market_run mr , mds_market mm 
where 
MP.MARKET_MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MARKET_DEFINITION_ID in (3)   
and MM.MARKET_DATE  between TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') and TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') +7
 order by MM.MARKET_DATE asc, mm.market_hour asc
union 
-- Trades 
select MP.MARKET_ID , MR.MARKET_RUN_ID , MM.MARKET_DATE , MM.MARKET_HOUR , MM.MARKET_DEFINITION_ID   from  market_plan mp , market_run mr , mds_market mm 
where 
MP.TRADE_MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MDS_MKT_CLS_ID = MR.MDS_MKT_CLS_ID
and MM.MARKET_DEFINITION_ID in (2)   
and MM.MARKET_DATE  between TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') and TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') +7 
order by 3



select TO_DATE('10/31/2014 12:00:00', 'MM/DD/YYYY HH24:MI:SS') +7 from dual  


   
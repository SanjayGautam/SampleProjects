-- OASIS DATA 
-- take a data ahead market(bids)

SET DEFINE OFF;
Insert into MDS_NOTIFICATION_CTL
   (NOTIFICATION_CTL_ID, MARKET_ID, MARKET_RUN_ID, NOTIFICATION_NAME, NOTIFICATION_COMMENTS, 
    STATUS, CREATED_DTS, UPDATE_DTS, UPDATE_USER, MDS_FLOW_STATE, 
    MDS_RETRY_COUNT, MDS_PROCESS_AFTER, MDS_FLOW_START_DTS, MDS_FLOW_END_DTS, TRADE_DT, 
    UPDATED_DTS)
 Values
   (SEQ_MDS_CTL_ID.nextval , '16101300', '116101300', 'PUBLISHDARESULTS', NULL, 
    'WAITING', sysdate , sysdate, 'OASIS', null ,  0, NULL, NULL, sysdate , NULL, 
    NULL);
COMMIT;

-- Use this query to check the data is there or not it should be in the waiting state  
select * from MDS_NOTIFICATION_CTL  where MARKET_RUN_ID= '116101300' 

-- Use this query to update the waiting state to ready .

update MDS_NOTIFICATION_CTL
set status = 'READY'
where MARKET_RUN_ID= '116101300'

-- After 40 secs you should see that PublishDaAheadResults flow is in Active tab of the jbpm. 



-- Now inset the CMRI DATA

-- Check in the CMRI DATA base if the record is entered by MDS  
select * from MDS_OASIS_STATUS_CTL  where MARKET_RUN_ID= '116101300'

-- Check in the CMRI DATA insert the record assuming the CMRI has successfully processed the record entered in the earlier steps. 
SET DEFINE OFF;
Insert into MDS_NOTIFICATION_CTL
   (NOTIFICATION_CTL_ID, MARKET_ID, MARKET_RUN_ID, NOTIFICATION_NAME, NOTIFICATION_COMMENTS, 
    STATUS, CREATED_DTS, UPDATE_DTS, UPDATE_USER, MDS_FLOW_STATE, 
    MDS_RETRY_COUNT, MDS_PROCESS_AFTER, MDS_FLOW_START_DTS, MDS_FLOW_END_DTS, TRADE_DT)
 Values
   (MDS_NOTIFICATION_CTLID_SEQ.nextval, '16101300', '116101300', 'PUBLISHDARESULTS', NULL, 
    'WAITING-ON-OASIS', SYSDATE, SYSDATE , 'PTR', NULL, 
    0, NULL, NULL, NULL, NULL);

COMMIT;

-- check whether the record is in waiting state WAITING-ON-OASIS
select * from MDS_NOTIFICATION_CTL  where MARKET_RUN_ID= '116101300'

-- update the records to the READY state now. 
UPDATE  MDS_NOTIFICATION_CTL
SET  status = 'READY'
WHERE  MARKET_RUN_ID= '116101300'

-- Publish Da Ahead result should have gone and we should have seen RTM Market Opened already now. 
-- you should se DAIST FLow in active tab of the JBPM Process Instancs





-- MDS Data 

-- Take the DAM/TRADE id for the trade date above and CLOSE It with help of SOAP UI 
-- > CLOSE THE MARKETS  

16062500 216062500
16101300 216101300

SET DEFINE OFF;
Insert into MRKT_PLAN
   (MRKT_PLAN_ID, MRKT_RUN_ID, MRKT_DEFINITION_ID, MRKT_STATUS_TYPE_ID, MRKT_DT, 
    MRKT_HOUR, REC_STATUS, CREATED_BY, CREATED_DT, UPDATED_BY, 
    UPDATED_DT)
 Values
   ('16101300', '216101300', 3 , 5, TO_DATE('09/17/2015 17:52:52', 'MM/DD/YYYY HH24:MI:SS'), 
    '00', 'AUDIT', NULL, TO_DATE('09/01/2015 17:52:52', 'MM/DD/YYYY HH24:MI:SS'), NULL, 
    TO_DATE('09/01/2015 17:52:52', 'MM/DD/YYYY HH24:MI:SS'));
COMMIT;





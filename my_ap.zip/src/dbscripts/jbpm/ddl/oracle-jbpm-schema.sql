/* Formatted on 8/3/2016 10:29:55 PM (QP5 v5.240.12305.39446) */
SET ECHO ON
SET DEFINE OFF;

SPOOL jbpm_db_1_1_0_v80.log

ALTER SESSION SET CURRENT_SCHEMA=JBPM;


CREATE TABLE Attachment
(
   id                        NUMBER (19, 0) NOT NULL,
   accessType                NUMBER (10, 0),
   attachedAt                TIMESTAMP,
   attachmentContentId       NUMBER (19, 0) NOT NULL,
   contentType               VARCHAR2 (255 CHAR),
   name                      VARCHAR2 (255 CHAR),
   attachment_size           NUMBER (10, 0),
   attachedBy_id             VARCHAR2 (255 CHAR),
   TaskData_Attachments_Id   NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE AuditTaskImpl
(
   id                  NUMBER (19, 0) NOT NULL,
   activationTime      TIMESTAMP,
   actualOwner         VARCHAR2 (255 CHAR),
   createdBy           VARCHAR2 (255 CHAR),
   createdOn           TIMESTAMP,
   deploymentId        VARCHAR2 (255 CHAR),
   description         VARCHAR2 (255 CHAR),
   dueDate             TIMESTAMP,
   name                VARCHAR2 (255 CHAR),
   parentId            NUMBER (19, 0) NOT NULL,
   priority            NUMBER (10, 0) NOT NULL,
   processId           VARCHAR2 (255 CHAR),
   processInstanceId   NUMBER (19, 0) NOT NULL,
   processSessionId    NUMBER (19, 0) NOT NULL,
   status              VARCHAR2 (255 CHAR),
   taskId              NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE BAMTaskSummary
(
   pk                  NUMBER (19, 0) NOT NULL,
   createdDate         TIMESTAMP,
   duration            NUMBER (19, 0),
   endDate             TIMESTAMP,
   processInstanceId   NUMBER (19, 0) NOT NULL,
   startDate           TIMESTAMP,
   status              VARCHAR2 (255 CHAR),
   taskId              NUMBER (19, 0) NOT NULL,
   taskName            VARCHAR2 (255 CHAR),
   userId              VARCHAR2 (255 CHAR),
   OPTLOCK             NUMBER (10, 0),
   PRIMARY KEY (pk)
);

CREATE TABLE BooleanExpression
(
   id                          NUMBER (19, 0) NOT NULL,
   expression                  CLOB,
   TYPE                        VARCHAR2 (255 CHAR),
   Escalation_Constraints_Id   NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE Content
(
   id        NUMBER (19, 0) NOT NULL,
   content   BLOB,
   PRIMARY KEY (id)
);

CREATE TABLE ContextMappingInfo
(
   mappingId     NUMBER (19, 0) NOT NULL,
   CONTEXT_ID    VARCHAR2 (255 CHAR) NOT NULL,
   KSESSION_ID   NUMBER (19, 0) NOT NULL,
   OWNER_ID      VARCHAR2 (255 CHAR),
   OPTLOCK       NUMBER (10, 0),
   PRIMARY KEY (mappingId)
);

CREATE TABLE CorrelationKeyInfo
(
   keyId               NUMBER (19, 0) NOT NULL,
   name                VARCHAR2 (255 CHAR),
   processInstanceId   NUMBER (19, 0) NOT NULL,
   OPTLOCK             NUMBER (10, 0),
   PRIMARY KEY (keyId)
);

CREATE TABLE CorrelationPropertyInfo
(
   propertyId             NUMBER (19, 0) NOT NULL,
   name                   VARCHAR2 (255 CHAR),
   VALUE                  VARCHAR2 (255 CHAR),
   OPTLOCK                NUMBER (10, 0),
   correlationKey_keyId   NUMBER (19, 0),
   PRIMARY KEY (propertyId)
);

CREATE TABLE Deadline
(
   id                           NUMBER (19, 0) NOT NULL,
   deadline_date                TIMESTAMP,
   escalated                    NUMBER (5, 0),
   Deadlines_StartDeadLine_Id   NUMBER (19, 0),
   Deadlines_EndDeadLine_Id     NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE Delegation_delegates
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE DeploymentStore
(
   id               NUMBER (19, 0) NOT NULL,
   attributes       VARCHAR2 (255 CHAR),
   DEPLOYMENT_ID    VARCHAR2 (255 CHAR),
   deploymentUnit   CLOB,
   state            NUMBER (10, 0),
   updateDate       TIMESTAMP,
   PRIMARY KEY (id)
);

CREATE TABLE ErrorInfo
(
   id           NUMBER (19, 0) NOT NULL,
   MESSAGE      VARCHAR2 (255 CHAR),
   stacktrace   LONG,
   timestamp    TIMESTAMP,
   REQUEST_ID   NUMBER (19, 0) NOT NULL,
   PRIMARY KEY (id)
);

CREATE TABLE Escalation
(
   id                       NUMBER (19, 0) NOT NULL,
   name                     VARCHAR2 (255 CHAR),
   Deadline_Escalation_Id   NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE EventTypes
(
   InstanceId   NUMBER (19, 0) NOT NULL,
   element      VARCHAR2 (255 CHAR)
);

CREATE TABLE I18NText
(
   id                              NUMBER (19, 0) NOT NULL,
   language                        VARCHAR2 (255 CHAR),
   shortText                       VARCHAR2 (255 CHAR),
   text                            CLOB,
   Task_Subjects_Id                NUMBER (19, 0),
   Task_Names_Id                   NUMBER (19, 0),
   Task_Descriptions_Id            NUMBER (19, 0),
   Reassignment_Documentation_Id   NUMBER (19, 0),
   Notification_Subjects_Id        NUMBER (19, 0),
   Notification_Names_Id           NUMBER (19, 0),
   Notification_Documentation_Id   NUMBER (19, 0),
   Notification_Descriptions_Id    NUMBER (19, 0),
   Deadline_Documentation_Id       NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE NodeInstanceLog
(
   id                  NUMBER (19, 0) NOT NULL,
   connection          VARCHAR2 (255 CHAR),
   log_date            TIMESTAMP,
   externalId          VARCHAR2 (255 CHAR),
   nodeId              VARCHAR2 (255 CHAR),
   nodeInstanceId      VARCHAR2 (255 CHAR),
   nodeName            VARCHAR2 (255 CHAR),
   nodeType            VARCHAR2 (255 CHAR),
   processId           VARCHAR2 (255 CHAR),
   processInstanceId   NUMBER (19, 0) NOT NULL,
   TYPE                NUMBER (10, 0) NOT NULL,
   workItemId          NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE Notification
(
   DTYPE                         VARCHAR2 (31 CHAR) NOT NULL,
   id                            NUMBER (19, 0) NOT NULL,
   priority                      NUMBER (10, 0) NOT NULL,
   Escalation_Notifications_Id   NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE Notification_BAs
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE Notification_Recipients
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE Notification_email_header
(
   Notification_id   NUMBER (19, 0) NOT NULL,
   emailHeaders_id   NUMBER (19, 0) NOT NULL,
   mapkey            VARCHAR2 (255 CHAR) NOT NULL,
   PRIMARY KEY (Notification_id, mapkey)
);

CREATE TABLE OrganizationalEntity
(
   DTYPE   VARCHAR2 (31 CHAR) NOT NULL,
   id      VARCHAR2 (255 CHAR) NOT NULL,
   PRIMARY KEY (id)
);

CREATE TABLE PeopleAssignments_BAs
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE PeopleAssignments_ExclOwners
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE PeopleAssignments_PotOwners
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE PeopleAssignments_Recipients
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE PeopleAssignments_Stakeholders
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE ProcessInstanceInfo
(
   InstanceId                 NUMBER (19, 0) NOT NULL,
   lastModificationDate       TIMESTAMP,
   lastReadDate               TIMESTAMP,
   processId                  VARCHAR2 (255 CHAR),
   processInstanceByteArray   BLOB,
   startDate                  TIMESTAMP,
   state                      NUMBER (10, 0) NOT NULL,
   OPTLOCK                    NUMBER (10, 0),
   PRIMARY KEY (InstanceId)
);

CREATE TABLE ProcessInstanceLog
(
   id                           NUMBER (19, 0) NOT NULL,
   duration                     NUMBER (19, 0),
   end_date                     TIMESTAMP,
   externalId                   VARCHAR2 (255 CHAR),
   user_identity                VARCHAR2 (255 CHAR),
   outcome                      VARCHAR2 (255 CHAR),
   parentProcessInstanceId      NUMBER (19, 0),
   processId                    VARCHAR2 (255 CHAR),
   processInstanceDescription   VARCHAR2 (255 CHAR),
   processInstanceId            NUMBER (19, 0) NOT NULL,
   processName                  VARCHAR2 (255 CHAR),
   processVersion               VARCHAR2 (255 CHAR),
   start_date                   TIMESTAMP,
   status                       NUMBER (10, 0),
   PRIMARY KEY (id)
);

CREATE TABLE Reassignment
(
   id                            NUMBER (19, 0) NOT NULL,
   Escalation_Reassignments_Id   NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE Reassignment_potentialOwners
(
   task_id     NUMBER (19, 0) NOT NULL,
   entity_id   VARCHAR2 (255 CHAR) NOT NULL
);

CREATE TABLE RequestInfo
(
   id             NUMBER (19, 0) NOT NULL,
   commandName    VARCHAR2 (255 CHAR),
   deploymentId   VARCHAR2 (255 CHAR),
   executions     NUMBER (10, 0) NOT NULL,
   businessKey    VARCHAR2 (255 CHAR),
   MESSAGE        VARCHAR2 (255 CHAR),
   owner          VARCHAR2 (255 CHAR),
   requestData    BLOB,
   responseData   BLOB,
   retries        NUMBER (10, 0) NOT NULL,
   status         VARCHAR2 (255 CHAR),
   timestamp      TIMESTAMP,
   PRIMARY KEY (id)
);

CREATE TABLE SessionInfo
(
   id                     NUMBER (19, 0) NOT NULL,
   lastModificationDate   TIMESTAMP,
   rulesByteArray         BLOB,
   startDate              TIMESTAMP,
   OPTLOCK                NUMBER (10, 0),
   PRIMARY KEY (id)
);

CREATE TABLE Task
(
   id                   NUMBER (19, 0) NOT NULL,
   archived             NUMBER (5, 0),
   allowedToDelegate    VARCHAR2 (255 CHAR),
   description          VARCHAR2 (255 CHAR),
   formName             VARCHAR2 (255 CHAR),
   name                 VARCHAR2 (255 CHAR),
   priority             NUMBER (10, 0) NOT NULL,
   subTaskStrategy      VARCHAR2 (255 CHAR),
   subject              VARCHAR2 (255 CHAR),
   activationTime       TIMESTAMP,
   createdOn            TIMESTAMP,
   deploymentId         VARCHAR2 (255 CHAR),
   documentAccessType   NUMBER (10, 0),
   documentContentId    NUMBER (19, 0) NOT NULL,
   documentType         VARCHAR2 (255 CHAR),
   expirationTime       TIMESTAMP,
   faultAccessType      NUMBER (10, 0),
   faultContentId       NUMBER (19, 0) NOT NULL,
   faultName            VARCHAR2 (255 CHAR),
   faultType            VARCHAR2 (255 CHAR),
   outputAccessType     NUMBER (10, 0),
   outputContentId      NUMBER (19, 0) NOT NULL,
   outputType           VARCHAR2 (255 CHAR),
   parentId             NUMBER (19, 0) NOT NULL,
   previousStatus       NUMBER (10, 0),
   processId            VARCHAR2 (255 CHAR),
   processInstanceId    NUMBER (19, 0) NOT NULL,
   processSessionId     NUMBER (19, 0) NOT NULL,
   skipable             NUMBER (1, 0) NOT NULL,
   status               VARCHAR2 (255 CHAR),
   workItemId           NUMBER (19, 0) NOT NULL,
   taskType             VARCHAR2 (255 CHAR),
   OPTLOCK              NUMBER (10, 0),
   taskInitiator_id     VARCHAR2 (255 CHAR),
   actualOwner_id       VARCHAR2 (255 CHAR),
   createdBy_id         VARCHAR2 (255 CHAR),
   PRIMARY KEY (id)
);

CREATE TABLE TaskDef
(
   id         NUMBER (19, 0) NOT NULL,
   name       VARCHAR2 (255 CHAR),
   priority   NUMBER (10, 0) NOT NULL,
   PRIMARY KEY (id)
);

CREATE TABLE TaskEvent
(
   id                  NUMBER (19, 0) NOT NULL,
   logTime             TIMESTAMP,
   processInstanceId   NUMBER (19, 0),
   taskId              NUMBER (19, 0),
   TYPE                VARCHAR2 (255 CHAR),
   userId              VARCHAR2 (255 CHAR),
   OPTLOCK             NUMBER (10, 0),
   workItemId          NUMBER (19, 0),
   PRIMARY KEY (id)
);

CREATE TABLE VariableInstanceLog
(
   id                   NUMBER (19, 0) NOT NULL,
   log_date             TIMESTAMP,
   externalId           VARCHAR2 (255 CHAR),
   oldValue             VARCHAR2 (255 CHAR),
   processId            VARCHAR2 (255 CHAR),
   processInstanceId    NUMBER (19, 0) NOT NULL,
   VALUE                VARCHAR2 (255 CHAR),
   variableId           VARCHAR2 (255 CHAR),
   variableInstanceId   VARCHAR2 (255 CHAR),
   PRIMARY KEY (id)
);

CREATE TABLE WorkItemInfo
(
   workItemId          NUMBER (19, 0) NOT NULL,
   creationDate        TIMESTAMP,
   name                VARCHAR2 (255 CHAR),
   processInstanceId   NUMBER (19, 0) NOT NULL,
   state               NUMBER (19, 0) NOT NULL,
   OPTLOCK             NUMBER (10, 0),
   workItemByteArray   BLOB,
   PRIMARY KEY (workItemId)
);

CREATE TABLE email_header
(
   id               NUMBER (19, 0) NOT NULL,
   body             CLOB,
   fromAddress      VARCHAR2 (255 CHAR),
   language         VARCHAR2 (255 CHAR),
   replyToAddress   VARCHAR2 (255 CHAR),
   subject          VARCHAR2 (255 CHAR),
   PRIMARY KEY (id)
);

CREATE TABLE task_comment
(
   id                     NUMBER (19, 0) NOT NULL,
   addedAt                TIMESTAMP,
   text                   CLOB,
   addedBy_id             VARCHAR2 (255 CHAR),
   TaskData_Comments_Id   NUMBER (19, 0),
   PRIMARY KEY (id)
);

    ALTER TABLE Attachment
        ADD CONSTRAINT FK1C93543D937BFB5
        FOREIGN KEY (attachedBy_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE Attachment
        ADD CONSTRAINT FK1C9354333CA892A
        FOREIGN KEY (TaskData_Attachments_Id)
        REFERENCES Task;

    ALTER TABLE BooleanExpression
        ADD CONSTRAINT FKE3D208C06C97C90E
        FOREIGN KEY (Escalation_Constraints_Id)
        REFERENCES Escalation;

    ALTER TABLE CorrelationPropertyInfo
        ADD CONSTRAINT FK761452A5D87156ED
        FOREIGN KEY (correlationKey_keyId)
        REFERENCES CorrelationKeyInfo;

    ALTER TABLE Deadline
        ADD CONSTRAINT FK21DF3E78A9FE0EF4
        FOREIGN KEY (Deadlines_StartDeadLine_Id)
        REFERENCES Task;

    ALTER TABLE Deadline
        ADD CONSTRAINT FK21DF3E78695E4DDB
        FOREIGN KEY (Deadlines_EndDeadLine_Id)
        REFERENCES Task;

    ALTER TABLE Delegation_delegates
        ADD CONSTRAINT FK47485D5772B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE Delegation_delegates
        ADD CONSTRAINT FK47485D57786553A5
        FOREIGN KEY (task_id)
        REFERENCES Task;

    ALTER TABLE DeploymentStore
        ADD CONSTRAINT UK_DeploymentStore_1 UNIQUE (DEPLOYMENT_ID);

    ALTER TABLE ErrorInfo
        ADD CONSTRAINT FK8B1186B6724A467
        FOREIGN KEY (REQUEST_ID)
        REFERENCES RequestInfo;

    ALTER TABLE Escalation
        ADD CONSTRAINT FK67B2C6B5D1E5CC1
        FOREIGN KEY (Deadline_Escalation_Id)
        REFERENCES Deadline;

    ALTER TABLE EventTypes
        ADD CONSTRAINT FKB0E5621F7665489A
        FOREIGN KEY (InstanceId)
        REFERENCES ProcessInstanceInfo;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686BF4ACCD69
        FOREIGN KEY (Task_Subjects_Id)
        REFERENCES Task;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686B424B187C
        FOREIGN KEY (Task_Names_Id)
        REFERENCES Task;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686BAB648139
        FOREIGN KEY (Task_Descriptions_Id)
        REFERENCES Task;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686BB340A2AA
        FOREIGN KEY (Reassignment_Documentation_Id)
        REFERENCES Reassignment;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686BF0CDED35
        FOREIGN KEY (Notification_Subjects_Id)
        REFERENCES Notification;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686BCC03ED3C
        FOREIGN KEY (Notification_Names_Id)
        REFERENCES Notification;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686B77C1C08A
        FOREIGN KEY (Notification_Documentation_Id)
        REFERENCES Notification;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686B18DDFE05
        FOREIGN KEY (Notification_Descriptions_Id)
        REFERENCES Notification;

    ALTER TABLE I18NText
        ADD CONSTRAINT FK2349686B78AF072A
        FOREIGN KEY (Deadline_Documentation_Id)
        REFERENCES Deadline;

    ALTER TABLE Notification
        ADD CONSTRAINT FK2D45DD0BC0C0F29C
        FOREIGN KEY (Escalation_Notifications_Id)
        REFERENCES Escalation;

    ALTER TABLE Notification_BAs
        ADD CONSTRAINT FK2DD68EE072B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE Notification_BAs
        ADD CONSTRAINT FK2DD68EE093F2090B
        FOREIGN KEY (task_id)
        REFERENCES Notification;

    ALTER TABLE Notification_Recipients
        ADD CONSTRAINT FK98FD214E72B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE Notification_Recipients
        ADD CONSTRAINT FK98FD214E93F2090B
        FOREIGN KEY (task_id)
        REFERENCES Notification;

    ALTER TABLE Notification_email_header
        ADD CONSTRAINT UK_F30FE3446CEA0510 UNIQUE (emailHeaders_id);

    ALTER TABLE Notification_email_header
        ADD CONSTRAINT FKF30FE3448BED1339
        FOREIGN KEY (emailHeaders_id)
        REFERENCES email_header;

    ALTER TABLE Notification_email_header
        ADD CONSTRAINT FKF30FE3443E3E97EB
        FOREIGN KEY (Notification_id)
        REFERENCES Notification;

    ALTER TABLE PeopleAssignments_BAs
        ADD CONSTRAINT FK9D8CF4EC72B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE PeopleAssignments_BAs
        ADD CONSTRAINT FK9D8CF4EC786553A5
        FOREIGN KEY (task_id)
        REFERENCES Task;

    ALTER TABLE PeopleAssignments_ExclOwners
        ADD CONSTRAINT FKC77B97E472B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE PeopleAssignments_ExclOwners
        ADD CONSTRAINT FKC77B97E4786553A5
        FOREIGN KEY (task_id)
        REFERENCES Task;

    ALTER TABLE PeopleAssignments_PotOwners
        ADD CONSTRAINT FK1EE418D72B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE PeopleAssignments_PotOwners
        ADD CONSTRAINT FK1EE418D786553A5
        FOREIGN KEY (task_id)
        REFERENCES Task;

    ALTER TABLE PeopleAssignments_Recipients
        ADD CONSTRAINT FKC6F615C272B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE PeopleAssignments_Recipients
        ADD CONSTRAINT FKC6F615C2786553A5
        FOREIGN KEY (task_id)
        REFERENCES Task;

    ALTER TABLE PeopleAssignments_Stakeholders
        ADD CONSTRAINT FK482F79D572B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE PeopleAssignments_Stakeholders
        ADD CONSTRAINT FK482F79D5786553A5
        FOREIGN KEY (task_id)
        REFERENCES Task;

    ALTER TABLE Reassignment
        ADD CONSTRAINT FK724D056062A1E871
        FOREIGN KEY (Escalation_Reassignments_Id)
        REFERENCES Escalation;

    ALTER TABLE Reassignment_potentialOwners
        ADD CONSTRAINT FK90B59CFF72B3A123
        FOREIGN KEY (entity_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE Reassignment_potentialOwners
        ADD CONSTRAINT FK90B59CFF35D2FEE0
        FOREIGN KEY (task_id)
        REFERENCES Reassignment;

    ALTER TABLE Task
        ADD CONSTRAINT FK27A9A53C55C806
        FOREIGN KEY (taskInitiator_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE Task
        ADD CONSTRAINT FK27A9A5B723BE8B
        FOREIGN KEY (actualOwner_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE Task
        ADD CONSTRAINT FK27A9A55427E8F1
        FOREIGN KEY (createdBy_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE task_comment
        ADD CONSTRAINT FK61F475A57A3215D9
        FOREIGN KEY (addedBy_id)
        REFERENCES OrganizationalEntity;

    ALTER TABLE task_comment
        ADD CONSTRAINT FK61F475A5F510CB46
        FOREIGN KEY (TaskData_Comments_Id)
        REFERENCES Task;

CREATE SEQUENCE ATTACHMENT_ID_SEQ;

CREATE SEQUENCE AUDIT_ID_SEQ;

CREATE SEQUENCE BAM_TASK_ID_SEQ;

CREATE SEQUENCE BOOLEANEXPR_ID_SEQ;

CREATE SEQUENCE COMMENT_ID_SEQ;

CREATE SEQUENCE CONTENT_ID_SEQ;

CREATE SEQUENCE CONTEXT_MAPPING_INFO_ID_SEQ;

CREATE SEQUENCE CORRELATION_KEY_ID_SEQ;

CREATE SEQUENCE CORRELATION_PROP_ID_SEQ;

CREATE SEQUENCE DEADLINE_ID_SEQ;

CREATE SEQUENCE DEPLOY_STORE_ID_SEQ;

CREATE SEQUENCE EMAILNOTIFHEAD_ID_SEQ;

CREATE SEQUENCE ERROR_INFO_ID_SEQ;

CREATE SEQUENCE ESCALATION_ID_SEQ;

CREATE SEQUENCE I18NTEXT_ID_SEQ;

CREATE SEQUENCE NODE_INST_LOG_ID_SEQ;

CREATE SEQUENCE NOTIFICATION_ID_SEQ;

CREATE SEQUENCE PROCESS_INSTANCE_INFO_ID_SEQ;

CREATE SEQUENCE PROC_INST_LOG_ID_SEQ;

CREATE SEQUENCE REASSIGNMENT_ID_SEQ;

CREATE SEQUENCE REQUEST_INFO_ID_SEQ;

CREATE SEQUENCE SESSIONINFO_ID_SEQ;

CREATE SEQUENCE TASK_DEF_ID_SEQ;

CREATE SEQUENCE TASK_EVENT_ID_SEQ;

CREATE SEQUENCE TASK_ID_SEQ;

CREATE SEQUENCE VAR_INST_LOG_ID_SEQ;

CREATE SEQUENCE WORKITEMINFO_ID_SEQ;


CREATE INDEX IDX_Attachment_Id
   ON Attachment (attachedBy_id);

CREATE INDEX IDX_Attachment_DataId
   ON Attachment (TaskData_Attachments_Id);

CREATE INDEX IDX_BoolExpr_Id
   ON BooleanExpression (Escalation_Constraints_Id);

CREATE INDEX IDX_CorrPropInfo_Id
   ON CorrelationPropertyInfo (correlationKey_keyId);

CREATE INDEX IDX_Deadline_StartId
   ON Deadline (Deadlines_StartDeadLine_Id);

CREATE INDEX IDX_Deadline_EndId
   ON Deadline (Deadlines_EndDeadLine_Id);

CREATE INDEX IDX_Delegation_EntityId
   ON Delegation_delegates (entity_id);

CREATE INDEX IDX_Delegation_TaskId
   ON Delegation_delegates (task_id);

CREATE INDEX IDX_ErrorInfo_Id
   ON ErrorInfo (REQUEST_ID);

CREATE INDEX IDX_Escalation_Id
   ON Escalation (Deadline_Escalation_Id);

CREATE INDEX IDX_EventTypes_Id
   ON EventTypes (InstanceId);

CREATE INDEX IDX_I18NText_SubjId
   ON I18NText (Task_Subjects_Id);

CREATE INDEX IDX_I18NText_NameId
   ON I18NText (Task_Names_Id);

CREATE INDEX IDX_I18NText_DescrId
   ON I18NText (Task_Descriptions_Id);

CREATE INDEX IDX_I18NText_ReassignId
   ON I18NText (Reassignment_Documentation_Id);

CREATE INDEX IDX_I18NText_NotSubjId
   ON I18NText (Notification_Subjects_Id);

CREATE INDEX IDX_I18NText_NotDocId
   ON I18NText (Notification_Documentation_Id);

CREATE INDEX IDX_I18NText_NotDescrId
   ON I18NText (Notification_Descriptions_Id);

CREATE INDEX IDX_I18NText_DeadDocId
   ON I18NText (Deadline_Documentation_Id);

CREATE INDEX IDX_Not_EscId
   ON Notification (Escalation_Notifications_Id);

CREATE INDEX IDX_NotBAs_Entity
   ON Notification_BAs (entity_id);

CREATE INDEX IDX_NotBAs_Task
   ON Notification_BAs (task_id);

CREATE INDEX IDX_NotRec_Entity
   ON Notification_Recipients (entity_id);

CREATE INDEX IDX_NotRec_Task
   ON Notification_Recipients (task_id);

CREATE INDEX IDX_NotEmail_Not
   ON Notification_email_header (Notification_id);

CREATE INDEX IDX_PAsBAs_Entity
   ON PeopleAssignments_BAs (entity_id);

CREATE INDEX IDX_PAsBAs_Task
   ON PeopleAssignments_BAs (task_id);

CREATE INDEX IDX_PAsExcl_Entity
   ON PeopleAssignments_ExclOwners (entity_id);

CREATE INDEX IDX_PAsExcl_Task
   ON PeopleAssignments_ExclOwners (task_id);

CREATE INDEX IDX_PAsPot_Entity
   ON PeopleAssignments_PotOwners (entity_id);

CREATE INDEX IDX_PAsPot_Task
   ON PeopleAssignments_PotOwners (task_id);

CREATE INDEX IDX_PAsRecip_Entity
   ON PeopleAssignments_Recipients (entity_id);

CREATE INDEX IDX_PAsRecip_Task
   ON PeopleAssignments_Recipients (task_id);

CREATE INDEX IDX_PAsStake_Entity
   ON PeopleAssignments_Stakeholders (entity_id);

CREATE INDEX IDX_PAsStake_Task
   ON PeopleAssignments_Stakeholders (task_id);

CREATE INDEX IDX_Reassign_Esc
   ON Reassignment (Escalation_Reassignments_Id);

CREATE INDEX IDX_ReassignPO_Entity
   ON Reassignment_potentialOwners (entity_id);

CREATE INDEX IDX_ReassignPO_Task
   ON Reassignment_potentialOwners (task_id);

CREATE INDEX IDX_Task_Initiator
   ON Task (taskInitiator_id);

CREATE INDEX IDX_Task_ActualOwner
   ON Task (actualOwner_id);

CREATE INDEX IDX_Task_CreatedBy
   ON Task (createdBy_id);

CREATE INDEX IDX_TaskComments_CreatedBy
   ON task_comment (addedBy_id);

CREATE INDEX IDX_TaskComments_Id
   ON task_comment (TaskData_Comments_Id);

CREATE INDEX IDX_Task_processInstanceId
   ON Task (processInstanceId);

CREATE INDEX IDX_Task_processId
   ON Task (processId);

CREATE INDEX IDX_Task_status
   ON Task (status);

CREATE INDEX IDX_Task_archived
   ON Task (archived);

CREATE INDEX IDX_Task_workItemId
   ON Task (workItemId);

CREATE INDEX IDX_EventTypes_element
   ON EventTypes (element);

CREATE INDEX IDX_CMI_Context
   ON ContextMappingInfo (CONTEXT_ID);

CREATE INDEX IDX_CMI_KSession
   ON ContextMappingInfo (KSESSION_ID);

CREATE INDEX IDX_CMI_Owner
   ON ContextMappingInfo (OWNER_ID);

CREATE INDEX IDX_RequestInfo_status
   ON RequestInfo (status);

CREATE INDEX IDX_RequestInfo_timestamp
   ON RequestInfo (timestamp);

CREATE INDEX IDX_RequestInfo_owner
   ON RequestInfo (owner);

CREATE INDEX IDX_BAMTaskSumm_createdDate
   ON BAMTaskSummary (createdDate);

CREATE INDEX IDX_BAMTaskSumm_duration
   ON BAMTaskSummary (duration);

CREATE INDEX IDX_BAMTaskSumm_endDate
   ON BAMTaskSummary (endDate);

CREATE INDEX IDX_BAMTaskSumm_pInstId
   ON BAMTaskSummary (processInstanceId);

CREATE INDEX IDX_BAMTaskSumm_startDate
   ON BAMTaskSummary (startDate);

CREATE INDEX IDX_BAMTaskSumm_status
   ON BAMTaskSummary (status);

CREATE INDEX IDX_BAMTaskSumm_taskId
   ON BAMTaskSummary (taskId);

CREATE INDEX IDX_BAMTaskSumm_taskName
   ON BAMTaskSummary (taskName);

CREATE INDEX IDX_BAMTaskSumm_userId
   ON BAMTaskSummary (userId);

CREATE INDEX IDX_PInstLog_duration
   ON ProcessInstanceLog (duration);

CREATE INDEX IDX_PInstLog_end_date
   ON ProcessInstanceLog (end_date);

CREATE INDEX IDX_PInstLog_extId
   ON ProcessInstanceLog (externalId);

CREATE INDEX IDX_PInstLog_user_identity
   ON ProcessInstanceLog (user_identity);

CREATE INDEX IDX_PInstLog_outcome
   ON ProcessInstanceLog (outcome);

CREATE INDEX IDX_PInstLog_parentPInstId
   ON ProcessInstanceLog (parentProcessInstanceId);

CREATE INDEX IDX_PInstLog_pId
   ON ProcessInstanceLog (processId);

CREATE INDEX IDX_PInstLog_pInsteDescr
   ON ProcessInstanceLog (processInstanceDescription);

CREATE INDEX IDX_PInstLog_pInstId
   ON ProcessInstanceLog (processInstanceId);

CREATE INDEX IDX_PInstLog_pName
   ON ProcessInstanceLog (processName);

CREATE INDEX IDX_PInstLog_pVersion
   ON ProcessInstanceLog (processVersion);

CREATE INDEX IDX_PInstLog_start_date
   ON ProcessInstanceLog (start_date);

CREATE INDEX IDX_PInstLog_status
   ON ProcessInstanceLog (status);


--
-- A hint submitted by a user: Oracle DB MUST be created as "shared" and the
-- job_queue_processes parameter  must be greater than 2, otherwise a DB lock
-- will happen.   However, these settings are pretty much standard after any
-- Oracle install, so most users need not worry about this.
--
-- Many other users (including the primary author of Quartz) have had success
-- runing in dedicated mode, so only consider the above as a hint ;-)
--

CREATE TABLE qrtz_job_details
(
   JOB_NAME            VARCHAR2 (200) NOT NULL,
   JOB_GROUP           VARCHAR2 (200) NOT NULL,
   DESCRIPTION         VARCHAR2 (250) NULL,
   JOB_CLASS_NAME      VARCHAR2 (250) NOT NULL,
   IS_DURABLE          VARCHAR2 (1) NOT NULL,
   IS_VOLATILE         VARCHAR2 (1) NOT NULL,
   IS_STATEFUL         VARCHAR2 (1) NOT NULL,
   REQUESTS_RECOVERY   VARCHAR2 (1) NOT NULL,
   JOB_DATA            BLOB NULL,
   PRIMARY KEY (JOB_NAME, JOB_GROUP)
);

CREATE TABLE qrtz_job_listeners
(
   JOB_NAME       VARCHAR2 (200) NOT NULL,
   JOB_GROUP      VARCHAR2 (200) NOT NULL,
   JOB_LISTENER   VARCHAR2 (200) NOT NULL,
   PRIMARY KEY (JOB_NAME, JOB_GROUP, JOB_LISTENER),
   FOREIGN KEY
      (JOB_NAME, JOB_GROUP)
       REFERENCES QRTZ_JOB_DETAILS (JOB_NAME, JOB_GROUP)
);

CREATE TABLE qrtz_triggers
(
   TRIGGER_NAME     VARCHAR2 (200) NOT NULL,
   TRIGGER_GROUP    VARCHAR2 (200) NOT NULL,
   JOB_NAME         VARCHAR2 (200) NOT NULL,
   JOB_GROUP        VARCHAR2 (200) NOT NULL,
   IS_VOLATILE      VARCHAR2 (1) NOT NULL,
   DESCRIPTION      VARCHAR2 (250) NULL,
   NEXT_FIRE_TIME   NUMBER (13) NULL,
   PREV_FIRE_TIME   NUMBER (13) NULL,
   PRIORITY         NUMBER (13) NULL,
   TRIGGER_STATE    VARCHAR2 (16) NOT NULL,
   TRIGGER_TYPE     VARCHAR2 (8) NOT NULL,
   START_TIME       NUMBER (13) NOT NULL,
   END_TIME         NUMBER (13) NULL,
   CALENDAR_NAME    VARCHAR2 (200) NULL,
   MISFIRE_INSTR    NUMBER (2) NULL,
   JOB_DATA         BLOB NULL,
   PRIMARY KEY (TRIGGER_NAME, TRIGGER_GROUP),
   FOREIGN KEY
      (JOB_NAME, JOB_GROUP)
       REFERENCES QRTZ_JOB_DETAILS (JOB_NAME, JOB_GROUP)
);

CREATE TABLE qrtz_simple_triggers
(
   TRIGGER_NAME      VARCHAR2 (200) NOT NULL,
   TRIGGER_GROUP     VARCHAR2 (200) NOT NULL,
   REPEAT_COUNT      NUMBER (7) NOT NULL,
   REPEAT_INTERVAL   NUMBER (12) NOT NULL,
   TIMES_TRIGGERED   NUMBER (10) NOT NULL,
   PRIMARY KEY (TRIGGER_NAME, TRIGGER_GROUP),
   FOREIGN KEY
      (TRIGGER_NAME, TRIGGER_GROUP)
       REFERENCES QRTZ_TRIGGERS (TRIGGER_NAME, TRIGGER_GROUP)
);

CREATE TABLE qrtz_cron_triggers
(
   TRIGGER_NAME      VARCHAR2 (200) NOT NULL,
   TRIGGER_GROUP     VARCHAR2 (200) NOT NULL,
   CRON_EXPRESSION   VARCHAR2 (120) NOT NULL,
   TIME_ZONE_ID      VARCHAR2 (80),
   PRIMARY KEY (TRIGGER_NAME, TRIGGER_GROUP),
   FOREIGN KEY
      (TRIGGER_NAME, TRIGGER_GROUP)
       REFERENCES QRTZ_TRIGGERS (TRIGGER_NAME, TRIGGER_GROUP)
);

CREATE TABLE qrtz_blob_triggers
(
   TRIGGER_NAME    VARCHAR2 (200) NOT NULL,
   TRIGGER_GROUP   VARCHAR2 (200) NOT NULL,
   BLOB_DATA       BLOB NULL,
   PRIMARY KEY (TRIGGER_NAME, TRIGGER_GROUP),
   FOREIGN KEY
      (TRIGGER_NAME, TRIGGER_GROUP)
       REFERENCES QRTZ_TRIGGERS (TRIGGER_NAME, TRIGGER_GROUP)
);

CREATE TABLE qrtz_trigger_listeners
(
   TRIGGER_NAME       VARCHAR2 (200) NOT NULL,
   TRIGGER_GROUP      VARCHAR2 (200) NOT NULL,
   TRIGGER_LISTENER   VARCHAR2 (200) NOT NULL,
   PRIMARY KEY (TRIGGER_NAME, TRIGGER_GROUP, TRIGGER_LISTENER),
   FOREIGN KEY
      (TRIGGER_NAME, TRIGGER_GROUP)
       REFERENCES QRTZ_TRIGGERS (TRIGGER_NAME, TRIGGER_GROUP)
);

CREATE TABLE qrtz_calendars
(
   CALENDAR_NAME   VARCHAR2 (200) NOT NULL,
   CALENDAR        BLOB NOT NULL,
   PRIMARY KEY (CALENDAR_NAME)
);

CREATE TABLE qrtz_paused_trigger_grps
(
   TRIGGER_GROUP   VARCHAR2 (200) NOT NULL,
   PRIMARY KEY (TRIGGER_GROUP)
);

CREATE TABLE qrtz_fired_triggers
(
   ENTRY_ID            VARCHAR2 (95) NOT NULL,
   TRIGGER_NAME        VARCHAR2 (200) NOT NULL,
   TRIGGER_GROUP       VARCHAR2 (200) NOT NULL,
   IS_VOLATILE         VARCHAR2 (1) NOT NULL,
   INSTANCE_NAME       VARCHAR2 (200) NOT NULL,
   FIRED_TIME          NUMBER (13) NOT NULL,
   PRIORITY            NUMBER (13) NOT NULL,
   STATE               VARCHAR2 (16) NOT NULL,
   JOB_NAME            VARCHAR2 (200) NULL,
   JOB_GROUP           VARCHAR2 (200) NULL,
   IS_STATEFUL         VARCHAR2 (1) NULL,
   REQUESTS_RECOVERY   VARCHAR2 (1) NULL,
   PRIMARY KEY (ENTRY_ID)
);

CREATE TABLE qrtz_scheduler_state
(
   INSTANCE_NAME       VARCHAR2 (200) NOT NULL,
   LAST_CHECKIN_TIME   NUMBER (13) NOT NULL,
   CHECKIN_INTERVAL    NUMBER (13) NOT NULL,
   PRIMARY KEY (INSTANCE_NAME)
);

CREATE TABLE qrtz_locks
(
   LOCK_NAME   VARCHAR2 (40) NOT NULL,
   PRIMARY KEY (LOCK_NAME)
);


CREATE TABLE PATCH_APPLIED
(
   APP             VARCHAR2 (50 BYTE),
   APP_COMPONENT   VARCHAR2 (50 BYTE),
   PATCH_VERSION   VARCHAR2 (50 BYTE),
   APPLIED_DATE    DATE DEFAULT SYSDATE,
   HOST            VARCHAR2 (30 BYTE),
   INSTALLER       VARCHAR2 (50 BYTE),
   EXECUTED_AS     VARCHAR2 (50 BYTE),
   ACTION          VARCHAR2 (1 BYTE),
   SUCCESS_YN      VARCHAR2 (1 BYTE)
);




 
 

INSERT INTO qrtz_locks
     VALUES ('TRIGGER_ACCESS');

INSERT INTO qrtz_locks
     VALUES ('JOB_ACCESS');

INSERT INTO qrtz_locks
     VALUES ('CALENDAR_ACCESS');

INSERT INTO qrtz_locks
     VALUES ('STATE_ACCESS');

INSERT INTO qrtz_locks
     VALUES ('MISFIRE_ACCESS');

CREATE INDEX idx_qrtz_j_req_recovery
   ON qrtz_job_details (REQUESTS_RECOVERY);

CREATE INDEX idx_qrtz_t_next_fire_time
   ON qrtz_triggers (NEXT_FIRE_TIME);

CREATE INDEX idx_qrtz_t_state
   ON qrtz_triggers (TRIGGER_STATE);

CREATE INDEX idx_qrtz_t_nft_st
   ON qrtz_triggers (NEXT_FIRE_TIME, TRIGGER_STATE);

CREATE INDEX idx_qrtz_t_volatile
   ON qrtz_triggers (IS_VOLATILE);

CREATE INDEX idx_qrtz_ft_trig_name
   ON qrtz_fired_triggers (TRIGGER_NAME);

CREATE INDEX idx_qrtz_ft_trig_group
   ON qrtz_fired_triggers (TRIGGER_GROUP);

CREATE INDEX idx_qrtz_ft_trig_nm_gp
   ON qrtz_fired_triggers (TRIGGER_NAME, TRIGGER_GROUP);

CREATE INDEX idx_qrtz_ft_trig_volatile
   ON qrtz_fired_triggers (IS_VOLATILE);

CREATE INDEX idx_qrtz_ft_trig_inst_name
   ON qrtz_fired_triggers (INSTANCE_NAME);

CREATE INDEX idx_qrtz_ft_job_name
   ON qrtz_fired_triggers (JOB_NAME);

CREATE INDEX idx_qrtz_ft_job_group
   ON qrtz_fired_triggers (JOB_GROUP);

CREATE INDEX idx_qrtz_ft_job_stateful
   ON qrtz_fired_triggers (IS_STATEFUL);

CREATE INDEX idx_qrtz_ft_job_req_recovery
   ON qrtz_fired_triggers (REQUESTS_RECOVERY);

-- Insert patch history record for application 
INSERT INTO JBPM.PATCH_APPLIED (
   APP, APP_COMPONENT, PATCH_VERSION, 
   APPLIED_DATE, HOST, INSTALLER, 
   EXECUTED_AS, ACTION, SUCCESS_YN) 
VALUES ( 'JBPM',
 'DB-Jbpm6.2.0.Final',
 '1.1.0_b80',
  sysdate,
  sys_context('USERENV','TERMINAL'),
  sys_context('USERENV','OS_USER'),
  user,
 'I',
 'Y');
 



COMMIT;

SPOOL OFF;
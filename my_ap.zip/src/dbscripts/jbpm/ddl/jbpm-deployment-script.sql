SET DEFINE OFF;

update  DEPLOYMENTSTORE
   set STATE = 0
 WHERE DEPLOYMENT_ID = 'com.caiso.mdsbpm:mds-jbpm-kjar:1.1.0_b1' ;



Insert into DEPLOYMENTSTORE
   (ID, ATTRIBUTES, DEPLOYMENT_ID, DEPLOYMENTUNIT, STATE, 
    UPDATEDATE)
 Values
   (DEPLOY_STORE_ID_SEQ.nextval , NULL, 'com.caiso.mdsbpm:mds-jbpm-kjar:1.1.0_b2', '<org.jbpm.kie.services.impl.KModuleDeploymentUnit>
  <artifactId>mds-jbpm-kjar</artifactId>
  <groupId>com.caiso.mdsbpm</groupId>
  <version>1.1.0_b2</version>
  <kbaseName></kbaseName>
  <ksessionName></ksessionName>
  <strategy>SINGLETON</strategy>
  <mergeMode>MERGE_COLLECTIONS</mergeMode>
  <deploymentDescriptor class="org.jbpm.runtime.manager.impl.deploy.DeploymentDescriptorImpl">
    <persistenceUnit>org.jbpm.domain</persistenceUnit>
    <auditPersistenceUnit>org.jbpm.domain</auditPersistenceUnit>
    <auditMode>JPA</auditMode>
    <persistenceMode>JPA</persistenceMode>
    <runtimeStrategy>SINGLETON</runtimeStrategy>
    <marshallingStrategies class="linked-hash-set"/>
    <eventListeners class="linked-hash-set"/>
    <taskEventListeners class="linked-hash-set"/>
    <globals class="linked-hash-set"/>
    <workItemHandlers class="linked-hash-set">
      <org.kie.internal.runtime.conf.NamedObjectModel>
        <resolver>mvel</resolver>
        <identifier>new com.caiso.workitem.mds.mrkt.MDSWebServiceWorkItemHandler(ksession, classLoader)</identifier>
        <parameters/>
        <name>MDSWebServiceWIH</name>
      </org.kie.internal.runtime.conf.NamedObjectModel>
      <org.kie.internal.runtime.conf.NamedObjectModel>
        <resolver>mvel</resolver>
        <identifier>new org.jbpm.process.workitem.webservice.WebServiceWorkItemHandler(ksession, classLoader)</identifier>
        <parameters/>
        <name>WebService</name>
      </org.kie.internal.runtime.conf.NamedObjectModel>
      <org.kie.internal.runtime.conf.NamedObjectModel>
        <resolver>mvel</resolver>
        <identifier>new org.jbpm.process.instance.impl.demo.SystemOutWorkItemHandler()</identifier>
        <parameters/>
        <name>Log</name>
      </org.kie.internal.runtime.conf.NamedObjectModel>
      <org.kie.internal.runtime.conf.NamedObjectModel>
        <resolver>mvel</resolver>
        <identifier>new org.jbpm.process.workitem.bpmn2.ServiceTaskHandler(ksession, classLoader)</identifier>
        <parameters/>
        <name>Service Task</name>
      </org.kie.internal.runtime.conf.NamedObjectModel>
      <org.kie.internal.runtime.conf.NamedObjectModel>
        <resolver>mvel</resolver>
        <identifier>new org.jbpm.process.workitem.rest.RESTWorkItemHandler()</identifier>
        <parameters/>
        <name>Rest</name>
      </org.kie.internal.runtime.conf.NamedObjectModel>
    </workItemHandlers>
    <environmentEntries class="linked-hash-set"/>
    <configuration class="linked-hash-set"/>
    <requiredRoles class="linked-hash-set"/>
    <classes/>
    <mappedRoles>
      <entry>
        <string>execute</string>
        <linked-hash-set/>
      </entry>
      <entry>
        <string>view</string>
        <linked-hash-set/>
      </entry>
      <entry>
        <string>all</string>
        <linked-hash-set/>
      </entry>
    </mappedRoles>
  </deploymentDescriptor>
  <deployed>false</deployed>
  <strategyUnset>false</strategyUnset>
  <attributes/>
</org.jbpm.kie.services.impl.KModuleDeploymentUnit>', 0, 
    TO_TIMESTAMP('7/13/2016 6:29:18.027000 PM','fmMMfm/fmDDfm/YYYY fmHH12fm:MI:SS.FF AM'));
COMMIT;
